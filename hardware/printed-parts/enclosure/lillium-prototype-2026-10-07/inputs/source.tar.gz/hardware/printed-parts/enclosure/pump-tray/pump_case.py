"""Pump case — two-piece enclosure for a peristaltic pump.

Base: base plate with octagon-to-footprint ramp, octagon pump bore,
      and a cylindrical tower below.
Cap:  asymmetric flared skirt (wide on +Y, narrow on -Y) with a lower
      extension that tapers to uniform width.

The two parts mate at a stepped split surface and lock together with
snap-fit ramps on four interior walls.
"""

import math
import sys
from pathlib import Path

import cadquery as cq

_here = Path(__file__).resolve().parent
sys.path.insert(0, str(next(p for p in _here.parents if p.name == "printed-parts") / "cadlib"))
sys.path.insert(0, str(next(p for p in _here.parents if p.name == "hardware") / "scripts"))
sys.path.insert(0, str(next(p for p in _here.parents if (p / "tools" / "docgen").is_dir()) / "tools"))

from world_workplane import WorldWorkplane, xy_plane_z_up, xz_plane_y_up
from snap import Frame, apply_ramp_out_first, apply_ramp_in_first
from docgen import substitute_py_comments


# Physical dimensions
footprint_x = 70.0
footprint_y = 70.0
corner_r = 6.0
wall_thickness = 3.0

center_x = footprint_x / 2
center_y = footprint_y / 2
footprint_half_extent = footprint_x / 2

base_thickness = 3.0
ramp_from_skirt_to_octagon_height = 18.0

# Skirt
skirt_upper_height = 21.0
skirt_wall = wall_thickness
skirt_wide_flare_per_side = 3.0
skirt_narrow_taper_per_side = 4.0
skirt_wide_straight_height = 4.5
# The pump's skirt overhangs the narrower body by this much on the two X flanks. The cartridge
# joins them across Y- on the measured 5 mm land and supports all three on one horizontal plane.
skirt_support_band = skirt_narrow_taper_per_side

# Pump bore
bore_square_side = 43.0
ledge_depth = 1.5
ledge_shelf_span = 26.03

bore_half_diag = bore_square_side * math.sqrt(2) / 2
bore_half_span = 53.0 / 2

vertex_far = bore_half_span
vertex_near = bore_half_diag - bore_half_span

# Tower
tower_height = 60.0
tower_cap_thickness = 3.0
cylinder_id = 37.0
cylinder_r_inner = cylinder_id / 2

# Lower extension
lower_height = 23.0
lower_cap_thickness = 3.0
lower_footprint_straight = skirt_wide_straight_height

# Stepped split
step_height = 19.0
step_y_clearance = 6.0

# Snap fits
snap_zone_width = 20.0
snap_wall_height = 9.0
snap_deflection = 1.0

# Tube-casing arch notches: 13 mm openings on the physical casings' 59.75 mm pitch.
arch_radius = 6.5
arch_pitch = 59.75
arch_hole_xs = (center_x - arch_pitch / 2.0,
                center_x + arch_pitch / 2.0)


# Outer envelope of the assembled case, including the snaps and tubes
# that protrude past the bare base/cap solids.

# Snap protrudes past the footprint; silicone tubes extend past the case body.
snap_protrusion_per_side = 2.5
tube_protrusion_length = 11.3

# [75.0 mm](CASE_OUTER_X) is the full width of the assembled case
case_outer_x = footprint_x + 2 * snap_protrusion_per_side

# [87.3 mm](CASE_OUTER_Y) is the full depth of the assembled case, with the protruding tubes included
case_outer_y = (footprint_y + 2 * skirt_wide_flare_per_side
                + tube_protrusion_length)

# [135.5 mm](CASE_OUTER_Z) is the full height of the assembled case
case_outer_z = (base_thickness + ramp_from_skirt_to_octagon_height + tower_height
                + skirt_upper_height + skirt_wide_flare_per_side
                + skirt_wide_straight_height + lower_height + lower_cap_thickness)

# Half-extent of the stepped-split cutter slab.  Exceeds the case's X and
# Y footprint half-extents so the cut pierces through to free air on every
# side.
cutter_half_extent = max(case_outer_x, case_outer_y) / 2 + 5.0


# Slop added to cut depths so they pierce cleanly through sibling solid
# boundaries.
overcut = 0.1
# Polygonization count per quarter-circle for round-corner profiles.
arc_segments = 8


# Coordinate convention
# ---------------------
# Every `_y` and `_z` in this file is a signed world coordinate.
# Distances/heights/thicknesses are unsigned magnitudes.
#
# Origin is at the center of the case footprint, on the bore-opening
# face of the base plate.  +Z points toward the tower (away from the
# cap); -Z points toward the skirt top (toward the cap).  Construction
# uses the following cross-section levels:
#
#   z = [+81 mm](CYLINDER_BOTTOM_Z) — tower cylinder's far face
#   z = [+21 mm](BORE_BOTTOM_Z) — bore wall's far face (octagonal bore cavity ends here)
#   z = [+8 mm](CYLINDER_TOP_Z) — tower cylinder's near face
#   z = [+3 mm](BASE_PLATE_FAR_Z) — base plate's far face
#   z = 0 — base plate's bore-opening face — origin
#   z = [-9.5 mm](NARROW_SPLIT_Z) — narrow-half cap-side step (the stepped split)
#   z = [-28.5 mm](SKIRT_BOTTOM_Z) — skirt's wide-half mating edge with the cap
#   z = [-51.5 mm](LOWER_CAP_TOP_Z) — lower cap's interior face (cavity ends here)
#   z = [-54.5 mm](LOWER_CAP_BOTTOM_Z) — lower cap's exterior face (case's far end)

octagon_wall_outer_extent = vertex_far + wall_thickness

bore_depth = base_thickness + ramp_from_skirt_to_octagon_height
bore_bottom_z = bore_depth  # [+21 mm](BORE_BOTTOM_Z)

# Inward step from the cylinder to the octagonal bore wall at the
# cardinals.
cylinder_cardinal_step = 0.5
cylinder_r_outer = octagon_wall_outer_extent + cylinder_cardinal_step

# Cylinder's top Z, where its top edge is tangent to the base-plate
# ramp at the cardinals.
cylinder_top_z = footprint_half_extent + base_thickness - cylinder_r_outer  # [+8 mm](CYLINDER_TOP_Z)
cylinder_bottom_z = bore_bottom_z + tower_height  # [+81 mm](CYLINDER_BOTTOM_Z)


# Polygon generators

class Turtle:
    """Logo-style turtle that accumulates (x, y) polygon points."""

    def __init__(self, x, y, heading_deg):
        self.x = x
        self.y = y
        self.heading = math.radians(heading_deg)
        self.points = []

    def forward(self, dist):
        self.x += dist * math.cos(self.heading)
        self.y += dist * math.sin(self.heading)
        self.points.append((self.x, self.y))

    def left(self, deg):
        self.heading += math.radians(deg)

    def right(self, deg):
        self.heading -= math.radians(deg)


def bore_octagon_profile():
    """Pump bore octagon with ledge indentations, centered at origin."""
    vf = vertex_far
    vn = vertex_near

    vertices = [
        (vn, vf), (vf, vn), (vf, -vn), (vn, -vf),
        (-vn, -vf), (-vf, -vn), (-vf, vn), (-vn, vf),
    ]
    long_edge_indices = {0, 2, 4, 6}

    pts = []
    for i in range(8):
        start_x, start_y = vertices[i]
        end_x, end_y = vertices[(i + 1) % 8]
        pts.append((start_x, start_y))

        if i not in long_edge_indices:
            continue

        edge_dx, edge_dy = end_x - start_x, end_y - start_y
        edge_length = math.hypot(edge_dx, edge_dy)
        edge_heading = math.degrees(math.atan2(edge_dy, edge_dx))

        mid_x, mid_y = (start_x + end_x) / 2, (start_y + end_y) / 2
        unit_x, unit_y = edge_dx / edge_length, edge_dy / edge_length
        normal_x, normal_y = unit_y, -unit_x
        if normal_x * (-mid_x) + normal_y * (-mid_y) < 0:
            normal_x, normal_y = -normal_x, -normal_y
        inward_is_left = (normal_x * (-unit_y) + normal_y * unit_x) > 0

        ledge_ramp_length = ledge_depth * math.sqrt(2)
        entry_length = (edge_length - ledge_shelf_span) / 2
        shelf_length = ledge_shelf_span - 2 * ledge_depth

        t = Turtle(start_x, start_y, edge_heading)
        t.forward(entry_length)
        if inward_is_left:
            t.left(45); t.forward(ledge_ramp_length); t.right(45)
            t.forward(shelf_length)
            t.right(45); t.forward(ledge_ramp_length); t.left(45)
        else:
            t.right(45); t.forward(ledge_ramp_length); t.left(45)
            t.forward(shelf_length)
            t.left(45); t.forward(ledge_ramp_length); t.right(45)
        t.forward(entry_length)

        pts.extend(t.points[:-1])

    return pts


def _ring(section):
    """A section's own points with the first repeated, so the closing edge is DRAWN.

    `close()` infers it instead, from the last edge's end read back off OCCT — a few 1e-16 off
    the point that was passed in — and a tangential boolean downstream resolves that vertex one
    way in one process and the other way in the next. Naming the point is what makes the same
    source write the same bytes."""
    pts = list(section)
    return pts if pts[0] == pts[-1] else pts + [pts[0]]


def offset_polygon(pts, distance):
    """Offset each edge of a closed polygon outward by distance."""
    n = len(pts)

    edges = []
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        dx, dy = x2 - x1, y2 - y1
        length = math.hypot(dx, dy)
        nx, ny = -dy / length, dx / length
        edges.append((dx, dy, nx, ny))

    result = []
    for i in range(n):
        prev = (i - 1) % n
        ax = pts[prev][0] + distance * edges[prev][2]
        ay = pts[prev][1] + distance * edges[prev][3]
        adx, ady = edges[prev][0], edges[prev][1]

        bx = pts[i][0] + distance * edges[i][2]
        by = pts[i][1] + distance * edges[i][3]
        bdx, bdy = edges[i][0], edges[i][1]

        det = adx * bdy - ady * bdx
        if abs(det) < 1e-10:
            result.append((bx, by))
        else:
            t = ((bx - ax) * bdy - (by - ay) * bdx) / det
            result.append((ax + t * adx, ay + t * ady))

    return result


def rounded_rect_profile(width, height, radius, n=arc_segments):
    """Polygon points for a rounded rectangle centered at origin."""
    hw, hh = width / 2, height / 2
    pts = []
    corners = [
        (hw - radius, hh - radius, 0, 90),
        (-hw + radius, hh - radius, 90, 180),
        (-hw + radius, -hh + radius, 180, 270),
        (hw - radius, -hh + radius, 270, 360),
    ]
    for cx, cy, start_deg, end_deg in corners:
        for i in range(n + 1):
            angle = math.radians(start_deg + (end_deg - start_deg) * i / n)
            pts.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
    return pts


def split_skirt_profile(wide_half_extent, wide_radius,
                        narrow_half_extent, narrow_radius,
                        transition_y_plus=None, transition_y_minus=None,
                        wide_half_extent_y=None, narrow_half_extent_y=None,
                        n=arc_segments):
    """Asymmetric profile: wider on +Y, narrower on -Y, with diagonal transitions.

    A symmetric profile has one exact transition vertex on each side. The diagonal is born
    from that point at the next loft level; it is not approximated by a short edge."""
    wide_radius = max(wide_radius, 0.01)
    narrow_radius = max(narrow_radius, 0.01)
    if wide_half_extent_y is None:
        wide_half_extent_y = wide_half_extent
    if narrow_half_extent_y is None:
        narrow_half_extent_y = narrow_half_extent
    wide_corner_center_x = wide_half_extent - wide_radius
    wide_corner_center_y = wide_half_extent_y - wide_radius
    narrow_corner_center_x = narrow_half_extent - narrow_radius
    narrow_corner_center_y = narrow_half_extent_y - narrow_radius

    if transition_y_plus is None:
        transition_y_plus = (wide_half_extent - narrow_half_extent) / 2
    if transition_y_minus is None:
        transition_y_minus = -transition_y_plus

    pts = []

    for i in range(n + 1):
        a = math.radians(90 * i / n)
        pts.append((wide_corner_center_x + wide_radius * math.cos(a),
                    wide_corner_center_y + wide_radius * math.sin(a)))
    for i in range(n + 1):
        a = math.radians(90 + 90 * i / n)
        pts.append((-wide_corner_center_x + wide_radius * math.cos(a),
                    wide_corner_center_y + wide_radius * math.sin(a)))

    wide_transition = (-wide_half_extent, transition_y_plus)
    narrow_transition = (-narrow_half_extent, transition_y_minus)
    pts.append(wide_transition)
    if narrow_transition != wide_transition:
        pts.append(narrow_transition)

    for i in range(n + 1):
        a = math.radians(180 + 90 * i / n)
        pts.append((-narrow_corner_center_x + narrow_radius * math.cos(a),
                    -narrow_corner_center_y + narrow_radius * math.sin(a)))
    for i in range(n + 1):
        a = math.radians(270 + 90 * i / n)
        pts.append((narrow_corner_center_x + narrow_radius * math.cos(a),
                    -narrow_corner_center_y + narrow_radius * math.sin(a)))

    narrow_transition = (narrow_half_extent, transition_y_minus)
    wide_transition = (wide_half_extent, transition_y_plus)
    pts.append(narrow_transition)
    if wide_transition != narrow_transition:
        pts.append(wide_transition)

    return pts


# Bore profiles (shared by bore construction and tower)
bore_profile = bore_octagon_profile()
bore_wall_profile = offset_polygon(bore_profile, wall_thickness)


# Skirt profiles (shared by skirt, lower extension, the split, and snap fits).
#
# The skirt splits asymmetrically: +Y half flares outward ([70](FOOTPRINT_X)→[76](SKIRT_WIDE_WIDTH)), -Y half
# tapers inward ([70](FOOTPRINT_X)→[62](SKIRT_NARROW_WIDTH)). Both flares are at 45 degrees. The transition wall
# stays in a fixed vertical plane by tracking each endpoint's Y independently.
# The same profile set is used by the outer skirt surface and (shrunk by
# skirt_wall) by the inner cavity.

skirt_base_half_extent = footprint_half_extent
skirt_wide_half_extent = skirt_base_half_extent + skirt_wide_flare_per_side
skirt_narrow_half_extent = skirt_base_half_extent - skirt_narrow_taper_per_side
skirt_wide_full_width = 2 * skirt_wide_half_extent
skirt_narrow_full_width = 2 * skirt_narrow_half_extent
# At the moment the wide flare completes ([3mm](SKIRT_WIDE_FLARE)), the narrow side
# has only tapered by [3mm](SKIRT_WIDE_FLARE) of its [4mm](SKIRT_NARROW_TAPER).
skirt_mid_narrow_half_extent = skirt_base_half_extent - skirt_wide_flare_per_side

# Both skirt halves terminate at skirt_bottom_z; the narrow side's deeper
# taper leaves it a correspondingly shorter straight section.
skirt_narrow_straight_height = (
    skirt_wide_straight_height
    - (skirt_narrow_taper_per_side - skirt_wide_flare_per_side)
)

# Transition Y coordinates at the two genuinely split profiles. Together with each symmetric
# profile's one exact collapse point, they keep the seam wall in one vertical 45-degree plane
# as the +Y half flares and the -Y half tapers at different rates.
skirt_transition_y_mid = (skirt_wide_flare_per_side, -skirt_wide_flare_per_side)
skirt_transition_y_end = (skirt_wide_flare_per_side, -skirt_narrow_taper_per_side)
skirt_transition_y_end_plus = skirt_transition_y_end[0]

# Signed world-Z deltas between the five skirt cross-section levels.
# Each entry is negative because the skirt grows from z=0 (base plate)
# toward more negative Z (away from the bore, toward the cap).
skirt_z_steps = [
    -skirt_upper_height,
    -skirt_wide_flare_per_side,
    -(skirt_narrow_taper_per_side - skirt_wide_flare_per_side),
    -skirt_narrow_straight_height,
]
skirt_bottom_z = sum(skirt_z_steps)  # [-28.5 mm](SKIRT_BOTTOM_Z), case's wide-half mating edge with the cap

# Z level of the cap-side stepped split — narrow half (-Y) meets the cap
# step_height higher into the skirt than the wide half (+Y).
narrow_split_z = skirt_bottom_z + step_height  # [-9.5 mm](NARROW_SPLIT_Z)

# The lower extension's own ramp: the wide half comes in from the skirt's flare to the narrow
# half's width, at 45 degrees like every other flare on this case.  It runs one
# lower_footprint_straight under the skirt's bottom, so the case's two flank ramps stand at
# different depths and in opposite halves.
lower_ramp_height = (skirt_base_half_extent + skirt_wide_flare_per_side
                     - skirt_narrow_half_extent)

# Lower cap Z anchors. The lower extension is a hollow shell from
# skirt_bottom_z to lower_cap_top_z; the closing wall (the "lower cap")
# fills lower_cap_top_z..lower_cap_bottom_z. lower_cap_bottom_z is the
# case's outermost face on the -Z end.
lower_cap_top_z = skirt_bottom_z - lower_height  # [-51.5 mm](LOWER_CAP_TOP_Z)
lower_cap_bottom_z = lower_cap_top_z - lower_cap_thickness  # [-54.5 mm](LOWER_CAP_BOTTOM_Z)

# World Y of the case's +Y outer face.
pos_y_face_y = center_y + footprint_half_extent


def _skirt_profile_set(wall_offset):
    """Five skirt cross-section profiles, top-of-skirt to bottom-of-skirt."""
    # Shift of the transition Y values that holds the inner seam plane a full
    # perpendicular wall_offset inward from the outer, the seam at 45 deg in XY.
    seam_y_shift = wall_offset * (math.sqrt(2) - 1)

    base_he = skirt_base_half_extent - wall_offset
    wide_he = skirt_wide_half_extent - wall_offset
    narrow_he = skirt_narrow_half_extent - wall_offset
    mid_narrow_he = skirt_mid_narrow_half_extent - wall_offset
    radius = corner_r - wall_offset

    ty_symmetric = seam_y_shift
    ty_mid_plus = skirt_transition_y_mid[0] + seam_y_shift
    ty_mid_minus = skirt_transition_y_mid[1] + seam_y_shift
    ty_end_plus = skirt_transition_y_end[0] + seam_y_shift
    ty_end_minus = skirt_transition_y_end[1] + seam_y_shift

    symmetric = split_skirt_profile(
        base_he, radius, base_he, radius,
        ty_symmetric, ty_symmetric,
    )
    mid = split_skirt_profile(
        wide_he, radius, mid_narrow_he, radius,
        ty_mid_plus, ty_mid_minus,
        wide_half_extent_y=base_he, narrow_half_extent_y=base_he,
    )
    end = split_skirt_profile(
        wide_he, radius, narrow_he, radius,
        ty_end_plus, ty_end_minus,
        wide_half_extent_y=base_he, narrow_half_extent_y=base_he,
    )
    return [symmetric, symmetric, mid, end, end]


skirt_outer_profiles = _skirt_profile_set(0)
skirt_inner_profiles = _skirt_profile_set(skirt_wall)


def build_base_plate_with_ramp():
    """Base plate (z=0..[+3 mm](BASE_PLATE_FAR_Z)) plus the 45° ramp (z=[+3 mm](BASE_PLATE_FAR_Z)..[+21 mm](BORE_BOTTOM_Z)) shrinking from
    the [70](FOOTPRINT_X)x[70](FOOTPRINT_X) footprint to a [34](RAMP_BOTTOM_WIDTH)x[34](RAMP_BOTTOM_WIDTH) footprint that meets the octagon bore wall."""
    footprint = rounded_rect_profile(footprint_x, footprint_y, corner_r)
    footprint_at_ramp_bottom = rounded_rect_profile(
        footprint_x - 2 * ramp_from_skirt_to_octagon_height,
        footprint_y - 2 * ramp_from_skirt_to_octagon_height,
        corner_r)

    return (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=0)
        .center(center_x, center_y)
        .polyline(_ring(footprint)).wire()
        .workplane(offset=base_thickness)
        .polyline(_ring(footprint)).wire()
        .workplane(offset=ramp_from_skirt_to_octagon_height)
        .polyline(_ring(footprint_at_ramp_bottom)).wire()
        .loft(ruled=True)
    )


def add_bore_wall(solid):
    """Octagonal bore wall around the pump-flange seat, unioned onto solid."""
    bore_wall = (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=0)
        .center(center_x, center_y)
        .polyline(_ring(bore_wall_profile)).wire()
        .extrude(bore_depth)
    )
    return solid.union(bore_wall)


def cut_bore_cavity(solid):
    """Octagonal pump-flange seat (with ledges) cut through the bore wall
    and the tower cylinder material overlapping the bore-wall region."""
    bore_cavity = (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=0)
        .center(center_x, center_y)
        .polyline(_ring(bore_profile)).wire()
        .extrude(bore_depth + overcut)
    )
    return solid.cut(bore_cavity)


def loft_profile_stack(start_world_z, z_steps, profiles, overcut_last_step=False):
    """Loft a stack of skirt profiles at successive world-Z levels.

    start_world_z: world Z of the first profile.
    z_steps: signed world-Z deltas between consecutive profiles.
    overcut_last_step: extend the last delta by overcut in the same
        direction as the loft's travel, so a cut profile pierces cleanly
        through a sibling solid boundary.

    The symmetric outline has one transition vertex on each side; the asymmetric outline has
    the two ends of its diagonal. That is a real topology change: one vertex opens into one edge.
    OpenCascade's generic through-sections loft cannot make the ruled solid from unequal wires,
    so state that correspondence directly. Every ordinary edge makes one ruled face; at each
    transition the collapsed vertex and the next outline's edge make one triangle. Top, bottom
    and those side faces are one shell — no epsilon edge and no Boolean seam between half-solids.
    """
    if len(profiles) != len(z_steps) + 1:
        raise ValueError("a profile stack needs one more outline than Z steps")

    levels = []
    z = start_world_z
    levels.append([cq.Vector(center_x + x, center_y + y, z) for x, y in profiles[0]])
    for i, (step, profile) in enumerate(zip(z_steps, profiles[1:])):
        is_last = i == len(z_steps) - 1
        extra = math.copysign(overcut, step) if (overcut_last_step and is_last) else 0
        z += step + extra
        levels.append([cq.Vector(center_x + x, center_y + y, z) for x, y in profile])

    def closed_wire(points):
        return cq.Wire.makePolygon(points, close=True)

    faces = [cq.Face.makeFromWires(closed_wire(levels[0])),
             cq.Face.makeFromWires(closed_wire(levels[-1]))]
    collapsed_count = 4 * (arc_segments + 1) + 2
    split_count = collapsed_count + 2
    collapse_i = 2 * (arc_segments + 1)

    def aligned(points):
        if len(points) == split_count:
            return points
        if len(points) != collapsed_count:
            raise ValueError(
                f"a skirt outline has {len(points)} vertices, expected "
                f"{collapsed_count} collapsed or {split_count} split")
        # Repeat each collapsed point only in this correspondence list. No edge is made from
        # either repetition: `_side_face` below turns its mate into the one triangular face.
        return (points[:collapse_i + 1] + [points[collapse_i]]
                + points[collapse_i + 1:] + [points[-1]])

    def side_face(a0, a1, b0, b1):
        if (a1 - a0).Length < 1e-10:
            return cq.Face.makeFromWires(closed_wire((a0, b0, b1)))
        if (b1 - b0).Length < 1e-10:
            return cq.Face.makeFromWires(closed_wire((a0, a1, b0)))
        return cq.Face.makeRuledSurface(cq.Edge.makeLine(a0, a1),
                                        cq.Edge.makeLine(b0, b1))

    for upper, lower in zip(levels, levels[1:]):
        a, b = aligned(upper), aligned(lower)
        for i in range(split_count):
            j = (i + 1) % split_count
            faces.append(side_face(a[i], a[j], b[i], b[j]))

    solid = cq.Solid.makeSolid(cq.Shell.makeShell(faces)).fix()
    if not solid.isValid() or len(solid.Solids()) != 1:
        raise ValueError("the exact skirt loft did not make one valid solid")
    # Keep the project wrapper at the API boundary so later unions/cuts unwrap their operands
    # before CadQuery's strict Workplane type check.
    return WorldWorkplane(cq.Workplane(obj=solid))


def build_skirt():
    """Asymmetric flared skirt: wide on +Y, narrow on -Y."""
    skirt_outer = loft_profile_stack(0, skirt_z_steps, skirt_outer_profiles)
    skirt_cavity = loft_profile_stack(0, skirt_z_steps, skirt_inner_profiles, overcut_last_step=True)
    return skirt_outer.cut(skirt_cavity)


def build_tower():
    """Cylindrical tower extending downward from cylinder_top_z. Its outer
    radius circumscribes the octagonal bore wall, overlapping it on the
    outside from above the bore wall's far face."""
    tower_cylinder = (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=cylinder_top_z)
        .center(center_x, center_y)
        .circle(cylinder_r_outer)
        .extrude(cylinder_bottom_z - cylinder_top_z)
    )

    tower_bore_depth = tower_height - tower_cap_thickness
    tower_bore = (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=bore_bottom_z - overcut)
        .center(center_x, center_y)
        .circle(cylinder_r_inner)
        .extrude(tower_bore_depth + overcut)
    )
    return tower_cylinder.cut(tower_bore)


def _lower_profile_set(wall_offset):
    """Four lower-extension cross-section profiles, top to bottom of lower section."""
    seam_y_shift = wall_offset * (math.sqrt(2) - 1)
    narrow_he = skirt_narrow_half_extent - wall_offset
    base_he = skirt_base_half_extent - wall_offset
    radius = corner_r - wall_offset
    ty_end_minus = skirt_transition_y_end[1] + seam_y_shift
    narrow_symmetric = split_skirt_profile(
        narrow_he, radius, narrow_he, radius,
        ty_end_minus, ty_end_minus,
        wide_half_extent_y=base_he, narrow_half_extent_y=base_he,
    )
    top = _skirt_profile_set(wall_offset)[-1]
    return [top, top, narrow_symmetric, narrow_symmetric]


def lower_z_steps():
    """Signed world-Z deltas between the lower extension's four cross-section levels:
    straight off the skirt, the wide half's ramp, then uniform to the cap."""
    uniform = lower_height - lower_ramp_height - lower_footprint_straight
    # Lower extension extends in -Z, away from the base plate.
    return [-lower_footprint_straight, -lower_ramp_height, -uniform]


def flank_ramp_bands():
    """THE TWO BANDS THE CAVITY CLOSES IN ON A HEAD OVER, each (top_z, bottom_z).

    The skirt tapers its NARROW half (-Y) over the first and the lower extension ramps its
    WIDE half (+Y) over the second, both at 45 degrees.  Everywhere else the room round a head
    is plumb, so these two bands are the only levels where the case can bear DOWN on the part
    — and what stands in them is the surface a case carries a pump on."""
    aft_top = skirt_bottom_z - lower_footprint_straight
    return ((sum(skirt_z_steps[:1]), sum(skirt_z_steps[:3])),
            (aft_top, aft_top - lower_ramp_height))


def _profile_prism(profile, z0, z1):
    """One stated case profile carried vertically between two exact Z planes."""
    return (WorldWorkplane(xy_plane_z_up)
            .workplane(offset=z0)
            .center(center_x, center_y)
            .polyline(_ring(profile)).wire()
            .extrude(z1 - z0))


def _stepped_skirt_y_mask(z0, z1, body_y_bounds):
    """The one rectangular Y interval occupied by the body below the skirt."""
    y_min, y_max = body_y_bounds
    if not y_min < y_max:
        raise ValueError(f"bad skirt-body Y interval {body_y_bounds}")
    x0 = center_x - cutter_half_extent
    return (cq.Workplane("XY")
            .box(2.0 * cutter_half_extent,
                 y_max - y_min,
                 z1 - z0, centered=False)
            .translate((x0, center_y + y_min, z0)))


def stepped_skirt_cavity(air, support_z, body_y_bounds, skirt_y_max):
    """The head room with the skirt transition made as one flat three-sided step.

    Above ``support_z`` the room keeps the skirt's symmetric upper outline. Below it the room
    immediately takes the narrower body outline and retains that outline to the lower extension.
    Their difference is one continuous land on the X-, X+ and Y- flanks at ``support_z``:
    4 mm on X and 5 mm on Y-. Closing the measured ``body_y_bounds`` adds the 3.482 mm Y+ land;
    the cartridge's separate tube passages later leave only its centre bridge.
    """
    if not skirt_bottom_z < support_z < 0.0:
        raise ValueError(
            f"a skirt support at {support_z:g} must lie between "
            f"{skirt_bottom_z:g} and 0 mm")
    offset = skirt_wall - air
    upper = _skirt_profile_set(offset)[1]
    lower = _skirt_profile_set(offset)[3]
    room = cavity(air).val()
    lower_mask = _profile_prism(
        lower, lower_cap_top_z - overcut, support_z).val()
    y_mask = _stepped_skirt_y_mask(
        lower_cap_top_z - overcut, support_z, body_y_bounds).val()
    lower_room = room.intersect(lower_mask).intersect(y_mask)
    upper_room = _profile_prism(upper, support_z, 0.0).val().intersect(
        _stepped_skirt_y_mask(
            support_z, 0.0, (-cutter_half_extent, skirt_y_max)).val())
    return cq.Workplane(obj=upper_room.fuse(lower_room))


def stepped_skirt_drop_well(air, support_z, body_y_bounds, skirt_y_max):
    """``stepped_skirt_cavity`` swept toward the bracket plane for Z insertion."""
    offset = skirt_wall - air
    upper = _skirt_profile_set(offset)[1]
    lower = _skirt_profile_set(offset)[3]
    swept = drop_well(air).val()
    lower_mask = _profile_prism(
        lower, lower_cap_top_z - overcut, support_z).val()
    y_mask = _stepped_skirt_y_mask(
        lower_cap_top_z - overcut, support_z, body_y_bounds).val()
    lower_room = swept.intersect(lower_mask).intersect(y_mask)
    # The completed split outline is wider on +Y than the upper outline. Carry that side
    # upward as the physical lower skirt does during insertion; on -Y it is contained and the
    # flat support land remains intact.
    upper_room = _profile_prism(upper, support_z, 0.0).union(
        _profile_prism(lower, support_z, 0.0)).val().intersect(
            _stepped_skirt_y_mask(
                support_z, 0.0, (-cutter_half_extent, skirt_y_max)).val())
    return cq.Workplane(obj=upper_room.fuse(lower_room))


def cavity(air=0.0):
    """THE ROOM THE CASE LEAVES A HEAD — the skirt's interior and the lower extension's, as
    one solid in the case's own world frame, opened `air` on every face.

    It is not a prism.  `flank_ramp_bands` is where it closes in, and a head shaped to it
    (`kamoer_kphm400.build_head`) carries a 45 degree face on each side at each band, looking
    down and outboard. The complete two-piece bench case closes on those fitted faces.

    AND IT IS NOT SQUARE IN PLAN EITHER. The skirt is split in Y and its two halves are
    different widths: `skirt_narrow_half_extent` on -Y and `skirt_wide_half_extent` on +Y,
    which is the OUTLET side.  The flare is a HALF-EXTENT and not a Y offset, so the wide half
    stands further out ACROSS as well — 70.0 mm of room at the outlet face, 64.0 at the centre,
    56.0 at the narrow end.  The complete pump stands widest at that same outlet face, across
    its two tube fittings (`kamoer_kphm400.outlet_span_x`).

    `air` grows every face by walking the profile stack out, so the running fit is struck the
    way the case's own wall is and every radius opens with it."""
    offset = skirt_wall - air
    skirt = loft_profile_stack(0, skirt_z_steps, _skirt_profile_set(offset))
    lower = loft_profile_stack(skirt_bottom_z, lower_z_steps(),
                               _lower_profile_set(offset))
    return skirt.union(lower)


def drop_well(air=0.0):
    """THE ROOM A PUMP NEEDS TO BE LOWERED THROUGH, not just to stand in — `cavity` swept
    along its own axis toward the crown, in the case's world frame.

    Every station stands at least as open as the widest one under it: 70.0 mm from the flared
    outlet band up through the crown, and `cavity`'s own figure below that band.

    THE SWEEP IS EACH STATED OUTLINE CARRIED UP TO THE CROWN. `_stack_levels` is every Z the
    cavity states a section on and `_stack_profiles` the outline standing there. Between them
    each half changes monotonically and their exact collapse/transition vertices stay on one
    fixed 45-degree seam plane. The ruled cavity carries that change through its own band; once
    a half reaches its extremal stated outline, that outline's crown prism carries it through
    the rest of the insertion path. No sampled staircase stands in the fitting openings.

    `cavity`'s fitted faces stand under their own bands and this leaves them there."""
    solid = cavity(air)
    for z, profile in zip(_stack_levels(), _stack_profiles(skirt_wall - air)):
        if z >= -1e-9:
            continue
        # Struck the way `loft_profile_stack` strikes the same outlines: a profile is stated
        # about the origin and stands on the footprint's own centre.
        solid = solid.union(
            WorldWorkplane(xy_plane_z_up).workplane(offset=z).center(center_x, center_y)
            .polyline(_ring(profile)).wire().extrude(-z))
    return solid


def _stack_levels():
    """Every Z the cavity states a cross-section on, crown first — the skirt's five and the
    lower extension's four, which share the plane between them."""
    out, z = [0.0], 0.0
    for dz in skirt_z_steps:
        z += dz
        out.append(z)
    for dz in lower_z_steps():
        z += dz
        out.append(z)
    return out


def _stack_profiles(offset):
    """The outlines that stand on `_stack_levels`, in the same order. The lower extension's
    first profile IS the skirt's last, so it is not repeated."""
    return list(_skirt_profile_set(offset)) + list(_lower_profile_set(offset))[1:]


def build_lower_extension():
    """Lower portion extending from skirt bottom: taper to uniform, then cap."""
    lower_outer_profiles = _lower_profile_set(0)
    lower_inner_profiles = _lower_profile_set(skirt_wall)

    steps = lower_z_steps()
    lower_outer = loft_profile_stack(skirt_bottom_z, steps, lower_outer_profiles)
    lower_inner = loft_profile_stack(skirt_bottom_z, steps, lower_inner_profiles,
                                     overcut_last_step=True)
    lower_shell = lower_outer.cut(lower_inner)

    lower_cap = (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=lower_cap_top_z)
        .center(center_x, center_y)
        .polyline(_ring(lower_outer_profiles[-1])).wire()
        .extrude(-lower_cap_thickness)
    )
    return lower_shell.union(lower_cap)


def cut_arch_notches(combined):
    """Semicircular notches on the +Y face for wire routing."""
    arch_cut_depth = skirt_wall + wall_thickness
    for ax in arch_hole_xs:
        arch_cutter = (
            WorldWorkplane(xz_plane_y_up)
            .workplane(offset=pos_y_face_y + overcut)
            .center(ax, skirt_bottom_z)
            .circle(arch_radius)
            .extrude(-(arch_cut_depth + overcut))
        )
        combined = combined.cut(arch_cutter)
    return combined


def split_into_base_and_cap(combined):
    """Stepped split creating base (with tower) and cap (with lower extension).

    The two parts meet at two different Z levels:
      Wide half (+Y):   at skirt_bottom_z
      Narrow half (-Y): step_height higher into the skirt
    The boundary follows the seam diagonal.
    """
    lower_end_z = lower_cap_bottom_z - overcut

    full_slab = (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=skirt_bottom_z)
        .center(center_x, center_y)
        .rect(2 * cutter_half_extent, 2 * cutter_half_extent)
        .extrude(lower_end_z - skirt_bottom_z)
    )

    step_y = skirt_transition_y_end_plus + step_y_clearance
    narrow_box = [
        (-cutter_half_extent, -cutter_half_extent),
        (cutter_half_extent, -cutter_half_extent),
        (cutter_half_extent, step_y + overcut),
        (-cutter_half_extent, step_y + overcut),
    ]
    narrow_step = (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=narrow_split_z)
        .center(center_x, center_y)
        .polyline(_ring(narrow_box)).wire()
        .extrude(skirt_bottom_z - narrow_split_z)
    )

    step_cutter = full_slab.union(narrow_step)

    base = combined.cut(step_cutter)
    cap = combined.intersect(step_cutter)
    return base, cap


def add_snap_fits(base, cap):
    """Snap-fit ramps on four interior walls where base meets cap.

    The base wall grows a ramp_out_first zigzag; the cap wall grows the
    complementary ramp_in_first zigzag. The two interleave across the split,
    their tips reaching past the mating plane to wrap around each other and
    lock the halves together — the solids slide past without interpenetrating.

    Each snap grows along Z from its split plane. The +Y wide-split snap sits
    on the flared face; the -Y, +X, -X snaps sit on the narrow-split faces.
    """
    snap_plus_y_inner = pos_y_face_y - wall_thickness
    snap_minus_y_inner = center_y - footprint_half_extent + wall_thickness
    snap_plus_x_inner = center_x + footprint_half_extent - wall_thickness
    snap_minus_x_inner = center_x - footprint_half_extent + wall_thickness

    # ±Y snaps extrude along X (plane YZ, +X normal); zone spans X about center.
    yz_zone_range = (center_x - snap_zone_width / 2, center_x + snap_zone_width / 2)
    # ±X snaps extrude along Y (plane ZX, +Y normal); zone spans Y from just
    # inside the narrow-face corner.
    zx_zone_start = center_y - skirt_narrow_half_extent + corner_r + 0.5
    zx_zone_range = (zx_zone_start, zx_zone_start + snap_zone_width)

    snap_faces = [
        (snap_plus_y_inner, +1, skirt_bottom_z, "YZ", yz_zone_range),
        (snap_minus_y_inner, -1, narrow_split_z, "YZ", yz_zone_range),
        (snap_plus_x_inner, +1, narrow_split_z, "ZX", zx_zone_range),
        (snap_minus_x_inner, -1, narrow_split_z, "ZX", zx_zone_range),
    ]

    for inner_face, sign, split_z, plane, zone_range in snap_faces:
        base_frame = Frame(extrusion_plane=plane, outward_sign=sign,
                           up_axis="Z", up_sign=-1)
        cap_frame = Frame(extrusion_plane=plane, outward_sign=sign,
                          up_axis="Z", up_sign=+1)
        base = apply_ramp_out_first(
            base,
            frame=base_frame,
            inner_wall_at=inner_face,
            wall_top_at=split_z,
            wall_height=snap_wall_height,
            zone_range=zone_range,
            deflection_distance=snap_deflection,
        )
        cap = apply_ramp_in_first(
            cap,
            frame=cap_frame,
            inner_wall_at=inner_face,
            wall_top_at=split_z,
            wall_height=snap_wall_height,
            zone_range=zone_range,
            deflection_distance=snap_deflection,
        )

    return base, cap


# Assembly

def build_pump_case():
    solid = build_base_plate_with_ramp()
    solid = solid.union(build_skirt())
    solid = add_bore_wall(solid)
    solid = solid.union(build_tower())
    solid = cut_bore_cavity(solid)
    combined = solid.union(build_lower_extension())
    combined = cut_arch_notches(combined)
    base, cap = split_into_base_and_cap(combined)
    base, cap = add_snap_fits(base, cap)
    return base, cap


def main():
    substitute_py_comments(
        _here / "pump_case.py",
        variables={
            "CASE_OUTER_X": f"{case_outer_x:.1f} mm",
            "CASE_OUTER_Y": f"{case_outer_y:.1f} mm",
            "CASE_OUTER_Z": f"{case_outer_z:.1f} mm",
            "CYLINDER_BOTTOM_Z": f"{cylinder_bottom_z:+g} mm",
            "BORE_BOTTOM_Z": f"{bore_bottom_z:+g} mm",
            "CYLINDER_TOP_Z": f"{cylinder_top_z:+g} mm",
            "BASE_PLATE_FAR_Z": f"+{base_thickness:.4g} mm",
            "NARROW_SPLIT_Z": f"{narrow_split_z:+g} mm",
            "SKIRT_BOTTOM_Z": f"{skirt_bottom_z:+g} mm",
            "LOWER_CAP_TOP_Z": f"{lower_cap_top_z:+g} mm",
            "LOWER_CAP_BOTTOM_Z": f"{lower_cap_bottom_z:+g} mm",
            "FOOTPRINT_X": f"{footprint_x:.4g}",
            "RAMP_BOTTOM_WIDTH": f"{footprint_x - 2 * ramp_from_skirt_to_octagon_height:.4g}",
            "SKIRT_WIDE_WIDTH": f"{skirt_wide_full_width:.4g}",
            "SKIRT_NARROW_WIDTH": f"{skirt_narrow_full_width:.4g}",
            "SKIRT_WIDE_FLARE": f"{skirt_wide_flare_per_side:.4g}mm",
            "SKIRT_NARROW_TAPER": f"{skirt_narrow_taper_per_side:.4g}mm",
        },
    )
    print("-> updated comments in pump_case.py")


if __name__ == "__main__":
    main()
