"""Shared interface for the cold-core's geometry modules — dimensional
constants and hole-punch helpers that every sibling part (foam shell,
foam cap stack, reservoir, copper plugs, coil mandrel) needs to stay
in sync against.

The constants carry claims about each other — a screw long enough for its insert, a lane wide
enough for its bore, two columns far enough apart for foam to reach between them — and those are
settled here, as this file is read, with no solid yet to measure. `_stated_bounds` is the ledger
they record into; `enclosure_assembly.carry_stated_bounds` drains it onto the machine's card, where
an open one is a red row a reader can see beside the geometry it describes. The siblings that
import this module take `bound` and `state` from here rather than reaching for the ledger
themselves, because this is already the path they read every other shared name off."""

import itertools
import math
import sys
from collections import namedtuple
from pathlib import Path

_here = Path(__file__).resolve().parent
sys.path.insert(0, str(next(p for p in _here.parents if p.name == "printed-parts") / "cadlib"))
sys.path.insert(0, str(next(p for p in _here.parents if p.name == "hardware") / "scripts"))
sys.path.insert(0, str(_here.parent / "enclosure" / "enclosure"))
sys.path.insert(0, str(_here.parent / "valve-seat"))
sys.path.insert(0, str(_here.parents[1] / "reference" / "g-ganen-pump" / "installation"))

import cadquery as cq

import reeding
import fits
import valve_seat as _valve_seat
import g_ganen_installation as _water_pump
from world_workplane import xy_plane_z_up, xz_plane_y_up, xz_plane_y_down, WorldWorkplane
from _stated_bounds import bound, state
from _enclosure_interface import (manifold_rise, inner_limb_drop,
                                  rear_plane_y, rear_seam_clear)


# All structural walls and floors are [2 mm](WALL_AND_FLOOR_THICKNESS) PET-GF. The outer
# wall is one flute deeper than this, and `outer_shell_wall` below is where that is said.
wall_and_floor_thickness = 2.0
hole_shift_from_edge = 15.0


# --- The show skin ---------------------------------------------------------------------
#
# THE CORE'S OUTER SKIN IS FLUTED, on the box's own field at the box's own figures
# (`cadlib/flute_skin.py`, `cadlib/reeding.py`). What the texture buys is not ornament. A
# groove field at this pitch lays its own highlight and shadow across the surface at a spacing
# finer, and in far higher contrast, than a layer line — so the layer lines fall under it and a
# large flat face stops announcing how it was made. On PET-GF15 that is the difference between
# a face that reads as printed and one that reads as moulded, and it is worth most on exactly
# the faces that are hardest to print clean: the slot's fan is off and its chamber is at 50 °C
# (`foam-shell/print-log.md`), which is a profile tuned for a standing wall.
#
# IT IS LIMITED TO WHAT STANDS VERTICAL, and that is the printer's fact and not a choice. On a
# standing wall the groove is Z-INVARIANT: every layer traces the same toothed perimeter, so
# the texture is the outer wall loop taking a wavier path and costs nothing. Off vertical the
# same groove stops being a wall feature and becomes top-shell geometry, which is stepped solid
# infill. So the four walls of the shell and of both caps carry it and no horizontal face does.
flute_depth = 1.2
flute_rise = 5.0
flute_pitch_nominal = 5.0
#: How far the landed pitch may sit from the nominal — `flute_count` closes on the perimeter
#: exactly, so the pitch is a consequence and this is what holds it near the coupon's.
flute_pitch_drift = 0.15
#: THE COUNT IS EVEN, AND TWO SEPARATE THINGS BUY THAT. The footprint has two mirror planes and
#: a datum on one of them gives its own for free (`flute_skin.rounded_rect_segments`); the
#: other costs an even count. And the top cap and its lid install spun a half turn about Z
#: (`foam_assembly._spin`), which shifts their field by half the perimeter — a whole number of
#: pitches only when the count is even, and half a pitch otherwise, which would land every
#: groove of the cap on a land of the shell. `flute-closes` and `flute-even` read both.
flute_count = 182

# THE GROOVE'S STOCK COMES OUT OF THE POUR, NOT OFF THE ENVELOPE. A flute must have a whole
# `wall_and_floor_thickness` standing behind it — the box's `flute_backing` rule, which its
# corner coupon proved on the 0.6 mm an engraved label took out of the far side and which read
# on the show face as a mark you could find. A 1.2 mm groove in a 2 mm wall leaves 0.8, which is
# under the 0.87 mm of shell two loops draw, so a wall that carries flutes is one flute deeper
# than one that does not. The depth is found on the INSIDE: `outer_shell_x_length` and
# `outer_shell_y_length` are what they were, and the foam behind the wall gives up the
# difference. Nothing outboard moves, so the cabinet around the core does not know this
# happened.
outer_shell_wall = wall_and_floor_thickness + flute_depth


# The cold cylinder + its evaporator coil. [7 mm](COIL_RADIAL_CLEARANCE) of
# radial clearance out from the cylinder OD holds the 1/4" ACR copper coil +
# thermal tape; the carbonator support ring cradles the carbonator rim at this envelope.
carbonator_outer_radius = 63.5
coil_radial_clearance = 7.0
carbonator_coil_envelope_radius = carbonator_outer_radius + coil_radial_clearance

# Foam blanket around the cylinder — the pour-foam standoff measured from the
# cylinder OD out to the reservoir's carbonator-facing wall, uniform around the wrapped
# arc (that wall is a concentric arc), with the coil embedded in its inner slice
# (so it must be >= coil_radial_clearance). This VALUE is not a thermal target:
# it is set so the reservoir, shifted out by it, keeps the 283 mm outer width
# (outer_shell_x_length below) with its reed channel butted against the outer
# wall — i.e. the foam that used to sit outboard of the reed moved to the
# cylinder side. The reservoir-facing (cavity) face is one wall further out.
foam_thickness_around_cylinder = 15.0
pocket_centerward_arc_outer_radius = (
    carbonator_outer_radius + foam_thickness_around_cylinder + wall_and_floor_thickness
)

# Foam-shell outer height. Carbonator height + [30 mm](ABOVE_TANK_ELBOWS_HEIGHT) above for top-side elbow
# fittings + [30 mm](BELOW_TANK_ELBOWS_HEIGHT) below for bottom-side elbow fittings + 1 mm
# wall-thickness compensation.
carbonator_height = 152.4
below_carbonator_elbows_height = 30.0
above_carbonator_elbows_height = 30.0
foam_shell_outer_height = (
    carbonator_height + below_carbonator_elbows_height + above_carbonator_elbows_height + 1.0
)

carbonator_support_ring_height = 30.0
support_ring_radial_width = 9.0

# ⌀[6.8](PORT_HOLE_DIAMETER) — the project-wide standard for small through-shell features
# (water outlet, reservoir bulkheads, reed cable holes, CO2 tube clearance).
#   IT IS SIZED OFF THE TUBE ON THE BENCH AND NOT THE NOMINAL. 1/4" LLDPE calipers ⌀6.5 at the
# top of its spool band (`tube-collar/tube_collar.py`), so a bore cut to the ⌀6.35 nominal is
# an interference fit on the line it is for, and the printer takes more off it again. This is
# that measured tube plus the slip a hand needs to push it through.
port_hole_radius = 6.5 / 2.0 + fits.slip

# Reed-channel cavity depth (radial, out from the bag-pocket far wall). The reed
# column drops into this cavity; the outer_shell X width is sized so the cavity +
# its wall butt the outer shell wall (see outer_shell_x_length). Consumed by
# _reed_channels.py too.
reed_x_depth = 6.0
# Half the cavity's reach along the reservoir, either side of the column's own station. The
# cavity carries the laced column and the cable that leaves up it, and `reed_cable_conduit_xy`
# stands on the same two figures — one lane, read here rather than in two places.
reed_y_half_w = 4.0

# WHERE THE LEVEL SENSOR STANDS along the reservoir — the float rod inside
# (`reservoir.rod_position_y`) and the reed column outside (`_reed_channels.reed_y_center`),
# which are ONE station and not two: a reed reads the float's magnet across the pocket wall
# and nothing else, so the two cannot drift apart (`reservoir/level-sensing.md` carries the
# bench-measured magnet-to-reed path). The pair rides the reservoir's +Y half, clear of the
# bulkhead exit on the −Y front, and the donut has its whole travel clear of both cavity
# walls anywhere along that half.
#   What pins it HERE is the FORWARD BAND overhead: the reed channel's envelope and
# reservoir B's draw conduit both stand in that band's 8 mm, on the same face of the shell,
# and a ⌀[6.8](PORT_HOLE_DIAMETER) bore and a reed cavity cannot share one lane. The conduit takes the lane its
# own deck wants and the reed column steps off it.
level_rod_y = 32.5

# Bag pocket. Width and depth are the reservoir's own dimensions — sized to the
# flavor charge it carries (each usable window, Reed 1 low → Reed 4 full over
# 135 mm of float travel, holds 2 × SodaStream 0.44 L bottles). They are NOT tied
# to the carbonator geometry: the ±Y width stands on its own so growing the cylinder's
# foam blanket slides the pocket outward without resizing the reservoir.
bag_pocket_width = 145.0
bag_pocket_depth = 49 + 2 * wall_and_floor_thickness
bag_pocket_far_inner_x = (
    pocket_centerward_arc_outer_radius + bag_pocket_depth - 2 * wall_and_floor_thickness
)
bag_pocket_y_inner_max = bag_pocket_width / 2 - wall_and_floor_thickness
bag_pocket_floor_top_z = wall_and_floor_thickness
bag_pocket_walls_top_z = foam_shell_outer_height

# Matches the reservoir's outer +X × ±Y fillet (R=6) with reservoir_clearance
# on top, so the reservoir's outer arc slides into a snugly-mated arc on
# the pocket's inner corner with uniform clearance.
reservoir_clearance = fits.running
bag_pocket_corner_inner_radius = 6.0 + reservoir_clearance
reservoir_floor_thickness = 3.0
# Bulkhead vertical scheme. The PureSec mounts elbow-DOWN: the integral 90°
# elbow + its dry-side flange + the below-side printed-TPU washer hang below
# the reservoir's flat exterior floor bottom (the wet-side primary seal is a
# purchased silicone flat washer in a wet/cavity-side counterbore, compressed
# by the nut on the wet/cavity side, above; the dry-side TPU washer is the
# secondary seal under the elbow flange). The reservoir's weight rides on the
# corner support posts; the
# elbow's lowest point clears the bag-pocket floor by bulkhead_floor_clearance
# and bears no load. The flavor-line wall holes and the reed cable holes both
# pin their Z to bulkhead_elbow_exit_z (the elbow's lateral-port center), so
# the tube and the cable run level out of the open pocket.
bulkhead_floor_clearance = 1.0  # gap from the lowest bulkhead hardware down to the bag-pocket floor — non-load-bearing
bulkhead_elbow_bottom_z = bag_pocket_floor_top_z + bulkhead_floor_clearance
bulkhead_elbow_exit_z = bulkhead_elbow_bottom_z + 3.0  # elbow's lateral-PTC-port Z center
reservoir_bulkhead_port_x = (bag_pocket_far_inner_x + pocket_centerward_arc_outer_radius) / 2
# Y of a pocket-wall pass-through, 10 mm inboard of the bag pocket's ±Y wall outer
# face. Reservoir A's draw and BOTH reed cables cross the −Y wall at this y, onto
# the port lane; reservoir B's draw crosses the +Y wall at its mirror, onto the west
# lane. Which wall a line takes is which lane its cap conduit stands over.
reservoir_bulkhead_port_y = -(bag_pocket_width / 2 - 10)

# The reservoir's SECOND mouth, in its own cap. The draw leaves by the bulkhead
# at the bottom of the wet V; the fill arrives up here, above the liquid, so the
# two never share a mouth and everything entering has to cross the cavity to
# leave by the trough. The cap reads its station (`reservoir.build_reservoir_cap`)
# and so does the conduit standing over it (`cap_conduits`) — in two different
# frames, neither part seeing the other, so `reservoir_fill_conduit_xy` is the
# whole of what holds them together and the assertion under `cap_conduits` is
# what enforces it. A conduit that misses its bore is a hole into a sealed
# pocket; a bore that misses its conduit is a blind one.
#   EACH RESERVOIR TAKES ITS OWN STATION, and only half of what picks it lives
# in this file. THIS half is the cap's: anywhere the vent boss, the rod's
# register boss and the screw bosses leave empty, standing over open cavity
# so the bore lands in the headspace rather than in a wall. Both stations answer
# that, and it leaves a wide choice.
#   The OTHER half is what stands on the crown over each pocket, and this module
# cannot see it — the machine imports the cold core, not the reverse. So the
# fence is measured where the bodies are, in `manifold-layout/enclosure_assembly.py`,
# and what arrives here is the answer rather than the reasoning. B's pocket has
# a clear crown and takes the corner furthest from its own drain. A's carries
# the pump and the power brick, and its station is the strip they leave between
# them.
#   The conduit's own boss does not pay that fence either way: it is a column
# INSIDE the cap, under the crown those bodies stand on. What has to find room
# up there is the tube.
reservoir_fill_port = {
    -1: (-90.5, 43.5),      # B, forward pocket — the corner opposite its drain
    +1: (102.5, -57.5),     # A, aft pocket — the strip between the pump and the brick
}
reservoir_fill_sides = tuple(sorted(reservoir_fill_port))


def reservoir_fill_conduit_xy(side):
    """The CAP-frame station of the conduit standing over one reservoir's cap fill bore.

    The bore is authored in the RESERVOIR's frame (`reservoir._add_fill_port`) and the
    conduit in the CAP's, and the cap installs spun a half turn about Z
    (`foam_assembly.spin_xy`) — so the station is the anchor negated in both coordinates."""
    x, y = reservoir_fill_port[side]
    return (-x, -y)

# Outer footprint. The ±Y (front/back) gap is the carbonator's foam blanket out to the
# shell wall. The ±X width is set by the reservoir + its reed channel butted
# against the shell wall — no outboard foam there; it moved to the cylinder side.
outer_shell_foam_gap = 16.0  # ±Y front/back foam-pour gap
bag_pocket_outermost_x = (
    pocket_centerward_arc_outer_radius + bag_pocket_depth - wall_and_floor_thickness
)
# ±X: reservoir far wall + reed cavity + reed wall + shell wall (reed butted).
outer_shell_x_length = 2 * (
    bag_pocket_outermost_x + reed_x_depth + 2 * wall_and_floor_thickness
)
# ±Y: reservoir side wall (its own half-width) + front/back foam + shell wall.
outer_shell_y_length = 2 * (
    bag_pocket_width / 2 + outer_shell_foam_gap + wall_and_floor_thickness
)

# The ±X FORWARD BAND — what is left between the bag pocket's far wall and the outer shell's
# inner face. The band exists at every y BECAUSE the reed channel is in it at one: the pair
# that set `outer_shell_x_length` is the reed channel's own depth and wall. What the show skin
# takes comes off this band, because the wall it thickens into is this band's outboard face —
# and the reed channel is unharmed by that, because the wall it grows into is the reed's own
# outboard wall, which is the same solid once the two are unioned. The reed CAVITY does not
# move. A line climbing this band is potted in the pour beside the reed column, and there is
# still a bore's width of it to climb (`forward-band-takes-a-bore`).
forward_band_width = reed_x_depth + 2 * wall_and_floor_thickness - outer_shell_wall
# AND ITS MIDDLE, which is where a line climbing it runs. A tube in this band has the pocket's
# far wall on one hand and the shell's cavity face on the other and no room to favour either,
# so the station is the band's own centre and not a figure — the show skin thickens the wall
# this band's outboard face is, and a stated number would have stayed where the wall used to
# be. `forward-band-takes-a-bore` is what says a tube still fits between the two.
forward_band_mid_x = bag_pocket_outermost_x + forward_band_width / 2.0

# The −Y pour band — the open gap between the bag-pocket wall's outer face
# and the outer shell's inner face, poured full of foam around the
# reservoirs. Every front-wall pass-through crosses it, so each is two
# bores rather than one: the pocket-wall bore stays where the fitting
# inside points, the outer-shell bore goes where the cabinet needs it, and
# the line turns through the band between them. The band is what lets the
# two sit at different X.
pour_band_pocket_side_y = -(bag_pocket_width / 2)
pour_band_shell_side_y = -(outer_shell_y_length / 2 - outer_shell_wall)
pour_band_mid_y = (pour_band_pocket_side_y + pour_band_shell_side_y) / 2


# Foam-cap stack — the pour trays that close both ends of the shell (one
# mouth-up on top, one mouth-down underneath), each with a thin pour lid.
# The interior height is the cap's foam depth; the printed cup adds one
# floor.
foam_cap_interior_height = outer_shell_foam_gap
foam_cap_height = foam_cap_interior_height + wall_and_floor_thickness
foam_cap_lid_pour_radius = 10.0
foam_cap_lid_vent_radius = 3.0
foam_cap_lid_hole_inset = 30.0

# --- The carbonator's clocking --------------------------------------------------
#
# Four 1/4" NPT ports, two per end plate, each pair [1.5"](CARBONATOR_PORT_PITCH) centre to
# centre on a diameter (`hole_offset` in cut-parts/carbonation/endcaps-circular). Both
# plates carry the float rod's blind register on the axis at right angles to their own
# pair, the rod is tack-welded into the bottom plate's register and enters the top plate's
# at closure, so the plates are clocked together and the carbonator has ONE port axis.
#   That axis is the shell's ±Y. All four ports stand [19.05 mm](CARBONATOR_PORT_OFFSET) off
# the shell's own axis on it, two under the carbonator and two over it.
carbonator_port_offset = 0.750 * 25.4

# CO2 inlet — the bottom plate's LANE-SIDE port, open into the vessel. Gas enters below
# the liquid and rises to replenish the headspace; the top water-inlet jet provides the
# intended gas/water contact during refill (`assembly/water-inlet-jet.md`).
#   Outside the carbonator it is one bore on the shell's own centreline, level with the
# bottom-plate elbows, run from the port out through the carbonator support ring to the
# port lane. The port, its TAISHER elbow, the PI010822S collet made up on it and
# the ring bore all stand on that one line, so the tube is the only thing that
# crosses shell material and no bend is taken in-cavity. The line reaches the
# bore's lane end from ABOVE — down the port lane from the cap's `co2-in`
# conduit — so it is laid before the top cap goes on, not pushed in from outside.
co2_inlet_y = -carbonator_port_offset
co2_inlet_tube_radius = port_hole_radius

# The top plate's two, by the same pair. Filtered tap water arrives at the top plate ABOVE the
# liquid and falls into the headspace against the CO2 back-pressure; the carbonated draw leaves
# at the bottom plate, below it. So the carbonator is filled high and drawn low, the same way both
# reservoirs are.
# Port 4 and its shroud stand on +Y. The barrel vent points down the west lane,
# turns once and crosses the +Y shell flank into the enclosure's exterior relief
# chase (`_internal_routes.prv_vent_flank_y`). The top water inlet stands on -Y;
# its tube crosses the carbonator top to the +Y cap band.
water_inlet_port_y = -carbonator_port_offset
prv_port_y = +carbonator_port_offset

# Cap-to-outer-shell joinery: one attachment point per station in
# `attachment_stations`, per face × 2 faces, each screw passing lid + cap into an
# insert pressed from the shell face it mates. TPU gasket per cap
# (foam-cap-gasket.step). See bom.md for hardware SKUs.
screw_clearance_radius = 3.0 / 2.0 + fits.slip
insert_pocket_radius = 2.0  # ⌀[4](INSERT_POCKET_DIAMETER), ruthex's own recommended hole
insert_pocket_depth = 8.0  # 5.7 mm insert engagement + 2.3 mm relief
screw_boss_size = 8.0  # ⌀[8 × 8 mm](SCREW_BOSS_SIZE) cylindrical boss at each attachment

# The head sits in the lid, and a lid is [5.4 mm](FOAM_CAP_LID_H) thick where it takes one —
# one wall of PET-GF under the head, the boss section under that, and the lid's outer face a
# plane. EACH END OF THE STACK BUYS THAT HEIGHT ITS OWN WAY. The bottom cup's boss columns stop
# [3.4 mm](HEAD_PAD_H) short of its mouth and the lid's pad, of the boss's own cross-section,
# fills that relief. The TOP lid is solid to the same height over its whole footprint — it is
# the plate the service bay stands on, so its underside is one plane and the band is the cup's
# to give up (`_foam_cap.top_cap_height`).
screw_head_height = 3.0  # DIN 912 M3 nominal
head_seat_recess = fits.slip
head_cbore_radius = 5.5 / 2.0 + fits.slip
head_cbore_depth = screw_head_height + head_seat_recess
# A pad as tall as the counterbore is deep leaves the land at one wall exactly.
# The bottom lid prints outer-face-down. Its supported screw-seat roofs need
# the bridge allowance, backed by the same full plate thickness. The matching
# cup relief follows this pad; top cup/lid share the band at fixed stack height.
head_pad_height = head_cbore_depth + fits.supported_surface
head_pad_slip = fits.slip  # pad to the boss relief that receives it
# A lid, plate and pad in one. `_foam_cap.lid_total_height` builds on this name.
foam_cap_lid_height = wall_and_floor_thickness + head_pad_height

# --- The front face, and the lane that reaches it ---------------------------
#
# Every penetration opens on the shell's −X face. That face is the SHORT one, and
# in the appliance it is yawed onto the machine's front (`enclosure_assembly.FOAM_YAW`) —
# which is why the shell's short axis is what sets the appliance's width.
#
# Nothing reaches that face head-on: the reservoir pockets fill both ±X ends of the
# shell, so a line from the carbonator or from either pocket gets there along the −Y POUR
# BAND, which runs the shell's whole length outboard of both pockets. What a line
# may use of that band is the LANE: the strip inboard of every attachment boss.
# Every boss on a ±Y wall stands hard against it (`attachment_stations`) and reaches
# `screw_boss_size` in from its outer face, so the lane is exactly what they leave,
# and it runs clear end to end at every height above the floor slab. The two bosses on
# the ±X walls stand on the face the lanes arrive at, clear of both bands in y.
#
# The lane is ONE BORE WIDE. That is what makes each lane a column rather than a grid, and
# what its slot stands on is `front_port_floor_z` below.
front_wall_x = -outer_shell_x_length / 2
port_lane_outer_y = -(outer_shell_y_length / 2 - screw_boss_size)
port_lane_inner_y = pour_band_pocket_side_y
port_lane_mid_y = (port_lane_outer_y + port_lane_inner_y) / 2

# The +Y band's lane, which is this one mirrored — the bosses stand at both signs, so both
# bands leave the same strip. Two lines use it, and they use it end to end rather than
# crossing: reservoir B's flavor line comes out of its pocket's +Y wall, comes about in this
# band and climbs it to the TOP, out through the cap's own `reservoir-b` conduit; and the
# evaporator's WARM tail drops this band to its own station low on the front wall
# (`copper_plugs.columns`).
west_lane_mid_y = -port_lane_mid_y
# PET-GF left either side of a bore on the lane, and under the lowest one over the
# floor slab. Below this the wall between two features stops being printable.
port_lane_wall = 1.5
state(
    "port-lane-width", "The port lane carries a bore with a wall either side of it",
    f"{2 * (port_hole_radius + port_lane_wall):g} mm of lane",
    port_lane_inner_y - port_lane_outer_y >= 2 * (port_hole_radius + port_lane_wall),
    f"the port lane is {port_lane_inner_y - port_lane_outer_y:g} mm wide, which cannot carry a "
    f"⌀{2 * port_hole_radius:g} bore with {port_lane_wall:g} mm of PET-GF either side")

# Where the evaporator coil's two tails leave the carbonator: the low one one
# `hole_shift_from_edge` above the bottom-plate elbow band, the high one the same
# below the top's. These are the COIL's heights — what the mandrel is wound to and
# what the reed bridge's wrap band spans — and they are NOT the heights their copper
# crosses the shell wall at. Each tail turns onto a LANE OF ITS OWN — the inlet's onto
# the port lane, the outlet's onto the west (`copper_plugs.columns`) — and both drop
# from there to their stations in the slot, so compressing the field can never compress
# the coil.
evap_tail_low_z = hole_shift_from_edge + wall_and_floor_thickness + below_carbonator_elbows_height
evap_tail_high_z = (foam_shell_outer_height - hole_shift_from_edge
                    - wall_and_floor_thickness - above_carbonator_elbows_height)

# NOTHING CROSSES THIS FACE BUT THE SLOTS. The front wall is mated face to face with the
# refrigeration base — the condenser against it and the compressor's own plate just short of that
# plane — so a bore struck here opens into that base rather than into the machine. Every one of
# the seven fluid lines leaves by the TOP, up its own band to a conduit in the cap
# (`cap_conduits`), and so do the two reed cables, each up the channel its column stands in
# (`reed_cable_conduit_xy`). What is left on this face is the copper slot on each lane and
# no round bore at all.
front_port_pitch = 2 * port_hole_radius + port_lane_wall
# WHAT THE SLOT STANDS ON is the pocket floor's own band — one wall of PET-GF over the floor, one
# bore of lane, one wall again. That is the lowest anything can sit on this lane and still leave
# the floor its material.
front_port_floor_z = bag_pocket_floor_top_z + port_lane_wall + port_hole_radius
# AND WHAT HOLDS IT UP OFF THAT IS THE APPLIANCE'S OWN FLOOR. The core stands on `enclosure`'s
# slab with the compressor bay mated to this face, and both coppers cross here — so a slot
# that sits at the bottom of its lane puts the evaporator's two legs in the slab's material
# instead of the machine's air. `enclosure_assembly` reads that on `clearance-floor`, `port-leads`
# and `lines-clear`, all three against the loop rather than against this figure.
#   ONE LANE PITCH IS THE STANDOFF, and it is STATED here rather than derived: nothing inside this
# shell sets it, so a crossing that drops reads red in the appliance instead of quietly walking
# the refrigerant loop into a wall. `copper_plugs.evap_cross_z` takes the slot's own reach up
# from this top.
front_slot_standoff = front_port_pitch
front_port_field_top_z = front_port_floor_z + front_slot_standoff + port_hole_radius

# The face every penetration opens on, as a direction: the shell's own −X. A station is a
# position and the way out of it, so a turn that moves the shell moves both.
front_port_axis = (-1.0, 0.0, 0.0)


# Rounded outer-shell corners. Each corner's exterior wall is a true arc:
# the outer face is a quarter-round of [12 mm](CORNER_ROUND_R) radius, the
# inner face concentric one wall-thickness inboard.
corner_round_radius = 12.0


# --- The run the show skin is struck along ----------------------------------------------
#
# ONE RUN FOR THE WHOLE STACK. The shell, both caps and both lids are all cut to the SAME
# footprint (`outer_shell_x_length` × `outer_shell_y_length` on `corner_round_radius`), so from
# the outside the core is one silhouette with seams across it, and there is one perimeter for
# every piece of it to strike its field on. A piece that took its own pitch off its own height
# would put its grooves half a land off its neighbour's at the seam, which is the one place a
# reader's eye is already going.
#
# ARC LENGTH IS THE ACROSS-COORDINATE, so a flute crosses `corner_round_radius`'s quarter turn
# without knowing the corner is there, and a run round the outside is the same object to
# `flute_skin` as any other run.


def outer_shell_plan_segments():
    """The core's outer plan boundary as (kind, length, data), walked from the middle of the
    −X wall — the FRONT face, the one every penetration opens on and the one a reader is
    standing at. That station is on the y = 0 plane the core is struck about."""
    return reeding.rounded_rect_segments(
        outer_shell_x_length, outer_shell_y_length, corner_round_radius)


def outer_shell_plan_perimeter():
    """How far it is round the core's outer plan once — what `flute_count` divides."""
    return sum(length for _kind, length, _data in outer_shell_plan_segments())


def outer_shell_plan_at(s):
    """That boundary's point and OUTWARD normal at arc length `s` from the datum.

    THE PLAN CLOSES, so any `s` is on it: the walk is taken modulo the perimeter and the core
    has no station where the field restarts."""
    segments = outer_shell_plan_segments()
    return reeding.walk(segments, s % sum(length for _k, length, _d in segments))


def flute_pitch():
    """The spacing the field actually lands on. It is a CONSEQUENCE of `flute_count`, not a
    figure of its own: a stated pitch would leave the perimeter with a remainder, and the
    remainder has to go somewhere — one wrong land, at whichever station the array closed on."""
    return outer_shell_plan_perimeter() / flute_count


state("flute-closes", "The flute count lands near the nominal pitch",
      f"|{flute_pitch():.4g} - {flute_pitch_nominal:g}| <= {flute_pitch_drift:g} mm",
      abs(flute_pitch() - flute_pitch_nominal) <= flute_pitch_drift,
      f"{flute_count} grooves close on the {outer_shell_plan_perimeter():.4g} mm perimeter at "
      f"{flute_pitch():.4g} mm, which is {abs(flute_pitch() - flute_pitch_nominal):.4g} mm off "
      f"the nominal {flute_pitch_nominal:g}")
state("flute-even", "The flute count is even",
      "the spun cap's grooves land on the shell's",
      flute_count % 2 == 0,
      f"{flute_count} is odd, so the half-perimeter the top cap's spin shifts its field by "
      f"({flute_pitch() * flute_count / 2:.4g} mm) is a half pitch out of step, and every "
      f"groove of the cap lands on a land of the shell")
state("flute-backed", "A groove keeps a whole wall behind it",
      f"{outer_shell_wall:g} - {flute_depth:g} >= {wall_and_floor_thickness:g} mm",
      outer_shell_wall - flute_depth >= wall_and_floor_thickness - 1e-9,
      f"a {flute_depth:g} mm groove in the {outer_shell_wall:g} mm outer wall leaves "
      f"{outer_shell_wall - flute_depth:g} mm, under the {wall_and_floor_thickness:g} mm a "
      f"fluted face must stand on")
state("forward-band-takes-a-bore", "The forward band still passes a line",
      f"{forward_band_width:g} >= {port_hole_radius * 2:g} mm",
      forward_band_width >= port_hole_radius * 2,
      f"the show skin thickened the ±X wall into the forward band, leaving "
      f"{forward_band_width:g} mm against the {port_hole_radius * 2:g} mm bore that climbs it")

# A STATION NAMES THE WALL IT LEANS ON, and that is the whole of this table. A boss is a
# cylinder tangent to one exterior face with a web run out to it, and WHICH face cannot be
# read off the sign of the boss's own coordinates: a station on a ±X wall stands at y = 0,
# where the sign is neither. `attachment_stations` carries it; `attachment_xy_positions` is
# the same table read as bare points, which is what every clearance reading in the tree wants.
#
# Every boss on a ±Y wall stands HARD against it — none in a corner, and none inboard.
# The ±Y bands are the only place a line running to the front face can travel, and a boss
# reaching further in than `screw_boss_size` would narrow the lane below one bore. A boss
# seated diagonally IN a corner (its cylinder tangent to the exterior arc, which is the
# deepest seat available) reaches diagonally into the band, and that is what closed the corner
# the lane has to turn through. Held against the wall instead, every one of them leaves the
# same lane and the ±X ends of both bands run clear to the wall.
#   THE FOUR CORNER BOSSES stand over the reservoir pockets' own far walls, which is the
# furthest out they can go and still keep one wall of PET-GF around their insert pockets
# inside the corner's rounded skin.
#   THE FOUR MID BOSSES stand two to a wall. What a mid boss is FOR is the gasket: the clamp
# is what holds the TPU land against the pour, and a station's worth is the span it halves.
# Two to a wall also settles the shroud, which is the one body standing where a single centred
# boss would go: the PRV's ⌀23 cup lies on the carbonator's +Y port axis (`prv-shroud/`) and
# its closed end reaches within ~3 mm of the +Y wall, so its section spans x ±11.5 there. At
# `mid_screw_x_offset` neither boss is near it, and neither ±Y wall is a special case of the
# other.
#   THE TWO END BOSSES stand centred on a ±X wall, the only station either ±X run has. Their
# cylinder is tangent to the ±X face the same way a ±Y boss is tangent to its own, and the web
# runs out to that face instead. Both centres are clear: in the shell the two copper-plug slots
# the front face is cut for stand at y ±77.5 and nothing else reaches it, and on the TOP LID's
# outer face — the deck the machine stands on — the one body that would cover a centre is
# `water-3`'s tie post, which stands along its own run and is set where this station is not
# (`cap_side_anchors`, `cap_side_anchor_room`).
#
# The whole pattern is symmetric under a 180° turn about Z — balanced gasket compression, and
# the top cap free to install either way round. Two bosses to a ±Y wall is what makes that
# free: one to a wall bought the same symmetry only by standing the pair on a diagonal.
_boss_wall_y = outer_shell_y_length / 2 - screw_boss_size / 2
_boss_wall_x = outer_shell_x_length / 2 - screw_boss_size / 2
_end_boss_x = bag_pocket_outermost_x
# EVEN THIRDS OF THE RUN WOULD BE 43.83 — the corner bosses stand at ±`_end_boss_x`, so a
# third of what lies between them is that. The last 3.8 mm of it is bought from the
# `carb-water-out` conduit, whose column stands at (52.2, 77.5) on the +Y band: at the third
# it reads 3.04 mm off this boss, against the 4.43 mm the tightest station in the cup reads
# without one. So the pair stands a little inboard of even, where the worst span on the run is
# 91.5 mm against the third's 87.7 and nothing already standing in the cup moves at all.
mid_screw_x_offset = 40.0
#: Every attachment station as `((x, y), wall)`, `wall` naming the exterior face its cylinder
#: stands tangent to and its web runs out to — "x", "y", or "corner" for one against both.
attachment_stations = (
    tuple(((x_sign * _end_boss_x, y_sign * _boss_wall_y), "corner")
          for x_sign in (1, -1) for y_sign in (1, -1))
    + tuple(((x_sign * mid_screw_x_offset, y_sign * _boss_wall_y), "y")
            for x_sign in (1, -1) for y_sign in (1, -1))
    + tuple(((x_sign * _boss_wall_x, 0.0), "x") for x_sign in (1, -1))
)
attachment_xy_positions = [_xy for _xy, _wall in attachment_stations]

# A STATION IS PRICED AGAINST THE LANE IT IS NOT IN. A ±Y boss shares the ±Y band with every
# line running to the front face, so it is held to the outer `screw_boss_size` of it and the
# lane is exactly what it leaves. A ±X boss is in neither band — it stands on the face those
# lines arrive AT, clear of both lanes in y — so the reading that fences it is the lane's own
# volume, measured where the bodies are (`foam-shell/foam_shell._report_front_ports`) rather
# than inferred from a coordinate here.
_boss_lane = bound(
    "boss-clears-lane", "Every ±Y attachment boss stands clear of the port lane",
    "every ±Y boss inboard of the lane's outer edge")
for (_bx, _by), _wall in attachment_stations:
    if _wall == "x":
        continue
    _boss_lane(
        abs(_by) - screw_boss_size / 2 >= outer_shell_y_length / 2 - screw_boss_size,
        f"attachment boss at ({_bx:g}, {_by:g}) reaches past the port lane's outer edge "
        f"({port_lane_outer_y:g}) — the lane every front penetration runs along")
_boss_lane_x = bound(
    "boss-clears-lane-x", "Every ±X attachment boss stands clear of both lanes in y",
    "every ±X boss inboard of both bands")
for (_bx, _by), _wall in attachment_stations:
    if _wall != "x":
        continue
    _boss_lane_x(
        abs(_by) + screw_boss_size / 2 <= abs(port_lane_inner_y),
        f"attachment boss at ({_bx:g}, {_by:g}) reaches into a ±Y band (inboard edge "
        f"{abs(port_lane_inner_y):g}) — a boss on the face the lanes arrive at must stand "
        f"clear of both of them")
gasket_thickness = 2.0
gasket_strip_width = 5.0

# EVERY BAND OF THE SILHOUETTE, AND WHICH SIDE OF THE RUN-OUT IT FALLS ON. The stack stands on
# one footprint with seams across it, so what runs down the core's side is a column of bands —
# shell, cup, plate, gasket, and nothing else: every other piece of the core is potted inside
# the foam or inside the shell and reaches the outer plan at no station.
#
# A BAND CARRIES THE FIELD ONLY WHERE IT IS TWICE `flute_rise` TALL, and that is the field's own
# fact rather than a choice. The fade is driven by how far a station stands from the nearest edge
# of the show face (`_show_skin`, `flute_skin._depth_field`), a band's own two faces are both
# edges, so the deepest station on a band of height h stands h / 2 from one — and reaches
# `flute_depth` only once that clears `flute_rise`. Under that height every station on the band
# is still on the ramp.
#
# WHAT A SHORT BAND GETS INSTEAD IS A REVEAL. Cut on the core's own field the top lid's plate
# comes back at 0.604 mm and the bottom lid's and the gasket's at 0.121 mm, against the 0.4 mm
# layer and 0.82 mm bead the core prints at (`foam-shell/print-log.md`) — the last two shallower
# than one layer of the very defect the field is cut to hide. So the three take none of it, and
# each seam of the stack is a smooth band standing between the two run-outs either side of it.
#
# AND THE GASKET WOULD OWE THIS AT ANY HEIGHT. It is the TPU 90A land the cap clamps against the
# shell's face, and a groove across a sealing land is a path out.
flute_full_depth_height = 2.0 * flute_rise
silhouette_bands = (
    ("foam-shell", foam_shell_outer_height, True),
    ("foam-cap-bottom", foam_cap_height, True),
    ("foam-cap-top", foam_cap_height - head_pad_height, True),
    ("foam-cap-lid-top", foam_cap_lid_height, False),
    ("foam-cap-lid-bottom", wall_and_floor_thickness, False),
    ("foam-cap-gasket", gasket_thickness, False),
)
_flute_reveal = bound(
    "flute-reveal", "A band on the run either carries the field or is a reveal",
    f"fluted iff it stands {flute_full_depth_height:g} mm tall")
for _band, _band_height, _band_fluted in silhouette_bands:
    _flute_reveal(
        _band_fluted == (_band_height >= flute_full_depth_height),
        f"{_band} stands {_band_height:g} mm on the run and is "
        + (f"fluted, under the {flute_full_depth_height:g} mm it takes before one station on "
           f"it stands {flute_rise:g} mm clear of both its faces — so the whole band is ramp "
           f"and no groove on it reaches {flute_depth:g} mm"
           if _band_fluted else
           f"left smooth, though at {flute_full_depth_height:g} mm the field would reach its "
           f"full {flute_depth:g} mm on it"))

# The clamp screw, end to end. From under its head an M3 × [25](CAP_SCREW_L)
# crosses the land, then the one continuous PET-GF section the lid and the cap's
# boss column make between them, then the gasket — and whatever is left is what
# it has to give the insert on the far side of the shell's face. The recess
# spends none of that: the head carries the land down with it, so the screw
# arrives deeper by exactly the pad it sank.
#   BOTH ENDS MEASURE THE SAME, and not for the same reason. At the bottom the cup
# stands its full height and its boss column stops a pad short of the mouth; at the
# top the column runs to the rim and the CUP is a pad shorter. Either way a station
# carries one pad of lid over the rest of `foam_cap_height` in column.
cap_screw_length = 25.0
insert_length = 5.7  # ruthex RX-M3x5.7, set flush with the face
cap_screw_beyond_face = cap_screw_length - (
    wall_and_floor_thickness  # the land under the head
    + (foam_cap_height - head_pad_height)  # the boss column under the pad
    + gasket_thickness
)
state(
    "cap-screw-reach", "The clamp screw reaches the whole of its insert",
    f"{insert_length:g} mm past the shell face",
    cap_screw_beyond_face >= insert_length,
    f"an M3 × {cap_screw_length:g} reaches {cap_screw_beyond_face:g} mm past the shell "
    f"face, short of its {insert_length:g} mm insert")
state(
    "cap-screw-bottom", "The clamp screw pulls its head down before it bottoms",
    f"{insert_pocket_depth:g} mm past the shell face at most",
    cap_screw_beyond_face <= insert_pocket_depth,
    f"an M3 × {cap_screw_length:g} reaches {cap_screw_beyond_face:g} mm past the shell "
    f"face and bottoms in a {insert_pocket_depth:g} mm pocket before its head is down")

# Deck mounts — the service bay's electronics, carried on columns of the TOP CAP. The cap
# is already a foam-poured cup with a screw-boss column at every station spanning its full
# height; a deck
# mount is that same column at four more stations. Foam pours around the shanks, a ruthex
# short sits flush in each column's top bore, and the module bolts down into it. Nothing is
# bonded and no tray floor stands between the module and the cap.
#   A station with no standoff stops at the cap's mouth rim, under the lid, and its module
# seats on the lid's outer face. A station with a standoff carries its column on through
# the lid, and its module seats on the column tops.
#   The stations live here, in the cap's own frame, because the mount belongs to the part it
# is printed in. `foam_assembly.deck_mount_station` carries them into the stack's own frame,
# and whoever seats the stack carries them from there into the world.
deck_mount_boss_radius = 4.0     # Ø8 column; 2 mm stock around the Ø4 insert pilot
deck_mount_bore_radius = 2.0     # ⌀4 for a ruthex M3 heat-set
deck_mount_lid_slip = fits.slip  # a standing column to the lid's clearance hole
deck_mount_insert_length = 5.7   # ruthex RX-M3x5.7, set flush with the column top
deck_mount_bore_relief = 1.0     # ruthex minimum blind relief; also reserve travel past the screw tip

# The least room a deck column leaves to anything else standing in the cup — a screw boss,
# the cavity wall, another column. Liquid foam reaches between them.
deck_mount_cap_gap = 1.5

# Per module: the mount rectangle's centre in the cap's frame, the module's own hole pitch
# across X and Y, how far proud of the lid's outer face its column tops stand, what the
# screw head clamps down onto the column, and the screw that does it. A pitch of zero
# collapses the rectangle onto a line or a point, so a mount is however many DISTINCT
# columns its pitches leave: the ground stud rides one.
#   NO ELECTRICAL BODY IS ON THIS CAP but the ground stud. The supply and the main board hang
# on the +X wall of back-top, one over the other; the relay lies on the lid in the band they
# left and the Wago row stands on the brick's crown, and neither has a joint yet — a body resting on
# another is not mounted, so neither carries a row here. `deck_mount_cap_room` holds each
# column [1.5 mm](DECK_MOUNT_CAP_GAP) off whatever else stands in the cup for the pour to reach
# between them.
#   THE PATTERN IS THE CAP'S ROTATION KEY. The top cap installs spun a half turn about Z
# (`foam_assembly._spin`) and its clamp bosses are symmetric under that turn, so the thing
# that tells a builder which way the cup goes on is what is NOT symmetric — this station and the
# seven conduit columns beside it. `assembly/cold-core.md` CC-06 and CC-15 both read the cap
# that way.
#   A STATION IS THE BODY THAT BOLTS TO IT, so the table is one row long: the water pump. Its
# four identical rubber sliders stand at the fully engaged fore/aft rail ends.
# Their screw axes sit 1.5 mm outward within the elongated slots, leaving the
# Ø9 × 0.8 washer flat on each 7 mm pad. An M3 SHCS passes through the lid into
# its insert. The nominal pad/washer stack and the blind screw-tip reserve are
# separate dimensions; actual rubber compression is read during assembly.
#   Every other body standing on this cap is carried some other way: the electronics bay hangs on
# the enclosure's own wall bosses (`enclosure_assembly.wall_mounts`), and the three valves press
# into the cradles below, which take no screw.
DeckMount = namedtuple("DeckMount", "points standoff seat screw seat_min")
deck_mounts = {
    "g-ganen-pump": DeckMount(
        _water_pump.CAP_MOUNT_XY, 0.0,
        _water_pump.observed_pad_upper_z() + _water_pump.WASHER_T,
        _water_pump.SCREW_LENGTH,
        _water_pump.observed_pad_lower_z() + _water_pump.WASHER_T),
}


def deck_mount_xy(name):
    """Explicit selected boss centres in the cap's own frame."""
    return tuple(sorted(set(deck_mounts[name].points)))


def deck_mount_standoff(name):
    """How far proud of the lid's outer face this mount's column tops stand."""
    return deck_mounts[name].standoff


def deck_mount_proud():
    """The tallest standoff in the pack — the foam assembly's own top over its lid's face.
    Every station stands at `standoff = 0.0`, so the columns top out flush with the lid."""
    return max((deck_mount_standoff(name) for name in deck_mounts), default=0.0)


def deck_mount_reach(name):
    """How far a seated screw runs past this mount's column top. A flush station's screw
    crosses the WHOLE lid on its way down — the top lid is solid to `foam_cap_lid_height`,
    and that is what a station under it spends before it reaches the column. A standing one
    meets its column at the head and crosses nothing. `seat` is what the head bears on before
    either — a board's own thickness, a hub's floor, or the fan of ring terminals that is the
    ground bus."""
    m = deck_mounts[name]
    over = m.seat
    if m.standoff == 0.0:
        over += foam_cap_lid_height
    return m.screw - over


# The pump's minimum blind depth leaves screw-tip travel below its nominal stack.
deck_mount_bore_depth = max(deck_mount_insert_length + deck_mount_bore_relief,
    _water_pump.SCREW_BORE_MIN_DEPTH, max(
    (m.screw - m.seat_min - (foam_cap_lid_height if m.standoff == 0.0 else 0.0)
     for m in deck_mounts.values()), default=0.0) + deck_mount_bore_relief)
_mount_reach = bound(
    "deck-mount-reach", "Every deck mount's screw reaches the whole of its insert",
    f"{deck_mount_insert_length:g} mm into the column")
for _name in deck_mounts:
    _mount_reach(
        deck_mount_reach(_name) >= deck_mount_insert_length,
        f"deck mount {_name}: an M3 × {deck_mounts[_name].screw:g} through "
        f"{deck_mounts[_name].seat:g} mm of seat reaches {deck_mount_reach(_name):g} mm "
        f"into the column, short of its {deck_mount_insert_length:g} mm insert")


def deck_lid_hole_radius(name):
    """The lid's opening at a deck-mount station: a slip fit around a column standing
    through it, a screw clearance over one that stops beneath it."""
    if deck_mount_standoff(name) == 0.0:
        return screw_clearance_radius
    return deck_mount_boss_radius + deck_mount_lid_slip


def deck_mount_cap_room(name):
    """The least room this station's columns leave to anything else standing in the cup:
    `(mm, what)` — a screw boss, the cavity wall, another mount's column."""
    room = []
    for x, y in deck_mount_xy(name):
        for bx, by in attachment_xy_positions:
            room.append((math.hypot(x - bx, y - by)
                         - screw_boss_size / 2.0 - deck_mount_boss_radius, "a screw boss"))
        room.append((min(outer_shell_x_length / 2.0 - abs(x),
                         outer_shell_y_length / 2.0 - abs(y))
                     - outer_shell_wall - deck_mount_boss_radius, "the cavity wall"))
        for other in deck_mounts:
            for ox, oy in deck_mount_xy(other):
                if (ox, oy) != (x, y):
                    room.append((math.hypot(x - ox, y - oy) - 2.0 * deck_mount_boss_radius,
                                 f"the {other} mount"))
    return min(room)


_mount_room = bound(
    "deck-mount-room", "Every deck-mount column leaves the pour its gap in the cup",
    f"{deck_mount_cap_gap:g} mm off everything standing in the cup")
for _name in deck_mounts:
    _room, _what = deck_mount_cap_room(_name)
    _mount_room(
        _room >= deck_mount_cap_gap - 1e-9,
        f"deck mount {_name}: a column stands {_room:.3f} mm off {_what}, inside the "
        f"{deck_mount_cap_gap:g} mm the pour needs to reach between them")


# --- Valve cradles on the lid's outer face -----------------------------------
#
# A CRADLE IS FOUR BOSSES ON THE TOP LID'S OUTER FACE, with nothing between them: one under each
# of the Beduan's corner posts, in one broad plinth. The valve's round body lands
# on the plinth beside its open port channel. The sockets retain the valve without
# screws or inserts. `valve_seat` builds the plinth; `foam_cap` places it on the lid.
# Each station gives the centre, port-axis yaw from cap +X, and mounting-plane
# height relative to the lid. The flavour valves' sockets extend
# into its plate with 3 mm blind floors; V-K meets the suction chain's port plane.
Cradle = namedtuple("Cradle", "centre yaw seat")
# The cap installs with its +X opposite world +Y. The fixed flavour valves' mounting
# centres stay on world Y256.710 while the core follows the rear enclosure plane.
cap_manifold_cradle_x = (rear_plane_y - rear_seam_clear - outer_shell_x_length / 2.0
                         - 256.710)
cap_cradles = {
    #                      centre           yaw    seat
    "vk-solenoid": Cradle(( 92.270,  65.050), 0.0, 3.6500),
    "valve-v-a":   Cradle((cap_manifold_cradle_x,  24.270), 0.0, -1.4000),
    "valve-v-b":   Cradle((cap_manifold_cradle_x, -22.350), 0.0, -1.4000),
}

# Where a boss stands off the valve's centre, and how wide it is: a socket with a wall around it.
cap_cradle_corner_inset_x = _valve_seat.corner_inset_x
cap_cradle_corner_inset_y = _valve_seat.corner_inset_y
cap_cradle_socket_radius = _valve_seat.socket_radius
cap_cradle_wall = _valve_seat.wall
cap_cradle_boss_radius = _valve_seat.boss_radius
cap_cradle_half_x = _valve_seat.seat_half_x
cap_cradle_half_y = _valve_seat.seat_half_y
cap_cradle_corner_radius = _valve_seat.seat_corner_radius

# What a cradle holds off every other thing cut in the lid's outer face. Nothing is poured
# between them — this face is the machine's room, not the cup's — so the fence is the
# machine's own clearance floor rather than the pour gap the cavity keeps.
cap_cradle_room_gap = 1.0


def cap_cradle_xy(name):
    """A cradle's four socket centres, in the cap's own frame."""
    (cx, cy) = cap_cradles[name].centre
    th = math.radians(cap_cradles[name].yaw + 90.0)
    c, s = math.cos(th), math.sin(th)
    return tuple((cx + c * sx * cap_cradle_corner_inset_x - s * sy * cap_cradle_corner_inset_y,
                  cy + s * sx * cap_cradle_corner_inset_x + c * sy * cap_cradle_corner_inset_y)
                 for sx in (-1, 1) for sy in (-1, 1))


def cap_cradle_half_extents(name):
    """Axis-aligned half extents of the plinth in the cap's frame."""
    th = math.radians(cap_cradles[name].yaw + 90.0)
    c, s = abs(math.cos(th)), abs(math.sin(th))
    return (c * cap_cradle_half_x + s * cap_cradle_half_y,
            s * cap_cradle_half_x + c * cap_cradle_half_y)


def cap_cradle_circle_gap(name, x, y, radius):
    """Plan clearance from a circular opening to the rounded plinth outline."""
    (cx, cy), yaw, _seat = cap_cradles[name]
    th = math.radians(yaw + 90.0)
    dx, dy = x - cx, y - cy
    px = abs(math.cos(th) * dx + math.sin(th) * dy)
    py = abs(-math.sin(th) * dx + math.cos(th) * dy)
    qx = px - (cap_cradle_half_x - cap_cradle_corner_radius)
    qy = py - (cap_cradle_half_y - cap_cradle_corner_radius)
    return (math.hypot(max(qx, 0.0), max(qy, 0.0))
            + min(max(qx, qy), 0.0) - cap_cradle_corner_radius - radius)


def cap_cradle_rectangle_gap(name, x0, x1, y0, y1):
    """Plan clearance to an axis-aligned rectangle at these cap stations."""
    (cx, cy), yaw, _seat = cap_cradles[name]
    assert math.isclose(yaw % 90.0, 0.0), "plinth rectangle reading needs an axial station"
    hx, hy = cap_cradle_half_extents(name)
    core_x, core_y = hx - cap_cradle_corner_radius, hy - cap_cradle_corner_radius
    dx = max(x0 - (cx + core_x), (cx - core_x) - x1, 0.0)
    dy = max(y0 - (cy + core_y), (cy - core_y) - y1, 0.0)
    return math.hypot(dx, dy) - cap_cradle_corner_radius


def cap_cradle_room(name):
    """Least plan clearance around the plinth and its conduit edge passages."""
    room = []
    for cname, (x, y) in cap_conduits.items():
        gap = cap_cradle_circle_gap(name, x, y, cap_conduit_entry_relief_radius)
        # The plinth opens a full-height passage with this radial clearance.
        room.append((max(gap, cap_cradle_room_gap), f"the {cname} conduit passage"))
    for x, y in attachment_xy_positions:
        room.append((cap_cradle_circle_gap(name, x, y, head_cbore_radius),
                     "a clamp screw's counterbore"))
    for dname in deck_mounts:
        for x, y in deck_mount_xy(dname):
            room.append((cap_cradle_circle_gap(name, x, y, deck_lid_hole_radius(dname)),
                         f"the {dname} mount's lid hole"))
    cx, cy = cap_cradles[name].centre
    hx, hy = cap_cradle_half_extents(name)
    room.append((min(outer_shell_x_length / 2.0 - abs(cx) - hx,
                     outer_shell_y_length / 2.0 - abs(cy) - hy),
                 "the lid's own edge"))
    for other, station in cap_cradles.items():
        if other == name:
            continue
        ox, oy = station.centre
        ohx, ohy = cap_cradle_half_extents(other)
        # The rectangle includes the other plinth's rounded corners.
        room.append((cap_cradle_rectangle_gap(name, ox-ohx, ox+ohx, oy-ohy, oy+ohy),
                     f"the {other} plinth"))
    return min(room)


# --- Cap conduits ------------------------------------------------------------
#
# A conduit is one of the cup's own full-height columns carrying a THROUGH bore: liquid
# foam pours around its shank the way it pours around a deck mount's, the lid passes it,
# and a line runs up it from the shell's open top out onto the lid's outer face. The
# service bay stands on that face.
lldpe_tube_od = 6.35                         # the 1/4" line every fluid port on the core takes
state("forward-band-takes-a-tube", "A tube on the forward band's centre clears both its faces",
      f"{forward_band_width:g} >= {lldpe_tube_od:g} mm",
      forward_band_width >= lldpe_tube_od,
      f"a ⌀{lldpe_tube_od:g} tube centred in a {forward_band_width:g} mm band stands "
      f"{(forward_band_width - lldpe_tube_od) / 2.0:g} mm off each face")
cap_conduit_bore_radius = port_hole_radius   # the ⌀[6.8](PORT_HOLE_DIAMETER) every shell penetration takes
cap_conduit_wall = 2.0
cap_conduit_boss_radius = cap_conduit_bore_radius + cap_conduit_wall
cap_conduit_lid_slip = deck_mount_lid_slip   # per side, a standing column to the lid's clearance hole

# How far off its own bore axis a line leaves a conduit — a bore's `manifold_layout.FLAVOR_SKEW`.
# The LID'S HOLE IS COUNTERSUNK to this angle: the lip a leaning line crosses lies along it, and
# what the tube bears on there is a face. Everything under that countersink carries the bore on
# its own axis — the rest of the lid's plate and the column beneath it, one straight run.
# `_lines.CAP_BORE_SKEW` is bound to this name.
cap_conduit_entry_skew = 38.0
# The countersink's mouth on the lid's outer face — the bore opened at that angle through the
# one wall of plate the cone is sunk into: ⌀[9.925](ENTRY_RELIEF_D).
cap_conduit_entry_relief_radius = (
    cap_conduit_bore_radius
    + wall_and_floor_thickness * math.tan(math.radians(cap_conduit_entry_skew)))
# The relief stands inside the boss its own column carries, so `cap_conduit_room`,
# `cap_conduit_wall_neck` and `cap_conduit_pair_neck` fence the cone where they fence the
# column. A wall of boss over a cone one wall deep puts that ceiling at
# [45°](ENTRY_SKEW_CEILING).
cap_conduit_entry_skew_ceiling = math.degrees(
    math.atan2(cap_conduit_wall, wall_and_floor_thickness))
state(
    "entry-skew-ceiling", "The countersink stands inside the boss its own column carries",
    f"{cap_conduit_entry_skew_ceiling:.1f}° at most",
    cap_conduit_entry_skew <= cap_conduit_entry_skew_ceiling + 1e-9,
    f"cap conduit entry: {cap_conduit_entry_skew:g}° opens the lid's hole to "
    f"⌀{2.0 * cap_conduit_entry_relief_radius:.2f}, past the ⌀{2.0 * cap_conduit_boss_radius:g} "
    f"column under it — a relief stands inside its own boss, which is "
    f"{cap_conduit_entry_skew_ceiling:.1f}° here")
# The mouth passes the tube's SECTION and not just its centreline: a ⌀[6.35](LLDPE_TUBE_OD) line
# crossing the outer face at that lean reads `r / cos(skew)` wide in the face's own plane.
state(
    "entry-passes-section", "The countersink's mouth passes the leaning tube's whole section",
    f"⌀{lldpe_tube_od / math.cos(math.radians(cap_conduit_entry_skew)):.2f} across the face",
    cap_conduit_entry_relief_radius >= (
        0.5 * lldpe_tube_od / math.cos(math.radians(cap_conduit_entry_skew)) - 1e-9),
    f"cap conduit entry: a ⌀{lldpe_tube_od:g} line leaning {cap_conduit_entry_skew:g}° reads "
    f"{lldpe_tube_od / math.cos(math.radians(cap_conduit_entry_skew)):.2f} mm across the lid's "
    f"face, over the ⌀{2.0 * cap_conduit_entry_relief_radius:.2f} the relief opens to")

# Per conduit: its centre in the CAP'S OWN frame. The cap installs spun a half turn about
# Z (`foam_assembly.spin_xy`), and a half turn is its own inverse — so a conduit that
# stands over a carbonator port at (x, y) in the shell's frame is authored at (−x, −y) here,
# and `foam_assembly.cap_conduit_station` turns it back.
#   A CONDUIT IS ONE END OF A LINE, and what the line does at the far end is what this table
# is for; `_internal_routes` draws every one of them and measures it against the shell. Seven
# stand here, and they answer to the carbonator and the two reservoirs. TWO ENTER THE
# CARBONATOR (water at the top plate, CO2 at the bottom) and one draws it; each reservoir is
# entered once at its cap and drawn once at its floor. Every line that ENTERS one of the three
# arrives above that one's liquid and every line that LEAVES takes its lowest point, so nothing
# can enter and leave without crossing it. That is what the air-purge and clean-flush service modes run on.
#
#   water-in — the carbonator's TOP-PLATE −Y port, above the water line, where filtered tap
# water is pumped in against the CO2 back-pressure and falls into the headspace. The port
# carries one of the four TAISHER street elbows every carbonator port takes (`ledger/bom.md`) with
# a PTC adapter made up on its female end; the line leaves it laterally, crosses the carbonator's
# own top on one diagonal in the band between that plate and the cap's floor
# (`top_band_to_cap`), comes about in the +Y band and turns into
# the FORWARD BAND, where this bore stands. The top band is [14](TOP_BAND) mm against the
# [25.4 mm](LLDPE_BEND_R) a stock arc wants, so the corner off the elbow is the one that reach
# buys with, and it is potted where it turns. It shares the forward strip with both reservoir
# draws, each climbing its own bore `cap_conduit_pair_neck` away.
#   water-in's X in the cap's frame is that strip's own centreline. Its Y is THE DECK ABOVE:
# the discharge chain lies fore and aft in the lane the water split leaves it, collet forward,
# and this bore stands on the chain's own column at the far end of the fall. So the run off the
# collet is one straight and one slant, the slant entering the bore inside its own
# `cap_conduit_entry_skew`, and the lid's countersink is what lays the lip along it.
#   reservoir-b and reservoir-a are the two DRAWS, and both stand over that same FORWARD BAND —
# the strip between a pocket's own wall and the shell's, [6.8 mm](FORWARD_BAND) of it
# (`forward_band_width`). Each line starts on its reservoir's floor bulkhead, at the bottom of
# the wet V and the lowest drainable point in the cavity; the elbow under the raised floor turns
# it laterally, it crosses its pocket's own ±Y wall at `bulkhead_elbow_exit_z` into the band
# behind it, comes about, and climbs the forward strip potted to this bore. B takes the +Y band
# and A the −Y one, because that is the wall each one's elbow points at, and A's climb is the
# longer for it — its pocket is the far one from this strip.
#   A ⌀[6.8](PORT_HOLE_DIAMETER) bore leaves the tube a `LINE_HUG` of foam either side; what
# pins the two stations in Y is that and the reed channels, whose envelopes stand in this same
# strip and which both bores clear (`_reed_channels` measures it).
#   THE FORWARD STRIP'S COLUMNS ARE MERGED and not standing. The strip is forward of everything
# in the cup, so a post over it stands inside the pour gap the perimeter wall wants — and a
# conduit has the same two states against that wall it has against another conduit
# (`cap_conduit_wall_neck`): the column fuses into the wall and the bore runs up a local
# thickening of it, carrying a wall's material outboard.
#   A RESERVOIR FILL stands over its own reservoir rather than over a band, and has no run
# inside the shell at all: it is the column between a valve on the deck and the bore in the cap
# of the reservoir it fills, and that cap's own outer face is the last thing under this one, so
# the two features meet across the pour clearance over the reservoir and nothing else
# (`_internal_routes` draws and measures the stub). The bore it lands on opens
# into the reservoir's HEADSPACE, above the liquid and clear of the vent boss, the rod register
# and every screw boss — so what arrives falls into the cavity and can only leave by the trough.
# `reservoir_fill_conduit_xy` is the station, and `reservoir_fill_sides` is which reservoirs
# have one.
#   carb-water-out — the carbonator's BOTTOM-PLATE +Y port, under the liquid, which is the
# carbonator's own drain and the dispense line's source. The elbow turns it laterally, it crosses
# under the carbonator inboard of the support ring, leaves the ring through the ring's OWN SLOT on
# this bore's column (`_port_cuts.water_outlet_ring_crossing_x` — no bore, and the four bearing
# segments stay whole), and climbs beside the coil clear of the port lane until the carbonator's top
# plate is under it. Only there does it step out onto the lane and into this bore. That climb is
# inboard because the CO2 owns the lane's own strip at the bottom of the shell.
#   Its X answers to two things. THE DECK ABOVE: the +X flank stands a column of bodies on the
# lid — V-K, the main board, the power brick — and each leaves the lane a window rather
# than a lane, and this bore takes the widest of them. And THE COIL'S OWN TAIL: the climb runs
# in the annulus between the wrapped coil and a reservoir pocket's centreward arc, which is
# where the evaporator's inlet tail turns off its helix, and one bore of that annulus holds one
# run. The column stands clear of the tail's own, and far enough round that the ring crossing
# under it still falls inside one ring slot (`_port_cuts.water-outlet-slot`) — those two fences
# leave a 2.5 mm band and this is in it.
#   co2-in stands over the PORT LANE and its line runs DOWN it, the one conduit here that feeds
# rather than drains. It falls the shell's whole height, turns along the lane's floor and leans
# in to `_port_cuts.co2_inlet_xyz` — the one bore through the support ring — to land on the
# collet made up under the bottom plate's lane-side port. That port opens directly into the
# water column; gas rises to the headspace. Because the line arrives from above, it is laid
# down the lane before the top cap goes on.
#   ITS FALL IS THE ONLY RISER THE LANE CARRIES. A lane is one bore wide, so a riser in it is a
# wall to everything crossing that column, and the lane's other traffic all runs WEST at one
# storey each: the evaporator's inlet copper drops onto the lane beside the carbonator and takes it to
# its slot station (`copper_plugs.columns`), reservoir A's draw crosses on the pockets' floor
# storey, and the carbonated water joins only once it is over the carbonator.
# The PRV shroud lies on the west lane and its vent leaves through the +Y flank.
#   WHERE THE LEAN CROSSES is the Carbonator SUPPORT RING's business, not this file's. The reach in
# from the lane to the bottom plate's port crosses the ring, and the ring is four bearing
# segments with four slots between them (`_support_ring`); a reach that misses a slot would have
# to be bored through a segment that carries the carbonator. `_port_cuts.co2-inlet-slot` is that
# fence, and `co2_lane_x` is the column whose lean lands inside slot four.
co2_lane_x = 72.5
# THE RING IS AT THE FLOOR AND THE CONDUIT IS IN THE CAP, so one column does not have to serve
# both. The line falls the lane, runs along its floor and only then leans in, and it is the LEAN
# the ring reads — a jog along the lane costs the run nothing it was not already spending, since
# it turns on that floor either way. Splitting them lets the cap conduit stand where the
# APPLIANCE has room for it, and that is what picks this column: the conduit is what the
# enclosure's CO2 chain comes down onto, enclosure y is `319.5 − x` here, and this lands the
# chain at y 318 — clear of the relay's own terminal block, which is what the +X column puts
# in this lane at the deck's storey, and far enough off the regulator's outlet plane that the
# leg between the two still carries a rib.
co2_cap_x = 1.5
# THE CARBONATED WATER IS SPLIT THE SAME WAY, at the other end of its line. Its CLIMB is
# pinned: it crosses the carbonator support ring at one of the ring's own four slots, so the column
# it rises on may not wander without notching a bearing segment, and the slot leaves it under
# 8 mm of travel — all of it under the same deck body its bore has to dodge. Its cap bore has
# no such tie: the run is already on the lane by then, and a jog ALONG a lane costs it nothing.
# So the ring reads this column and the appliance reads the bore's, and neither is the other's.
water_outlet_climb_x = -48.5
# The lower climb clears the inlet copper tail; above it the tube leans gently toward the
# centre to clear reservoir B's upper corner, keeping the stock bend radius at each turn.
water_outlet_upper_climb_x = -47.0
water_outlet_drift_z = (80.0, 140.0)
# THE TWO REED CABLES LEAVE BY THE LID, each up the channel its own column stands in. A reed
# channel is a cavity open from the shell's floor to its top face (`_reed_channels`), so the
# cable's way out is the slot it is already lying in and a bore in the cap over the mouth of it.
# The column drops into the channel at `assembly/cold-core.md` step 7 and the cap goes on after
# it, so what this bore passes is the cable and never the column.
#   IT STEPS OFF THE CAVITY'S CENTRE AWAY FROM RESERVOIR B'S DRAW. B's channel shares the
# forward band with that draw's own conduit one lane over, and on the cavity's centre the two
# columns stand at exactly the tangent `cap_conduit_pair_neck` refuses — too near to leave the
# pour its gap between them, too far to fuse. Stepping the other way, INTO the merge, is a
# window `cap_conduit_entry_skew` closes from the other side: two bores near enough to share a
# post still open two entry cones in the lid, and those may not overlap. So the pair stands
# APART, and the step is what buys the gap. A's channel has nothing beside it and takes the same
# station mirrored, because one figure for both sides is what makes the pair read as one lane.
#   The bore is wider than the cavity and stands proud of it either side in X; what it owes is
# that it OPEN on the cavity rather than clip its corner, which is `_reed_channels` bound
# `reed-cable-conduit-stands-over-its-channel`.
reed_cable_conduit_x = bag_pocket_outermost_x + reed_x_depth / 2.0
reed_cable_conduit_step = 1.5
reed_cable_conduit_y = level_rod_y - reed_cable_conduit_step


def reed_cable_conduit_xy(side):
    """One side's reed-cable conduit in the CAP's frame — the cap installs spun a half turn,
    so a bore over the shell-frame station `(x, y)` is authored at `(−x, −y)` here."""
    return (-side * reed_cable_conduit_x, -reed_cable_conduit_y)


cap_fluid_conduits = {
    # THE THREE THAT CLIMB THE FORWARD BAND stand on its centre (`forward_band_mid_x`), which is
    # the only station in it that clears both its faces.
    "water-in": (forward_band_mid_x, -56.0),
    "reservoir-a": (forward_band_mid_x, 43.5),
    "reservoir-b": (forward_band_mid_x, -43.5),
    "reservoir-a-fill": reservoir_fill_conduit_xy(+1),
    "reservoir-b-fill": reservoir_fill_conduit_xy(-1),
    "carb-water-out": (52.2, -port_lane_mid_y),
    "co2-in": (co2_cap_x, -port_lane_mid_y),
}
# AND THE TWO THAT CARRY A CABLE. A bore in the cap over the mouth of a reed channel is the
# same column with the same bore, so it stands in the same table and answers to the same
# gates — `cap-conduit-room`, `cap-conduit-wall`, `cap-conduit-pair`, `entry-skew-ceiling`.
# What it is not is one end of a line: a reader counting the plumbing counts
# `cap_fluid_conduits`, and one counting holes in the lid counts these too.
cap_cable_conduits = {
    "reed-cable-a": reed_cable_conduit_xy(+1),
    "reed-cable-b": reed_cable_conduit_xy(-1),
}
cap_conduits = {**cap_fluid_conduits, **cap_cable_conduits}

# Every cut cap has a conduit over its bore, and every fill conduit has a cut cap under it.
# Naming is what carries the pairing across the two frames, so the name is checked too: the
# conduit for `side` is `reservoir-<x>-fill`, and it stands exactly on that side's anchor.
_fill_conduits = {n for n in cap_conduits if n.endswith("-fill")}
_fill_wanted = {f"reservoir-{'ab'[s < 0]}-fill" for s in reservoir_fill_sides}
state(
    "fill-conduits-paired", "Every fill bore has a conduit over it and every conduit a bore",
    f"the cap's fills naming {sorted(_fill_wanted)}",
    _fill_conduits == _fill_wanted,
    f"reservoir fills: {sorted(_fill_conduits)} stand on the cap, but "
    f"`reservoir_fill_sides` cuts {reservoir_fill_sides} — a conduit with no bore under it "
    f"is a hole into a sealed pocket, and a bore with no conduit over it is a blind one")
# The station is read only where the pairing above found a conduit to read it off. An unpaired
# side has already said so on its own row, and a lookup that is not there would take the whole
# module down with it — the one thing this ledger exists to stop.
_fill_station = bound(
    "fill-conduit-station", "Every fill conduit stands on its own side's anchor",
    "each conduit on the station its anchor strikes")
for _s in reservoir_fill_sides:
    _n = f"reservoir-{'ab'[_s < 0]}-fill"
    _at = cap_conduits.get(_n)
    if _at is None:
        continue
    _fill_station(
        _at == reservoir_fill_conduit_xy(_s),
        f"{_n} stands at {_at}, off the side {_s:+d} anchor's own station "
        f"{reservoir_fill_conduit_xy(_s)}")

# What a line arriving off-axis turns in: the band from a top-plate elbow's own lateral
# axis up to the cap's floor, against the rise a corner of 1/4" LLDPE takes.
carbonator_top_plate_z = wall_and_floor_thickness + carbonator_support_ring_height + carbonator_height
top_band_to_cap = foam_shell_outer_height - (carbonator_top_plate_z + hole_shift_from_edge)
# [25.4 mm](LLDPE_BEND_R) — the cold core's 4 × OD routing allowance. Actual drawn corner
# radii follow `_routing.stock_min`; the cured foam retains the internal routes.
# A bend radius alone does not specify the unloaded shape of an exposed tube.
lldpe_bend_radius = 4.0 * lldpe_tube_od


def cap_conduit_wall_neck(x, y):
    """What a conduit standing near the cup's PERIMETER leaves: `(mm, what)`.

    The same two states a pair of conduits has (`cap_conduit_pair_neck`), read against the
    wall instead of against another column. APART, with the pour gap between the column and
    the wall's inner face, so foam reaches down behind it. Or MERGED into the wall, and then
    what carries the joint is the material left OUTBOARD of the bore, which must be a wall
    thick — the column is no longer a post in the pour, it is a local thickening of the wall
    the bore runs up.
    A column that neither clears the wall nor reaches it stands tangent, which closes the
    same knife edge a tangent pair does."""
    to_outer = min(outer_shell_x_length / 2.0 - abs(x), outer_shell_y_length / 2.0 - abs(y))
    if to_outer - outer_shell_wall >= cap_conduit_boss_radius:
        return (to_outer - outer_shell_wall - cap_conduit_boss_radius,
                "the pour gap behind a standing column")
    return (to_outer - cap_conduit_bore_radius, "the wall left outboard of a merged bore")


def cap_conduit_room(name):
    """The least room this conduit leaves to anything else STANDING in the cup:
    `(mm, what)` — a screw boss, a deck mount's column. The perimeter wall is not one of
    these: a column may merge into it, and `cap_conduit_wall_neck` is what prices that."""
    x, y = cap_conduits[name]
    room = []
    for bx, by in attachment_xy_positions:
        room.append((math.hypot(x - bx, y - by)
                     - screw_boss_size / 2.0 - cap_conduit_boss_radius, "a screw boss"))
    for other in deck_mounts:
        for ox, oy in deck_mount_xy(other):
            room.append((math.hypot(x - ox, y - oy)
                         - deck_mount_boss_radius - cap_conduit_boss_radius,
                         f"the {other} mount"))
    return min(room)


_conduit_room = bound(
    "cap-conduit-room", "Every conduit column leaves the pour its gap in the cup",
    f"{deck_mount_cap_gap:g} mm off everything else standing in the cup")
_conduit_wall = bound(
    "cap-conduit-wall", "Every conduit column stands the pour gap off the wall or merges in",
    f"the pour gap apart or a {cap_conduit_wall:g} mm neck")
for _name in cap_conduits:
    _room, _what = cap_conduit_room(_name)
    _conduit_room(
        _room >= deck_mount_cap_gap - 1e-9,
        f"cap conduit {_name}: the column stands {_room:.3f} mm off {_what}, inside the "
        f"{deck_mount_cap_gap:g} mm the pour needs to reach between them")
    _neck, _what = cap_conduit_wall_neck(*cap_conduits[_name])
    _want = deck_mount_cap_gap if _what.startswith("the pour") else cap_conduit_wall
    _conduit_wall(
        _neck >= _want - 1e-9,
        f"cap conduit {_name}: {_what} is {_neck:.3f} mm, under the {_want:g} mm it takes "
        f"— a column either stands the pour gap off the wall or merges into it")


def foam_cap_lid_pour_xy():
    """Pour centre nearest the cap centreline with room beside mounts and plinths."""
    x = outer_shell_x_length / 2 - foam_cap_lid_hole_inset
    bands = []

    def fence(sx, sy, need):
        reach = need ** 2 - (x - sx) ** 2
        if reach > 0.0:
            half = math.sqrt(reach)
            bands.append((sy - half, sy + half))

    for name in deck_mounts:
        for sx, sy in deck_mount_xy(name):
            fence(sx, sy, foam_cap_lid_pour_radius + screw_clearance_radius
                  + deck_mount_cap_gap)
    for name, station in cap_cradles.items():
        assert math.isclose(station.yaw % 90.0, 0.0)
        cx, cy = station.centre
        hx, hy = cap_cradle_half_extents(name)
        core_x, core_y = hx - cap_cradle_corner_radius, hy - cap_cradle_corner_radius
        reach = foam_cap_lid_pour_radius + deck_mount_cap_gap + cap_cradle_corner_radius
        dx = max(abs(x - cx) - core_x, 0.0)
        if dx < reach:
            half = core_y + math.sqrt(reach * reach - dx * dx)
            bands.append((cy - half, cy + half))
    # MERGE FIRST, THEN STEP. Two stations near each other throw overlapping bands, and a
    # hole stepped off one lands inside the next — so the bands are run together into the
    # spans they actually close before the offset is read, and the answer is the nearer edge
    # of the one span that holds the centreline.
    merged: list = []
    for lo, hi in sorted(bands):
        if merged and lo <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], hi)
        else:
            merged.append([lo, hi])
    y = 0.0
    for lo, hi in merged:
        if lo < y < hi:
            y = lo if (y - lo) <= (hi - y) else hi
            break
    return (x, y)


def foam_cap_lid_vent_xy():
    """Both vent holes' centres in the lid — the −X corners, mirrored across y, where the
    pour hole is not and nothing stands. Air leaves by whichever is uppermost."""
    x = -(outer_shell_x_length / 2 - foam_cap_lid_hole_inset)
    y = outer_shell_y_length / 2 - foam_cap_lid_hole_inset
    return ((x, y), (x, -y))


_mount_pour = bound(
    "deck-mount-pour", "Every deck mount's lid hole leaves a land under its screw head",
    f"{deck_mount_cap_gap:g} mm off the pour hole")
for _name in deck_mounts:
    _px, _py = foam_cap_lid_pour_xy()
    for _sx, _sy in deck_mount_xy(_name):
        _room = (math.hypot(_px - _sx, _py - _sy)
                 - foam_cap_lid_pour_radius - screw_clearance_radius)
        _mount_pour(
            _room >= deck_mount_cap_gap - 1e-9,
            f"deck mount {_name}: its lid clearance hole at ({_sx:g}, {_sy:g}) stands "
            f"{_room:.3f} mm off the pour hole, inside the {deck_mount_cap_gap:g} mm that "
            f"leaves a land under the screw's head")


# Clearances are read on the complete plinth outline. Its conduit passages are
# cut separately; each socket keeps its complete surrounding wall beside them.
_cradle_room = bound(
    "cradle-room", "Every plinth clears the other openings on the lid",
    f"{cap_cradle_room_gap:g} mm off the nearest")
_cradle_pour = bound(
    "cradle-pour", "Every plinth leaves a land beside the pour hole",
    f"{cap_cradle_room_gap:g} mm off the pour hole")
_cradle_vent = bound(
    "cradle-vent", "Every plinth clears both vents",
    f"{cap_cradle_room_gap:g} mm off either vent")
for _name in cap_cradles:
    _room, _what = cap_cradle_room(_name)
    _cradle_room(_room >= cap_cradle_room_gap - 1e-9,
                 f"valve plinth {_name}: {_room:.3f} mm off {_what}")
    _room = cap_cradle_circle_gap(_name, *foam_cap_lid_pour_xy(), foam_cap_lid_pour_radius)
    _cradle_pour(_room >= cap_cradle_room_gap - 1e-9,
                 f"valve plinth {_name}: {_room:.3f} mm off the pour hole")
    for _hx, _hy in foam_cap_lid_vent_xy():
        _room = cap_cradle_circle_gap(_name, _hx, _hy, foam_cap_lid_vent_radius)
        _cradle_vent(_room >= cap_cradle_room_gap - 1e-9,
                     f"valve plinth {_name}: {_room:.3f} mm off a vent")
    for _sx, _sy in cap_cradle_xy(_name):
        for _hx, _hy in cap_conduits.values():
            _room = (math.hypot(_sx - _hx, _sy - _hy)
                     - cap_cradle_boss_radius - cap_conduit_entry_relief_radius)
            _cradle_room(_room >= cap_cradle_room_gap - 1e-9,
                         f"valve plinth {_name}: conduit passage preserves each socket wall")


# --- Chain anchors on the lid's outer face -----------------------------------
#
# ONE RIB UNDER A BODY THAT LIES OVER THIS FACE. The discharge chain is three fittings made up on
# the bench as one bar, held at one end by a hose clamp over the pump's stub and at the other by a
# push-fit collet. Between them it lies in this.
#
# THE SEAT IS A BORE, concentric with the section it takes. Every hex on that chain sits on a
# made-up thread, so where its flats land is wherever the thread stopped, and nothing on the body
# is clocked — the check's arrow is axial.
#
# IT OPENS UP, AND THE ZIP TIE ONLY PRELOADS IT. The chain lies IN this rib, so cutting the zip tie
# leaves it where it lies; what the zip tie carries is lift-out and the pump's own pulse. The pump
# bolts to this same plate through `deck_mounts`, so the stub between them spans no joint.
#
# The station lives here, in the cap's own frame, because the rib is printed in this part.
# `foam_cap.add_chain_anchors` stands it, `enclosure_assembly.build_discharge_chain` seats the
# body on `cap_anchor_axis_over_face`, and `check_disch_seated` reads the gap back off the two
# placed solids rather than off this table.
#
# Per anchor: the seat's centre in the CAP'S OWN frame, and the radius of the bore — the seated
# section's own circumradius plus the slip the machine closes on it. The rib is extruded along the
# cap's +X.
#   A RIB MAY BE LONGER THAN THE SECTION IT BEARS ON. The suction chain's longest metal is the
# MAACFLOW's 6 mm hex — its twin seats on the GASHER's 18 mm hex, and that fitting is only on the
# discharge side — so its rib overhangs onto the barb and the NPT either side. Both are thinner
# than the bore and neither touches it. `enclosure_assembly.anchor_rows` holds that: every section
# under a rib clears the bore, and exactly one fills it.
#   A ROW MAY STATE ITS OWN HEIGHT, and one kind of row has to. A CHAIN is free in Z — nothing
# above it fixes it — so it is seated on the rib and the rib takes the height the section stack
# asks for. A RUN is not: the plane a tube lies on is set by the two ports it joins, so there the
# rib comes to the tube instead, and `over_face` is what it has to reach. `check_run_seated` reads
# that back off the placed solids.
CapAnchor = namedtuple("CapAnchor", "centre seat_r over_face")
CapAnchor.__new__.__defaults__ = (None,)
cap_anchors = {
    #                             centre         seat_r  over_face
    "discharge-chain": CapAnchor((61.000, -60.500), 8.5 + fits.slip, 14.700),
    "suction-chain":   CapAnchor((33.120,  65.050), 8.5 + fits.slip, 14.700),
    # Reservoir A's fill runs aft along this straight cap lane. The anchor stands behind
    # V-A's plinth with the full room required by `cap_anchor_room`.
    #
    # Its column and height define the low lane between the actual V-A and V-K bodies.
    # `_lines._fluid_14` reads both from this row; `check_run_seated` reads the native
    # tube and seat back together. The 3 mm tie-channel floor and full bearing web remain.
    "fluid-14":        CapAnchor(( 41.000,  44.750), 6.35 / 2.0 + fits.slip, 15.894),
}

# What a zip tie is, wherever one is cut for on this cap. `enclosure.tie_w` is the same
# fastener stated for the other box; `enclosure_assembly.check_tie_vocabulary` holds the two
# against each other.
#   WHAT PICKS THE TIE IS THE LOOP, not the width: `cap_anchor_tie_loop` is [76.7 mm](ANCHOR_LOOP)
# round the chain and its rib, past the ~69 mm a 4" closes, so this one takes the 6" 18 lb the
# ledger already carries. An 18 lb zip tie is 0.1" across at every length it is sold in, so the
# longer tie goes through the same cavity.
cap_anchor_tie_w = 2.5              # the 18 lb zip tie, across its width — 0.1"
cap_anchor_cav_buffer = 2.0 * fits.slip
cap_anchor_cav_w = cap_anchor_tie_w + cap_anchor_cav_buffer
# Solid either side of the channel, ALONG the run: what the rib keeps of itself at each end.
cap_anchor_cav_wall = 3.0
# ITS LENGTH ALONG THE BODY IS ITS CHANNEL'S. One zip tie crosses one anchor, so the rib is that
# zip tie's cavity with `cap_anchor_cav_wall` of itself at each end of it.
cap_anchor_len = cap_anchor_cav_w + 2.0 * cap_anchor_cav_wall
# One wall of material under the bore's floor, and one more from there down to the lid's face —
# the height the rib's two ends stand, and the zip tie's channel between them. `valve_seat`'s is
# the wall this face already carries.
cap_anchor_wall = cap_cradle_wall


def cap_anchor_axis_over_face(name):
    """How far the seated body's AXIS stands over the lid's outer face.

    Three layers of the rib, read from the face up: the channel the zip tie is pushed through, one
    `cap_anchor_wall`; the material under the bore, one more; then the bore's own radius. A body
    seated lower than that sits on its own zip tie.

    A row that STATES its own height is one whose body cannot move to meet the rib, so the rib is
    built up to it. What it must not do is come out under the three layers, which is the same
    floor a seated body has."""
    stated = cap_anchors[name].over_face
    least = cap_anchors[name].seat_r + 2.0 * cap_anchor_wall
    if stated is None:
        return least
    if stated < least - 1e-9:
        raise ValueError(
            f"cap_anchor_axis_over_face: {name} states {stated:.3f} mm over the lid's face and "
            f"the rib's own three layers come to {least:.3f}. A seat lower than that stands the "
            f"body on its own zip tie.")
    return stated


def cap_anchor_tie_loop(name):
    """The shortest zip tie that closes round the seated body and the rib together.

    A zip tie turns INSIDE the channel, so what it reaches round is the body with the rib's own
    back behind it — the convex perimeter of that pair, and not of the lid the rib stands on.
    Read on the bore rather than on the body, which is the section this part knows.

    The hull is the rib's rectangle with a cap of the bore over it: its floor, its two flanks,
    a tangent from each top corner onto the bore, and the arc between the two tangent points."""
    r = cap_anchors[name].seat_r
    w = r + cap_anchor_wall                       # the rib's half-width, and its depth
    return 2.0 * w + 2.0 * w + 2.0 * math.sqrt(w * w - r * r) + r * (math.pi - 2.0 * math.acos(r / w))


def cap_anchor_room(name):
    """The least room this rib leaves to anything else opening on the lid's outer face:
    `(mm, what)` — a conduit's entry countersink, a clamp screw's counterbore, a deck mount's
    lid hole, a cradle boss, the pour hole, a vent, the lid's own edge.

    Read on the rib's own rectangle, which is the whole of it: `cap_anchor_len` down the cap's
    +X and one `reach` either side of the centre across it."""
    (cx, cy) = cap_anchors[name].centre
    reach = cap_anchors[name].seat_r + cap_anchor_wall
    x0, x1 = cx - cap_anchor_len / 2.0, cx + cap_anchor_len / 2.0
    y0, y1 = cy - reach, cy + reach

    def off(px, py, r):
        """How far a disc of radius `r` at (px, py) stands off the rib's rectangle."""
        dx = max(x0 - px, 0.0, px - x1)
        dy = max(y0 - py, 0.0, py - y1)
        return math.hypot(dx, dy) - r

    room = []
    for cname, (bx, by) in cap_conduits.items():
        room.append((off(bx, by, cap_conduit_entry_relief_radius),
                     f"the {cname} conduit's entry"))
    for bx, by in attachment_xy_positions:
        room.append((off(bx, by, head_cbore_radius), "a clamp screw's counterbore"))
    for dname in deck_mounts:
        for dx, dy in deck_mount_xy(dname):
            room.append((off(dx, dy, deck_lid_hole_radius(dname)),
                         f"the {dname} mount's lid hole"))
    for vname in cap_cradles:
        room.append((cap_cradle_rectangle_gap(vname, x0, x1, y0, y1),
                     f"the {vname} plinth"))
    room.append((off(*foam_cap_lid_pour_xy(), foam_cap_lid_pour_radius), "the pour hole"))
    for hx, hy in foam_cap_lid_vent_xy():
        room.append((off(hx, hy, foam_cap_lid_vent_radius), "a vent"))
    room.append((min(outer_shell_x_length / 2.0 - abs(x0),
                     outer_shell_x_length / 2.0 - abs(x1),
                     outer_shell_y_length / 2.0 - abs(y0),
                     outer_shell_y_length / 2.0 - abs(y1)), "the lid's own edge"))
    return min(room)


# The rib stands on a plate it only touches, so everything the face opens has to be somewhere
# else: a rib over a hole is a channel with no floor and a zip tie that falls into the cup.
_anchor_room = bound(
    "anchor-room", "Every chain anchor stands its room off everything else the face opens",
    f"{cap_cradle_room_gap:g} mm off the nearest")
for _name in cap_anchors:
    _room, _what = cap_anchor_room(_name)
    _anchor_room(
        _room >= cap_cradle_room_gap - 1e-9,
        f"chain anchor {_name}: the rib stands {_room:.3f} mm off {_what}, inside the "
        f"{cap_cradle_room_gap:g} mm this face keeps between two things it opens")


# --- the anchors that grip SIDEWAYS -----------------------------------------
#
# The ribs above open at the sky: a run is laid down into the trough and the zip tie comes up round
# it. A run laid ACROSS this lid cannot be held that way. `water-3` crosses the machine along the
# cap's own Y, one lane off the core's front face, and an upward trough on that line would open
# its mouth at the funnel — a tube dropped into it would come down through the storey the
# source valves fill.
#
# SO THIS ONE STANDS ON THE STEP AND GRIPS THE RUN FROM BEHIND. A post, its FORWARD face the run's
# own axis plane, a half pipe cut into that face, and the tube pushed in horizontally.
#
# THE POST GROWS ALONG THE CAP'S OWN −X, which the machine lays on world +Y: the pipe's axis
# plane is its forward face and everything behind it is between the run and the core the run is
# assembled onto. `centre` is that axis plane, so the post is on the far side of it from the room.
#
# THE TIE'S TUNNEL IS A WINDOW CUT THROUGH THE POST, front to back, hung one wall under the pipe.
# The tie goes through the window, out the front, round the tube and back over the post's crown,
# and buckles in the channel down its back — so the loop closes on the tube, and every millimetre
# the window stands off the pipe is a millimetre added to that loop and taken out of the post.
# Each station's `depth` runs aft from its front face along the cap's −X.
SideAnchor = namedtuple("SideAnchor", "centre over_face seat_r axis_off depth")

cap_side_wall = cap_anchor_wall           # every solid section in the post
cap_side_len = cap_anchor_len             # along the run, one tie's tunnel and its two flanks
cap_side_cav_w = cap_anchor_cav_w         # the tunnel's width, on the zip tie and its slip
cap_side_flank = (cap_side_len - cap_side_cav_w) / 2.0
# The 18 lb zip tie through its thickness — `enclosure.tie_t`, and the one figure the window
# has to leave standing.
cap_side_tie_t = 1.0
# WHAT THE WINDOW IS NOT IS THE WHOLE COLUMN UNDER THE PIPE. The up-opening ribs take their
# channel as the remainder between two feet, and a post that did the same would give the whole of
# its height to one: this post stands as tall as the run it grips, so on a high crossing the
# remainder is two `cap_side_flank` blades running the post's length with nothing but the roof
# joining them — a pair of towers to print where the section wants to be one block.
#   So the window is a STATED height and the rest of that column is the post's own stock, which
# is `enclosure.tube_anchor_cavity_depth`'s bargain read on this face: a 1 mm zip tie needs its
# own thickness and routing air, not every millimetre between a low run and a tall post.
cap_side_cav_h = cap_side_wall
# And a post whose pipe runs low keeps all the air it has. Capping a window that is already
# compact buys a fraction of channel back as a floor thinner than the room the cavity is cut
# with — `enclosure.tube_anchor_backing_min` again, and the same figure.
cap_side_cav_backing_min = 1.0  # printable stock, independent of tie clearance
# The tie's own channel down the post's back face, so the buckle seats and the zip tie cannot walk
# along the run.
cap_side_back_relief = 1.2
# The bore and the rear tie channel retain one nominal wall between them. The
# zip tie pulls the tube into that section; this geometric floor does not qualify
# its retention load or endurance.
cap_side_web = cap_side_wall

cap_side_anchors = {
    # The tap-water branch to V-K, on the lid's front step. `centre` is the run's own axis where
    # it crosses this post — the cap's (x, y), with the run along the cap's Y — and `over_face`
    # is the height that axis stands over the lid's outer face.
    #   The post stands on the lid's front step inside the core's plan outline, its face two
    # lanes aft of the core's own front plane — the crossing walks with the funnel drain's
    # berth (`funnel.neck_dy`), and the post follows it aft so the fall off the union
    # keeps its metre. The cap's Y is on the mirror line, between the two port stubs the
    # source pair leaves over this step. `axis_off` stands the pipe forward of the post's
    # face: the seat is the shallower wrap that leaves, and the tie is what holds.
    #   THE POST AND `_lines.CROSS_Y` ARE ONE FIGURE IN TWO FILES — the run crosses where this
    # grips it. `enclosure_assembly.cap_tube_anchors` is what refuses a post no leg passes
    # through, so the pair cannot drift apart quietly.
    # The post is one length deep, with the V-B plinth aft of it.
    "water-3": SideAnchor((138.000, -13.000), 7.600, 6.35 / 2.0 + fits.slip, 1.500, cap_side_len),
    # The flavor-A crossing is on the lid's fore strip, ahead of both cap valves.
    # Its low side seat keeps a full wall below and above the bore, a tie path under it,
    # and 3.475 mm of stock between the bore and the rear tie channel. The west leg
    # follows the cap's outboard flank before returning to the rear union's column.
    "fluid-18": SideAnchor((120.800, 34.000), 7.600, 6.35 / 2.0 + fits.slip, 1.000, 7.000),
}


def cap_side_axis_y(name) -> float:
    """The pipe's axis in the cap's own X — the post's front face, stood `axis_off` forward of
    it. The cap's +X is the world's forward, so the axis is at the greater figure."""
    a = cap_side_anchors[name]
    return a.centre[0] + a.axis_off


def cap_side_wrap_deg(name) -> float:
    """How much of the tube's own circle the seat closes on, in degrees. A pipe on the face
    itself takes half; one stood proud of it takes less, and what makes up the difference is the
    tie."""
    a = cap_side_anchors[name]
    return 2.0 * math.degrees(math.acos(a.axis_off / a.seat_r))


def cap_side_tunnel_roof(name) -> float:
    """The tunnel's roof over the lid's outer face — one wall under the pipe, which is the whole
    of the column the post has to hand the zip tie."""
    a = cap_side_anchors[name]
    return a.over_face - a.seat_r - cap_side_wall


def cap_side_tunnel_h(name) -> float:
    """The tunnel's own height, hung under that roof.

    A post with the column to spend gives the window `cap_side_cav_h` of it and stands its own
    stock under the rest, so what prints below the pipe is one block and not two blades. A post
    whose pipe runs low keeps all the air it has, since a window capped there would trade the
    channel for a floor thinner than `cap_side_cav_backing_min`."""
    roof = cap_side_tunnel_roof(name)
    if roof - cap_side_cav_h >= cap_side_cav_backing_min - 1e-9:
        return cap_side_cav_h
    return roof


def cap_side_anchor_height(name) -> float:
    """How tall the post stands over the lid's outer face — the axis, the pipe's own radius over
    it, and one wall over that."""
    a = cap_side_anchors[name]
    return a.over_face + a.seat_r + fits.supported_surface + cap_side_wall


def cap_side_anchor_holds(name) -> None:
    """The post's own stack, against what the run's height gives it.

    A run laid closer to the lid's face than the pipe, one wall and the zip tie together is a run
    with no tie path under it, and the post would stand on its own zip tie."""
    a = cap_side_anchors[name]
    roof = cap_side_tunnel_roof(name)
    if roof < cap_side_tie_t - 1e-9:
        raise ValueError(
            f"cap_side_anchor_holds: {name} runs {a.over_face:.3f} mm over the lid's face; the "
            f"pipe takes {a.seat_r:.3f} of that and one wall {cap_side_wall:.3f} more, leaving "
            f"{roof:.3f} mm under it where the zip tie is {cap_side_tie_t:g} thick. What gives "
            f"way here is the run's own lane, not the lid: route it further off that face.")
    if a.axis_off >= a.seat_r - cap_side_tie_t:
        raise ValueError(
            f"cap_side_anchor_holds: {name} stands its pipe {a.axis_off:.3f} mm forward of the "
            f"post's face on a seat of {a.seat_r:.3f} — what is left of the seat is a scratch in "
            f"the face, and the tube would lie on the face rather than in anything.")
    # The bore eats forward from the front face and the tie's channel eats back from the rear one,
    # and they meet over the pipe: what is left between them is the whole of the web, so the
    # relief comes off the reading the same way the seat does.
    web = a.depth + a.axis_off - a.seat_r - cap_side_back_relief
    if web < cap_side_web - 1e-9:
        raise ValueError(
            f"cap_side_anchor_holds: the post runs {a.depth:.3f} mm back from its face; "
            f"the pipe takes {a.seat_r - a.axis_off:.3f} of that and the tie's channel "
            f"{cap_side_back_relief:g} more, leaving a web of {web:.3f} where this face wants "
            f"{cap_side_web:g}. What caps the depth is the body behind the post, so what gives "
            f"is the pipe or the lane — not the web.")


def cap_side_anchor_tie_loop(name) -> float:
    """The shortest tie that closes round the tube and the post's own back together.

    A tie turns INSIDE the window, so what it reaches round is everything ABOVE the window: the
    tube, and the block of post between the window's roof and the post's own crown. That crown
    is one wall PROUD OF THE TUBE'S TOP, so the loop clears the post there and not the pipe, and
    the figure is not the up-opening ribs' — theirs stops on the axis plane.
      The hull is that block's rectangle with the pipe bulging out of one face: the window's own
    floor, the crown, the back face between them, a tangent from each front corner onto the pipe,
    and the arc the two tangent points leave. Read on the post's own faces, so the back channel's
    relief is slack the tie does not have to reach round.
      IT IS THE WINDOW'S HEIGHT THAT SETS IT, which is why the window is stated rather than left:
    a window taken as the remainder under the pipe carries the loop up with the post."""
    a = cap_side_anchors[name]
    w = a.seat_r + cap_side_wall
    tun_h = cap_side_tunnel_h(name)
    axis = tun_h + w                              # the pipe's axis over the window's floor
    crown = tun_h + 2.0 * w                       # and the post's crown over that same floor
    d_lo = math.hypot(a.axis_off, axis)           # the two front corners' reach to the axis
    d_hi = math.hypot(a.axis_off, crown - axis)
    sweep = (math.atan2(crown - axis, -a.axis_off)
             - math.atan2(-axis, -a.axis_off)) % (2.0 * math.pi)
    return (2.0 * a.depth + crown
            + math.sqrt(d_lo * d_lo - a.seat_r * a.seat_r)
            + math.sqrt(d_hi * d_hi - a.seat_r * a.seat_r)
            + a.seat_r * (sweep - math.acos(a.seat_r / d_lo) - math.acos(a.seat_r / d_hi)))


def cap_side_anchor_room(name):
    """The least room this post leaves to anything else opening on the lid's outer face:
    `(mm, what)` — a clamp screw's counterbore, a conduit's entry countersink, a deck mount's
    lid hole, a cradle boss, the pour hole, a vent, the up-opening ribs.

    A POST IS THE ONE THING ON THIS FACE THAT STANDS ON IT WITHOUT BEING CUT INTO IT, and that
    is why it needs saying. Every other body here opens THROUGH the plate, so two of them
    fouling shows up as a hole in the wrong shape; a post fouling one shows up as nothing at
    all — the lid comes off the plate correct and the screw under the post cannot be driven.
    `cap_anchor_room` reads the up-opening ribs the same way and this is its twin, on the
    family that stands on the cap's side instead.

    Read on the post's own rectangle, which is the whole of its footing. `centre` is NOT the
    middle of it in both axes: in the cap's X it is the post's FRONT FACE, the plane
    `axis_off` stands the pipe forward of, and the block runs the station's `depth` aft of that.
    In the cap's Y it is the middle, and the block is `cap_side_len` long about it."""
    a = cap_side_anchors[name]
    (cx, cy) = a.centre
    x0, x1 = cx - a.depth, cx
    y0, y1 = cy - cap_side_len / 2.0, cy + cap_side_len / 2.0

    def off(px, py, r):
        """How far a disc of radius `r` at (px, py) stands off the post's rectangle."""
        dx = max(x0 - px, 0.0, px - x1)
        dy = max(y0 - py, 0.0, py - y1)
        return math.hypot(dx, dy) - r

    room = []
    for bx, by in attachment_xy_positions:
        room.append((off(bx, by, head_cbore_radius), "a clamp screw's counterbore"))
    for cname, (bx, by) in cap_conduits.items():
        room.append((off(bx, by, cap_conduit_entry_relief_radius),
                     f"the {cname} conduit's entry"))
    for dname in deck_mounts:
        for dx, dy in deck_mount_xy(dname):
            room.append((off(dx, dy, deck_lid_hole_radius(dname)),
                         f"the {dname} mount's lid hole"))
    for vname in cap_cradles:
        room.append((cap_cradle_rectangle_gap(vname, x0, x1, y0, y1),
                     f"the {vname} plinth"))
    for aname in cap_anchors:
        room.append((off(*cap_anchors[aname].centre,
                         cap_anchors[aname].seat_r + cap_anchor_wall),
                     f"the {aname} rib"))
    room.append((off(*foam_cap_lid_pour_xy(), foam_cap_lid_pour_radius), "the pour hole"))
    for hx, hy in foam_cap_lid_vent_xy():
        room.append((off(hx, hy, foam_cap_lid_vent_radius), "a vent"))
    return min(room)


_side_anchor_room = bound(
    "cap-side-anchor-room", "Every side post stands clear of what the lid's face opens",
    f"{cap_cradle_room_gap:g} mm off the nearest")
for _name in cap_side_anchors:
    _room, _what = cap_side_anchor_room(_name)
    _side_anchor_room(
        _room >= cap_cradle_room_gap - 1e-9,
        f"cap side anchor {_name}: its post stands {_room:.3f} mm off {_what}, inside the "
        f"{cap_cradle_room_gap:g} mm this face keeps between two things it opens — a post over "
        f"one of them is a body no plate reads as fouled")


def cap_conduit_pair_neck(a, b):
    """What a PAIR of conduits leaves between them: `(mm, what)`.

    A pair is one of two things and never a third. APART, with at least the pour gap
    between the two columns, so foam reaches down between them. Or MERGED, the two bores
    standing nearer than a boss diameter and their columns fusing into one post — and then
    what matters is the NECK the lens leaves, which carries the joint and must be a wall
    thick. What neither may be is tangent: two circles meeting near a point close a knife
    edge that prints as a void and holds no load.

    `cap_conduit_room` prices a conduit against everything else standing in the cup; this
    is the one pair it cannot price, because for a pair overlap is a design and not a
    clash."""
    r = cap_conduit_boss_radius
    d = math.hypot(a[0] - b[0], a[1] - b[1])
    if d >= 2.0 * r:
        return (d - 2.0 * r, "the pour gap between two standing columns")
    return (2.0 * math.sqrt(max(r * r - (d / 2.0) ** 2, 0.0)), "the neck their lens leaves")


_pair_neck = bound(
    "cap-conduit-pair", "Every pair of conduits stands apart or merges on a neck, never tangent",
    f"the pour gap apart or a {cap_conduit_wall:g} mm neck")
for _a, _b in itertools.combinations(sorted(cap_conduits), 2):
    _neck, _what = cap_conduit_pair_neck(cap_conduits[_a], cap_conduits[_b])
    _want = (deck_mount_cap_gap
             if _what.startswith("the pour") else cap_conduit_wall)
    _pair_neck(
        _neck >= _want - 1e-9,
        f"cap conduits {_a} and {_b}: {_what} is {_neck:.3f} mm, under the "
        f"{_want:g} mm it takes — a pair either stands the pour gap apart or merges on a "
        f"neck a wall thick")


def cap_conduit_shell_xy(name):
    """One cap conduit's station in the SHELL's own frame — where the line coming down it
    lands in the shell, which is the frame every band and lane in this file is stated in.

    The cap installs spun a half turn about Z (`foam_assembly.spin_xy`) and a half turn is
    its own inverse, so this is the authored pair negated. Everything that has to meet a
    conduit from BELOW reads it here."""
    x, y = cap_conduits[name]
    return (-x, -y)


# The face a cap conduit opens on, as a direction: the TOP cap's own +Z.
cap_conduit_axis = (0.0, 0.0, 1.0)


def cap_conduit_station(name):
    """One cap conduit's mouth in the CAP'S OWN frame: `(position, outward axis)`, with Z
    left at the lid's outer face for whoever seats the stack to carry."""
    x, y = cap_conduits[name]
    return ((x, y, 0.0), cap_conduit_axis)



def make_box(x_range, y_range, z_range):
    """Axis-aligned box from world-coordinate ranges in each axis."""
    x_min, x_max = min(x_range), max(x_range)
    y_min, y_max = min(y_range), max(y_range)
    z_min, z_max = min(z_range), max(z_range)
    return (
        WorldWorkplane(xy_plane_z_up)
        .workplane(offset=z_min)
        .moveTo(((x_min + x_max) / 2, (y_min + y_max) / 2))
        .rect(x_max - x_min, y_max - y_min)
        .extrude(z_max - z_min)
        .unwrap()
    )


def build_hole_punch(
    *,
    origin=(0, 0, 0),
    hole_punch_radius,
    hole_punch_height=40,
    direction=1,
):
    """Y-axis ⌀ × height cylindrical cut, centered at `origin`'s X/Z and
    starting at `origin`'s Y, extruded in `direction`·Y (+1 = +Y, −1 = −Y —
    so a port on the −Y wall punches outward toward −Y)."""
    x, y, z = origin
    return (
        cq.Workplane(xz_plane_y_up)
        .workplane(origin=(x, 0, z), offset=y)
        .circle(hole_punch_radius)
        .extrude(direction * hole_punch_height)
    )


def build_x_axis_hole_punch(
    *,
    origin=(0, 0, 0),
    hole_punch_radius,
    hole_punch_height=40,
    direction=1,
):
    """X-axis ⌀ × height cylindrical cut, centered at `origin`'s Y/Z and starting
    at `origin`'s X, extruded in `direction`·X (+1 = +X, −1 = −X — so a port on the
    −X wall punches outward toward −X)."""
    x, y, z = origin
    return cq.Solid.makeCylinder(
        hole_punch_radius, hole_punch_height,
        cq.Vector(x, y, z), cq.Vector(direction, 0, 0))


def cut_front_exit(foam_shell, *, z, hole_punch_radius, lateral=0.0):
    """One penetration's mouth: a bore straight out through the −X wall, on the
    port lane at `lateral` off its centre. The line inside reaches it along the
    lane, so this bore's Z is the field's station and has nothing to do with the
    height of the fitting it serves."""
    overshoot = 1.0                                    # a through-cut, both faces cleared
    return foam_shell.cut(
        build_x_axis_hole_punch(
            origin=(front_wall_x + wall_and_floor_thickness + overshoot,
                    port_lane_mid_y + lateral, z),
            hole_punch_radius=hole_punch_radius,
            hole_punch_height=wall_and_floor_thickness + 2.0 * overshoot,
            direction=-1,
        )
    )


def pour_band_pocket_punch(*, pocket_hole_x, y, z, hole_punch_radius):
    """The pocket-side half of a pour-band pass-through, as a SOLID: a bore through the
    bag-pocket (or ring) wall at `pocket_hole_x`, starting at `y` and stopping on the port
    lane.

    Named apart from the cut so that whatever prices a neighbouring opening against this
    hole is reading the hole itself and not a second construction of it."""
    return build_hole_punch(
        origin=(pocket_hole_x, y, z),
        hole_punch_radius=hole_punch_radius,
        hole_punch_height=y - port_lane_mid_y,
        direction=-1,
    )


def cut_pour_band_pass_through(
    foam_shell,
    *,
    pocket_hole_x,
    y,
    z,
    exit_z,
    hole_punch_radius,
):
    """Cut one pass-through as two bores that do not meet: through the bag-pocket
    (or ring) wall at `pocket_hole_x`, starting at `y` and stopping on the port
    lane, and out through the −X wall at the field station `exit_z`. Between them
    the line turns and runs along the open lane — west to the wall, and up it from
    the fitting's own height to the station's. The lane is what lets the two sit at
    different X *and* different Z."""
    foam_shell = foam_shell.cut(
        pour_band_pocket_punch(
            pocket_hole_x=pocket_hole_x, y=y, z=z, hole_punch_radius=hole_punch_radius)
    )
    return cut_front_exit(foam_shell, z=exit_z, hole_punch_radius=hole_punch_radius)


def build_slot_punch(
    origin=(0, 0, 0),
    slot_length=1.0,
    slot_diameter=6.5,
    slot_punch_height=40,
    direction=1,
):
    """Z-elongated, Y-extruded rounded slot (circle-rect-circle), centered
    at `origin`'s X/Z and starting at `origin`'s Y, extruded in `direction`·Y
    (+1 = +Y, −1 = −Y). Long axis runs along world Z. The rounded ends each
    contribute slot_diameter/2 of additional Z reach beyond `slot_length`."""
    x, y, z = origin
    return (
        cq.Workplane(xz_plane_y_up)
        .workplane(origin=(x, 0, z), offset=y)
        .slot2D(slot_length, slot_diameter, angle=90)
        .extrude(direction * slot_punch_height)
    )


def port_to_shell(solid, lane_y=None):
    """Carry a solid from the PORT FRAME into the shell's, onto one of the front wall's
    two lanes.

    The port frame is the one every penetration is authored in, the copper-plug
    stack among them: x lateral across the face, −y out through it, z the shell's
    own. One quarter turn about Z puts its −y on the shell's −X, and one slide puts
    its lateral centreline on a lane. Authoring there is what keeps the plug
    stack and the slot it fills a single reading — a plug is a part that plugs a slot
    in a wall, and that is the frame that says so; a pose turned by hand alongside a
    slot cut by hand is two implementations of one transform.

    ONE FRAME SERVES BOTH LANES because both are the same wall: `lane_y` is the only
    thing that differs, so a plug printed for one lane fits the other."""
    return (solid.rotate(cq.Vector(0, 0, 0), cq.Vector(0, 0, 1), -90.0)
                 .translate(cq.Vector(0.0, port_lane_mid_y if lane_y is None else lane_y, 0.0)))


def build_z_axis_hole_punch(
    *,
    origin=(0, 0, 0),
    hole_punch_radius,
    hole_punch_height=40,
):
    """Z-axis ⌀ × height cylindrical cut, centered at `origin`'s X/Y and
    starting at `origin`'s Z, extruded in +Z."""
    x, y, z = origin
    return (
        cq.Workplane(xy_plane_z_up)
        .workplane(origin=(x, y, 0), offset=z)
        .circle(hole_punch_radius)
        .extrude(hole_punch_height)
    )


if __name__ == "__main__":
    sys.path.insert(
        0,
        str(next(p for p in _here.parents if (p / "tools" / "docgen").is_dir()) / "tools"),
    )
    from docgen import substitute_py_comments

    variables = {
        "WALL_AND_FLOOR_THICKNESS": f"{wall_and_floor_thickness:.4g} mm",
        "COIL_RADIAL_CLEARANCE": f"{coil_radial_clearance:.4g} mm",
        "ABOVE_TANK_ELBOWS_HEIGHT": f"{above_carbonator_elbows_height:.4g} mm",
        "BELOW_TANK_ELBOWS_HEIGHT": f"{below_carbonator_elbows_height:.4g} mm",
        "PORT_HOLE_DIAMETER": f"{port_hole_radius * 2:.4g}",
        "SCREW_CLEARANCE_DIAMETER": f"{screw_clearance_radius * 2:.4g}",
        "INSERT_POCKET_DIAMETER": f"{insert_pocket_radius * 2:.4g}",
        "SCREW_BOSS_SIZE": f"{screw_boss_size:.4g} × {screw_boss_size:.4g} mm",
        "SCREW_HEAD_H": f"{screw_head_height:.4g} mm",
        "HEAD_PAD_H": f"{head_pad_height:.4g} mm",
        "FOAM_CAP_LID_H": f"{foam_cap_lid_height:.4g} mm",
        "HEAD_CBORE_D": f"{head_cbore_radius * 2:.4g} mm",
        "CAP_SCREW_L": f"{cap_screw_length:.4g}",
        "DECK_MOUNT_CAP_GAP": f"{deck_mount_cap_gap:.4g} mm",
        "CARBONATOR_PORT_PITCH": f"{2 * carbonator_port_offset / 25.4:.4g}\"",
        "CARBONATOR_PORT_OFFSET": f"{carbonator_port_offset:.4g} mm",
        "LLDPE_BEND_R": f"{lldpe_bend_radius:.4g} mm",
        "FORWARD_BAND": f"{forward_band_width:.4g} mm",
        "LLDPE_TUBE_OD": f"{lldpe_tube_od:.4g}",
        "ENTRY_RELIEF_D": f"{2.0 * cap_conduit_entry_relief_radius:.4g}",
        "ENTRY_SKEW_CEILING": f"{cap_conduit_entry_skew_ceiling:.4g}°",
        "ANCHOR_LOOP": f"{cap_anchor_tie_loop('discharge-chain'):.3g} mm",
    }
    substitute_py_comments(
        Path(__file__),
        variables=variables,
    )
    print("-> _cold_core_interface.py (self)")
