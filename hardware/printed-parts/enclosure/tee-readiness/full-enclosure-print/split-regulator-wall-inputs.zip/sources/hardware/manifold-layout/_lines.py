"""The enclosure assembly's tube runs — every line between two placed bodies, authored port to port.

The manifold's own 21 segments are drawn by `manifold_layout.py`, which knows its butt joints
and its hairpins. This module is for the runs BETWEEN sub-assemblies: a mouth on one placed body
to a mouth on another, through whatever the pack leaves between them.

Each run is one `R.bent(...)` — the source port, hand-placed interior waypoints, the destination
port — swept at the port's own bore. `_routing` seats the largest arc each corner's two legs
allow and records the shortfall of any that cannot: a run drawn past its stock's floor is still
drawn, and `BLOCKED` says by how much.

A RUN ARRIVES WITH THE BODIES IT JOINS. Both of its mouths have to be placed before it can be
authored, so the set here grows as `enclosure_assembly.build_pack` grows, and a run with one end in
the pack and the other nowhere is not written down as a guess. `build_seated_runs` is the same rule
one step later: the box is sized on the pack, so a body seated in one of its WALLS is placed after
it, and the lines reaching those bodies are drawn once the box exists.

Frames come off the placed pack, so a run rides a move of its parts: change a pose in
`enclosure_assembly.py` and every waypoint measured off that body's ports moves with it.

Where a piece of a run can stand is read by sweeping it —
[`probe.World.reroute`](/hardware/scripts/probe.py) slides named waypoints across a range of
offsets, redraws the run at each one, and reports what it collides with there, the bands that
are clear, and the radius each corner has left:

    tools/cad-venv/bin/python hardware/scripts/probe.py route fluid-14
    tools/cad-venv/bin/python hardware/scripts/probe.py reroute fluid-14 3-4 y- 0:80:2.5

A bend, a fall, a crossing, a leg — whatever the piece is called it is some waypoints of the
route, and those indices are the handle (`route` numbers them, `--near x,y,z` says which index
a pick off the STEP is). The centreline is what moves; the ribs struck on the run, the cap's
seat for it and the stretch it is graded on stand where they stand, and each sweep prints them.

Run it through the assembly:
    tools/cad-venv/bin/python hardware/manifold-layout/enclosure_assembly.py
"""

import sys
from pathlib import Path

_here = Path(__file__).resolve()
_hw = next(p for p in _here.parents if p.name == "hardware")
# EVERY MODULE IMPORTED BELOW IS ON THIS LIST, this module's own directory among them. A module
# that leans on its importer's path is one only that importer can import: the doc-sync drivers
# reach this file without going through `enclosure_assembly`, and they set up their own path.
for _p in (_hw / "scripts", _here.parent,
           _hw / "printed-parts" / "cold-core",
           _hw / "printed-parts" / "cold-core" / "copper-plugs",
           _hw / "printed-parts" / "zone-c" / "funnel",
           _hw / "printed-parts" / "enclosure" / "enclosure",
           _hw / "reference" / "compressor",
           _hw / "reference" / "condenser-block",
           _hw / "reference" / "g-ganen-pump" / "installation",
           _hw / "reference" / "seaflo-suction-chain",
           _hw / "reference" / "seaflo-discharge-chain",
           _hw / "reference" / "asse1022-assembly",
           _hw / "reference" / "water-split",
           _hw / "reference" / "neofit-flow-control",
           _hw / "reference" / "beduan-solenoid",
           _hw / "reference" / "jg-bulkhead-union",
           _hw / "reference" / "elbow-connector",
           _hw / "reference" / "neofit-bulkhead",
           _hw / "reference" / "gasher-check-valve",
           _hw / "reference" / "wr1110-regulator",
           _hw / "reference" / "digiten-flow-sensor"):
    sys.path.insert(0, str(_p))
import _routing as R                                   # noqa: E402
import _cold_core_interface as _cc                     # noqa: E402
import asse1022_assembly as _asse                      # noqa: E402
import funnel as _funnel                        # noqa: E402
import g_ganen_installation as _pump                         # noqa: E402
import seaflo_suction_chain as _suct                   # noqa: E402
import seaflo_discharge_chain as _dis                  # noqa: E402
import beduan_solenoid as _beduan                      # noqa: E402
import jg_bulkhead_union as _jg                        # noqa: E402
import elbow_connector as _elbow                       # noqa: E402
import neofit_bulkhead as _neofit                      # noqa: E402
import neofit_flow_control as _flowreg                 # noqa: E402
import water_split as _split                           # noqa: E402
import manifold_layout as _ml                           # noqa: E402
import compressor as _comp                             # noqa: E402
import condenser_block as _cond                        # noqa: E402
import copper_plugs as _plugs                          # noqa: E402
import gasher_check_valve as _gasher                    # noqa: E402
import wr1110_regulator as _wr1110                      # noqa: E402
import _gas_chain                                      # noqa: E402
import digiten_flow_sensor as _digiten                  # noqa: E402
# The one floor every pair on the card answers to, so a run drawn against a casting
# and the reading taken of it afterwards cannot come off two different millimetres.
import _scorecard as _card                             # noqa: E402

BLOCKED = R.BLOCKED


def _ea_cap(name):
    """The core's cap conduit stations, read off `enclosure_assembly` at call time — importing it
    here at module scope would close a cycle, since it imports this one."""
    import enclosure_assembly
    return enclosure_assembly.cap_conduit(name)

# The 3/8" reinforced PVC's own floor, and the coarsest stock on the machine: a corner it cannot
# hold is a corner nothing drawn here can.
HOSE_BEND = R.stock_min("water", _suct.HOSE_OD)
# The 1/4" LLDPE's, which every fitting on the water side hands over on.
TUBE_BEND = R.stock_min("water", _split.TUBE_D)
# How far off its own axis a hose may leave a BARB and still run unbent. A barb is a taper the
# hose stretches over and a clamp closes on, not a collet gripping a tube all round, so it takes
# a good deal more than `R.COLLET_SKEW`. Seeded, not ratified.
BARB_SKEW = 14.0
# 1/4" soft ACR copper, the stock the sealed loop is cut from.
CU_OD = 6.35
# The straight each copper mouth takes before its first corner, so the arcs seat in the middle
# of the run and neither brazed stub is asked to bend where it is made up.
CU_BEND = R.stock_min("refrigerant", CU_OD)
CU_LEAD = 20.0
# The lane the compressor's suction turns in, off the −X wall's inner face: the straight the leg
# leaves on and the radius its first corner carries past that straight.
CU_SUCTION_LANE = 2.0 * CU_BEND
# How far off its own axis a line may enter a CAP CONDUIT. The lid's hole is countersunk to this
# angle (`_cold_core_interface.cap_conduit_entry_skew`), so the lip a leaning line crosses lies
# along it and what the tube bears on there is a face.
CAP_BORE_SKEW = _cc.cap_conduit_entry_skew

# Which reference module states each placed body's stations, and the bore each one carries. The
# module gives `(position, outward axis)` in the body's own frame; `enclosure_assembly`'s `carry`
# takes that through the placement, so a port table is written once and rides every later move.
STATIONS = {
    # The cold core's cap conduits — bores up the cap's own columns, each opening on the lid's
    # outer face. A line reaching one arrives at the deck, not at a body face.
    "foam-assembly": {"water-in": (lambda: _ea_cap("water-in"), _split.TUBE_D),
                      "carb-water-out": (lambda: _ea_cap("carb-water-out"), _split.TUBE_D),
                      "reservoir-a": (lambda: _ea_cap("reservoir-a"), _split.TUBE_D),
                      "reservoir-b": (lambda: _ea_cap("reservoir-b"), _split.TUBE_D),
                      "reservoir-a-fill": (lambda: _ea_cap("reservoir-a-fill"), _split.TUBE_D),
                      "reservoir-b-fill": (lambda: _ea_cap("reservoir-b-fill"), _split.TUBE_D),
                      "co2-in": (lambda: _ea_cap("co2-in"), _split.TUBE_D),
                      # The evaporator's two ends are copper, not LLDPE, and they open on
                      # the core's own flanks rather than up its cap columns.
                      "evap-outlet": (lambda: _plugs.slot_station("evap-outlet"), CU_OD),
                      "evap-inlet": (lambda: _plugs.slot_station("evap-inlet"), CU_OD)},
    "compressor": {"refrig-suction": (lambda: _comp.stations()["refrig-suction"], CU_OD),
                   "refrig-discharge": (lambda: _comp.stations()["refrig-discharge"], CU_OD)},
    "condenser+fan": {"refrig-outlet": (lambda: _cond.stations()["refrig-outlet"], CU_OD),
                      "refrig-inlet": (lambda: _cond.stations()["refrig-inlet"], CU_OD)},
    "g-ganen-pump": {"suction": (_pump.suction, _suct.HOSE_OD),
                    "discharge": (_pump.discharge, _suct.HOSE_OD)},
    "suction-chain": {"barb-tip": (_suct.barb_tip, _suct.HOSE_OD),
                      "tube-port": (_suct.tube_port, _suct.TUBE_D)},
    "discharge-chain": {"barb-tip": (_dis.barb_tip, _dis.HOSE_OD),
                        "tube-port": (_dis.tube_port, _dis.TUBE_D)},
    "asse1022-assembly": {"tube-in": (lambda: _asse.port("tube-in"), _split.TUBE_D),
                          "tube-out": (lambda: _asse.port("tube-out"), _split.TUBE_D),
                          "vent-tip": (lambda: _asse.port("vent-tip"), _asse.VENT_STUB_OD)},
    "vk-solenoid": {"inlet": (_beduan.inlet, _split.TUBE_D),
                    "outlet": (_beduan.outlet, _split.TUBE_D)},
    "flow-regulator": {"inlet": (_flowreg.inlet, _flowreg.TUBE_D),
                       "outlet": (_flowreg.outlet, _flowreg.TUBE_D)},
    "bulkhead-water": {"inboard": (lambda: _jg.port(-1.0), _jg.PORT_D),
                       "outboard": (lambda: _jg.port(1.0), _jg.PORT_D)},
    # The other inlet on that wall, and the same two mouths under the same names: the customer's
    # red tether lands on the outboard collet and the gas chain leaves by the inboard one.
    "co2-inlet": {"inboard": (lambda: _neofit.port(-1.0), _neofit.TUBE_OD),
                  "outboard": (lambda: _neofit.port(1.0), _neofit.TUBE_OD)},
    "gasher-co2": {"inlet": (_gas_chain.check_inlet, _split.TUBE_D),
                   "outlet": (_gas_chain.check_outlet, _split.TUBE_D)},
    "wr1110": {"inlet": (_gas_chain.regulator_inlet, _split.TUBE_D),
               "outlet": (_gas_chain.regulator_outlet, _split.TUBE_D)},
    "water-split": {"supply": (_split.supply, _split.TUBE_D),
                    "to-vk": (_split.to_vk, _split.TUBE_D),
                    "to-flavor": (_split.to_flavor, _split.TUBE_D)},
    # The meter inline on the carb riser. Its two collets are coaxial on its own flow axis and
    # the machine lays that axis fore and aft, so `inlet` faces forward and `outlet` aft. The
    # bore takes the same 1/4" LLDPE the rest of the water side runs.
    "digiten-flow": {"inlet": (_digiten.inlet, _split.TUBE_D),
                     "outlet": (_digiten.outlet, _split.TUBE_D)},
    # The funnel's gravity drain — the spout's exit annulus, on the collar centre, facing the
    # floor. `funnel.drain_local` is in the part's own frame, so it rides the funnel
    # wherever the top wall carries it.
    "funnel": {"drain": ((lambda: (_funnel.drain_local, (0.0, 0.0, -1.0))),
                                _funnel.spout_id)},
    # The disconnect under that drain. Its upper collet takes the stub the funnel carries and
    # its lower one starts `fluid-4`, so the two are named for the joint rather than for flow:
    # `stub` is the mouth a hand works and `outlet` is the mouth a run leaves by.
    "funnel-drain-union": {"stub": (lambda: _elbow.port("z"), _elbow.TUBE_D),
                           "outlet": (lambda: _elbow.port("y"), _elbow.TUBE_D)},
}

# The three unions the machine dispenses through, all on one row of the +Y wall of back-top. Each carries
# the same two mouths the tap-water union does, under the names the topology gives them: the
# INBOARD collet is what a run inside the box pushes into, the outboard one is what the
# above-counter umbilical lands on.
for _b in ("bulkhead-flavor-a", "bulkhead-flavor-b", "bulkhead-carb"):
    STATIONS[_b] = {"tube-in": (lambda: _jg.port(-1.0), _jg.PORT_D),
                    "tube-out": (lambda: _jg.port(1.0), _jg.PORT_D)}


# The flavour manifold's ten solenoid valves. Each stands coil-up with its flow along the pack's
# own ±Y, and the fold names its two collets `front` and `back`.
# `enclosure_assembly.manifold_carry` takes both through the pose and the lift the pack is stood
# at, so a run anchors on where the collet ends up.
#
# Which collet is the INLET is the valve's own turn. `manifold_layout` stands each body on
# `valve_dirs(P[v]["arg"])`, and that argument is which way round it faces — the flow runs the
# way the moulded arrow points, so the two turns present opposite ends. Six valves take +1 and
# four take −1, and the manifold's own `MOUTHS` names the `front` collet of V-G and V-J
# V-x-**O**.
VALVES = ("V-A", "V-B", "V-C", "V-D", "V-E", "V-F", "V-G", "V-H", "V-I", "V-J")


def valve_ends(v: str) -> tuple:
    """A valve's two collets as `(inlet, outlet)` in the fold's own `front`/`back` names, read
    off the turn `manifold_layout` stood the body at."""
    return ("front", "back") if _ml.P[v]["arg"] > 0 else ("back", "front")


for _v in VALVES:
    _in, _out = valve_ends(_v)
    STATIONS[f"valve-{_v.lower()}"] = {
        "inlet": ((lambda v=_v, e=_in: (_ml.port(v, e), _ml.port_axis(v, e))),
                  _split.TUBE_D),
        "outlet": ((lambda v=_v, e=_out: (_ml.port(v, e), _ml.port_axis(v, e))),
                   _split.TUBE_D),
    }


def frames(placed, carries):
    """Register one `_routing.Frame` per body that states stations, so a run may anchor on
    `"g-ganen-pump.suction"`. `placed` is the pack's solids by name; `carries` is the carry each
    was placed by."""
    out = {}
    for name, ports in STATIONS.items():
        if name not in placed or name not in carries:
            continue
        carry = carries[name]
        table = {}
        for port, (station, diam) in ports.items():
            pos, axis = carry(station())
            table[port] = (pos, tuple(axis), diam)
        out[name] = R.frame(name, placed[name], table)
    return out


def build_runs(placed, carries):
    """Every authored run, in the order they read.

    Each one names what it carries and what it turns on. A run's waypoints are world points, so
    the numbers in them are struck off the frames above — move a body and they move with it."""
    F = frames(placed, carries)
    runs = []
    if {"compressor", "foam-assembly"} <= set(F):
        runs.append(_refrig_3(F))
    if {"compressor", "condenser+fan"} <= set(F):
        runs.append(_refrig_1(F))
    if {"condenser+fan", "foam-assembly"} <= set(F):
        runs.append(_refrig_2(F))
    if {"g-ganen-pump", "suction-chain"} <= set(F):
        runs.append(_water_7(F))
    if {"g-ganen-pump", "discharge-chain"} <= set(F):
        runs.append(_water_6(F))
    if {"discharge-chain", "foam-assembly"} <= set(F):
        runs.append(_water_5(F))
    if {"asse1022-assembly", "water-split"} <= set(F):
        runs.append(_water_2(F))
    if {"water-split", "flow-regulator"} <= set(F):
        runs.append(_fluid_1(F))
    if {"water-split", "vk-solenoid"} <= set(F):
        runs.append(_water_3(F))
    if {"co2-inlet", "wr1110"} <= set(F):
        runs.append(_co2_0(F))
    if {"gasher-co2", "wr1110"} <= set(F):
        runs.append(_co2_1(F))
    if {"gasher-co2", "foam-assembly"} <= set(F):
        runs.append(_co2_2(F))
    if ({"flow-regulator", "valve-v-a", "bulkhead-flavor-a"} <= set(F)
            and {"coil-v-a", "g-ganen-pump"} <= set(placed)):
        runs.append(_fluid_2(F, placed))
    if {"foam-assembly", "digiten-flow"} <= set(F):
        runs.append(_carb_1(F))
    if {"digiten-flow", "bulkhead-carb"} <= set(F):
        runs.append(_carb_2(F))
    if {"valve-v-j", "bulkhead-flavor-b"} <= set(F) and "valve-v-i" in F:
        runs.append(_fluid_28(F, placed))
    if {"valve-v-g", "bulkhead-flavor-a"} <= set(F) and "valve-v-f" in F:
        runs.append(_fluid_18(F, placed))
    if {"valve-v-i", "foam-assembly"} <= set(F):
        runs.append(_fluid_24(F))
    if {"valve-v-h", "foam-assembly"} <= set(F):
        runs.append(_fluid_26(F))
    if {"valve-v-f", "foam-assembly"} <= set(F):
        runs.append(_fluid_14(F, placed))
    if {"valve-v-e", "foam-assembly"} <= set(F):
        runs.append(_fluid_16(F))
    return runs


def build_seated_runs(placed, carries):
    """The runs with a mouth on a body the BOX seats rather than the pack.

    The box is sized on the pack, so a body seated in one of its walls is placed after it — and a
    run reaching that body can only be authored once it is.
    `enclosure_assembly.build_enclosure_assembly` calls this with the pack's own bodies and the
    seated one added to them, so a run drawn here anchors on exactly the frames the pack's own runs
    do."""
    F = frames(placed, carries)
    runs = []
    if {"funnel-drain-union", "valve-v-a", "valve-v-b", "g-ganen-pump"} <= set(F):
        runs.append(_fluid_4(F, placed))
    return runs


def _co2_0(F):
    """co2-0 — wall bulkhead to the fixed regulator's PI010822S inlet collet."""
    return R.bent(
        "co2-0", "co2-inlet.inboard", "wr1110.inlet",
        kind="co2", note="CO2: rear-wall bulkhead → WR1110 inlet collet")


def _co2_1(F):
    """co2-1 — a forward U-turn between regulator and downstream check inlet collets."""
    src = F["wr1110"].at("outlet")
    dst = F["gasher-co2"].at("inlet")
    # The soda-water crossing's ceiling cradle is immediately forward of this run.
    # Bring the U-turn 1 mm back toward its collets to clear that existing cradle;
    # both corners retain the stock's full bend radius.
    turn_y = min(src[1], dst[1]) - 2.0 * TUBE_BEND + 1.0
    return R.bent(
        "co2-1", "wr1110.outlet", (src[0], turn_y, src[2]),
        (dst[0], turn_y, dst[2]), "gasher-co2.inlet",
        kind="co2", note="CO2: WR1110 outlet → downstream check inlet, U-turn above the pump")


# The rear bulkhead's inboard collet and the ASSE 1022's inlet collet meet face to face, so the
# first tube in the machine — everything the customer's supply line reaches passes through it —
# is a length of stock cut to the two grips and swallowed whole. There is no free tube to sweep,
# and no `water-1` in this table.


# WHERE THE MACHINE IS CROSSABLE, and it is the cold core's own front step. The lid's outer face
# runs forward at z 253.4 from the deck the valve cradles stand on, and the band over that face —
# between the core's front and the funnel union's ring — is clear from wall to wall. The crossing
# lies in it, one lane off the core it is assembled onto, and the core's cap prints the rib that
# holds it there. Re-measure it by sweeping the cast in y —
#
#     w.cast((-78.0, y, z), (1, 0, 0), dia=6.35)
#
# WHAT MOVES IT IS THE FUNNEL'S OWN STATION. The band's forward bound is the funnel union's ring
# and the fall `fluid-4` drops off it; the union hangs on the funnel's drain, and the drain
# stands `funnel.neck_dy` aft of the collar's Y centre — so this crossing walks with
# `enclosure.funnel_front_y` and that offset, and with nothing else. The display housing's
# back is its own stated cut (`enclosure.display_housing_back`), so the facet does not drag the
# funnel aft behind it.
# The run is authored in `build_runs`, which draws the pack's own runs before the box seats the
# funnel, so the union is not there to measure against and this is a Y rather than a standoff.
# `clearance-floor` is what holds the two apart, and it is what caught the facet growing.
_CORE_FRONT_Y = _cc.rear_plane_y - _cc.rear_seam_clear - _cc.outer_shell_x_length
CROSS_Y = _CORE_FRONT_Y - 1.5
# THE DODGE ONTO THE LID. `CROSS_Y` runs one and a half millimetres FORWARD of the core's own
# front face, so over that stretch the lane has no lid beneath it and nothing there can hold it.
# Where the run has to be gripped, it steps aft onto the lid and comes back — two shallow plan
# corners each way — and the post that grips it stands on what it stepped onto
# (`_cold_core_interface.cap_side_anchors["water-3"]`). The step is the post's own
# front face plus the `axis_off` the pipe stands proud of it, which is what puts the axis here.
#   THE SPAN IS THE POST'S, and it goes where the post goes: the aft flat has to run the post's
# whole length under it or the pipe ramps inside the seat that grips it. `cap_tube_anchors`
# refuses a post no leg passes through, which is what holds the two files together.
#   IT SITS WEST OF THE CENTRELINE because that is the side with room. The run arrives from the
# channel at `CHANNEL_X` and leaves on `CROSS_LIFT_X`, so east of centre the step's far corner
# and the lift stand within a couple of millimetres of each other and the leg between them
# falls under the stock's own bend radius. West of centre that leg is the whole crossing.
#   Everywhere else the lane holds `CROSS_Y`: the reservoir draws and `water-5` cross this
# storey on their own columns west of here, and the lane at `CROSS_Y` is what clears them.
CROSS_DODGE_Y = _CORE_FRONT_Y + 2.0
CROSS_DODGE_SPAN = (-22.0, -5.5)
CROSS_DODGE_RAMP = 8.0
# And how far UNDER V-K's own inlet plane it runs. The funnel's disconnect hangs on the spout's
# column and its ring stands in the storey this run used to cross on, so the crossing drops
# beneath the union's foot — and what it drops ONTO is the height the cap's rib holds it at over
# the lid's face, which is what `_cold_core_interface.cap_anchors` states.
CROSS_DROP = 7.1
# THE CHANNEL THE BRANCH FALLS INTO, and it is the strip the box already leaves west of the core.
# `enclosure.side_band_inset` is the band between the shell's own face and the wall's inner one,
# and NOTHING UNDER IT IS THE CORE'S — which is what this run comes here for: a belly in the strip
# is floored by the cabinet rather than by the cap lid the shell's own x-band stands over.
#   TWO THINGS STAND IN IT. The Y SEAM, where the front piece laps the back one, puts a second
# wall's thickness proud of the inner face on that plane, and this run crosses the seam on its way
# forward — so the lap fences its west edge, and the raised first bend clears the core to its
# east. And `fluid-28`'s anchor rib crosses the band bodily at tube height, on the slice of Y its
# own `GATE_B_STEP_Y` places it in. This run is forward of that rib and does not meet it; a run
# taken up the band aft of it would. Re-measure across at the seam's own plane, and along it for
# the rib —
#
#     w.cast((-90.0, 213.1, z), (-1, 0, 0), dia=6.35)
#     tools/cad-venv/bin/python hardware/scripts/probe.py hits --x -101.5,-90.5 --y 265,290 --z 260,280
#
CHANNEL_X = -94.0
# HOW FAR UNDER THE CROSSING'S LANE THE FALL BOTTOMS OUT. The branch's corner turns through more
# than a right angle: the leg leaving it leans west into the channel and rises onto the lane over
# the run forward, so the fall ends beneath the storey it hands the water to.
#
# THE TEE ABOVE STANDS ONE TANGENT OVER THAT CORNER, which is what the fall costs it. The arc's
# own belly is the deepest the run gets, one `port_lead` under the branch collet, and it holds its
# lane over the lid's outer face.
#
# THE CROSSING IS SEATED ON THE CAP, so its intentional anchor contact cannot measure the free
# first bend's clearance. Read that bend separately, aft of Y=190: its swept tube clears the core
# by more than 1 mm, and the full run clears both enclosure halves by more than 1 mm. The height
# and west channel position are paired dimensions; lowering the bend would spend the core gap.
# Re-read the bend where it turns off the split's column —
#
#     tools/cad-venv/bin/python hardware/scripts/probe.py hits --x -99,-87 --y 220,242 --z 250,274
#
CROSS_RISE = 4.5
# Where it starts leaning off the core again. The crossing hugs the core as far east as the
# funnel union's ring, then leans forward and up in ONE leg onto V-K's column and inlet plane:
# the collet needs its own straight, and a crossing that stayed against the core to the end would
# leave a closing leg too short to turn a stock arc in.
# WHERE THE RUN REACHES THE CHANNEL'S OWN COLUMN, and it is what carries the fall's belly out of
# the lid's shadow. The branch collet fires down on `enclosure_assembly.SPLIT_COLUMN`, whose tube
# stands its east face inside the shell's x-band — so a corner whose outgoing leg is mostly
# FORWARD keeps its arc on that column and bellies over the cap. Struck aft of the crossing, the
# leg out of that corner heads WEST instead, the arc swings with it, and the belly comes down in
# the strip where the lid is not underneath. What the fall may then spend is `CROSS_RISE`, and
# what that is worth is the tee's own height.
#   IT IS FENCED BOTH WAYS. The leg into it has to seat corner 0's whole quarter-turn as tangent,
# so it cannot be struck so near the branch that the fall has no room to turn; and the leg out of
# it runs the channel to the crossing, which is what the run is in the strip FOR.
CHANNEL_ENTRY_Y = _CORE_FRONT_Y + 44.0
CROSS_LIFT_X = 20.0
CROSS_APPROACH_Y = 164.0




def _water_3(F):
    """water-3 — the split's DOWNWARD branch to V-K's forward-facing inlet, and the one run in
    the assembly that crosses the whole machine.

    It has to. The split stands in the WEST lane and V-K stands on the EAST, and V-K's inlet
    faces FORWARD — so the water leaves the split going down, and has to arrive at V-K from in
    front of it. There is no shorter way round: the valve manifold occupies the storey between
    the two columns and the band behind the union's ring is the one window through it.

    IT FALLS INTO THE CHANNEL AND RUNS IT. The branch drops on the split's own column, and its
    corner turns WEST off that column into `CHANNEL_X` — the strip between the shell's face and
    the wall's — reaching that column at `CHANNEL_ENTRY_Y`, aft of the crossing. What follows is
    a leg down the channel itself, rising `CROSS_RISE` onto the crossing's storey as it goes.

    THE TEE ABOVE STANDS ONE TANGENT OVER THAT CORNER, which is what the fall costs it, so where
    the corner's arc bellies is what sets the tap's height. `SPLIT_COLUMN` stands the branch's own
    tube with its east face inside the shell's x-band, so an arc that leaves mostly FORWARD stays
    on that column and bellies over the cap lid. Leaving WEST swings the arc into the strip, where
    what is under the belly is the cabinet floor rather than the lid.

    IT CROSSES UNDER THE FUNNEL'S DISCONNECT. The union hangs on the funnel's spout in the middle
    of that window, so the crossing runs `CROSS_DROP` under the inlet's own plane, the whole width
    of the machine beneath the union's foot and against the cold core's front, and climbs back
    onto the inlet's plane on V-K'S OWN COLUMN — where the climb costs nothing, because the aft
    leg into the collet is there anyway and the lean shares it. The cap's own side post grips the
    run on that lane (`_cold_core_interface.cap_side_anchors`), which is what fixes its height.

    The closing straight is planted on the collet's axis (`lead`), so the mouth is entered square
    however the lean arrives at it."""
    split, vk = F["water-split"], F["vk-solenoid"]
    src, dst = split.at("to-vk"), vk.at("inlet")
    z = dst[2] - CROSS_DROP
    dx0, dx1 = CROSS_DODGE_SPAN
    return R.bent(
        "water-3", "water-split.to-vk",
        (src[0], src[1], z - CROSS_RISE),   # the whole fall, on the branch's column, past the lane
        (CHANNEL_X, CHANNEL_ENTRY_Y, z - CROSS_RISE),  # west OUT of the lid's shadow, still low
        (CHANNEL_X, CROSS_Y, z),              # forward down the channel, rising onto the lane
        (dx0 - CROSS_DODGE_RAMP, CROSS_Y, z),  # east along that lane, to the drain's column
        (dx0, CROSS_DODGE_Y, z),               # aft into the lid's notched corner, round the fall
        (dx1, CROSS_DODGE_Y, z),               # through the side post's own grip
        (CROSS_LIFT_X, CROSS_Y, z),            # and back onto the lane
        (dst[0], CROSS_APPROACH_Y, dst[2]),  # one lean off the core, onto V-K's column and plane
        "vk-solenoid.inlet",
        kind="water", lead=(None, _ml.STUB),
        note="tap water: split branch → V-K inlet, down into the west channel, across the window "
             "under the funnel's union — stepping aft round the drain's fall — and up V-K's own "
             "column into the mouth")


def _fluid_1(F):
    """fluid-1 — the flavour tap off the split, into the regulator that throttles it.

    A HAIRPIN. The regulator stands over the split on one column with its inlet facing the way
    the split's flavour collet faces, so the run leaves one mouth going forward, turns through
    180° in the open room ahead of the pair, and comes back into the other.

    THE TWO WAYPOINTS ARE THE TURN'S OWN CORNERS, one radius forward of the FURTHER mouth and one
    over the other. A square U is what the router is given and two quarter-arcs are what it
    returns: the rise is `enclosure_assembly.FLUID_1_RISE`, each arc spends a radius of it, and
    nothing is left over. Both mouths are on one X, so the turn lies in the lane's own vertical
    plane; the two stand one reach apart along it, because the pair is stacked on its BODIES'
    centres and their two collets look the same way off that column. So the apex is struck on
    whichever mouth reaches further forward, and the other's leg is the reach longer."""
    split, reg = F["water-split"], F["flow-regulator"]
    src, dst = split.at("to-flavor"), reg.at("inlet")
    apex = min(src[1], dst[1]) - TUBE_BEND
    return R.bent(
        "fluid-1", "water-split.to-flavor",
        (src[0], apex, src[2]),             # forward off the split's collet, and turn up
        (src[0], apex, dst[2]),             # up the turn's own column, and turn back aft
        "flow-regulator.inlet",
        kind="fluid", bend=TUBE_BEND,
        note="flavor tap: split run -> flow regulator, a 180 degree hairpin forward of the pair")


# What each collet on the step gets straight off its own axis before `water-2` starts to lean.
# NOT A GRIP — a collet grips inside the fitting, behind the face, and a line starts curving at
# that face. What this holds is the TANGENT its own corner seats on, R·tan(θ/2) for the lean the
# step takes, so it is priced against the corner rather than against the push-fit. Taken out of
# the reach `enclosure_assembly.WATER_2` gives.
#   IT ALSO CARRIES THE LEAN OUT OF THE TAP'S OWN STOREY. The split's supply mouth faces aft and
# this straight runs aft on its axis, level, a storey under the regulator — so every millimetre
# here is a millimetre the climb does not spend in the band `fluid-2` leaves the regulator
# through. The lean starts where this ends.
#   AND IT IS SELF-OPPOSING, which is what keeps it honest: the lead is taken out of the step's Y
# and the fall is not, so a longer straight leaves the lean less run for the same drop and steepens
# it. The corner's own demand rises with it — slower than the lead does, which is why there is a
# figure that satisfies both, but the two move together and neither may be read alone.
WATER_2_LEAD = 12.0
# THE SPLIT END'S HORIZONTAL SECTION, stated as a leg rather than reached for as a lead. A lead
# plants its point along the port's own axis and the climb's corner then backs its tangent into
# that same straight, so what stands off the tee is the lead less that tangent. A waypoint is a
# place the run passes through: the leg is the length, and the corner takes its tangent out of the
# LEAN instead. What the eye reads standing off the collet is this figure less `R·tan(θ/2)`.
#   IT IS FENCED AT BOTH ENDS. Aft, `wago-reeds-b`'s well opens at y 294.60 on that wall, and this
# leg's far end has to stop short of it. Forward, the lean it hands the run to crosses the lane
# `fluid-2` leaves the regulator on, and a leg that ends too early puts that crossing in the same
# band. Between them, `WATER_2_LEAD` and this share one leg — the lean — and each of the two
# corners backs its tangent down it, so neither figure may be read alone. `bend-radius` reads the
# pair back and `clearance-floor` reads the crossing.
WATER_2_RUN = 21.25


def _water_2(F):
    """water-2 — the ASSE 1022's outlet to the split's supply, and the tap's whole step off the
    panel deck.

    ONE LEAN IN THE OPEN ROOM AFT OF THE FUNNEL. The chain hands the water over facing forward
    down the west lane and the split's own run axis IS that lane, a storey lower — so the two
    collets face each other down the lane with `enclosure_assembly.FLAVOR_STEP` between them.
    The run leaves the chain on-axis off its own `WATER_2_LEAD` stub and arrives at the tee along
    `WATER_2_RUN`, the level leg stated aft of it; the whole fall is taken in the lean between,
    which lies in the room the bowl stops short of.

    THE TWO ARE NOT ON ONE COLUMN. The chain's is the +Y wall of back-top's `PORT_WEST_COLUMN` and the
    split's is `enclosure_assembly.SPLIT_COLUMN`, so the lean crosses as well as falls.

    ONE END IS A STUB AND THE OTHER IS A PLACE, and that is the whole shape of it. At the chain,
    `lead=` plants a point one reach along the collet's axis and the lean starts wherever the
    corner off it leaves off — a standoff, spent by its own turn. At the tee, `WATER_2_RUN` is a
    waypoint the run must pass through, so the level leg is the length it says and the lean starts
    at its far end. The tee's stub is therefore 0, not open: `None` there would ask the router for
    one bend radius along the same axis the waypoint already stands on.
      The lean is the single leg between those two, and it turns twice — once out of the chain's
    stub, once onto the tee's leg — at whatever angle the step's fall and crossing make of it."""
    _S2 = F["water-split"].at("supply")
    return R.bent(
        "water-2", "asse1022-assembly.tube-out",
        # A STATED HORIZONTAL SECTION off the tee, on the tee's own storey. `lead=` cannot carry
        # this: it plants its point along the port axis and the climb's own corner then reaches
        # back into it, so a longer lead is largely eaten before it is seen. A waypoint is a place
        # the run must pass through, so this length is the length.
        (_S2[0], _S2[1] + WATER_2_RUN, _S2[2]),
        "water-split.supply",
        kind="water", bend=TUBE_BEND, lead=(WATER_2_LEAD, 0.0),
        note="tap water: ASSE outlet → split supply, one lean off the deck onto the lane the "
             "funnel's bowl leaves")


def _water_7(F):
    """Braided suction hose from the measured G Ganen barb to its anchored chain."""
    return R.bent(
        "water-7", "g-ganen-pump.suction", "suction-chain.barb-tip",
        kind="water", bend=HOSE_BEND, skew=BARB_SKEW, lead=HOSE_BEND,
        note="carb water: G Ganen suction barb → suction chain, 3/8 inch braided PVC, two clamps")


def _water_6(F):
    """Braided discharge hose between independently measured, placed barb axes."""
    return R.bent(
        "water-6", "g-ganen-pump.discharge", "discharge-chain.barb-tip",
        kind="water", bend=HOSE_BEND, skew=BARB_SKEW, lead=HOSE_BEND,
        note="carb water: G Ganen discharge barb → discharge chain, 3/8 inch braided PVC, two clamps")


def _water_5(F):
    """water-5 — the discharge chain's collet to the cold core's water-in conduit, and the
    tap-water path's only descent.

    ONE SLANT ACROSS THE FALL. The collet looks forward off the far end of the laid-down chain
    and the bore opens up out of the cap's lid on that chain's own column, ahead of it and
    below it — so the tube leaves the collet straight on its own axis, crosses the fall at a
    slant, and enters the bore dead on the vertical it is drilled at. Two gentle turns rather
    than one square one; its height only ever descends.

    `lead` is what plants the two straights: one stock bend radius off each mouth, so the
    corners live in the middle of the run and both mouths take the tube unbent."""
    return R.bent(
        "water-5", "discharge-chain.tube-port", "foam-assembly.water-in",
        kind="water", lead=TUBE_BEND, skew=(R.COLLET_SKEW, CAP_BORE_SKEW),
        note="carb water: discharge chain's collet → the core's water-in cap conduit, one "
             "slant across the fall")


def _co2_2(F):
    """co2-2 — check outlet collet, aft then east onto the existing cap-conduit column."""
    out = F["gasher-co2"].at("outlet")
    bore = F["foam-assembly"].at("co2-in")
    turn_y = out[1] + 2.0 * TUBE_BEND
    return R.bent(
        "co2-2", "gasher-co2.outlet",
        (out[0], turn_y, out[2]),
        (bore[0], turn_y, out[2]),
        (bore[0], bore[1], out[2]),
        "foam-assembly.co2-in",
        kind="co2", lead=(TUBE_BEND, TUBE_BEND), skew=(R.COLLET_SKEW, CAP_BORE_SKEW),
        note="CO2: downstream check outlet → east lane → the core's CO2 cap conduit")


# The straight `fluid-2` runs aft off the regulator's outlet before it turns. It is longer than
# the arc's own tangent so a length of tube still leaves the collet straight, and no longer:
# `water-2` comes down this same lane from the chain overhead, and the further aft this run turns
# the nearer it turns to that descent.
FLUID_2_LEAD = 15.0
# THE STOREY THE CROSSING RUNS ON, and it runs LEVEL on it. `fluid-4` climbs and comes about west
# of V-B and leans down onto the collet from out there, so what this run passes over is that lean,
# and it passes over it with the whole of its own height in hand rather than threading a window.
# The fall onto V-A's port plane is spent afterwards, down the valve's own column, where nothing
# is over it.
#
# WHAT IT HAS OVER IT is `fluid-18`, which crosses this band on its cap side-anchor plane, and the
# daylight between the two is this run's whole clearance to it.
FLUID_2_CROSS_Z = 289.0
# WHERE THE CROSSING STOPS BEING LEVEL. Only the stretch over the drain's lean has to hold the
# storey; east of the lean's own column the run is free to spend its height, and it spends it in
# the SAME leg that carries it the rest of the way east. Taken as a column instead, the fall
# would stand square to the crossing above it and square to the collet's axis below, and two
# square corners want two whole radii of the leg between them — where this lean turns a third of
# that at the top and seats the collet's own straight at the bottom. The figure is what the run
# holds past the lean's column before it starts down.
FLUID_2_LEVEL_CLEAR = 6.0
# The level crossing stays forward of the pressure switch; the final turn is lower, beneath
# that casting, and reaches aft onto V-A's inlet column. These are separate Y planes so the
# descent can clear the switch while the inlet corner keeps its full stock radius.
FLUID_2_CROSS_FORWARD = 4.0   # additional room ahead of the casting's clearance plane
FLUID_2_INLET_SET = 5.0      # reach beyond the pack's mouth stub for the oblique inlet corner
# The column the run goes forward and down in: the strip WEST of the flavour-A line's own aft
# lane. `fluid-18` holds that lane over the whole depth this run crosses it in, so the strip is
# struck off the union that line falls onto and rides it wherever the union goes. Both are 1/4",
# and the figure is axis to axis — one tube's diameter of it is the two skins.
FLUID_2_LANE_CLEAR = 10.35


def _fluid_2(F, solids):
    """fluid-2 — the flow regulator's outlet to V-A's inlet, and the tap water's last leg
    before the flavour manifold.

    THE TWO MOUTHS FACE THE SAME WAY AND THE VALVE IS BEHIND THE REGULATOR. The regulator stands
    over the split with its flow running aft, so its outlet fires AFT; V-A stands coil-up on the
    deck with its inlet on the AFT end, so the run has to come at that collet from behind. It goes
    aft off the regulator, turns east across the lane, comes forward and down the strip in one
    leg, and leans east behind both coils onto V-A's column.

    IT CROSSES THE LANE LEVEL, ON THE OUTLET'S OWN STOREY, AND SPENDS NO HEIGHT DOING IT. `water-2`
    comes down this same lane from the chain overhead and passes under this run on its way to the
    split, so what the two have between them is whatever this one has not yet given away — and the
    crossing stands where the descent has barely begun.

    THE STRIP'S DESCENT AND ITS RUN FORWARD ARE ONE LEG. Taken as two they are two SQUARE corners
    sharing the strip's own depth, and a square corner spends its whole radius as tangent in each
    leg it touches — so the pair would want two stock radii of a strip that has 22. Leaning the
    descent forward instead makes both corners shallower than square AND lengthens the leg they
    share, and the two spend under two thirds of what they then stand in.

    THE CROSSING RUNS OVER THE DRAIN AND NOT THROUGH IT. `fluid-4` climbs west of V-B and leans
    down onto that valve's collet from out there, so this run holds `FLUID_2_CROSS_Z` level for
    the whole width of that lean and clears it by the height between them. Past the lean's own
    column it stops holding: the fall onto V-A's port plane is spent in the same leg that carries
    the run the rest of the way east, which is what keeps both of that leg's corners off square.

    The last leg reaches `manifold_layout.STUB + FLUID_2_INLET_SET` off the inlet. Its rounded
    turn stands under the pressure switch while the level crossing stays forward of the switch
    face. The descent joins those two planes in one oblique leg. Drawing this run makes the
    pack's mouth stub a real line, so `enclosure_assembly.build_pack` omits its placeholder.
    The finished sweep must retain the stock radius and clear the actual pump solid by
    `clearance-floor`; its square construction corners are not the tube's occupied envelope."""
    reg, vk_a = F["flow-regulator"], F["valve-v-a"]
    out, inlet = reg.at("outlet"), vk_a.at("inlet")
    lane = out[1] + FLUID_2_LEAD
    lane_x = F["bulkhead-flavor-a"].at("tube-in")[0] - FLUID_2_LANE_CLEAR
    inlet_turn = inlet[1] + _ml.STUB + FLUID_2_INLET_SET
    pump_fore = solids["g-ganen-pump"].BoundingBox().ymin
    cross = min(inlet_turn,
                pump_fore - _card.CLEARANCE_FLOOR - _split.TUBE_D / 2.0
                - FLUID_2_CROSS_FORWARD)
    level_end = F["valve-v-b"].at("inlet")[0] + FLUID_2_LEVEL_CLEAR
    run = R.bent(
        "fluid-2", "flow-regulator.outlet",
        (lane_x, lane, out[2]),                       # east across the lane, level on its own storey
        (lane_x, cross, FLUID_2_CROSS_Z),             # forward down that strip onto the crossing storey
        (level_end, cross, FLUID_2_CROSS_Z),          # east over the drain's lean, level for all of it
        (inlet[0], inlet_turn, inlet[2]),             # east and down beneath the switch onto V-A's column
        "valve-v-a.inlet",
        kind="fluid", lead=(FLUID_2_LEAD, _ml.STUB),
        note="tap water: flow regulator outlet → V-A inlet, aft off the regulator, level east "
             "across the lane into the strip west of the flavor-A line, forward and down that "
             "strip, and east through the window the drain leaves")
    radius = min(run.radii.values(), default=run.bend)
    if radius < TUBE_BEND - 1e-6:
        raise ValueError(f"fluid-2's inlet approach seats R{radius:.3f}, below its R{TUBE_BEND:g} stock")
    tube = R.tube(run)
    # Fore/aft box separation is a lower bound on the finished sweep's clearance.
    if pump_fore - tube.BoundingBox().ymax < _card.CLEARANCE_FLOOR - 1e-6:
        pump_gap = tube.distance(solids["g-ganen-pump"])
        if pump_gap < _card.CLEARANCE_FLOOR - 1e-6:
            raise ValueError(
                f"fluid-2's finished sweep clears the pump by {pump_gap:.3f} mm, below "
                f"the {_card.CLEARANCE_FLOOR:g} mm clearance floor")
    return run


# --- the funnel's gravity drain ---------------------------------------------
#
# The spout exit and every tube segment stand above V-B's inlet. The line has
# a local rise below the spout, so its physical drain and purge behaviour must
# be checked with the assembled tubing and concentrate.

# The drain leaves the elbow forward and rounds the west side of the source pair.
# Its low crossing stays above V-B's inlet; the aft rise clears the reservoir lines.
FLUID_4_FORE_Y = 148.0
FLUID_4_LOOP_X = -52.0
FLUID_4_LOW_Z = 272.0
FLUID_4_RISE_START_Y = 193.0
FLUID_4_RISE_END_Y = 223.0
FLUID_4_LANE_Z = 282.0
FLUID_4_COMEABOUT = 17.0


def _fluid_4_turn_y(F, solids) -> float:
    """Aft tangent plane, leaving a full R14 corner into V-B's inlet."""
    return solids["valve-v-b"].BoundingBox().ymax + FLUID_4_COMEABOUT


def _fluid_4(F, solids):
    """The funnel's gravity feed, forward off the elbow and aft around V-B.

    The west lane rises below the spout exit and stays above the destination inlet.
    Each corner holds the stock's R14 minimum; the final lean meets the valve axially.
    """
    drain = F["funnel-drain-union"].at("outlet")
    inlet = F["valve-v-b"].at("inlet")
    turn = _fluid_4_turn_y(F, solids)
    return R.bent(
        "fluid-4", "funnel-drain-union.outlet",
        (drain[0], FLUID_4_FORE_Y, drain[2]),
        (FLUID_4_LOOP_X, FLUID_4_FORE_Y, FLUID_4_LOW_Z),
        (FLUID_4_LOOP_X, FLUID_4_RISE_START_Y, FLUID_4_LOW_Z),
        (FLUID_4_LOOP_X, FLUID_4_RISE_END_Y, FLUID_4_LANE_Z),
        (FLUID_4_LOOP_X, turn, FLUID_4_LANE_Z),
        (inlet[0], turn, inlet[2]),
        "valve-v-b.inlet",
        kind="fluid", bend=TUBE_BEND,
        note="funnel disconnect → V-B inlet, forward off the elbow, west around the source "
             "pair and aft along the reservoir-line gap, then east and down into V-B")


# --- the carb-water riser, and the two flavour gates' lines to the panel ----
#
# All three end on the panel deck (`enclosure_assembly.PANEL_X`), which is the band over the water
# pump's crown, and all three reach it by a column that runs the machine's whole height.

# The carbonated-water riser's deck station stands this far forward of its cap-conduit axis.
# Its source is a countersunk lid bore which expressly accepts `CAP_BORE_SKEW`, so the run leans
# gently over the full climb rather than spending another pair of corners on a one-millimetre
# dogleg. At the electronics bay that lean keeps the tube one `clearance-floor` off the populated
# main board while the horizontal deck leg and its ceiling anchor remain straight.
CARB_1_FORWARD_LEAN = 1.0


def _carb_1(F):
    """carb-1 — the cold core's carbonated-water conduit to the meter's inlet.

    UP THE PORT LANE AND WEST ALONG THE DECK. The bore opens out of the cap's lid facing the
    ceiling and the meter lies fore and aft on the panel deck with its inlet facing forward, so
    the run leans one millimetre forward over the full climb to keep its service air past the
    main board, crosses west onto the meter's column, and runs aft down it into the collet.

    The closing leg is THE COLLET'S OWN AXIS, so there is no closing corner: the column the run
    turns onto is the meter's own X and the deck is its own Z, and what is left between them is
    one straight length of tube."""
    bore = F["foam-assembly"].at("carb-water-out")
    inlet = F["digiten-flow"].at("inlet")
    deck_y = bore[1] - CARB_1_FORWARD_LEAN
    return R.bent(
        "carb-1", "foam-assembly.carb-water-out",
        (bore[0], deck_y, inlet[2]),         # lean forward over the climb onto the deck
        (inlet[0], deck_y, inlet[2]),        # west along the deck onto the meter's column
        "digiten-flow.inlet",                # and aft down it into the collet
        kind="water", lead=(TUBE_BEND, TUBE_BEND), skew=(CAP_BORE_SKEW, R.COLLET_SKEW),
        note="carb water: the core's carb-water cap conduit → DIGITEN inlet, leaning forward "
             "up the port lane for main-board air, then west along the panel deck onto the "
             "meter's own column")


def _carb_2(F):
    """carb-2 — a shallow rise from the meter's outlet to the carb union's inboard collet.

    The meter's cover sets its axis below the panel deck. Four-millimetre waypoint leads leave
    both collets on-axis while the two tangent R14 bends take that height difference.
    """
    return R.bent(
        "carb-2", "digiten-flow.outlet", "bulkhead-carb.tube-in",
        kind="water", lead=4.0, bend=TUBE_BEND,
        note="carb water: DIGITEN outlet → rear union, a shallow rise between two on-axis ends")


# How high the WEST gate's line climbs on its own column before it steps outboard. That gate has
# its own channel's reservoir line standing over it, so the column is a bay and not a shaft, and
# this is the air left under whatever that is.
#
# WHAT CROSSES A GATE'S COLUMN IS ITS OWN CHANNEL'S FILL LINE. West that is `fluid-24`, which
# runs aft up the outboard lane on `RESERVOIR_CRUISE` and passes directly over V-J and fixes this
# plane. East, `fluid-14` climbs a storey higher to cross V-K, so NOTHING FENCES V-G AT ALL —
# and `fluid-18` climbs its own bay through this plane to the crown lane. This figure is the
# west line's.
GATE_STUB_CLEAR = 4.0
# WHERE THE WEST GATE'S LINE RUNS AFT IS ITS OWN UNION'S COLUMN, and it takes that column at the
# first corner it can and holds it to the wall. The gate stands on `LIMB_OUT_XW` and the union on
# `PORT_WEST_COLUMN`, which are ONE MILLIMETRE apart — so the whole crossing between them is that
# millimetre, and a line that spends it once has nothing left to spend. Everything aft of the jog
# is one column: the cold core's whole length, the panel deck and the collet.
#
# WHAT THAT LEAVES IS THE WEST FLANK ITSELF. A run out in the outboard strip stands its section in
# the one band the −X wall's own furniture wants — the tap-water split's cap reaches x −85.1
# inboard and the three cluster lever nuts sit in that wall's wells — and it fences that band for
# the whole height it crosses at. On the union's column the tube spans x[−81.2, −74.9] and the
# strip outboard of it is the wall's.
#
# THE EAST FLANK IS NOT ITS TWIN. The main board and its relay hang on the +X wall's own seat and take
# that column from y 232 aft for the whole of the height a gate line would climb it in — so
# `fluid-18` cannot come down its own flank at all and takes the crown lane over the core instead.
# What follows is the west line's.
#
# HOW FAR AFT THE JOG IS TAKEN, and it is fenced from both sides. The leg has to hold the climb's
# whole quarter-turn as tangent — a square corner spends its whole radius in each leg it touches,
# so `TUBE_BEND` of this leg is spoken for before the jog's own corner asks for any — and the jog
# turns only `atan(1 / reach)`, which `_routing._straighten` DROPS under 2°: past 28.6 mm of reach
# there is no corner here at all and the run is drawn as one straight into the collet, off its
# axis. This stands between the two, at 2.87° of turn.
#
# WHAT IT IS MEASURED FROM is V-J's own outlet, which rides `enclosure_assembly.PACK_Y`. Both
# fences above are on the leg, so both are read from there too, and `bend-radius` is what reports
# the climb's quarter when the leg is short of the first one.
GATE_B_JOG_LEG = 19.9
# Where the line comes off the cruise plane onto its union's own storey. The rise is 2.9 mm and
# the run holds the plane it climbed to for everything before it, so what this figure places is
# THE ANCHOR: the rib rides the middle of the leg it names, and the middle of this one stands in
# the daylight between the tap-water split's barrel (which ends at y 260) and the wall's own
# cluster wells (which begin at y 295). It is the one stretch of that wall a rib can cross without
# standing in something else's band, and it leaves 12 mm either side.
GATE_B_STEP_Y = 393.0
# What the rise takes fore and aft. Both its corners turn 8.1° and spend a millimetre of tangent
# apiece, so nearly all of this is straight — the reach is here to keep the corner well over the
# 2° a lean needs to be a lean, not because the arcs want it.
GATE_B_RISE_RUN = 20.0
# The upper lane passes between V-K's east face and the actual populated main board.
# Its diagonal arrives before the valve's front face, with both R14 tangents intact.
GATE_A_EAST_AIR = 1.5
GATE_A_LANE_REACH = 18.0
# Turn west ahead of the carb-water riser, then meet the post on a full straight.
GATE_A_CROSS_TURN_Y = 244.0
GATE_A_POST_STRAIGHT_AIR = 1.0


def _gate_a_anchor(F) -> tuple:
    """The installed side-post axis, from the cap's own placement declaration."""
    draw = F["foam-assembly"].at("reservoir-a")
    anchor = _cc.cap_side_anchors["fluid-18"]
    local_draw = _cc.cap_conduits["reservoir-a"]
    # Installed cap +Y is world +X and cap +X is world -Y.
    return (draw[0] + anchor.centre[1] - local_draw[1],
            draw[1] + local_draw[0] - _cc.cap_side_axis_y("fluid-18"),
            draw[2] + anchor.over_face)


def _gate_a_lane_y(solids) -> float:
    """Where the slant off the gate lands on the crown lane — fore of V-K, whose block takes
    the lane's east flank from its own front face aft."""
    return solids["vk-solenoid"].BoundingBox().ymin - _split.TUBE_D / 2.0 - LANE_CLEAR


def _gate_a_desc_y(solids) -> float:
    """Where the crown lane starts down — aft of `fluid-14`'s fall, which owns the lane's low
    room fore of this, one section and an air off its own last corner."""
    return (_fill_a_lane_y(solids) + FILL_A_LANE_RUN + FILL_A_FALL_RUN
            + _split.TUBE_D / 2.0 + 1.0)
# The west leg holds the side-post height until it has passed fluid-2. It then
# drops below the G Ganen discharge hose and regains the union's height behind that
# hose. Each end remains on its original collet axis with a straight lead.
GATE_A_FALL_START_Y = 292.0
GATE_A_FALL_Y = 328.0
GATE_A_RISE_Y = 366.0
GATE_A_RISE_RUN = 20.0


def gate_cruise(v_i_outlet_z: float) -> float:
    """The storey the WEST flavour gate cruises aft at, off the collet of the valve whose own
    channel crosses that gate's column.

    The same figure struck on `RESERVOIR_CRUISE` instead of on a stub — what the west gate climbs
    to under `fluid-24`. A run's own underside is one half-section below its axis, exactly as a
    stub's box is, so the lane and the reservoir line crossing it come out on one plane.

    IT IS WHAT BOTH UNIONS ARE STOOD ON, or the least of it: the west line cruises this plane the
    whole way aft and the east line comes down its union's column onto it, so neither has a storey
    to find at the end. What the unions actually take is `enclosure_assembly.flavor_storey`, which
    carries this plane up to whatever passes their barrels over the pump's bracket.

    Takes the Z rather than the frames, so a body may be STOOD on this plane before any run is
    drawn — `enclosure_assembly.panel_z` puts the flavor-B union on it."""
    # V-I stands ``FORE_STUB_GAP`` above the pump-barb tee so its short flex stub can work.
    # That buys extra clearance over the flavour gate; it does not move the gate, its rear
    # union or the long line between them to a new storey.
    return (v_i_outlet_z - _ml.FORE_STUB_GAP
            + RESERVOIR_CRUISE - _split.TUBE_D - GATE_STUB_CLEAR)


def station(body: str, port: str):
    """One body's station in its own frame, as a carry takes it."""
    return STATIONS[body][port][0]()


def _gate_climb_under_cruise(F) -> float:
    """`gate_cruise` read off the placed valve."""
    return gate_cruise(F["valve-v-i"].at("outlet")[2])


def _fluid_28(F, solids):
    """fluid-28 — the flavor-B gate to its rear union, and the line the manifold sends out of the
    machine on the WEST side.

    V-J-O faces UP off the west outboard valve, under the funnel's bowl and behind the reservoir
    stub that shares its column. So the run climbs what that stub leaves, comes about onto its
    UNION'S OWN COLUMN in one jog, and holds that column the rest of the way — the cold core's
    whole length, the panel deck, and into the collet on the collet's own axis.

    IT CROSSES ONCE AND THE CROSSING IS A MILLIMETRE. Gate and union stand one millimetre apart
    across the machine, so there is no lane to take and nothing to come back from: the run is on
    its final column before the cold core's front face, and every station aft of the jog
    reads the same X.

    WHAT IT LEAVES BEHIND IS THE WEST FLANK. The tap-water lane stands outboard of this column —
    the split's cap reaches x −85.1 and the wall's own cluster wells are outboard of that — and
    none of it is under this tube. The one thing this run puts in that strip is the rib that
    holds it, and `GATE_B_STEP_Y` stands that rib in the daylight between the two.

    THE STEP UP IS TAKEN LAST. The union stands a storey over the plane the gate climbs to,
    because `enclosure_assembly.flavor_storey` carries both barrels over the pump's bracket — so
    the run cruises the gate's own plane the whole way aft and spends the rise in one short lean
    behind the ASSE drip pan, where nothing is over it."""
    gate = F["valve-v-j"].at("outlet")
    tin = F["bulkhead-flavor-b"].at("tube-in")
    climb = _gate_climb_under_cruise(F)
    return R.bent(
        "fluid-28", "valve-v-j.outlet",
        (gate[0], gate[1], climb),                          # up what the reservoir stub leaves
        (tin[0], gate[1] + GATE_B_JOG_LEG, climb),          # the one jog, onto the union's column
        (tin[0], GATE_B_STEP_Y, climb),                     # the cold core's whole length, one column
        (tin[0], GATE_B_STEP_Y + GATE_B_RISE_RUN, tin[2]),  # one lean onto the union's own storey
        "bulkhead-flavor-b.tube-in",                        # and straight aft into the collet
        kind="fluid", bend=TUBE_BEND,
        note="flavor B: V-J-O → rear union, up the gate's own bay and one jog onto the union's "
             "own column, held to the wall")


def _fluid_18(F, solids):
    """Flavor A: rise off V-G, pass east of V-K, and cross through the cap's side post.

    The complete post bears on a straight tube. The west leg remains high over fluid-2,
    passes below the discharge hose, then rises onto the rear union's unchanged axis.
    """
    gate = F["valve-v-g"].at("outlet")
    tin = F["bulkhead-flavor-a"].at("tube-in")
    anchor_x, deck_y, cross_z = _gate_a_anchor(F)
    lane_x = (solids["vk-solenoid"].BoundingBox().xmax
              + _split.TUBE_D / 2.0 + GATE_A_EAST_AIR)
    join_x = (anchor_x + _cc.cap_side_len / 2.0 + TUBE_BEND
              + GATE_A_POST_STRAIGHT_AIR)
    low_z = (F["g-ganen-pump"].at("discharge")[2]
             - (_suct.HOSE_OD + _split.TUBE_D) / 2.0 - LANE_CLEAR)
    run = R.bent(
        "fluid-18", "valve-v-g.outlet",
        (gate[0], gate[1], cross_z),
        (lane_x, gate[1] + GATE_A_LANE_REACH, cross_z),
        (lane_x, GATE_A_CROSS_TURN_Y, cross_z),
        (join_x, deck_y, cross_z),
        (tin[0], deck_y, cross_z),
        (tin[0], GATE_A_FALL_START_Y, cross_z),
        (tin[0], GATE_A_FALL_Y, low_z),
        (tin[0], GATE_A_RISE_Y, low_z),
        (tin[0], GATE_A_RISE_Y + GATE_A_RISE_RUN, tin[2]),
        "bulkhead-flavor-a.tube-in",
        kind="fluid", bend=TUBE_BEND,
        note="flavor A: V-G-O → rear union, east of V-K through the cap's side post, "
             "over fluid-2 and below the pump discharge hose")
    if run.tightest < TUBE_BEND - 1e-6:
        raise ValueError(f"fluid-18: minimum bend {run.tightest:.3f} mm is below R{TUBE_BEND:g}")
    return run


# --- the four reservoir lines, gate to reservoir and reservoir to gate --------
#
# Neither reservoir has a junction: each carries two mouths of its own — the draw on the bulkhead
# at the bottom of its wet V, the fill on a bore in its own cap — so each pair's two valves reach
# one directly. The fill arrives ABOVE THE LIQUID, which is the whole point of the second mouth:
# everything entering has to cross the cavity to leave by the trough, so a purge displaces what
# is in there rather than short-circuiting back out the drain it came in by.
#
# BOTH ENDS OF EVERY ONE OF THESE FACE UP. A gate's collet on the lower deck opens +Z and a cap
# conduit opens +Z, so each is a U over the crown rather than a fall: it leaves on its own axis,
# crosses on one plane, and comes down on the far one's.
#
# THREE OF THE FOUR CROSS ON `RESERVOIR_CRUISE`, which is not typed — it is the least a collet
# facing up can rise and still turn, one stock radius, and every one of those ends sits on the
# same port plane so one figure serves them. `fluid-14` is the exception and says why.
RESERVOIR_CRUISE = TUBE_BEND
# The two ends of `fluid-24`'s crossing from the outboard lane to the bore's own column.
#
# THE WEST HALF IS OPEN AT THIS PLANE ONLY FORWARD OF `water-5`. Swept east from x −80 at the
# cruise, the strip runs clear across the machine at every station up to y 185 and then shuts:
# `water-5` crosses this plane at x[−60.1, −53.2] over y[185.7, 203.2] on its way down to the
# `water-in` bore, and the discharge chain takes x[−64.5, −49] from y 223 aft. So the crossing
# is taken forward of both, and what the run does aft of it is hold the bore's column, which is
# clear the machine's whole depth.
# `water-5` leaves the anchored discharge chain's collet and slants down to its cap
# bore. Its own placed route determines the crossing clearance in this plane.
#   `FILL_B_JOIN_Y` is then fenced from the other side: `fluid-26` rises off the draw bore at
# y 184 on this same column, so the join stands clear of that climb by more than the two lines'
# own sections. `FILL_B_LEAN_Y` holds the gate's column long enough to make the crossing steep,
# which is what buys that clearance.
FILL_B_LEAN_Y = 170.0
FILL_B_JOIN_Y = 192.0
# The first rise leans 0.6 mm inboard, within the collet's 3-degree allowance.
# This leaves 1.19 mm to the manifold-B Wago while retaining the full R14 bend.
FILL_B_GATE_INBOARD = 0.6
# What a line holds off a body it passes in a lane, where the lane is the whole of its room.
LANE_CLEAR = 4.0
# The high approach crosses over fluid-16. The long low leg's column and height belong to
# its cap anchor, in the native round-body gap between V-A and V-K. Its finished sweep must
# retain the ordinary clearance floor to both valves; their boxes do not describe that gap.
FILL_A_LANE_Z = 289.0
# Straight lead off V-F before spending its lifted station in the diagonal. The completed
# route below checks every bend rather than assuming this lead alone guarantees R14.
FILL_A_GATE_LEAD = 17.0
# The draw line and fill line cross as two long leans. Keep their centre lines a tube section
# plus this air apart at the fill line's lane plane, rather than making either established end
# storey carry the other's valve lift.
FILL_A_DRAW_CLEAR = 1.5
FILL_A_DRAW_GATE_LEAD = 17.5
# How long the run holds that storey before it falls — one stock radius, of which the corner off
# the diagonal and the corner into the fall take 11.2 between them. What is left is the only
# straight between those two bends. Re-read the fall's room by sweeping the two waypoints that
# carry it —
#
#     tools/cad-venv/bin/python hardware/scripts/probe.py reroute fluid-14 3-4 y- 0:6:0.5
#
# — clear to 2.5 mm forward of here, then that corner starves and `fluid-16` arrives a few
# millimetres behind it. The rib holding this run stands in the cap's own frame and does not
# follow the fall: `_cold_core_interface.cap_anchors["fluid-14"]`.
FILL_A_LANE_RUN = TUBE_BEND
# How much depth the fall onto the cap takes. Both its corners spend `TUBE_BEND` as tangent, so
# what reaches the cap's plane is the fall plus those two arcs.
FILL_A_FALL_RUN = 10.0
# After the complete cap bearing, a shallow descent clears the suction hose
# while both hoses leave their measured barb axes. The rear fill approach keeps
# the cap anchor's storey; neither printed anchor nor conduit moves.
FILL_A_HOSE_DROP = 1.25
FILL_A_HOSE_FALL_RUN = 20.0
# The valve-side leg passes below the wide part of V-A, then returns to the
# complete cap bearing before its fore edge. These gentle bends retain R14.
FILL_A_VALVE_DROP = 1.5
FILL_A_VALVE_RETURN_RUN = 8.0
FILL_A_BEARING_LEAD = 2.0


def _fill_a_lane_y(solids) -> float:
    """Where the run comes about onto the lane — one clear section forward of V-K's own face,
    so the diagonal off the gate is on the lane's column before it reaches the valve it passes."""
    return solids["vk-solenoid"].BoundingBox().ymin - _split.TUBE_D - LANE_CLEAR


def _fill_a_cap_z(F) -> float:
    """The cap's actual outer face plus its own fluid-14 bearing height."""
    return (F["foam-assembly"].at("reservoir-a-fill")[2]
            + _cc.cap_anchor_axis_over_face("fluid-14"))


def _fill_a_turn_y(F) -> float:
    """Where it leaves the cap's plane for the bore's own column — aft of the tap-water riser.

    `water-7` crosses this lane on the pump's suction barb in 3/8" braided, the fattest stock the
    machine carries. The run holds the lane past that hose and leans east only behind it."""
    return F["g-ganen-pump"].at("suction")[1] + (_suct.HOSE_OD + _split.TUBE_D) / 2.0 + LANE_CLEAR


def _fluid_14(F, solids):
    """fluid-14 — the channel-A fill gate to the bore in reservoir A's own cap.

    Rise off V-F, cross above fluid-16, then fall into the round-body gap between V-A and V-K.
    The valve-side leg passes below V-A and returns to its anchor's height before the
    complete cap bearing. It descends gently under the suction hose, leaves that lane
    aft of the hose and returns to the anchor's storey on the fill-bore approach. Both
    the route and its rib share one placement declaration."""
    gate = F["valve-v-f"].at("outlet")
    bore = F["foam-assembly"].at("reservoir-a-fill")
    # The installed cap maps local +Y to world +X. Reference its draw conduit so a translated
    # core moves the anchor and route together without assuming a world-origin placement.
    lane_x = (F["foam-assembly"].at("reservoir-a")[0]
              + _cc.cap_anchors["fluid-14"].centre[1] - _cc.cap_conduits["reservoir-a"][1])
    fall = _fill_a_lane_y(solids) + FILL_A_LANE_RUN
    cap = _fill_a_cap_z(F)
    bearing_y = (F["foam-assembly"].at("reservoir-a")[1]
                 + _cc.cap_conduits["reservoir-a"][0]
                 - _cc.cap_anchors["fluid-14"].centre[0])
    valve_return = bearing_y - _cc.cap_anchor_len / 2.0 - FILL_A_BEARING_LEAD
    valve_under = cap - FILL_A_VALVE_DROP
    hose_fall_end = F["g-ganen-pump"].at("suction")[1] - 2.0 * HOSE_BEND
    hose_fall_start = hose_fall_end - FILL_A_HOSE_FALL_RUN
    hose_under = cap - FILL_A_HOSE_DROP
    run = R.bent(
        "fluid-14", "valve-v-f.outlet",
        (gate[0], gate[1], gate[2] + FILL_A_GATE_LEAD),     # a full-radius lead off lifted V-F
        (lane_x, _fill_a_lane_y(solids), FILL_A_LANE_Z),    # one diagonal aft, inboard and down
        (lane_x, fall, FILL_A_LANE_Z),                      # one stock radius of it, over that lean
        (lane_x, fall + FILL_A_FALL_RUN, valve_under),      # low through the V-A / V-K body gap
        (lane_x, valve_return - FILL_A_VALVE_RETURN_RUN, valve_under),
        (lane_x, valve_return, cap),                       # recover before the full cap bearing
        (lane_x, hose_fall_start, cap),                    # complete straight bearing over the bracket
        (lane_x, hose_fall_end, hose_under),               # shallow descent beneath the suction hose
        (lane_x, _fill_a_turn_y(F), hose_under),            # hold low until aft of the braided hose
        (bore[0], bore[1], cap),                            # one lean east onto the bore's column
        "foam-assembly.reservoir-a-fill",                   # and straight down the strip into it
        kind="fluid", bend=TUBE_BEND, skew=(R.COLLET_SKEW, CAP_BORE_SKEW),
        note="reservoir A fill: V-F-O → the fill bore in its own cap, over `fluid-16`'s lean and "
             "straight down onto the cap, then the whole way aft in the lane V-K and V-A leave "
             "to the bore's own column behind the suction hose")
    radius = min(run.radii.values(), default=run.bend)
    if radius < TUBE_BEND - 1e-6:
        raise ValueError(f"fluid-14 seats R{radius:.3f}, below its R{TUBE_BEND:g} stock")
    tube = R.tube(run)
    for name in ("valve-v-a", "vk-solenoid"):
        gap = tube.distance(solids[name])
        if gap < _card.CLEARANCE_FLOOR - 1e-6:
            raise ValueError(
                f"fluid-14 clears {name} by {gap:.3f} mm, below "
                f"the {_card.CLEARANCE_FLOOR:g} mm clearance floor")
    return run


def _fluid_16(F):
    """fluid-16 — the draw conduit on reservoir A's cap to the channel-A draw gate.

    A's draw conduit stands at the head of its band on the same forward strip B's does. It rises
    to a plane one tube and `FILL_A_DRAW_CLEAR` under the fill lane, then leans forward, inboard
    and up to a full-radius lead over the lifted gate. The unequal endpoints spend the valve
    lift in that long lean while both established reservoir and gate stations stay put."""
    bore = F["foam-assembly"].at("reservoir-a")
    gate = F["valve-v-e"].at("inlet")
    draw_z = FILL_A_LANE_Z - _split.TUBE_D - FILL_A_DRAW_CLEAR
    gate_z = gate[2] + FILL_A_DRAW_GATE_LEAD
    return R.bent(
        "fluid-16", "foam-assembly.reservoir-a",
        (bore[0], bore[1], draw_z),              # up under the fill lane with named skin air
        (gate[0], gate[1], gate_z),              # one lean forward, inboard and up
        "valve-v-e.inlet",                      # and straight down into the collet
        kind="fluid", bend=TUBE_BEND, skew=(CAP_BORE_SKEW, R.COLLET_SKEW),
        note="reservoir A draw: the cap's draw conduit → V-E-I, up under the fill lane and "
             "one lean forward, inboard and up onto the lifted gate's own column")


def _fluid_24(F):
    """fluid-24 — the channel-B fill gate to the bore in reservoir B's own cap.

    V-I-O opens up off the west outboard limb, on the same column the flavor-B gate climbs and
    one storey under it. The run rises what a corner needs, holds that column aft the length of
    the manifold — the outboard lane is clear of everything the west flank stands — and leans
    inboard onto the bore only at `FILL_B_JOIN_Y`, behind the tap water's own descent."""
    mouth = F["valve-v-i"].at("outlet")
    bore = F["foam-assembly"].at("reservoir-b-fill")
    cruise = mouth[2] + RESERVOIR_CRUISE
    lane_x = mouth[0] + FILL_B_GATE_INBOARD
    return R.bent(
        "fluid-24", "valve-v-i.outlet",
        (lane_x, mouth[1], cruise),            # a shallow inboard rise past the Wago's tip
        (lane_x, FILL_B_LEAN_Y, cruise),       # aft along the cleared outboard lane
        (bore[0], FILL_B_JOIN_Y, cruise),       # one lean inboard onto the bore's column
        (bore[0], bore[1], cruise),             # aft on it, past what shuts the strip west
        "foam-assembly.reservoir-b-fill",       # and straight down into the bore
        kind="fluid", bend=TUBE_BEND, skew=(R.COLLET_SKEW, CAP_BORE_SKEW),
        note="reservoir B fill: V-I-O → the fill bore in its own cap, up the west outboard "
             "lane and one lean inboard onto the bore")


def _fluid_26(F):
    """fluid-26 — the draw conduit on reservoir B's cap to the channel-B draw gate.

    The reverse journey of `fluid-24` and a shorter one, because the draw's conduit stands at the
    head of the +Y band on the FORWARD strip rather than over the pocket. The lean crosses between
    two descents on the same strip — `water-5` into `water-in` one column west, `fluid-2` a
    storey above — and holds the cruise plane between them."""
    bore = F["foam-assembly"].at("reservoir-b")
    gate = F["valve-v-h"].at("inlet")
    cruise = gate[2] + RESERVOIR_CRUISE
    return R.bent(
        "fluid-26", "foam-assembly.reservoir-b",
        (bore[0], bore[1], cruise),             # up off the bore onto the cruise plane
        (gate[0], gate[1], cruise),             # one lean forward and inboard onto the gate
        "valve-v-h.inlet",                      # and straight down into the collet
        kind="fluid", bend=TUBE_BEND, skew=(CAP_BORE_SKEW, R.COLLET_SKEW),
        note="reservoir B draw: the cap's draw conduit → V-H-I, up off the bore and one lean "
             "forward and inboard onto the gate's own column")


def _refrig_3(F):
    """refrig-3 — the evaporator's outlet back to the compressor's suction, in copper.

    The other two joints of the sealed loop are made across a plane their bodies already share
    and draw no tube. This one cannot be: the suction stands on the shell's WEST tangent, which
    looks at the side wall and at no neighbour at all, and the core stands a lane behind the can
    besides. So this leg is cut and brazed like any other run — out into the west lane, then one
    long diagonal aft and back inboard, past the shell's own shoulder and down into the core's
    outlet slot."""
    return R.bent(
        "refrig-3", "compressor.refrig-suction", "foam-assembly.evap-outlet",
        kind="refrigerant", bend=CU_BEND, lead=CU_LEAD,
        note="sealed loop: evaporator outlet → compressor suction, the one leg of the three "
             "that is drawn rather than made across a shared plane")


def _refrig_1(F):
    """refrig-1 — the compressor's discharge into the condenser's intake, in copper.

    BOTH MOUTHS FACE EACH OTHER ON ONE LINE. The can's discharge stub stands on its own +X
    tangent and the block's header is re-dressed to that stub's column and plane, so what
    crosses the lane the block's slide east opens is one length of tube."""
    return R.bent(
        "refrig-1", "compressor.refrig-discharge", "condenser+fan.refrig-inlet",
        kind="refrigerant",
        note="sealed loop: compressor discharge → condenser inlet, one straight across the lane")


def _refrig_2(F):
    """refrig-2 — the condenser's liquid line into the evaporator's inlet, in copper.

    BOTH MOUTHS OPEN ONTO THE SAME LANE but not onto the same axis: the block stands off the east
    flank\'s own section (`enclosure_assembly.east_lane_free`) and the core is packed to the rear,
    so the two ports sit a wall\'s thickness apart across the lane. `lead` is what makes that a
    tube rather than a skew — it leaves the outlet and enters the inlet on their own normals and
    turns in between, which is the bend a fitter puts in this leg anyway. The drier stands inside
    the block\'s own envelope, and what leaves it is this."""
    return R.bent(
        "refrig-2", "condenser+fan.refrig-outlet", "foam-assembly.evap-inlet",
        kind="refrigerant", lead=2.0, min_bend=8.0,
        note="sealed loop: condenser outlet → evaporator inlet, hand-formed across the lane")


def authored() -> frozenset:
    """The connection ids this module draws a run for, without building one. `enclosure_assembly`
    reads it before the pack is assembled, to know which of the manifold's placeholder mouth stubs
    a real line has replaced."""
    return frozenset(_AUTHORED)


# The ids `build_runs` can produce. One name per `_*` author below, and the guard each is behind
# only decides whether the bodies to draw it are placed yet.
_AUTHORED = ("water-7", "water-6", "water-5", "water-2", "fluid-1", "water-3",
             "co2-0", "co2-1", "co2-2", "fluid-2", "fluid-4", "carb-1", "carb-2", "fluid-28",
             "fluid-18", "fluid-24", "fluid-26", "fluid-14", "fluid-16", "refrig-3",
             "refrig-2", "refrig-1")






def tubes(runs):
    """Each run swept at its own bore, as `(name, solid)` — what the assembly carries.

    A RUN WHOSE ENDS MEET IS A BUTT and carries no solid. Both mouths are quick-connects, so
    there is tube in each of them and none exposed between the two, the same joint
    `manifold_layout.SEGMENTS` calls a butt on the pack's own interior. The run stays in the
    ledger at its own length — it is still a connection, and `fluid-topology.md` still owes it
    a row — but there is no stock to sweep.

    `_routing.BUTT_MAX` is the reading, and it is a PHYSICAL figure and not a numeric one: what stands
    between two collets is either a length of stock or nothing, and a collet swallows the better
    part of a bore in tube before it grips. What lands under it here is the float residue two
    faces brought together by a stated depth leave behind."""
    return [(f"tube-{r.id}", R.tube(r)) for r in runs if r.length > R.BUTT_MAX]


def report(runs):
    """One line per run: what it joins, the stock it cuts, and the roundest corner it turns."""
    if not runs:
        return
    print("\nruns")
    for r in runs:
        print(f"  {r.id:12} {r.frm:28} → {r.to:28} {r.length:7.1f} mm  "
              f"{len(r.bends)} corner(s) at R{r.tightest:.1f} "
              f"(stock floor R{R.stock_min(r.kind, r.diam):.1f})")
    for cid, why in sorted(BLOCKED.items()):
        print(f"  BLOCKED {cid}: {why}")
