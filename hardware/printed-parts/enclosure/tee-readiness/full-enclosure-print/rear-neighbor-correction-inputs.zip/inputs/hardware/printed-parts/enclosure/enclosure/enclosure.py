"""Thin Edition enclosure — a tall, narrow PETG box, split into four printable
pieces (front/back × bottom/top) that telescope and cross-pin together.

WIDTH, HEIGHT and DEPTH are all BOUNDS, not consequences — `appliance_width` struck
symmetric about x = 0, `appliance_height` from the floor slab's underside to the top
wall's outer face, and `rear_plane_y` fixing the back while the front wall reaches the
pump cartridge's plane from its interior datum. The contents do
not set them; they have to fit inside, and `_dims` measures every one of them against
the pack and enters the reading in `BOUNDS`. The box comes out at its stated size
either way, so a pack that overran it gets a wall drawn through it.

Three bodies stand on the floor slab — the compressor and the condenser side by side
across the front, and the cold core behind them. The seam blocks occupy `2 * socket_r`
in Y, with the lower pair carried up to the Z seam and the upper pair to the ceiling.
A body is held one `side_band_inset` off the wall where it meets their footprint in Y
and Z; outside that footprint the band is the wall's own air. The cold
core meets the chain and is held off it; the compressor stands under the front column's
collars and the condenser is not on the slab at all. The core is the widest of the three
even yawed a quarter turn (`enclosure_assembly.FOAM_YAW`), which is what puts its 181 mm
short face across the machine instead of its 283 mm long one. The pack is placed by
`../../../manifold-layout/enclosure_assembly.py`. Features:

  * A 30° machine-display plane between tangent front and roof curves. Rounded
    side edges meet the fluted walls; the rear top edge remains square. The
    rounded bezel snaps into the recessed plane, ahead of the inset funnel.
  * A front↔back split at the stated `y_seam`, so its machinery is aft of the
    front pack and a front-quadrant tray never has to be notched around it:
    the front pieces' aft walls telescope (a full-wall lip,
    nothing shaved) into the back pieces — a proud tongue on the side walls and
    ceiling, and on the floor, where the cold core rides the cavity side and a
    proud tongue cannot, a full-thickness tongue with a 45° scarf nose
    (`_floor_scarf`), so every seam laps and none butts — and SIX screw
    bosses cross the seam, the box's six screws: one per ±X side wall at the
    floor, just below the Z seam and under the ceiling. The lower and middle
    pairs pin the bottom pieces. Each boss is on an X axis:
    the screw drives in from the left/right EXTERIOR face. The BACK piece
    carries the PLUG: a block reaching inward from the wall with a screw
    clearance through it, carried aft into the back piece's full-thickness
    flank. The upper blocks join the ceiling; the lower and middle stations
    share straight jambs rooted in the floor. The FRONT piece's
    lip carries the SOCKET (faucet shell-bottom idiom): a collar slotted to
    receive the plug, open on its +Y face so the plug drops in as the pieces
    close, with a ruthex M3 heat-set at the deep end.
  * A bottom↔top split per column that SLIDES HOME and takes no screw, at ONE
    stated height both sides of the Y seam (`z_seam`, one level line round the
    box). The BOTTOM pieces carry the lip — a 3-sided band, their outer ±Y
    wall + both side walls, stopping short of the Y-seam overlap — with a
    HOOKED RAIL on each flank's straight run: an ARM standing on the mouth
    whose HEAD steps outboard over the groove (`_z_rail_heads`). The TOP
    pieces run their wall to the mouth at full section — the FOOT — with a
    notch above it that swallows that head (`_z_rail_feet`,
    `_z_rail_channels`). THE TWO COLUMNS ARE MIRRORED: front-top enters fore of
    home and slides AFT over the front wall's own plane, back-top enters aft of
    home and slides FORE over the rear wall's — each to the stop block closing
    its own far end; the end walls and corner turns close head-on behind it, the
    same telescoping mate the Y seam makes, arrived at along Y. Lifting a seated
    top lands each foot's flat top on its head's flat underside down both whole
    runs. A top comes off the way it went on, toward the end of the box it
    stands at — front-top forward into open air, back-top aft — so neither is
    lifted over the other and neither asks the box to come out from under
    whatever it is built under. Front-top is held by the upper pair of Y-seam
    screws alone, so two screws draw it off the front. A WALL THAT
    LIP STANDS ON IS `2 * wall` THICK, floor slab to lip rim
    (`_lip_underwall`): the lip is a skin standing proud of the interior
    face, and a skin that began at the seam would land its underside in air —
    a soffit round three sides of a piece that prints floor-down. Carried to
    the slab it is a wall instead, and there is nothing in a bottom piece for
    the bed to bridge.

The walls stand off the bodies rather than on them — one boss chain at the ±X
walls, one wall at the back — because a body on the floor spans the interior wall
to wall, so a wall on its face would leave the seam machinery nowhere to stand.
The cold core seats flush against the seams instead, and stands flat on the floor slab — its bottom cap's lid is a plane and
every cap screw is down in a counterbore, so nothing goes under it. The ±X bands'
own seam furniture fences it sideways, the back Z seam's lip behind, and the floor's
two core lugs (`_core_fence`) ahead. The floor that core stands on is flat: the
Y seam's floor tongue stays within the slab, with a 45° scarf nose rather than a
feature standing proud of its cavity-side face.

Three pieces print on their Z− FACE — the bottom pieces floor-down on the slab,
front-top mouth-down on its seam rim — and back-top prints on its Z+ face, its
ceiling on the bed. The build axis is the box's own Z on every piece and the sign
is the piece's (`print_up`): where it is +Z the face that hangs is the one looking
DOWN, where it is −Z the one looking UP, and every 45° relief in this file is
struck on the side that hangs for its piece. The anti-warp corner relief goes on
the arrises that run along the build axis: the box's four standing verticals. Each quadrant owns only two of them —
its other two "corners" are the Y-seam, a telescoping mating face with no
exterior arris to relieve — so the front pieces round the front-left/right
verticals, the back pieces the back-left/right, and every seam stays square.
The display plane meets rounded side edges, which continue into the fluted
walls. The rear top edge remains square.

Inside those same verticals stand the COLUMNS, and each is that relief MIRRORED —
congruent with it, a QUARTER TURN of the same radius, swung from the interior
corner because that is the only place such a turn fits with its ends on the two
inner faces. Two sharp corners and one arc between them, the corner behind it
solid, floor slab to ceiling. They are the cavity's own shape (`_cavity`), so everything held inside
it meets a column the way it meets a wall: a mount inside the footprint is the
column's material with only its bore left. At a front corner the rail channel's
deep lane passes through the pillar's flank side on its way to the stop, the one
mark the slide leaves on one.

A plug is the wall it drives through and the reach it needs past it: the first
`wall` of its length is that wall's own material and the rest a stub off it, its
mouth-side face on the mouth that receives it. A socket is a block round that plug —
one `wall` of material, a `socket_cap` over the insert's blind end — its rim-side
face on the lip rim and its far face a hair under the seam mouth, so it stands on
that band — lip above the mouth, wall under it below — down its whole length. Those are the two matings the
overlap depth is struck from. The lower and middle levels share a straight jamb.
A level stands where its socket has a body to be bored into (`_level_clear`).

A Z seam is held shut along its whole run rather than pinned at its ends: the
rails' hooks bear over every millimetre both flanks carry, and the stop
blocks and end walls close the travel. The Y seam has three pairs of screws:
floor and middle pairs close the bottoms, and the ceiling pair closes the tops.
The ceiling pair also locks front-top's slide. Levels are searched per side
wall against what stands against it, so the two walls need not carry the same
ones; main() prints what each ended up with.

main() exports the four printable pieces (enclosure-front-bottom.step,
enclosure-front-top.step, enclosure-back-bottom.step, enclosure-back-top.step)
plus enclosure.step — the four as separate solids in assembled position,
seams intact (mirrors `faucet_shell.py`). All five come through the same
code from a `Box`.
"""

import functools
import math
import sys
from collections import namedtuple
from pathlib import Path

import cadquery as cq
from OCP.BRepAdaptor import BRepAdaptor_Surface

_here = Path(__file__).resolve()
_repo = next(p for p in _here.parents if (p / "hardware" / "scripts" / "_cadq_export.py").is_file())
# _repo is this EDITION's root; tools/ is shared machinery with one copy at the
# repo root, so it gets its own anchor rather than a tools/ per edition.
_tools = next(p for p in _here.parents if (p / "tools" / "docgen").is_dir()) / "tools"
sys.path.insert(0, str(_repo / "hardware" / "scripts"))
sys.path.insert(0, str(_tools))
sys.path.insert(0, str(_repo / "hardware" / "printed-parts" / "cadlib"))
sys.path.insert(0, str(_repo / "hardware" / "printed-parts" / "zone-c" / "funnel"))
sys.path.insert(0, str(_repo / "hardware" / "reference" / "wago-221"))
sys.path.insert(0, str(_repo / "hardware" / "reference" / "mq6-gas-sensor"))
sys.path.insert(0, str(_repo / "hardware" / "reference" / "riteav-keystone"))
sys.path.insert(0, str(_repo / "hardware" / "reference" / "iec-c14-inlet"))
sys.path.insert(0, str(_repo / "hardware" / "printed-parts" / "valve-seat"))
sys.path.insert(0, str(_repo / "hardware" / "printed-parts" / "enclosure" / "valve-tray"))
sys.path.insert(0, str(_repo / "hardware" / "printed-parts" / "enclosure" / "pump-tray"))
from _cadq_export import export_assembly
from _materials import WALL_COLORS as PIECE_COLORS, one_body
from docgen import substitute_md, substitute_py_comments
import _boxes
import _realized
import cable_clip as _cable_clip
import fits
import reeding
import trimesh
import flute_skin as _flute_skin
import funnel as _funnel
import wago_221 as _wago
import mq6_gas_sensor as _mq6
import riteav_keystone as _keystone
import iec_c14_inlet as _c14
import valve_seat as _seat
import valve_tray as _valve_tray
import pump_tray as _tray
import _enclosure_interface as _interface
import _swept_top
import _display_retention

# Shell parameters.
wall = _interface.wall      # PETG wall thickness
pump_station_lead = _interface.pump_station_lead
pump_station_drop = _interface.pump_station_drop
# THE FLOOR SLAB IS NOT A WALL AND IS NOT ONE WALL THICK. It is the face the machine's whole
# mass stands on, the face a body bolted DOWN rather than hung on a flank is anchored to
# (`_floor_bosses`), and the one face of the box that prints flat on the bed — where section
# is filament and nothing else: no bridge, no support, no standing wall to warp.
# `appliance_height` is struck to its UNDERSIDE and the cavity keeps its own floor plane at
# the pack's z = 0, so the slab stands in the silhouette: the machine is `floor_t`, the
# cavity, and one `wall` of top.
floor_t = 6.0
# The +Y wall stands one wall off the rearmost content — the cold core, the
# only thing near the back — so the core seats flush against the rear Z-seam
# lip's inner face rather than against the wall the lip hangs off. A body mounted
# on the +Y wall seats on this same plane.
rear_seam_clear = _interface.rear_seam_clear
# The same standoff at the front, so the front column's Z lip keeps a full-width
# front segment behind the compressor bay instead of giving it up.
front_seam_clear = 3.0
corner_round = _interface.show_corner_r  # standing body corners

# --- which face each piece prints on ------------------------------------------
#
# THE BUILD AXIS IS THE BOX'S OWN Z, AND ONE PIECE STANDS ON ITS HEAD. The bottom pieces print
# floor-down on the slab and front-top prints mouth-down on its seam rim: build up = +Z, and the
# face that hangs is the one looking DOWN. back-top prints on its ceiling's outer face: build up
# = -Z, the ceiling is its first layers, and the face that hangs is the one looking UP. Every
# feature struck for a print reads `print_up` and puts its relief on the side that hangs — a
# corbel under a floor on one piece is a corbel over a crown on the other — and a face at 45°
# prints either way. What does not change is the anti-warp corner relief, which stands on the
# arrises along the build axis on every piece (`corner_round`).
PIECE_PRINT_UP = {
    "front-top": 1.0, "front-bottom": 1.0, "back-bottom": 1.0, "back-top": -1.0,
    # The clamp beds on its crown. Printed so, its two boss-to-can shoulders look print-up;
    # what looks down is the two head seats, each a bridge over its own clearance bore.
    "pump-cartridge": 1.0, "pump-cap": -1.0,
}
BACK_TOP_UP = PIECE_PRINT_UP["back-top"]


def print_up(y_side, z_side):
    """The build direction of one quadrant, as the sign of the box's Z it grows along: +1.0 for
    a piece bedded on its Z- face, -1.0 for one bedded on its Z+ face."""
    return PIECE_PRINT_UP[f"{y_side}-{z_side}"]

# --- the standing corners' columns ------------------------------------------
#
# THE COLUMN IS THE RELIEF MIRRORED, AND A MIRROR IS CONGRUENT OR IT IS NOT ONE. Each
# standing vertical is relieved `corner_round` outside — a QUARTER TURN tangent to both outer
# faces — so the column's face is a quarter turn of the same radius, the same arc and the same
# length. The only place such a turn fits inside the cavity with its ends on the two inner
# faces is swung from the corner they meet at, and that is the whole of it: one radius, one
# centre, the interior corner.
#
# It lands on each face at 90°, so the corner presents TWO SHARP CORNERS opposite each other,
# [12 mm](COLUMN_ALONG) along each face, with the arc between them. The section stands
# [8.27 mm](COLUMN_DEPTH) out of the cove at the corner's diagonal.
#
# THE CORNER BEHIND IT IS SOLID. The face is the column's only free surface: a second arc back
# there — the mirror's own mirror — would leave a through slot the column's whole height, so
# the column is everything within the radius and `_cavity` hands the wall the rest. The cove
# the wall had turned stops being a surface at all; what the room meets at a standing vertical
# is one arc, congruent with the one it meets outside.
#
# It is a pillar and not a feature at a station: it runs floor slab to ceiling, so every Z
# seam crosses it and the seam's own lip wraps its face the way it wraps a wall (`_cavity`).
# What stands in a corner is ABSORBED — a boss inside the footprint is the column's own
# material and keeps only its bore.
column_round = corner_round
# The corners that carry one, as the (x, y) signs of the interior corner each stands in.
column_corners = ((-1, -1), (1, -1), (-1, 1), (1, 1))

# --- the reeded skin --------------------------------------------------------
#
# THE FOUR STANDING WALLS ARE FLUTED, and it is ONE field, not four. Half-round grooves are
# struck by ARC LENGTH round the whole outer plan from a datum on the front wall's centreline,
# and arc length is what makes them one field: it does not know where a face ends, so a flute
# crosses `corner_round`'s quarter turn at exactly the spacing it keeps on the flat, and the
# four pieces cut their own z bands out of the same plan — which is why the grooves register
# across the Z seam without either piece being told the other exists.
#
# THE PROFILE IS `reeding.groove`, shared with the corner coupon at `c14bb2fff`. That coupon is the box's
# own corner at the box's own `wall` and `corner_round`, so what printed there is what prints
# here, and neither can drift from the other while they read one function.
#
# THE FIELD CLOSES ON ITSELF. `flute_count` is a whole number of grooves round the whole
# perimeter, so no station restarts the array and no two arrays meet anywhere — but which
# whole number is not free, because the pitch is what it lands on and WHERE THE FIELD LANDS
# DECIDES WHAT THE BOX'S OWN LINES ARE MADE OF. Two bounds spend it:
#
#   `flute-closes`       the pitch stays within a hair of the coupon's
#   `flute-hides-seam`   the Y seam — the one straight line running the full height of both
#                        side walls — falls in a groove's own shadow rather than on a land
#
# AND THE FIELD IS SYMMETRIC IN X, because the datum is a groove centre on x = 0, the plane
# the whole machine is struck about. Whatever `flute_count` is, the half-perimeter carries
# the same grooves the other way round.
#
# AND THE BOX HAS A SECOND FIELD, INDOORS. The bay's storey shows two mouth ledges, and those
# two actual surfaces are two open rails. `_bay_storey_segments` carries their one global phase
# path across the intervening open flanks and hidden tee span, which are never cutter paths.
# Both are struck at THIS pitch from a datum on the same x = 0, so their phase remains the
# machine's phase inside as it is outside. `flute_rails` is where the box says which runs it
# has, and `flute_skin.py` reads nothing else about either of them.
flute_count = 260
# THE DEPTH IS THE COUPON'S. the corner coupon at `c14bb2fff` cut this into a `wall`-thick standing wall
# and printed it; going deeper is a new question, not a free one.
flute_depth = _interface.flute_depth
# THE SOLID A FLUTE MUST HAVE BEHIND IT — the whole `wall`, not what is left after something
# else has taken its share. A groove cut where less than this stands behind it telegraphs
# through to the show face; the coupon proved it on the 0.6 mm its engraved label took out of
# the far side, which read on the outside as a mark you could find. So nothing may relieve
# into the outermost `flute_backing` of a fluted face, and `flute-backed` reads every stated
# section on those faces against it.
flute_backing = wall
# How many stations the groove's own curve is drawn through, half-width to half-width. The
# spline through them measures 1.1986 of the stated 1.2 at its deepest, which is a hundredth
# of the 0.42 mm the nozzle draws.
flute_samples = 13
# THE FIELD STOPS SHORT OF AN EDGE, and this is how far short — the corner coupon at `c14bb2fff`'s own
# `texture_rise`, ramped on the same smoothstep, so the box stops its flutes the way the
# coupon stopped its. WHICH edges is not a list: `flute_skin.py` measures, over the whole
# surface at once, how far every station stands from the nearest place the show face ends,
# and ramps on that. A seam, an opening's rim, a pocket's edge and the facet's own diagonal
# arris are the same fact to it, which is why none of them is named anywhere.
flute_rise = _interface.flute_rise
# WHAT A BAND GETS FOR BEING AS TALL AS IT IS. A band's own two faces are both edges of the show
# face, so its deepest station stands half the height from one and reaches `flute_depth` only
# once that clears `flute_rise`. The pieces let into the box's faces read these to say which side
# of that they fall on — `display_cover.display-cover-reveal`.
flute_full_depth_height = _interface.flute_full_depth_height
flute_reach = _interface.flute_reach
# Stations the ramp is drawn through, and the loft between them is RULED — a straight taper
# from each station to the next, which is the only kind of loft a 2 * `flute_count`-edge
# section survives being booleaned against afterwards. So the smoothstep is a polyline, and
# what matters is how far that polyline departs from the curve: at `flute_depth` over
# `flute_rise` the worst gap is about 0.9 / steps^2 mm, which at four steps is 56 microns and
# reads across a room as bands. Twelve is 6 microns — a seventieth of the bead the wall is
# drawn with — and the kink between two facets is 6.8°, against the 60° the groove's own arc
# turns through. Past that the sections cost more than anything they buy: the skin is
# 2 * `flute_count` edges and every station is that many ruled faces again.
flute_fade_steps = 12
# How far the pitch `flute_count` lands on may sit from the coupon's, and how far off a
# groove's centre the Y seam may fall. Both are what picks one count out of the several that
# close near 5 mm; `flute-closes` and `flute-hides-seam` are where they are read.
flute_pitch_drift = 0.15
flute_seam_miss = 0.5

# Integral disposal warning on the +Y wall of back-bottom. The height is the
# actual H outline, not the font's em. Full wording: hardware/markings/README.md.
disposal_lines = (
    "CAUTION",
    "RISK OF FIRE OR EXPLOSION.",
    "DISPOSE OF PROPERLY IN",
    "ACCORDANCE WITH THE APPLICABLE",
    "FEDERAL OR LOCAL REGULATIONS.",
    "FLAMMABLE REFRIGERANT USED.",
)
disposal_font = "Helvetica"
disposal_kind = "bold"
disposal_cap_height = 6.5
disposal_raise = 0.6
disposal_embed = 0.1
disposal_line_gap = 2.5
disposal_bottom = 14.0
disposal_margin = 5.0


def flute_backed_sections():
    """Every stated section a FLUTED face stands on, as (what, mm) — what a groove is cut into,
    read by `flute-backed` against `flute_backing`.

    A SURVEY IS NOT A GATE. Every one of these was measured on the built solids, by ray sweep
    and again by boolean, and measuring is also what found the three the file did not state:
    the front face under the display facet's arris, the east bosses' bores where the corner
    round carries the surface inboard, and a port pocket running off that same tangent. The
    first two became figures of their own — `facet-arris-backed` and `east_boss_bore_end` —
    because they are computed rather than typed. This is the rest, stated so that a section
    thinned in the file goes red here instead of on the next print."""
    return (
        ("a top piece's seam lane, where the mating head laps its inner face", wall),
        ("front-top's own ±X flank", front_top_flank_t),
        ("back-top's own ±X flank", back_top_flank_t),
        ("back-top's own +Y wall", back_top_wall_t),
        ("a bottom piece's lipped side, the lip's skin carried to the slab", 2.0 * wall),
        ("the front wall", front_wall),
        ("the +Y wall inside a stated relief", wall),
        ("behind a Wago well, which bottoms on `interior_x`", wall),
        ("front-top's collet-plate lift lane", wall),
        ("the pump cartridge's lower face over its relief floor",
         pump_relief_floor - pump_cartridge_front_y),
        ("the front wall below its tangent curve", front_wall),
        # AND THE MULLION THE CONDENSER'S VENTS LEAVE, which is the one row here a SLOT sets
        # rather than a wall does. The jamb stands `reeding.pierce_width / 2` off the groove's
        # own centre, out on the half-ellipse where the groove is shallower than at its floor —
        # so a WIDER slot thickens this and only ever thins the mullion (`enclosure_assembly.check_flank_vents`).
        # The depth at an offset is the profile's and not the pitch's, every offset here being
        # well inside one groove, so this reads the same whatever `flute_count` lands on.
        ("the flank behind a vent slot's jamb",
         2.0 * wall - flute_depth * float(reeding.groove(reeding.pierce_width / 2.0))),
    )

# H2C left-nozzle build envelope; each printed HALF must fit inside this.
H2C_X, H2C_Y, H2C_Z = 325.0, 320.0, 320.0

# The machine display sits on the swept top's 30-degree plane. Tangent R12 and
# R18 curves join the front and roof; the side edges use R6. The rear edge stays square.
display_bezel_x = _interface.display_bezel_x           # bezel glass, lateral (X)
display_bezel_slope = _interface.display_bezel_slope   # bezel glass, up the slope
display_bezel_cut_x = display_bezel_x + 2.0 * fits.slip
display_bezel_cut_slope = display_bezel_slope + 2.0 * fits.slip
# The glass is the datum (centered on the facet); the PCB body sits offset behind
# it because the glass overhangs the body unevenly (up-and-left). This is the
# body's own offset from the centered glass.
display_body_offset_x = 0.5      # PCB body offset from the centered glass, lateral (+X)
display_body_offset_slope = -1.0 # PCB body offset, down-slope
display_corner_r = _interface.display_corner_r         # corner rounding, matching the display bezel
# The rounded cover sits flush in a 2 mm inset. A 1 mm TPU ring bears on the glass,
# whose face lies 3 mm below the display plane. Broad side skirts retain the cover.
display_inset_lap = _interface.display_inset_lap
display_inset_reach = _interface.display_inset_reach
display_inset_depth = _interface.display_inset_depth
display_inset_x = _interface.display_inset_x
display_inset_slope = _interface.display_inset_slope
display_facet_buffer = 2.25
display_facet_x = display_inset_x + 2 * display_facet_buffer
display_facet_slope = _swept_top.FLAT
display_facet_angle_deg = _swept_top.ANGLE
display_facet_thickness = 19.0   # facet wall depth = display envelope depth
# The housing ends at a vertical plane ahead of the funnel. Its pockets and
# retaining skirts have solid surrounds; the underside accepts removable support.
display_housing_back = 96.0
display_bezel_depth = _interface.display_bezel_depth   # bezel counterbore depth, user face
display_pcb_x = 106.0 + 2.0 * fits.slip   # PCB body through-hole, lateral (X)
display_pcb_slope = 69.0 + 2.0 * fits.slip  # PCB body through-hole, up the display slope
display_pcb_cut_through = 3.0    # extra depth past the facet back, cutting a socket collar
                                 # clean through (it overhangs the hole otherwise)
# THAT HOLE LEAVES A RIDGE, AND THE RIDGE IS CARRIED. Where the hole's up-slope end wall breaks
# out of the slab's back the two planes meet in a line `display_pcb_x` long, and BOTH face down
# off it — the bottom vertex of a wedge, inside a closed cavity, which is the one line on this
# piece a nozzle would have to lay in air. `_ridge_wall` stands under it, `pcb_ridge` is where,
# and `ridge-carried` is the reading. Its section is the thickness of a rib and nothing more:
# what it carries is one bead's start, not a load.
ridge_wall_t = 3.0               # the rib under `pcb_ridge`, measured across it
# THE RIB RUNS WALL TO WALL, so the loom that crosses it is bored through it. SIG-7 is the
# enclosure display's own run — four 22 AWG in ONE flat ribbon, in the 1/2" PET expandable braid
# `ledger/bom.md` §11 buys (`assembly/cable-assemblies.md`). AN EXPANDABLE BRAID OPENS OVER WHAT
# IS INSIDE IT AND NOTHING ELSE, and what is inside this one is a single 4P ribbon: it lies at or
# under the nominal the sleeve is bought by and never approaches the 50% ceiling that figure
# opens to. So the bore is the nominal with air all round it. Nothing here is a fit: the bore
# locates nothing, carries nothing, and the loom is dressed after it is through.
cable_sleeve_nom = 12.7          # 1/2" PET expandable braid, SIG-7's own
cable_bore_air = 1.0             # all round it, because this is a pass and not a seat
cable_bore_dia = cable_sleeve_nom + 2.0 * cable_bore_air   # [14.7 mm](CABLE_BORE)
# THE CENTRE STATION IS THE PUMP JACK: a RiteAV RJ11 keystone jack, the module the +Y wall
# holds for the umbilical, in this rib's centreline where a hand reaching up through the empty
# pump bay finds it, its receptacle boss rooted on the bay bulkhead's crown. BOTH CROSSINGS STAND
# ON +X, WHICH IS THE SIDE BOTH RUNS ARRIVE ON: SIG-7 comes forward along that flank from the
# electronics bay and passes the rib through its own bore, with solid stock between that bore and
# the receptacle's boss; the fixed J13-to-jack lead comes down the same flank, turns the corner
# and runs back west into one full-depth cable clip rooted on this rib's cavity face. Nothing on
# the removable pump cartridge is clipped to the enclosure.
display_loom_x_offset = 32.0
pump_jack_clip_edge_land = 12.0
# AND THE FLANK CARRIES THE REST OF THAT RUN. What the ridge clip guides toward +X turns the
# corner onto front-top's own +X face and runs aft to the main-board wall, so that face takes the
# same complete clip profile embedded in the section `front_top_flank_t` provides.
#
# THEY STAND IN THE Y+ HALF OF THAT FACE, WHICH IS THE HALF THAT IS CLEAR. The +X Wago tower
# stands its own engagement off `interior_x` and reaches into this face's air over its Y band,
# and the fore end of the face is a corner the lead turns rather than a run it lies along. So
# both stations are aft of the tower, on one uninterrupted stretch to the Y seam, and both take
# the clip's full run. Stated as `(y0, run)` each, in the flank's own +Y order.
flank_clip_stations = ((137.0, _cable_clip.RUN),
                       (179.0, _cable_clip.RUN))
flank_clip_embed = 1.2
display_cover_thickness = _interface.display_cover_thickness
display_cover_slip = _interface.display_cover_slip

# Funnel opening (Zone C) — one rectangular opening through the top wall
# BEHIND the display facet, cut at the placed funnel's collar: the funnel is a
# static part (../../zone-c/funnel/, its own frame) placed at
# the box's own `funnel` centre with its brim on the box top, and with_funnel
# measures the top-wall frame against it (the housing's back cut ahead, the
# ±X boss chains either side, the +Y wall of back-top behind). The collar stands on
# `funnel_front_y` and reaches aft for its capacity, so it may CROSS the Y
# seam — both halves take their share of the cut.
# Air between the funnel's collar frame and the ±X boss chains it runs beside. CHOSEN, not
# derived: the two are printed in the same piece, so this is clearance for the eye and the
# deburring tool rather than a fit.
funnel_chain_gap = 1.0
# Running air on every collar face. The funnel is a removable printed part, so its throat is
# cut to the collar plus the project's ordinary slip instead of sharing an exact B-rep face
# with the roof rib and ceiling corbels.
funnel_collar_air = fits.running
# The collar's front edge, read by `enclosure_assembly.funnel_centre`. THE FUNNEL IS WHERE THE
# USER POURS, so it stands as far forward as the top wall lets it — and what stops it is the
# BRIM rather than the throat: the flange overhangs the collar by `funnel.brim_overhang`
# and has to land on top wall, which begins at the display facet's own arris. So the figure is
# that arris, one `wall` of landing, and the overhang — 66.87 + 3 + 7 — and it stands aft of
# `housing_back_y`, which is the other plane that could have stopped it. `funnel-brim-lands`
# reads it back against the facet the box actually cuts, which is what catches it when the
# facet's own size moves.
funnel_front_y = 107.0
funnel_seat_thickness = _swept_top.FUNNEL_SEAT
ceiling_skin = _interface.ceiling_skin
ceiling_lip_drop = funnel_seat_thickness + _funnel.brim_thickness - ceiling_skin
# The top wall between the display housing's back plane and the throat, read on
# `funnel-collar-frame`. The brim's overhang lands on the housing slab at zero.
funnel_front_ledge = 0.0

# Split + boss parameters — every dimension sized to its function, nothing
# inherited from the faucet. The seam is a Y plane; the front half's full-wall
# rear lip telescopes into the back; six stations cross-pin the seam with
# M3 screws from the ±X exterior. Each boss is a pin meeting the front socket's
# insert seat and the back half's own corner web along its whole +Y
# side. The pin's inboard face is the full-thickness back flank's own face; the
# M3x10 span left inboard of that plane is the front heat-set's pilot.
split_slip = 2.0 * fits.running # diametral slide fit, plug into socket bore
# What a 45 degree lap gives up along the axis it is driven home on, so the two raked faces
# stand one `fits.running` apart where they pass.
scarf_axial = fits.running * math.sqrt(2.0)
screw_clear_dia = _interface.screw_clear_dia  # M3 shank clearance
head_cbore_dia = _interface.head_cbore_dia    # M3 SHCS head counterbore
head_cbore_depth = 4.0       # head recess depth from the ±X exterior (the head seat)
screw_len = 10.0             # M3 SHCS under-head length (M3x10), head seat → heat-set
plug_dia = screw_clear_dia + 2.0 * wall          # 9.9 — the shank + one wall each side
socket_bore_dia = plug_dia + split_slip          # 10.2 — slide fit over the plug
socket_r = socket_bore_dia / 2.0 + wall          # pod half-size: one wall around the bore
heatset_dia = _interface.heatset_dia  # ruthex M3, ⌀4.0 recommended hole either length
# BOTH LENGTHS ARE THE SAME INSERT. ruthex's M3 short and M3 differ in body length and in
# nothing else — same ⌀4.6 knurl, same ⌀4.0 hole — so a station's choice between them is a
# question about the depth ITS OWN bore has and never about its section. Where a bore is
# already deeper than the long body, the long body goes in and the pocket does not move.
#
# THE SHORT ONE IS NOT A DEFAULT HERE; it is what one family can prove it needs. The Y
# seam's pilot is `screw_len - seam_pin_shank_len` and comes out under the long body —
# lengthening it costs a longer seam screw and a wider `side_band_inset` for grip the joint's
# load case does not ask for. Every other insert on this box is the long one, the pump clamp's
# two included: the cradle spine under the bracket plane has the depth.
heatset_len = _interface.heatset_len            # the Y seam, and no other
heatset_long_len = _interface.heatset_long_len  # the condenser fingers, nameplate, display
                                                # cover and the pump clamp
heatset_depth = _interface.heatset_depth  # general M3 pilot; the Y seam derives its own below
socket_cap = wall            # one wall capping the insert's deep end
# The upper Y-seam screw axes' inset from the interior ceiling plane.
seam_screw_end_inset = 17.95

# Two handholds open through the floor, with their inner walls on the seam caps' plane.
handhold_y = 214.0
handhold_length = 80.0
handhold_height = 35.0
handhold_wall = wall
handhold_roof = 4.0 * wall
handhold_corner_r = _interface.show_edge_r
handhold_edge_r = _interface.show_edge_r
# The ±X walls' own mounting bosses — what a body hung on a side wall is fastened by. Each
# stands off the wall's INNER face and reaches inboard to the body's own mounting plane,
# bored for a ruthex M3 short from that end; the screw comes the other way, in through the
# body from the room, so nothing is driven from outside the machine.
#
# The section is the one `printed-parts/electronics/module_tray` gives every M3 board boss in
# this machine: these land on a board's own hole pattern, between its pin fields, and a boss
# that carried a whole wall around its insert would foul them.
mount_boss_dia = _interface.mount_boss_dia
# What that section keeps round its insert, which is the material any boss in this machine
# stands a heat-set in.
boss_ligament = _interface.boss_ligament
# Assembly air between a electronics-bay body's exact envelope and a corbel that has to begin
# behind it. Most corbels reach their mounting face; this is spent only where the body itself
# crosses the otherwise printable 45 degree wedge.
east_boss_corbel_clear = 1.0
# HOW FAR A BODY HAS TO STAND OFF THE WALL BEFORE A BOSS IS WORTH STANDING, and it is the ring
# the insert already needs. A stem shorter than `boss_ligament` comes out thinner in X than the
# material it is made of is in section: its D-fill corners, its 45 degree wedge and its free face
# are all under that figure, so what the slicer lays on the wall is a step and a sliver round it
# rather than a boss. Below it the WALL IS THE MOUNTING FACE — the body's screw closes the air it
# was standing in — and the insert seats in the wall's own section.
east_boss_min_stand = boss_ligament
# TWO OF A BODY'S HOLES ON ONE LINE WITHIN THIS REACH SHARE ONE BAR. The relay's pattern stands
# its two holes 13 mm apart across the board at either end; the run between such a pair is one
# flat-topped bar with two bores, on one corbel (`east_boss_pairs`, `_east_bosses`). A 66 or
# 78 mm span is a board's edge, under which its pins hang, and those holes stand on their own.
mount_bar_reach = 20.0
# Air past the screw tip at the bore's blind end, so a screw longer than the insert has
# somewhere to go rather than bottoming on printed material.
mount_bore_relief = _interface.mount_bore_relief

# --- the floor slab's posts -------------------------------------------------
#
# THE POST IS THE SLEEVE. It rises through the bore of the rubber grommet the donor's plate
# carries, and it stops just under that grommet's crown — so drawing the screw up squeezes the
# top flange by the difference and then lands on printed material. The preload and the limit on
# it are the one dimension (`enclosure_assembly.FLOOR_GROMMET_SQUEEZE`). The rubber between the
# post and the metal hole it is wrapped through is the isolator.
#
# The section is the donor's: each station carries its own diameter, struck off that bore in
# `enclosure_assembly.floor_mounts`. What the post holds is a ruthex M5, and `_floor_bosses`
# reads the two against each other every build.
floor_heatset_dia = 6.8      # ruthex M5, Ø7.0 knurl
floor_heatset_depth = 9.5

# --- the side walls' Wago wells ---------------------------------------------
#
# The ten lever nuts this machine splices in are HELD BY THE WALL. There is no tray: a
# well is printed on a wall's inner face and the lug presses into it, which is one part
# fewer, two hold-down bosses fewer, and no plate between the lug and the thing that
# locates it. A lever nut has no mounting hole of its own — it is a free splice — so a
# printed pocket is the only way it is ever held, and the wall is as good a place to
# print one as a plate is.
#
# The lug goes in BUTT-FIRST, pushed onto the wall, ports facing the room. Its
# lever-hinge axis stands on Z and its closed-body height lies along Y, so the +X row
# runs fore and aft down the flank on the narrow face — five abreast in the depth three
# would take lying the other way. The well wraps the butt half on ±Y and ±Z and is open
# inboard, where the wire half stands proud and the levers swing.
#
# The rear half of a 221's depth is blank on every face; ports and levers are all in the
# front half. So the well takes the rear half and grips all four sides of it, at every
# size — including the 221-420, whose two lever rows hinge off the faces a well would
# otherwise wrap.
wago_well_wall = 3.0        # well wall thickness
wago_well_press = fits.slip      # per-side press-fit clearance, validated on the valve trays
# A supportless well keeps this much roof at each end of its pocket. The centre opens into one
# 45° wall-rooted ramp, so each tab is a short bridge instead of the pocket's whole span.
wago_roof_tab = 2.0


def wago_stand(size="413"):
    """One lug's own axes in a side wall's frame, as `(y, z, x)` — the closed-body
    height along the row, the lever-hinge axis across it, the wire-entry axis reaching
    inboard."""
    s = _wago.SIZES[size]
    return (s["height"], s["width"], s["depth"])


def wago_engage(size="413"):
    """How far into the well the lug's butt half goes, which is how far the tower
    stands off the wall."""
    return wago_stand(size)[2] / 2.0


def wago_half(size="413"):
    """The well's outer half-extents on the wall, as `(y, z)` — the lug's own half plus
    the wall it is wrapped in and that wall's press clearance."""
    sy, sz, _sx = wago_stand(size)
    return (sy / 2.0 + wago_well_wall + wago_well_press,
            sz / 2.0 + wago_well_wall + wago_well_press)


def wago_swing(size="413"):
    """How far a lug reaches on ±Y with its levers worked — the closed body plus the
    swing off each face that hinges one. The 221-420 hinges on both."""
    sy, _sz, _sx = wago_stand(size)
    rows = _wago.SIZES[size]["rows"]
    return sy + rows * _wago.lever_swing


# What each lug in the +X row costs the flank. Wells sharing a wall face would stand
# neighbours 14.70 apart and a lever standing fully up reaches `wago_swing` — so the row is
# spaced by the LEVER and not by the wall, and a lug can be opened and re-wired where it
# sits. A row's wells stand in one tower spanning the row (`_side_wells`), the slit the
# lever's spacing would leave between two towers filled. Different connector sizes in that
# row keep their own pockets inside one common outer envelope.
wago_lever_clear = 1.0      # air past the swept lever, so its tip does not graze the next lug
wago_pitch = max(2.0 * wago_half("413")[0], wago_swing("413") + wago_lever_clear)

# --- the −X strip's MQ-6 cradle ---------------------------------------------
#
# The combustible-gas sensor lies ALONG the open strip down the −X flank, low in the
# refrigeration bay beside the compressor. R-600a is half again heavier than air: it falls
# off whichever brazed joint let it go and spreads as one layer over the slab, so what the
# sensor owes that layer is HEIGHT, and the floor of this bay is one connected pool — every
# leak site the loop has feeds it. Laid along the strip the card sits as low as a 20 mm card
# stands, which is as low as this board goes.
#
# The card carries no mounting hole, so what holds it is a SLOT ITS OWN EDGES SLIDE INTO —
# the same bargain the Wago wells strike, for the same reason. TWO POSTS STAND ON THE SLAB,
# one at each end of the card's long run, grooved on the faces they turn toward each other,
# and the card DROPS IN FROM ABOVE until it lands on the shoulder at the foot of each groove.
# The grooves hold it in X and along the strip; the shoulders hold it in height.
#
# EVERY LAYER OF THAT LANDS ON THE ONE BELOW IT. A post is rooted on the slab and on the wall
# at once — a corner bracket in one piece with both faces it stands on, first layer on the bed,
# nothing printed over air and no support to pick out of a groove. That is the whole reason the
# card lies along the strip rather than across it: a card across the strip has to be caught by
# rails reaching horizontally off the wall, and a rail reaching off a wall is a rail printed
# over nothing.
#
# The can is centred on the card and reaches within half a millimetre of each long edge, which
# is what settles the rest: only the ENDS of the long run have material clear of the can, so the
# grooves take those, and what a groove may swallow there is what the can leaves and no more.
mq6_rail_wall = 3.0         # post section around the groove, and the shoulder under the card
mq6_slot_press = fits.running       # per-side slip in the groove, the wells' own figure
mq6_grip = 5.0              # how much of the card's long run each groove swallows at its end
# The pins face EAST off the card and the loom lands on them out of the bay, so the cheek on
# that side is cut away across the header — this is what the cut leaves either side of the pin
# field.
mq6_header_relief = 2.0
# The card's own axes in the strip's frame. It lies along the strip with its plane parallel to
# the flank, so its long side runs fore-aft, its short side is the height, and the whole of what
# it spends across the strip is its own thickness.
mq6_card_x = _mq6.PCB_T     # 1.6 — the card itself, what the groove grips
mq6_card_y = _mq6.PCB_X     # 32 — the long run down the strip
mq6_card_z = _mq6.PCB_Y     # 20 — height, the card's short side
# And the can, which is the only part of the board that reaches into the flank's own section: it
# bottoms in a well cut back to `lip_face_x` (`_front_bottom_flank_skin`), so THE WALL IS STILL
# THE DATUM IN X and what stands the card off it is the can's own height. Across, the can is what
# the well opens and what the two posts stand clear of, and both read this one figure.
mq6_can_yz = _mq6.CAN_D     # 19 — the can's diameter, in the plane the well is cut on

# --- the condenser block's four flanges -------------------------------------
#
# THE BLOCK IS HELD AT ITS FOUR FLANGES AND NOWHERE ELSE. Each of its two Y faces stands back
# over the block's whole width, leaving a folded sheet at the crown and one at the base, and
# both recesses open on their own face and both flanks — so the box can reach in at either end
# of the block without reaching round it.
#
# ONE END SLIDES AND THE OTHER SCREWS. The FORE flanges carry no hole, so what takes them is a
# GROOVE: a rail off the front wall at each end, the pair of them straddling nothing but air,
# and the block goes in aft-first and forward until its fore face meets the rail's own shoulder.
# THE RAIL IS THE DATUM IN Y. In Z each groove closes over its flange with air on both faces of
# the sheet, and what stands the block off the floor is the bore under its base flange. The lower
# rail's underside is the slab, which makes it a corner bracket rather than a shelf.
#
# The AFT flanges carry the donor's own two holes, one line through both, and each takes a screw
# DOWN into a ruthex M3. So both bosses stand under the sheet their screw passes through, and
# the geometry that carries them is one fin on the +X wall with a finger reaching west off it
# into the recess at either end. The lower finger runs to the slab and is what the block's aft
# end stands on; the upper one is a finger and nothing else.
#
# THE FIN IS EAST BECAUSE THE RECESS'S OWN FLOOR IS THE BASE FLANGE. Nothing can stand on the
# slab inside that recess — the sheet is in the way at every point of it — so the column that
# reaches the crown flange has to root outside the block's own flanks, and the lane between the
# block and the +X wall is the one that is free.
cond_rail_wall = 3.0        # rail and finger section around a groove or a bore
cond_slot_grip = 3.0        # how much of a fore flange's own depth each groove swallows
cond_mount_clear = 1.0      # air off the block: the fin's own lane, and each end of the band
# Per-face running clearance at the seated end of each flange groove.
cond_slot_press = fits.running


def cond_slot_half(sheet: float) -> float:
    """The running clearance on each face of the flange sliding into the groove."""
    return cond_slot_press


def cond_slot_mouth(face: float) -> float:
    """The world Y a station's groove opens at — one millimetre past the swallowed grip, so
    the flange enters from the bay and the groove never dead-ends on its own flange span."""
    return face + cond_slot_grip + 1.0


# --- the condenser's two vents ----------------------------------------------
#
# THE VENT IS THE FLUTES, PIERCED. The block's fan draws through one flank and blows out the
# other, and both flanks already carry the reeded field — so a slot narrower than the groove is
# struck down the groove's own FLOOR, on the same centres, clean through the section under it.
# Both jambs run WITH the flute and the groove carries on past both ends of the slot at full
# depth, so nothing crosses a flute anywhere in this feature and no `_flute_stop` treatment is
# owed at any edge it makes — the skin's own rule, that a rim running with the flutes is not one
# of them. Off-normal the wall reads as unbroken reeding; head-on it is a grille.
#
# EVERY GROOVE, NOT ALTERNATE. The coupon at `c14bb2fff` printed the three schemes side by side on a
# section of this same flank at this same pitch, and the widest slot down every groove is both the
# more open of them and the thicker at its thinnest: what a slot is measured against is the MULLION
# left between two of them (`reeding.mullion`, `reeding.pierce_max`) and not the section behind the
# groove floor, and the two move OPPOSITE ways. A wider slot puts its jamb further out on the
# half-ellipse, where the groove is shallower and the wall behind it thicker.
#
# THE STATIONS ARE THE FIELD'S OWN. A slot is struck at a groove centre found by walking arc
# length (`flute_centres`, `plan_at`), not at a Y typed here, so the vent follows the field if
# `flute_count` is ever retuned and a jamb can never land off a groove's floor.
#
# IN HEIGHT THE BAND IS THE FAN, not the airway. What moves air through this wall is the axial
# fan bolted to the block's own flank; the finstack either side of it is served by whatever that
# fan pushes, and wall opened opposite it is opening on metal. So the band is the block's placed
# extent (`cond_airway`) brought in `cond_fan_rise` at the base and `cond_fan_drop` at the crown
# — the fan's own footprint on the flank and nothing wider (`vent_band`).
#
# LESS WHATEVER THE FLANK CARRIES BEHIND THAT PARTICULAR GROOVE. Nothing is listed: the piece is
# asked, groove by groove, what stands rooted on its inner face there, with `cond_vent_clear`
# round the root in Y and Z. The transoms are the opening vocabulary, so a root touching part of
# one segment leaves that whole segment as fluted wall; a lone opening beyond such a land stays
# wall as well. THE MQ-6'S CRADLE IS NOT ONE OF THE ROOTS THE INTAKE ANSWERS FOR: its two posts
# stop at the card's crown and the band starts one `cond_fan_rise` over the block's base, so the
# whole cradle stands under the vent with the clearance to spare and the lowest course runs the
# full segment across like every other.
#
# AND THE BAND IS CROSSED BY TRANSOMS, which is what makes it printable. A mullion is
# `reeding.mullion` across on a `2 * wall` wall, so a slot run the whole height of the fan leaves
# a picket fifty-odd times as tall as it is thick, with nothing tying its top to anything. The
# brace is NOT a bar between two of them: at `cond_vent_transoms` heights the wall is simply NOT
# PIERCED (`vent_transoms`), so every mullion and both jambs run into one full-section plate
# `cond_vent_transom_h` tall. Nothing bridges, nothing stands at 45° across a groove, and nothing
# grows out of a tower. The GROOVE runs through a transom unbroken — only the piercing stops —
# so the field reads continuous down the flank and a transom is invisible off-normal.
cond_vent_clear = wall       # the root the vent leaves round anything standing on the flank
cond_vent_probe = wall       # how far inboard the flank is read for what stands on it. A rail,
                             # a fin or a pod web is ROOTED on the inner face, so its first
                             # `wall` is what a slot behind it would break out of; a body
                             # standing free of that face is not the vent's to answer for
cond_vent_island_min = 2     # one opening marooned past a solid land is a nick, not a grille
cond_fan_rise = 22.0         # the fan's own bottom over the block's, measured on the block
cond_fan_drop = 5.0          # and its top under the block's crown. The two and the fan's 110 mm
                             # close on `condenser_block.FACE_B`, which is what says they are a
                             # reading of one face and not three numbers
cond_vent_transoms = 3       # unpierced bands crossing the vent, each one tying all 22 mullions
                             # and both jambs into a single plate of full section
cond_vent_transom_h = 4.0    # how tall each one stands — more than an exterior loop pair either
                             # side of the groove's own floor, so a transom is wall and not skin


# --- what holds the cold core ------------------------------------------------
#
# THE CORE HAS NO HOLE IN IT. It is a foamed cup with a screwed cap at each end and a plain
# rounded-rectangular skin the whole way round — the heaviest single body in the machine, and
# the one on the floor with nothing to bolt through. What holds it is the box shut on it: every
# quadrant is screwed to the two beside it, so a feature printed on one piece stands over a body
# sitting in another.
#
# TWO FEATURES, EACH ON THE PIECE WHOSE OWN MATERIAL REACHES THE FACE IT TAKES, and each a
# mirror pair about x = 0:
#
#   `_core_stops`  on **enclosure-front-bottom** — a block in each front corner of the slab,
#                  pocketed to the core's own plan outline: the corner round outboard of the
#                  tangent and one round of the flat front face inboard of it. The flat takes the
#                  core FORWARD and the round takes it in X and in yaw, and the pair leaves it no
#                  lateral travel.
#   `_core_holds`  on **enclosure-back-top** — a bracket standing in the `rear_seam_clear` band
#                  behind the core and turning over the aft edge of its cap. It takes the core
#                  UP: the slab is under it, so a pad on the crown stands in the way of a
#                  straight lift and of either tip, whose far end carries this pad with it.
#
# The floor takes the weight and the +Y wall the aft. `enclosure_assembly.check_core_held`
# reads all four off the built pieces and the placed core.
#
# THE CORE ENTERS THE POCKET FROM AHEAD OR FROM ABOVE. The pocket is that outline carried
# straight down, so it stands clear of the core at every stand-off and closes on it at the slip:
# the front assembly slides aft onto a core already down, or the core comes straight down into a
# box already telescoped.
#
# The fit is the diametral slide the seam's own plug takes in its socket, and it is one figure on
# the round and on the flat — one offset of one outline.
core_stop_slip = split_slip
core_stop_web = 6.0           # material ahead of that outline, at every point of the pocket
# How far the block stands off the slab. The lane in front of the core belongs to the refrigerant
# loop — both drawn legs cross it and land on the core's front face — so the block takes the depth
# of it that is empty and stops under them. A leg that came down into it is a `pack-closes` clash.
core_stop_rise = 40.0
core_hold_reach = 12.0        # how far a bracket's foot runs onto the cap off the core's aft face
core_hold_land = 8.0          # that foot's own thickness where it leaves the gusset
# How far the bracket's leg carries UP the +Y wall behind the foot, standing in the band
# `rear_seam_clear` holds open. The foot's load arrives at the wall over the leg's whole height.
#
# THE SECTION IS A TRIANGLE AND NOT AN L. One face runs from the foot's own tip to the head of
# that leg, so the corner between them is solid and the foot is a flange on a web rather than a
# cantilever. It takes no envelope the L's two arms did not already reach, and it falls
# `core_hold_reach + rear_seam_clear` in `core_hold_rise - core_hold_land` — 25° off vertical,
# which is the bracket's own UPPER face, laid on the section beneath it the whole way out.
core_hold_rise = 40.0


# THE BORE SWALLOWS THE WHOLE SCREW. Every other insert in this box is reached through a body
# that holds a share of the screw's own length; this one is reached through four tenths of sheet,
# which holds none of it. So the bore is the screw and the air past its tip, and the grip inside
# it is still the ruthex's own `heatset_depth`.
cond_screw_len = screw_len - 2.0                    # M3 × 8, the box's own shelf screw
cond_bore_depth = cond_screw_len + mount_bore_relief
# What a finger keeps under that bore: the bore itself and a wall beneath it.
cond_boss_t = cond_bore_depth + cond_rail_wall
# How far one of those bosses stands OFF the wall's inner face — which is the standoff a body
# hung on the flank gets, and every millimetre of it is insert: the bore runs the boss's whole
# length and stops on the wall's own inner face, so the wall behind is what caps its blind end.
# Nothing here is spent holding the body away from the wall. That is the point — a body bolted
# to a wall wants to be ON it, and this is the shortest column an M3 heat-set can live in.
mount_boss_out = heatset_depth + mount_bore_relief
# How far a boss stands inboard of the wall it drives through: the whole chain
# of head counterbore, pin body, heat-set and cap, less the wall the counterbore
# is sunk into. This is the socket collar's own depth off the wall.
boss_in = head_cbore_depth + screw_len + socket_cap - wall
# The band down each ±X wall IS that chain: what a floor body stands off the wall where the
# seam's bosses are, so each mouth, plug and collar seats at full section and the body seats
# flush against them. One name for the reader who is thinking about the band and one for the
# reader thinking about a single boss, and one number under both — an M3 of another length
# moves the chain and the band together.
side_band_inset = boss_in
# The telescoping overlap is NOT a free dimension. It is exactly what makes the
# back plug's −Y face mate the back mouth (y_joint) AND the front socket collar's
# +Y face mate the lip rim, with the two bosses coaxial for the cross-screw.
# With y_boss = y_joint + plug_dia/2 (plug −Y on the mouth), the collar's +Y face
# (y_boss + socket_r) lands on the rim iff lip_len = plug_dia/2 + socket_r.
lip_len = plug_dia / 2.0 + socket_r              # = (plug+bore)/2 + wall = 13.1

# The appliance's stated HEIGHT — floor slab's underside (z = −floor_t) to the top
# wall's outer face. It is the machine's silhouette, the one dimension a counter
# appliance is judged by before it is opened, and this is the number the thin machine
# is FOR. The contents live under it; `_dims` measures whether they do (`box-height`).
appliance_height = 361.0
# The stated WIDTH — ±X outer faces, struck symmetric about x = 0, which is the axis
# the whole pack is centred on. A body that leaves the floor, or a narrower one taking
# its place, does not make the machine narrower; a pack that outgrows this is a red
# `box-width`. What sets the number is the cold core standing its own `side_band_inset`
# off both walls: 181 across, 14 either side, and one wall each side of that.
appliance_width = 215.0


# WHAT A STATED BOUND IS READ TO. Each of the three is a placed body's own box against a plane,
# and that box is an OPTIMAL one — on a filleted or splined body it converges rather than closing
# exactly. The cold core is `outer_shell_y_length` = 181.0 by construction and its box reads
# 181.0000002, so it stands flush on this width and answers a finer bound by two ten-millionths
# of a millimetre. A bound struck under the reading's own precision measures the solver, not the
# machine. This is the figure the rest of this file reads a solid to.
stated_bound_tol = 1e-6


def interior_x():
    """The ±X interior faces, struck off the stated width alone. `_dims` builds the box on
    these and every body seated on a flank reads them through the same call, so the wall and
    the things that stand against it cannot come apart."""
    return (-(appliance_width / 2.0 - wall), appliance_width / 2.0 - wall)


def back_top_wall_face():
    """back-top's own interior rear plane — `back_top_wall_t` in from the exterior, where the
    box's own is one `wall` in.

    `rear_plane_y` is still the interior of the machine and every body is packed to it; this is
    the plane back-top's own +Y wall and its furniture stand on. back-bottom needs no such
    figure: its wall is the lip's own skin carried to the slab and already measures the same."""
    return rear_plane_y - (back_top_wall_t - wall)


def back_wall_t_at(x, z):
    """The section the +Y wall carries at one station — what a fitting's clamped stack is struck
    from, and the figure `enclosure_assembly.port_clamp_stack` reads it off.

    A RELIEF IS A FACT ABOUT THE WALL, not a note beside it. The CO2 station's barrel cannot take
    `back_top_wall_t`, so the wall is thinner there and this says so by measuring the same figure
    the solid is cut on rather than by naming an exception."""
    if z < z_seam:
        return 2.0 * wall              # back-bottom: the wall and its lip's own skin
    for _who, rx, rz, wx, wz in back_top_wall_reliefs:
        if abs(x - rx) <= wx / 2.0 and abs(z - rz) <= wz / 2.0:
            return wall
    return back_top_wall_t


def back_top_flank_face():
    """back-top's own ±X interior faces — `back_top_flank_t` in from the exterior, where the
    box's own is one `wall` in.

    `interior_x` is still the box's interior and every seated body is packed to it; this is the
    plane back-top's own flank furniture stands on, and the plane `_dims` reads back against the
    pack (`back-top-flank-clear`).

    THREE THINGS OUTSIDE BACK-TOP STAND ON THIS PLANE, so `back_top_flank_t` is not back-top's
    alone to move. `_rail_nominal_foot_face` takes the shallower of this and back-bottom's for
    the foot the two of them share, and the assembly datums both `SPLIT_COLUMN` and the exposed
    rib's wall root on it. Changing the section carries all three, which is why `back-top-flank-clear` reads a body's built solid
    against this face rather than the column it was placed on."""
    ix0, ix1 = interior_x()
    grown = back_top_flank_t - wall
    return (ix0 + grown, ix1 - grown)


def back_bottom_flank_face():
    """back-bottom's own ±X interior faces — `back_bottom_flank_t` in from the exterior, where
    the box's own is one `wall` in and the lip's underwall is `2 * wall`.

    NOTHING OUTSIDE THAT PIECE READS THIS. `interior_x` is still the box's interior and
    `lip_face_x` is still what a body seated low on a flank meets; this is the plane
    back-bottom's own flank stands on, and the plane `piece_root_faces` hands a feature built
    on it."""
    ix0, ix1 = interior_x()
    grown = back_bottom_flank_t - wall
    return (ix0 + grown, ix1 - grown)


def front_bottom_flank_face():
    """front-bottom's own ±X interior faces — `front_bottom_flank_t` in from the exterior.

    `lip_face_x` DOES NOT FOLLOW IT. The card that bottoms on the west flank and the copper lane
    struck off that same plane both keep the face they had, which is what makes the west side a
    well and not a move; the east side has only the condenser against it and that block reads
    this plane, so it comes west with the wall."""
    ix0, ix1 = interior_x()
    grown = front_bottom_flank_t - wall
    return (ix0 + grown, ix1 - grown)


def vent_flank_face(sx):
    """The interior face a vent slot is struck from — the plane the cut has to start at for the
    grille to come out the other side.

    IT IS THE FACE THAT IS THERE AND NOT `lip_face_x`. The airway stands in front-bottom's own
    bands, and that piece carries `front_bottom_flank_t` down both flanks where the lip's own
    underwall would leave `2 * wall` — so a slot struck on the lip's plane stops short of the
    room, and what it leaves is a blind pocket with the wall still closed behind it. Read by
    the cutter, by the run finder and by the measure, so all three agree about the same wall."""
    ix0, ix1 = front_bottom_flank_face()
    return ix1 if sx > 0.0 else ix0


def front_top_flank_face():
    """front-top's own ±X interior faces — `front_top_flank_t` in from the exterior, where the
    box's own is one `wall` in.

    `interior_x` is still the box's interior, and the bodies and the seams are all struck on it;
    this is the plane front-top's own flank furniture stands on and the plane its openings are
    cut to. All four pieces carry their own section in from it, and `_rail_nominal_foot_face`
    takes the shallower of this and front-bottom's for the foot the two of them share, so the
    front column's two sections answer to each other."""
    ix0, ix1 = interior_x()
    grown = front_top_flank_t - wall
    return (ix0 + grown, ix1 - grown)


def lip_face_x():
    """The ±X interior faces BELOW a Z seam, one `wall` inboard of `interior_x`.

    A wall a Z-seam lip stands on is `2 * wall` thick from the floor slab to the lip rim
    (`_lip_underwall`), so what a body seated low on a flank meets is this plane and not
    the other one. The MQ-6's can bottoms on it through the well cut back to it
    (`_west_cradle`), which is what stands its card off the flank in X."""
    ix0, ix1 = interior_x()
    return (ix0 + wall, ix1 - wall)


def piece_root_faces(inner, y_side, z_side):
    """The six interior planes a feature built on THIS PIECE actually roots on — `inner` with
    each face that piece carries thicker than the box's own standing where that piece puts it.

    `inner` IS THE BOX'S INTERIOR and every seated body is packed to it, which is what makes it
    the right frame for a station: a run's lane, an anchor's band and a boss's plan are all struck
    against the plane the pack stands in. IT IS NOT THE FRAME A RIB STOPS IN. Four faces on this
    box stand inboard of it on the piece that carries them — back-top's two flanks
    (`back_top_flank_face`), front-top's (`front_top_flank_face`), back-top's +Y wall
    (`back_top_wall_face`), and a bottom piece's flanks, which are the lip's own underwall
    (`lip_face_x`) — so a feature drawn to the box's plane on one of those is drawn to a plane
    that piece has already filled in.

    WHAT THAT COSTS IS THE ZIP TIE'S CHANNEL. A rib's two ends climb from the bore's crown to the
    face it roots on and the channel is the room LEFT between them (`_tube_anchors`): measured to
    a plane the wall stands inboard of, the whole of it comes out inside that wall's own stock,
    and the rib arrives buried to its crown with nowhere for a tie to pass."""
    ix0, ix1, iy0, iy1, iz0, iz1 = inner
    if z_side == "top":
        ix0, ix1 = front_top_flank_face() if y_side == "front" else back_top_flank_face()
        if y_side == "back":
            iy1 = back_top_wall_face()
    else:
        ix0, ix1 = (back_bottom_flank_face() if y_side == "back"
                    else front_bottom_flank_face())
        if y_side == "back":
            iy1 = rear_plane_y - wall      # the lip's own skin, already `2 * wall` of section
    return (ix0, ix1, iy0, iy1, iz0, iz1)
# The interior REAR PLANE — the inner face of the +Y wall, stated the same way. A
# component dragged forward inside the machine does not make the machine shallower,
# a pack that outgrows this plane reads red on `box-depth` instead of quietly resizing
# the appliance.
rear_plane_y = _interface.rear_plane_y
# --- back-top's own +Y section ------------------------------------------------
#
# THE +Y WALL IS ALREADY TWO WALLS THICK WHERE IT IS A BOTTOM PIECE. `_lip_underwall` carries
# the lip's own skin from the floor slab to the rim on all three of back-bottom's sides, so that
# wall measures `2 * wall` from the slab up. Above the rim it is back-top's, one `wall`, and this
# is what makes the two agree: one section for the whole back of the machine.
#
# IT IS TAKEN INWARD, off `rear_plane_y`, and 6 is the whole of what there is. The cold core and
# the water pump follow the rear datum, so the room behind the core is exactly
# `rear_seam_clear` — the standoff this wall was given in the first place, and which
# back-bottom already spends. A seventh millimetre is a wall drawn through the core.
back_top_wall_t = 6.0
# AND ONE STATION CANNOT AFFORD IT. What clamps a rear-wall fitting is its own bare barrel
# between flange and nut, and what that barrel spans is the wall's outer face down to whatever the
# nut lands on (`enclosure_assembly.port_clamp_stack`). The four umbilical unions offer 15.29 mm
# of barrel and do not care; the CO2 neoFit offers 7.90, and a 6 mm wall spends six of them — an
# M17 × 1.5 nut left holding 290 psi on 1.90 mm of thread. So the wall gives that one station back
# to `rear_plane_y` — the plane it is struck off — and the port field stands its whole boss on the
# section that leaves, so the nut lands on the boss with 2.90 mm of barrel under it.
#
# AND THE C14 IS THE SAME BARGAIN FOR A DIFFERENT REASON. Its receptacle bears on the fore face
# of a TUNNEL standing off this wall (`c14_tunnel_len`) and not on the wall itself, and the two
# M3 heat-sets holding it enter that fore face from inside the machine. Each one bottoms on this
# wall's inner face, so what stands over its blind end is the wall — and `socket_cap` is what an
# insert on this box is given over a blind end, which `wall` is and `back_top_wall_t` is not.
#
# THE RULE UNDER BOTH: what a fastening lands on keeps the plane it lands on. Stated as
# (station, x, z, across_x, across_z) — whose relief it is, where it stands, and the rectangle it
# takes. The name is carried because a relief that drifts off the thing it was cut for is a
# relief for nothing, and `back_wall_t_at` read at the placed station is what says whether it
# still lands on it (`enclosure_assembly.check_wall_clamped`, `_c14_tunnel`).
# AND THE COLUMN THE WHOLE C14 CHAIN HANGS ON IS ONE NAME. The receptacle's exact moulded rim
# stands under back-top's ceiling slab, which gives the rim its room over the receptacle's own
# plan (`Pack.ceiling_reliefs`); the cutout, tunnel, both screws and the wall relief below all
# read this one station.
c14_station_x = 66.9
back_top_port_row_z = 336.2105808375568
co2_axis_drop = _interface.co2_axis_drop
# THE BORE, THE POCKET AND THE SCREW PITCH ARE THE PRINT'S. The inlet's rim (`_c14.RIM_W` ×
# `_c14.RIM_H`, `_c14.RIM_PROUD` proud of its ears) bears on the pocket floor around this bore;
# the ears stand that far off the floor and the two screws hold through them. The pocket's
# outline is what the flange's width and the rim's height both clear with `c14_pocket_slip`.
c14_bore_w, c14_bore_h, c14_bore_r = 24.3, 18.3, 1.5
c14_pocket_w, c14_pocket_h = 49.77, 22.17
c14_pocket_end_chord = 17.98          # ear nose to the end of a long flat
c14_pocket_knuckle_r = 1.2
c14_screw_pitch = 40.0
c14_pocket_depth = 5.0                 # mouth to floor; the seated part's flange back lies at the mouth
c14_wall_relief_w = 2.0 * (c14_screw_pitch / 2.0 + heatset_dia / 2.0 + boss_ligament)
c14_wall_relief_h = c14_bore_h + 2.0 * back_top_wall_t
# The wall relief is the fastening field: 46.4 mm across both insert stations and the ligament
# round each bore, the tunnel block's own height, and it ends inside the block on both X sides,
# so the block roots on the relieved plane over the inserts and buries into the unrelieved
# wall beyond them. The aperture and both insert stations lie inside the relieved field and
# their cutters still run after the tunnel is fused.
back_top_wall_reliefs = (
    ("co2-inlet", 2.45, back_top_port_row_z - co2_axis_drop, 30.0, 30.0),  # the neoFit's nut across its
                                                  # corners, on
                                                  # enclosure_assembly.CO2_COLUMN (`co2-relief`)
    ("c14-inlet", c14_station_x, back_top_port_row_z,
     c14_wall_relief_w, c14_wall_relief_h),        # the bore and one
                                                  # `back_top_wall_t` over and under it
)
# THE LAND'S SKIRT RUNS TWO MILLIMETRES IN PLAN FOR THE ONE IT FALLS. A relieved port station
# keeps its whole clamped stack and gives back only the last millimetre to the nut land, down a
# drafted skirt (`_back_top_wall_relief_cut`). Two-to-one is past the lint's ligament bar — a
# 45° skirt on a one-millimetre fall is a 1.414 mm face, which is a strip — and in the print's
# frame every face of it stands steeper than the 45° floor. The roof keeps the relief's own
# `relief_chamfer` line unchanged.
station_land_draft = 2.0

# --- what stands on that relief: the C14's tunnel ------------------------------
#
# THE HOLE IN THIS WALL IS A TUNNEL AND NOT A BORE. `_c14_tunnel` wraps the cutout in material
# on the wall's inner face and the receptacle screws to the seating face at the floor of that
# block's flange pocket, so what the customer pushes the cord down is the aperture's own
# rectangle carried the whole depth of wall and tunnel together, and what stands outboard of the
# back face is nothing.
#
# THE SEAT STANDS ONE INSERT'S DEPTH OFF THE WALL. Each of the two M3 heat-sets enters the
# seating face — from inside, the way every insert on this box goes in — and bottoms on the
# wall's inner face under `socket_cap` of wall.
c14_tunnel_len = heatset_depth
# THE SECTION IT KEEPS ROUND THE BORE, and it is the section this wall already carries: the
# tunnel is the +Y wall of back-top made deep. What stands in it is the mouth a cord is pushed into a few
# thousand times, and what a millimetre of it costs is infill.
#
# ACROSS X THE INSERTS ASK FOR MORE and the tunnel gives it: each stands off the axis at its own
# station with `heatset_dia` of bore and `boss_ligament` round it, which reaches further than
# this section does. And the flange's pocket asks for more again, on both axes. `c14_mount_half`
# takes whichever is furthest per axis, so the bore keeps its own rectangle and both stations
# and the whole pocket land in material.
c14_tunnel_wall = back_top_wall_t
# --- and the pocket the receptacle's flange drops into --------------------------
#
# THE INLET LANDS IN A PROFILED POCKET AND NOT ON A FLAT FACE. The pocket's silhouette is
# `c14_pocket_profile`, the flange's width and the rim's height on one rounded/tapered wire,
# `c14_pocket_slip` off the part. Its floor is the seating face the inserts enter and the rim
# bears on; its mouth stands `c14_pocket_depth` fore of that floor, where the seated part's
# flange back lies, so the pocket locates the inlet before its screws hold it.
#
# THE TUNNEL IS ONE BLOCK WITH THAT POCKET IN IT. From the pocket's mouth to the wall the tunnel
# is one rectangle whose plan keeps at least `c14_pocket_wall` round the pocket everywhere in
# XZ, so it presents one fore plane with the flange-shaped cavity cut into it, one flank each
# side, and horizontal bed and crown planes. Its crown enters back-top's ceiling slab, which is
# the bed this piece prints on. None of this moves the part or its screws: the seating plane and
# the wall behind it are their fixed datums.
c14_pocket_slip = fits.slip
c14_pocket_wall = 3.0


def _c14_pocket_landmarks() -> dict:
    """Right-top landmarks of the pocket outline: a long flat, a knuckle round, the common
    external tangent to the ear circle, and the nose."""
    a = c14_pocket_w / 2.0 - math.sqrt(c14_pocket_end_chord ** 2 - (c14_pocket_h / 2.0) ** 2)
    h = c14_pocket_h / 2.0
    kr = c14_pocket_knuckle_r
    ear_r = (c14_pocket_w - c14_screw_pitch) / 2.0
    shoulder_center = (a, h - kr)
    ear_center = (c14_screw_pitch / 2.0, 0.0)
    dx = ear_center[0] - shoulder_center[0]
    dz = ear_center[1] - shoulder_center[1]
    span = math.hypot(dx, dz)
    if span <= abs(ear_r - kr):
        raise ValueError("the pocket's shoulder and ear rounds swallow their tangent")
    ux, uz = dx / span, dz / span
    along = (kr - ear_r) / span
    across = math.sqrt(1.0 - along * along)
    nx = along * ux + across * (-uz)
    nz = along * uz + across * ux
    q = (shoulder_center[0] + kr * nx, shoulder_center[1] + kr * nz)
    t = (ear_center[0] + ear_r * nx, ear_center[1] + ear_r * nz)
    theta = math.atan2(nz, nx)
    mid_theta = (math.pi / 2.0 + theta) / 2.0
    mid = (shoulder_center[0] + kr * math.cos(mid_theta),
           shoulder_center[1] + kr * math.sin(mid_theta))
    return {"shoulder": (a, h), "round_mid": mid, "tangent_start": q, "ear_tangent": t,
            "nose": (c14_pocket_w / 2.0, 0.0)}


def c14_pocket_profile(clearance: float = 0.0) -> cq.Sketch:
    """The pocket's outline, offset outward by `clearance`."""
    if clearance < 0.0:
        raise ValueError("pocket clearance must be non-negative")
    p = _c14_pocket_landmarks()
    a, h = p["shoulder"]
    mx, mz = p["round_mid"]
    qx, qz = p["tangent_start"]
    tx, tz = p["ear_tangent"]
    nose_x = p["nose"][0]
    sketch = (
        cq.Sketch()
        .segment((-a, h), (a, h))
        .arc((a, h), (mx, mz), (qx, qz))
        .segment((qx, qz), (tx, tz))
        .arc((tx, tz), (nose_x, 0.0), (tx, -tz))
        .segment((tx, -tz), (qx, -qz))
        .arc((qx, -qz), (mx, -mz), (a, -h))
        .segment((a, -h), (-a, -h))
        .arc((-a, -h), (-mx, -mz), (-qx, -qz))
        .segment((-qx, -qz), (-tx, -tz))
        .arc((-tx, -tz), (-nose_x, 0.0), (-tx, tz))
        .segment((-tx, tz), (-qx, qz))
        .arc((-qx, qz), (-mx, mz), (-a, h))
        .assemble()
        .reset()
    )
    if clearance:
        face = sketch._faces.Faces()[0]  # CadQuery Sketch has no public wire accessor.
        wires = face.outerWire().offset2D(clearance)
        if len(wires) != 1:
            raise ValueError(f"a {clearance:g} mm pocket offset produced {len(wires)} outlines")
        sketch = cq.Sketch().face(wires[0]).reset()
    return sketch


def c14_pocket_prism(clearance: float, y0: float, y1: float) -> cq.Workplane:
    """The pocket outline extruded from `y0` to `y1`."""
    if y1 <= y0:
        raise ValueError(f"pocket prism ends at {y1:g}, not beyond its start {y0:g}")
    from world_workplane import xz_plane_y_up
    return (cq.Workplane(xz_plane_y_up).workplane(offset=y0)
            .placeSketch(c14_pocket_profile(clearance)).extrude(y1 - y0))

# THE FLANGE ENTERS THROUGH THE FIXED +X STRIP before it reaches that pocket. Carry its exact
# slipped profile another 9 mm in Y- so the two-ear moulding can be held square and translated
# into its seat. One further millimetre is a boolean overcut past the stated running clearance,
# not assembly travel.
c14_insertion_relief = 9.0
c14_pocket_overcut = 1.0


def c14_mount_half(bore_w, bore_h, screw_reach):
    """Half extents of the tunnel block: the bore's own section, the inserts' ligaments and the
    flange pocket's wall, whichever reaches furthest on each axis."""
    pocket = c14_pocket_slip + c14_pocket_wall
    return (max(bore_w / 2.0 + c14_tunnel_wall,
                screw_reach + heatset_dia / 2.0 + boss_ligament,
                c14_pocket_w / 2.0 + pocket),
            max(bore_h / 2.0 + c14_tunnel_wall,
                c14_pocket_h / 2.0 + pocket))

# --- back-top's own ±X section ------------------------------------------------
#
# BOTH FLANKS CARRY THE SAME NINE-MILLIMETRE SECTION AS THE OTHER THREE PIECES. It is taken
# INWARD off `interior_x`, so the appliance's stated width and every exterior show face stay
# fixed. The nominal band begins past both telescopes and above the Z-seam rim
# (`_back_top_flanks`). At that seam `_z_rail_feet` carries the same section down to each
# caught face, and the back-bottom head spends the three millimetres gained past its lip wall
# on a five-millimetre overlap over that foot. The complete back joint therefore carries the
# grown section without moving an exterior face.
#
# WHAT STANDS ON A FLANK READS THE FACE THAT IS ACTUALLY THERE. Wago wells and the drip-pan
# sleeve cut their own berths through the whole section; the two fitting anchors give their zip
# tie lanes back to `interior_x`; and the +X electronics bay keeps its full insert-length boss datum
# clear of this face.
back_top_flank_t = 9.0

# --- back-bottom's own ±X section ---------------------------------------------
#
# AND THE STOREY UNDER IT CARRIES MORE, because down there nothing is in the way. The only
# body on this floor is the cold core, and it packs `side_band_inset` off `interior_x` — so
# where back-top's flank has the vent slots' mullions and the electronics bay against it, this
# one has 14 mm of air on both sides and spends 3 of it.
#
# IT IS TAKEN INWARD off `lip_face_x`, the face the lip's own underwall would otherwise leave.
# The back rail follows it: its arm stands at the grown face and its head spends the same added
# section on the overlap over back-top's foot. What the strip leaves at the rim is a step facing
# UP, on a piece that prints floor-down — the one direction a step costs nothing.
back_bottom_flank_t = 9.0


def back_seam_flank_t():
    """The common X section whose interior face both back pieces hand the Y-seam plugs.

    One plug crosses each Z seam level, so it has one inboard X face. Both pieces carrying
    that face therefore owe the same physical flank section; a mismatch is a joint with no
    plane on which the plug can finish flush."""
    if abs(back_top_flank_t - back_bottom_flank_t) > stated_bound_tol:
        raise ValueError(
            f"the Y-seam plug cannot finish on both back flanks: back-top is "
            f"{back_top_flank_t:g} mm and back-bottom is {back_bottom_flank_t:g} mm")
    return back_bottom_flank_t


# THE BACK PLUG ENDS ON THE PHYSICAL FULL-THICKNESS FLANK FACE. From either ±X exterior
# face to that plane is `back_seam_flank_t`; the head counterbore spends its depth first and
# leaves `seam_pin_shank_len` of solid registration pin under the screw shank. The remainder
# of the M3x10 span is the front socket's heat-set pilot: the complete four-millimetre insert
# plus the same one-millimetre screw-tip relief every wall-mounted M3 boss is owed. The cap's
# inboard plane therefore stays on the screw stack's own datum while the plug and its 45°
# corbel land exactly flush with the wall that roots them.
seam_pin_shank_len = back_seam_flank_t() - head_cbore_depth
seam_heatset_depth = screw_len - seam_pin_shank_len
seam_heatset_relief = seam_heatset_depth - heatset_len
if seam_pin_shank_len <= 0.0:
    raise ValueError(
        f"the {head_cbore_depth:g} mm Y-seam head seat consumes the whole "
        f"{back_seam_flank_t():g} mm back flank")
if seam_heatset_relief < mount_bore_relief - stated_bound_tol:
    raise ValueError(
        f"the Y-seam's M3x{screw_len:g} leaves a {seam_heatset_depth:g} mm heat-set pilot, "
        f"only {seam_heatset_relief:g} mm past the {heatset_len:g} mm insert; "
        f"it owes {mount_bore_relief:g} mm screw-tip relief")

# --- front-bottom's own ±X section --------------------------------------------
#
# THE FRONT PIECE CARRIES THE SAME 9 DOWN BOTH FLANKS, and neither body against them moves the
# way you would expect. The MQ-6's can bottoms on `lip_face_x` and the suction lane is struck off
# that same plane, so the WEST face cannot move without carrying the card inboard and the
# compressor east with it — the section closes ROUND the can instead
# (`_front_bottom_flank_skin` wells it off the station's own silhouette). The condenser's block
# already answers to the EAST wall
# (`enclosure_assembly.east_lane_free` stands it `cond_mount_clear` off this face), so that face
# moving carries the block west into the lane it has always had off the compressor's tangent.
#
# AND THE VENT STILL GOES CLEAN THROUGH. A slot is struck from the face that is actually there
# (`vent_flank_face`), so the grille pierces whatever this wall measures rather than a stated
# `2 * wall`; what a deeper wall costs the intake is throat, which `VENT_ASPECT` reads.
front_bottom_flank_t = 9.0
# AND IT OWES ITS ROOM TO THINGS THAT WERE ALREADY THERE. The front half's Y lip telescopes into
# this piece on this wall surface and back-bottom's Z lip rises into it on the same one, and the
# lane each rises into is exactly the `wall` this would add — so the section begins past the one
# and above the other, and neither telescope is ever asked about. The Wago wells bore from
# `interior_x` as they always did, so a lever nut bottoms where it bottomed and simply sits in a
# deeper pocket. And the ASSE drip pan's sleeve keeps its whole block: the pan withdraws through
# this flank, so what stands round it is the sleeve's own section and not this one.

# --- back-top's own ceiling ---------------------------------------------------
#
# THE REAR CEILING IS ONE SLAB, AND IT IS THE FACE THIS PIECE PRINTS ON. back-top beds on its
# ceiling's outer face (`print_up`), so the ceiling is the piece's first layers and everything
# rooted on it stands up from the bed. The box's established interior ceiling lane (`inner[5]`)
# is where every packed body, port and anchor station under the ceiling was laid out, and it does
# not move: the slab carries `back_top_ceiling_growth` of section inward from that lane, between
# the grown flanks and from the Y telescope's end to the +Y wall, and GIVES THAT SECTION BACK over
# whatever stands in it. Each pocket opens from the slab's interior face up to the lane and no
# further, so the top wall's own `wall` stands over every one of them:
#
#   * every purchased body whose placed solid enters the slab, over its exact plan plus assembly
#     slip, up to its own crown plus a clearance (`Pack.ceiling_reliefs`, struck by the pack);
#   * the flow meter's two anchors and every rib rooted on the ceiling, over the tie band
#     alone and up to the channel's roof (`_ceiling_tie_reliefs`) — the tie's own hole either
#     side of the rib, and nothing of the slab past it;
#   * the tap-water chain's shared tie channel, from the flank to the far edge of the chain's
#     own pocket over the span its two zip ties take (`_ceiling_tie_channel_relief`), so each
#     loop comes west over the chain's crown in the lane and drops into the anchor's cavity
#     through an open mouth.
back_top_ceiling_t = 12.0
back_top_ceiling_growth = back_top_ceiling_t - ceiling_skin


def back_top_ceiling_face():
    """The Z of back-top's ceiling's interior face, `back_top_ceiling_t` in from the show face —
    where the box's own lane (`inner[5]`) is one `wall` in. Every station under the ceiling is
    struck on the lane; this is the plane the slab presents between its pockets, and the plane a
    feature standing under the ceiling on this piece may rise to."""
    return appliance_height - floor_t - back_top_ceiling_t


def back_top_ceiling_stock(y_joint=None, lane=None):
    """The slab's added section, unrelieved: between back-top's own flank faces, from the Y
    telescope's end (`back_flank_start`) to back-top's own +Y face, and from the ceiling's
    interior face up one millimetre into the top wall it fuses with.

    Struck on stated figures alone (the seam `y_seam`, the lane off `appliance_height`), so the
    pack can read a body against it before any box is drawn."""
    y_joint = y_seam if y_joint is None else y_joint
    lane = (appliance_height - floor_t - ceiling_skin) if lane is None else lane
    fx0, fx1 = back_top_flank_face()
    return _ybox(fx0, fx1, back_flank_start(y_joint), back_top_wall_face(),
                 back_top_ceiling_face(), lane + 1.0)


# And the interior FRONT PLANE, holding the other end. The front wall is `front_wall` thick and
# its exterior is the pump cartridge's show plane. The flavour pack stands far enough aft that
# one full flute depth fits between that plane and the pump-pocket datum, so the removable face
# needs no step outside the fixed wall. What noses into the section gets a RELIEF, 45°-chamfered
# like every pocket on this box
# (`front_reliefs`): the compressor bay keeps the face it was packed against, and the
# pump bay roots on pocket floors struck by its own wrap rule. `box-front` reads the pack against
# the relieved surface, region by region, not one plane.
front_wall = 9.0
front_plane_y = 14.0
# One full groove depth stands ahead of the pump pocket datum so the groove floors, not their
# peaks, retain the pocket's complete printable backing.
pump_show_growth = flute_depth
# The compressor bay's reliefs: two stated pockets over what THE COMPRESSOR ALONE
# carries fore of the front wall's own interior plane — its plate's front strip and its power
# box, each floored on the face the can packs to. The shell's belly never reaches the wall,
# the condenser bears on the plane through its rails and
# the fuse clamp stands clear behind it — so the wall keeps its full `front_wall` section
# everywhere else along the front, including over and between these pockets.
#
# WHAT KEEPS THE CAN OUT HERE is the −X core stop: `_core_stops` stands a floor block
# `core_stop_web` ahead of the cold core's front face, which spends all but 0.9 mm of the room
# between the two bodies, so a can packed back to `front_plane_y` lands its aft corner in it.
# Stated as (x0, x1, z0, z1, floor).
fridge_reliefs = (
    (-71.0, 29.0, -1.0, 17.0, 11.0),   # the plate's front strip
    (-45.5, 3.5, 28.0, 77.0, 11.0),    # the power box
)
# And each pump's relief in the cradle face. Its floor follows the pump station, keeping the
# complete lower-head face section between the flute floors and the pocket.
pump_relief_skin = 3.9
pump_cartridge_front_y = front_plane_y - front_wall
pump_station_front_y = pump_cartridge_front_y + pump_show_growth
pump_relief_floor = pump_station_front_y + pump_relief_skin
relief_chamfer = _interface.relief_chamfer  # every relief ceiling rises at this angle to the mouth

# --- front-top's own ±X section ----------------------------------------------
#
# THE ONE WALL ON THIS BOX THAT IS NOT `wall`, and the only piece that carries it. front-top is
# the piece a hand works: the pump cartridge is hauled out through its face, and `_bay_cut`
# removes the complete front and flank band the cartridge owns. What is left stands 195 mm tall
# on a seam rim it prints mouth-down on; the wall aft of the collet plate and the lintel over
# the cradle keep its two flanks joined.
#
# IT IS TAKEN INWARD, and that is the whole of why nothing else on this box moves. The exterior
# is `appliance_width`, the silhouette a counter appliance is judged by, and it stands where it
# stands; `interior_x` is the plane every other piece and every seated body reads, and it stands
# where it stands too. What moves is this one piece's own inner face, and only this piece knows
# about it (`front_top_flank_face`).
#
# WHAT IT OWES, IT OWES TO THINGS THAT WERE ALREADY THERE: its main band begins at the Z-seam
# rim and its rail feet carry the same face through the storey below; the collet plate clears
# the rails' complete moving envelope; the openings are cut to the face this leaves; and the
# Wago wells bore through it to bottom on `interior_x`, so a lever nut sits where the box's own
# interior puts it and simply has more wall behind it.
front_top_flank_t = 9.0

# Where the box splits front from back, and where both columns split bottom from
# top. Both are STATED planes: which pieces the box comes apart into is a decision
# about the pieces — what each has to carry, and what a hand reaches when the front
# assembly is off — and the depth and height each piece comes to is what the plane
# leaves. `_dims` measures them against the facet, the bed, the pack and each column's
# own lip lane, and records what it reads (`y-seam-clears-facet`, `z-seam-bed`,
# `z-seam-two-pieces`, `z-seam-front-lane`, `z-seam-back-lane`, `z-seam-under-deck`).
y_seam = 200.0
# The bottom↔top seam: ONE plane, both Y columns — the seam line runs level round the box
# and the four pieces meet at a four-way corner on each side wall. The plane stands where
# its own machinery fits the pack: the seam ring's foot over the condenser's fin
# crown (`z-seam-front-lane`) and the rim under the forward valve tray's plate
# (`z-seam-under-deck`). Across the bay the ring's front segment goes to the bay floor and
# the pump heads over it (`_front_flat_lip_drop`), and the seam's own MOUTH is the plane
# that floor lies on (`bay-floor-bedded`); the pumps ride behind the pump cartridge face's own
# reliefs (`pumps-in-bay`, `enclosure_assembly.PACK_Y`) and sweep out over the floor's top
# (`heads-sweep-out`).
z_seam = 160.0

# A seam landing in an open band keeps this much air off every body in its own column,
# so a body there lands whole in one piece and its mounts have one piece to stand on.
# `_z_joints` reads each column's open bands against it for `_report_seams`.
z_joint_clear = 3.0
# The Z lip stops this short of the Y-seam overlap on each side, so the two
# telescopes never share a wall surface.
z_lip_y_margin = 2.0


def back_flank_start(y_joint):
    """The first Y plane carrying either back piece's full-thickness flank.

    Both back flanks begin past BOTH telescopes. The front half's Y lip runs to
    `y_joint + lip_len`; `z_lip_y_margin` past that rim is the first plane the closing
    front half never lands on. Back-bottom's added skin, back-top's nominal section and
    every seam feature which roots in that section all meet this one plane."""
    return y_joint + lip_len + z_lip_y_margin

# THE Z SEAMS SLIDE HOME, AND TAKE NO SCREW. Each top piece enters off the end of the box
# it stands at and slides the length of its own column — front-top fore of home over the
# front wall's own plane and aft to its stop, back-top aft of home over the rear wall's and
# fore to its own — riding a HOOKED RAIL down each ±X flank: the bottom
# piece raises an ARM on its mouth down each straight run, and the arm's HEAD steps
# outboard over the groove the top's FOOT slides in — the top's wall carried to the
# mouth at full section, with a notch above the foot that swallows the head. Lifting the
# top lands the foot's flat top face on the head's flat underside along the whole of
# both runs — horizontal printed face on horizontal printed face — so the seam is held
# closed continuously down every millimetre both flanks carry.
# The slide stops on a STOP BLOCK closing each rail's far end — the foot's end face on
# the block's, the one nominal contact in the joint and the column's Y datum — with the
# end walls and corner turns closing head-on one `slide_slip` behind it. THE TWO COLUMNS
# GO ON TOWARD EACH OTHER AND ESCAPE APART: front-top draws off the front of the box, into
# open air, and back-top off the back. What holds front-top is the Y seam's upper pair of
# screws — the plug back-top carries, in the socket front-top's lip carries. Six M3×10
# close the whole box, and the two upper ones are what front-top hangs on.
#
# THE CATCH FACES ARE SQUARE. The head's broad underside and the foot's broad top are
# the joint's bearing against lift, flat along both complete runs. The bottom pieces print
# those undersides with support. Front-top prints its foot from the mouth; back-top prints
# its foot ceiling-down with support under the caught face. The back notch closes to the wall
# on one horizontal roof, with support accepted under that broad plane; front-top alone keeps
# a 45° roof where its mouth-down print has no bed beneath the channel. The arm's base falls
# back to the lip's underwall at 45°; every sliding and bearing face remains vertical or
# horizontal.
slide_slip = fits.running       # per-face running clearance on every sliding face of a Z seam
hook_foot = 8.7              # the foot: the top's full section, mouth face to caught face
hook_lap = 2.0               # the catch overlap before a thick flank spends its added section
# Both columns spend the same three millimetres they gain past the six-millimetre lip wall on
# their catches too. Five millimetres still lie wholly over each six-millimetre foot past
# `interior_x`, leaving the fixed exterior skin untouched while both pieces answer to the same
# grown section.
front_hook_lap = hook_lap + (front_bottom_flank_t - 2.0 * wall)
back_hook_lap = hook_lap + (back_bottom_flank_t - 2.0 * wall)
# THE Z SEAM'S OWN STOREY, mouth to rim, and THE FLAVOUR DECK IS ITS CEILING: the rim
# stands under the lowest valve plate (`z-seam-under-deck`), so this is the whole height
# the box has to spend on the joint. What it buys first is the GROOVE — `hook_foot` is
# the top piece's own sliding tongue, the part of the joint a hand can break — and the
# head takes the remainder over the catch. It is a HEIGHT; `lip_len` is the Y seam's
# overlap struck off its own boss, and the two are independent figures.
z_rise = 14.8
# The arm's own section behind its sliding face. It also sets the channel's width, and
# through it the gable's ridge height: the ridge stands PROUD of the bay storey's one
# ledge plane (`rim + wall` — the seam cap's top and the sill), so the roof leaves that
# plane through a slot instead of meeting it edge-on in a zero-thickness line.
hook_arm = 4.0
rail_stop_len = 4.0          # the stop block closing each rail's far end, along Y
rail_entry = 5.0             # approach past full disengagement, entry to first engagement
rail_lead = 2.0              # 45° plan taper easing the head's open end over the foot
# HOW FAR THE RAIL REACHES BELOW ITS SEAM, the way `z_rise` is how far it reaches above. The
# arm's base falls back to the lip's underwall on a 45° under-flare, so the fall equals its own
# run: the arm's back stands `slide_slip + hook_arm` inboard of the nominal foot face and the
# underwall half a millimetre outboard of it. `_z_rail_heads` builds that fall and `_lip_denied`
# denies seam heights by it — a body's crown has to clear the flare, not merely the wall over it.
rail_flare_drop = slide_slip + hook_arm + 0.5
# The deepest plane either hooked profile reaches inboard of `interior_x`: its full nominal
# foot first, then the arm clearance and the arm itself. Both complete envelopes remain inside
# the pack's `side_band_inset`; the collet plate spends this exact figure for its moving berth.
# EITHER means the deeper of the two columns' top sections, because everything reading this
# reads it for both: the plate is held off by the deepest thing it ever passes and holds that
# offset at every height, and `_lip_denied` measures the same band down whichever column it is
# given. Taking one column's section would make the figure true of both only while they agree.
rail_reach_in = (max(front_top_flank_t, back_top_flank_t) - wall) + slide_slip + hook_arm

# --- THE PUMP BAY AND ITS PUMP CARTRIDGE ------------------------------------------
#
# THE PUMPS SLIDE OUT OF THE FRONT OF THE BOX. The front wall's flat span — corner column to
# corner column — and the large lower cradle come out of front-top as one piece, the PUMP
# CARTRIDGE. Both pumps drop into that cradle and one top clamp closes on their stamped
# brackets. The cradle's filled bearing block rides the bay floor while the fixed shell perimeter
# stays one running clearance below its exterior face. Nothing latches it: four
# barb tubes gripped in the anchor tees' branch collets are the retention, and the collet plate
# (`_tee_wall`) is the release — pull the pump cartridge and the tees
# come with it until their collets press the plate, the tubes come free, and the pumps are
# in your hand. Pushing it home threads the four tubes back through the plate's holes into
# the same collets, the cradle's own aft face landing on the plate's.
#
# FRONT-TOP CARRIES A FLOOR ACROSS THE BAY (`_bay_floor`), and everything in this storey
# slides across it. THE FLOOR IS THIS PIECE'S FIRST LAYERS — front-top beds on the seam
# plane, so a floor struck there lies on the bed with nothing under it to hang. Its top is a
# fixed bay datum, relieved downward from the pump-neutral sill independently of the pump
# station. Front-bottom's side lip is given up over this whole run (`_flank_lip_drop`), so the
# floor crosses it wall to wall and only the front boss's own plinth still stands over the
# mouth here.
#
# THE COLLET PLATE IS THE RELEASE SECTION OF ONE CONTINUOUS BULKHEAD. Its flat fore
# face meets the cartridge's flat back. Four stepped passages carry the tubes and tee
# collars, and the release shoulders remain on their own Y datum. The bulkhead joins
# the bay floor, lintel and both flanks; front-bottom supports its two lower ends.
#
# The full-width opening extends from the show face to this bulkhead. The cartridge's
# front, rounded corners and flanks share the enclosure silhouette. Its hand pockets,
# pump wells and fitted tube passages open through this one cradle; the clamp lifts
# through the same straight upper wells after its two screws are removed.
bay_crown_air = 1.7          # neutral pump datum to the nominal bay roof
pump_bay_floor_relief = 2.6  # continuous sill clears the scanned rigid head-front rim
pump_bay_roof_relief = 2.5   # lintel underside above its neutral pump-derived datum
pump_relief_z_air = 1.0      # pump pocket past each head/collar end
pump_cartridge_z_clearance = fits.running  # Z air at the fixed sill and on the pump clamp; this
                                  # is not an X/Y inset or a cosmetic surface offset
pump_cartridge_top_clearance = fits.running  # the removable face's crown below the fixed lintel
pump_bay_side_air = fits.running      # pump-body air inside each cavity throat plane
# THE LOWER CRADLE HAS ONE RECTANGULAR Z OUTLINE. The exterior shell reaches the appliance's
# complete plan silhouette and its filled body reaches both cavity planes without a side taper.
# The monolithic clamp remains inside the cradle's two vertical wells throughout insertion and
# withdrawal.
cap_kiss = fits.running               # preferred plate air, cradle and clamp alike
cap_kiss_station_allowance = 0.01      # one least-significant place of the measured 30.11 mm skirt datum
# Front-bottom's two bearing lands under the pump-bay bulkhead.
plate_foot_reach = 10.0
plate_foot_y = 20.0
plate_foot_t = 3.0
plate_foot_corbel_angle = 45.0


# --- THE PUMP CARTRIDGE IS ONE CRADLE AND ONE TOP CLAMP ---------------------
#
# THE LOWER CRADLE IS THE CARTRIDGE. It owns the complete front face, the full-height block
# behind it, both bracket lands and both hand pulls. Each pump drops through
# its open well until the molded flange at the head-to-boss junction lands on the cradle.
# Nothing under the head carries it; the head clears the bay floor and the bracket puts the
# load into the block around the well.
#
# THE TOP CAP IS A CLAMP. One filled field spans both pump heads, begins on the stamped
# brackets' upper face and reaches its pump-carried crown over the cartridge's complete
# fore/aft depth, ending on the same flat back the cradle ends on. The complete boss octagons
# and motor cans are cut from that field, leaving the case-derived locating walls and pressing
# lands wherever the pumps allow material, and nothing else is cut from it: the field stays
# full. Two M3×60 run DOWN from counterbores in the crown through the whole field into long
# heat-sets in the cradle spine, so the cap captures both brackets without becoming a second
# thing the hand pulls on. The screw is as long as the field is tall.
#
# BOTH PARTS INSTALL IN Z. With the clamp off, the molded flange, head and two tube-side
# fittings have straight open paths from the top of the cradle to their seats. The clamp
# follows the same path over the cans. Its plate footprint
# is therefore the well above the bracket plane; below that plane the smaller head room leaves
# the bracket's three closed sides standing on material.
cap_pump_air = 0.4                    # fitted case-profile air in the cradle's lower well
cap_boss_air = fits.running  # per-face insertion air around each octagonal pump boss
cap_slot_half = _tray.outlet_open_half
cap_fitting_half = _tray.shaft_w / 2.0
cap_screw_len = 60.0         # M3 SHCS under-head length (M3x60), crown seat → cradle insert
cap_heatset_len = heatset_long_len  # RX-M3x5.7 in the cradle spine, which has the depth for it
cap_head_h = 3.0             # DIN 912 M3 head, nominal: the least crown a seat keeps over it
cap_screw_off = 18.0         # the two screws fore/aft of the centre lane's mid-depth
clamp_lane_overlap = 2.0     # the cradle's centre clearance into each upper well, so the lane
                             # and the two wells read as one opening for the clamp's spine
clamp_drop_air = fits.running  # clamp footprint and bracket air through the cradle well
clamp_pump_y_shift = _tray.rear_axis_y_shift  # rear-stack openings off the head/cradle datum
# Broad underside and fitted boss/can openings of the physically accepted cap.
cap_bridge_rise = 2.0
cap_terminal_opening_r = 22.5  # open crown around each motor end and its terminal pair
cap_lift_clearance = 0.25      # extra sampled travel below the nominal cap position

# --- THE HAND PULLS ONLY THE LOWER CRADLE -----------------------------------
#
# Each pull is a rounded pocket in an exposed ±X flank, with mirrored edge margins
# and an additional supported-roof allowance.
# Both pockets are centred on the cradle's Y run. Their aft faces carry insertion and their
# fore faces carry extraction.
pull_depth = 18.0            # fingertip reach inboard from each exposed flank
pull_run = 28.0              # fore/aft clear opening between the pulling and pushing ledges
pull_floor_below_tubes = 12.0
pull_corner_r = handhold_corner_r
pull_edge_r = handhold_edge_r


# The whole description of one box — what `build_pieces` cuts the four pieces from: the pack it
# stands around, and the figures the shell measures for itself once it knows what is inside.
#   pack          the placed bodies and every station they put on a wall, as `Pack` states them
#   inner/outer   the cavity and the shell, (x0, x1, y0, y1, z0, z1)
#   y_joint       the front↔back seam plane
#   splits        the bottom↔top seam height per Y column, (front, back)
#   y_bosses      the placement-cleared Y-seam fasteners, one
#                 (inner_x, outer_x, inboard_sign, z) per screw. These are measured while the
#                 placed solids are present and carried on the Box; rebuilding them later from
#                 module state would make a serialized Box a different machine.
#   z_seam_passes whether each (front, back) Z seam crosses its column rather than an open band;
#                 a report reading taken with the placed solids, carried for the same reason
#   column_reliefs what the standing corners' PILLARS give up to the pack standing in them, one
#                 (sx, sy, name, room) per body — the corner's own signs, whose body it is, and
#                 the world box the column is cut back to, as the six plain bounds
#                 `(x0, x1, y0, y1, z0, z1)` every station on the pack is written in.
#                 A STATION IS NUMBERS: `_facts` serialises this whole Box for the eight doc
#                 drivers that read it, and `build_piece` strikes the box where it cuts.
#                 Struck by `_dims` off the placed parts rather than passed in by the pack,
#                 because it is the one question that needs the bodies AND the walls at once;
#                 main() prints each.
#
#                 A COLUMN GIVES WAY TO A BODY AND NOT THE OTHER WAY ROUND. It is a print-corner
#                 feature — what it buys is a fat vertical on the bed, and it buys that over the
#                 height it does have. A body hung on a wall answers to the boss that holds it
#                 and to whatever the pack packed it against, and by the time one reaches a
#                 corner both of those are already spent.
#   pump_bay      the pump cartridge's opening in the flat front span, (x0, x1, z_top) —
#                 side-wall interior plane to side-wall interior plane, topped at the fixed
#                 relieved lintel datum over the pumps.
#                 None when the pack stands no pumps
# The two structured fields placement strikes for this description. They live with Box rather
# than with the placement pass so a serialized Box can be restored without importing the whole
# machine that produced it.
PortField = namedtuple("PortField", "proud rim pockets")
from _nameplate_interface import Nameplate
import _nameplate_interface as _nameplate_fit


Box = namedtuple(
    "Box", "pack inner outer y_joint splits y_bosses z_seam_passes column_reliefs pump_bay")


def documented(box):
    """The Box as `_box_spec` writes and reads it: its pack's stations without the placed solids.

    A station is numbers and a body is not, so the description a producer hands another action
    carries the walls and not the bodies that sized them. Both sides of a comparison between a
    freshly derived box and a restored one take this form, because the restored one has no
    solids to compare against."""
    return box._replace(pack=box.pack._replace(placed={}))

# What a box is built AROUND: the placed bodies, and every station they put on a wall.
# A pack that does not carry a subsystem yet carries no stations for it, and the wall
# comes out blank there rather than carrying a hole with nothing behind it. A Box stands
# one of these and reads its stations through it.
#   placed        {name: (solid, colour)} — the same shape a CadQuery assembly reads
#   front_ports   / back_ports   wall through-holes, in the pack's format
#   east_ports    +X side-wall through-holes, (kind, y, z, *size)
#   west_ports    −X side-wall through-holes, same shape — the ASSE drip pan's slot
#   funnel        the placed funnel's plan centre, or None for no throat
#   pan_sleeve    the ASSE drip pan's carry, `(adds, cuts)` of world boxes — the solid block fused
#                 onto the −X wall, and the berth cut back out of it
#   c14           the mains inlet's heat-set stations on the +Y wall of back-top, (x, z)
#   east_bosses   the +X wall's mounting bosses, (y, z, the plane the boss top reaches, the
#                 X plane its underside corbel reaches, optional clear Y bands where it reaches
#                 the mounting plane after all). The X planes normally agree. A body crossing
#                 only part of the candidate wedge holds that part back by
#                 `east_boss_corbel_clear`; the clear bands keep their wall-rooted corbel all
#                 the way to the body, and the D-shaped stem still reaches the whole hole
#   east_mount_fills  individually reviewed rectangular unions in that mounting field, each
#                 `(name, (x0, x1, y0, y1, z0, z1), replaced_corbels)`. A replacement station
#                 keeps its D stem and bore; the box replaces only its ordinary wedge
#   side_wells    the side walls' Wago wells, (side, y, z, size, clear_z, supportless_roof) —
#                 one press-fit pocket per lever nut, on the flank its own cluster stands on
#   floor_bosses  the floor slab's mounting bosses, (x, y, the plane the boss top reaches, the
#                 section the donor's own bore leaves the post standing in it)
#   west_cradle   the −X strip's MQ-6 card slot, (x, y, z) — the card's own mid-plane, and its
#                 centre along the strip and in height. The can's silhouette is read off the
#                 reference module round that centre, and is what the flank wells
#   cond_cradle   the front wall's condenser rails, one (face, x0, x1, fz0, fz1, root) per fore
#                 flange — the plane the block's fore face rests on, that flange's width, its
#                 two faces in height, and how far the rail runs down under it
#   cond_mount    the condenser's aft mount, (flank, y0, y1, bosses) — the fin's own west face,
#                 the Y band it stands in, and one (x, y, the flange face it reaches) per hole
#   cond_airway   the condenser's own airway, (y0, y1, z0, z1) — the finstack's footprint on
#                 either flank, which is the band the ±X vents are pierced over. The recesses
#                 at each Y end are not in it: they are the sheet the box holds the block by
#                 and the fan draws through neither
#   asse_cradle   the −X wall's tap-water cradle, (axis_z, sections, ties, reach_down) — the
#                 axis the ASSE anchor is struck on, one (y0, y1, apex_x) per section of the chain,
#                 the Y of each tie band, and how far under the axis its flanks run
#   flow_meter_anchors  the top wall's two flow-meter anchors, (axis_x, axis_z, seat_r, bands) —
#                 the arm axis the Vs are struck on, the barrel they seat, and the run of
#                 each arm one takes
#   tube_anchors  the runs' own seats, one (mid, along, root, seat_r, stand) each — the middle
#                 of the leg, its direction, root face, bore radius and the two end-web
#                 treatments selected against the placed pack
#   ceiling_reliefs  named body pockets in back-top's ceiling slab, one
#                 `(name, x0, x1, y0, y1, pocket_top_z)` each. Ordinary entries cut that box.
#                 `c14-inlet` cuts its canonical flange profile over the entry's Y span; its XZ
#                 numbers are the resulting cut's bounds. Geometry struck by the pack, not
#                 another placement.
#   flank_reliefs  named clearance pockets in back-top's west flank, one
#                 `(name, x0, x1, y0, y1, z0, z1)` from the intruding body. The pocket
#                 keeps the nominal wall; its print-down edge has a 45-degree return.
#   front_flank_reliefs  the same world-box fields for the two outer valve-coil
#                 yokes in front-top, with a 45-degree roof in its +Z print direction.
#   port_field    the pockets the +Y wall of back-top's outer face carries and the nut lands
#                 behind them, (proud, rim, pockets) — how deep a pocket is cut and how far a
#                 relieved station's retained land stands inboard, the wall the field keeps
#                 around each chip (`enclosure_assembly.PORT_FIELD_WEB` reads it), and one
#                 (x, z, width, rise) per pocket. A pocket is a D on its back: a half circle
#                 below the bore's axis and a rectangle above it, so it takes its chip one way
#                 up and no other. A station's relief bottoms one `proud` short of the wall it
#                 gives back (`_back_top_wall_relief_cut`), so the wall keeps its whole
#                 thickness under every chip
#   nameplate     the plate's own pocket on that same face, and the two screw bosses behind it —
#                 its station and outline, the two stations on it, and everything one screw
#                 costs the wall: the pad's pocket, the collar round it, the stem under that and
#                 the insert's bore through both
#   valve_trays   the flavour manifold's decks, one (plane, sign, seats) each — the world Y a
#                 deck's valves stand their mounting faces on, which way their own +Z runs off
#                 it, and one (x, z) per valve. A valve tray is a plate wall to wall carrying one
#                 four-boss `valve_seat` per valve (`valve_tray`), and it is this piece's own
#                 material the way the ASSE anchor and the flow-meter anchors are
#   pump_trays    the flavour manifold's two pump stations, one world `centre` each — the point
#                 a pump's own axis meets the +Z face of its head. The legacy field name is kept
#                 at the assembly boundary; the lower cradle and top clamp are built from these
#                 stations and from `pump_tray`'s case-derived collar section
#   core_stops    the cold core's two front corners, one (cx, cy, r, tip) each — the centre and
#                 radius of the core's own corner round, and the plane the block over it reaches
#   core_holds    the cold core's two hold-downs, one (x0, x1, aft, crown) each — the lane on the
#                 cap a bracket stands in, the core's aft face, and the plane its cap presents
#   vent_chase    the cold core's PRV relief line, one (x, y, z) — the core's west flank, which
#                 the chase's lip lands on, and the tube's own axis where it comes through
#   collet_plate  the integral printed release face, as the dict
#                 `enclosure_assembly.collet_plate_spec` strikes off the four anchor tees'
#                 branch collets: its two Y faces, its Z band, its X ends, and one (x, z)
#                 per hole. Its release shoulder is cut into the bay bulkhead.
#   tee_carrier   the moving four-tee mechanism and filled fixed body: motion/assembly cavities,
#                 web and handhold guides, release/park stops, spring pockets and tie sites
Pack = namedtuple(
    "Pack", "placed front_ports back_ports east_ports west_ports funnel pan_sleeve c14 "
            "east_bosses east_mount_fills side_wells floor_bosses west_cradle cond_cradle cond_mount "
            "cond_airway asse_cradle flow_meter_anchors tube_anchors ceiling_reliefs "
            "flank_reliefs port_field nameplate keystone "
            "valve_trays pump_trays core_stops core_holds vent_chase collet_plate tee_carrier "
            "front_flank_reliefs")
Pack.__new__.__defaults__ = (
    (),             # front_ports
    (),             # back_ports
    (),             # east_ports
    (),             # west_ports
    None,           # funnel
    (),             # pan_sleeve
    ((), ()),       # c14
    (),             # east_bosses
    (),             # east_mount_fills
    (),             # side_wells
    (),             # floor_bosses
    (),             # west_cradle
    (),             # cond_cradle
    (),             # cond_mount
    None,           # cond_airway
    (),             # asse_cradle
    (),             # flow_meter_anchors
    (),             # tube_anchors
    (),             # ceiling_reliefs
    (),             # flank_reliefs
    (),             # port_field
    None,           # nameplate
    None,           # keystone
    (),             # valve_trays
    (),             # pump_trays
    (),             # core_stops
    (),             # core_holds
    (),             # vent_chase
    None,           # collet_plate
    None,           # tee_carrier
    (),             # front_flank_reliefs
)


# --- the bounds this box states ---------------------------------------------
#
# Width, depth and height are BOUNDS the appliance states, and the seams and the funnel throat
# are cut on frames the pack has to leave open. Every one is measured against the placed
# contents at each build, so a pack that grows opens one.
#
# A VIOLATED BOUND IS A THING TO LOOK AT, and what a reader looks at is the STEP, the three
# elevations and the scorecard a run writes. So none of these stops the build: each hands back
# a `Bound` whether it holds or not, and THE BOX COMES OUT AT ITS STATED SIZE — too small for
# the pack that overran it. The overrun is then a red row on the card carrying this module's
# own message, and the walls standing through the bodies that overran them are clashes in
# `pack-closes`, which is where a reader should see them. A box quietly grown to fit would
# show neither.
#
# `enclosure_assembly.machine` and `enclosure_assembly.build_enclosure_assembly` carry these
# onto the assembly beside the bounds that module states itself. The ledger lives here
# because `enclosure` cannot import that module back — `machine_of` imports it inside the
# call for the same reason.
Bound = namedtuple("Bound", "id label ok value target detail")

BOUNDS: list = []


def record_bound(bound: Bound) -> Bound:
    """Enter one bound's reading in the ledger, replacing any of the same id."""
    BOUNDS[:] = [b for b in BOUNDS if b.id != bound.id] + [bound]
    return bound


# --- primitives -------------------------------------------------------------

def _ybox(x0, x1, y0, y1, z0, z1):
    return (
        cq.Workplane("XY")
        .box(x1 - x0, y1 - y0, z1 - z0, centered=False)
        .translate((x0, y0, z0))
        .val()
    )


def _supported_cut(cutter, up=1.0):
    """A cavity with extra room at its supported face, along the piece's build direction."""
    return cutter.fuse(cutter.translate((0.0, 0.0, up * fits.supported_surface)))


def _xcyl(r, y, z, x0, x1):
    """Cylinder of radius r along X from x0 to x1, axis at (y, z)."""
    return cq.Solid.makeCylinder(r, abs(x1 - x0), cq.Vector(min(x0, x1), y, z), cq.Vector(1, 0, 0))


def _ycyl(r, x, z, y0, y1):
    """Cylinder of radius r along Y from y0 to y1, axis at (x, z)."""
    return cq.Solid.makeCylinder(r, abs(y1 - y0), cq.Vector(x, min(y0, y1), z), cq.Vector(0, 1, 0))


def _zcyl(r, x, y, z0, z1):
    """Cylinder of radius r along Z from z0 to z1, axis at (x, y)."""
    return cq.Solid.makeCylinder(r, abs(z1 - z0), cq.Vector(x, y, min(z0, z1)), cq.Vector(0, 0, 1))


def _ring(section):
    """A section's own points with the first repeated, so the closing edge is DRAWN.

    `Workplane.close()` does not draw it — it reads the last edge's end back off OCCT, which
    hands it back rebuilt as origin + t·direction, a few 1e-16 from the point that was passed
    in, and lays the closing edge from there. The wire's first vertex then stands that far off
    the station the section states. A tangential boolean downstream — the teardrop roofs on
    their sleeve bore are one — resolves a coordinate that near zero either by inheriting the
    constructed vertex or by recomputing the intersection, and which it does moves between
    processes: the same source writes one of two files, and the artifact pointer file ping-pongs
    between two hashes with nothing in the tree changed. Naming the closing point leaves the
    vertex exactly where the section put it, and the tie is not there to take."""
    pts = list(section)
    return pts if pts[0] == pts[-1] else pts + [pts[0]]


def _yz_prism(x0, x1, section):
    """A prism along X from x0 to x1, whose `section` is a closed `(y, z)` polygon.

    `_ybox` with one of its four section corners free. The `YZ` workplane's own axes are the
    world's Y and Z, so the points are read in the frame every station is stated in."""
    return (
        cq.Workplane("YZ", origin=(min(x0, x1), 0.0, 0.0))
        .polyline(_ring(section)).wire()
        .extrude(abs(x1 - x0))
        .val()
    )


def _xz_prism(y0, y1, section):
    """A prism along Y from y0 to y1, whose `section` is a closed `(x, z)` polygon.

    `_yz_prism` turned a quarter. The `XZ` workplane faces −Y, so the extrusion is taken back
    the other way and the prism set down at y0 — and its axes are the world's X and Z, which
    is the plane a feature on a ±X wall is drawn in."""
    return (
        cq.Workplane("XZ")
        .polyline(_ring(section)).wire()
        .extrude(-(y1 - y0))
        .val()
        .translate((0.0, y0, 0.0))
    )


def _xy_prism(z0, z1, section):
    """A prism along Z from z0 to z1, whose `section` is a closed `(x, y)` polygon.

    The third of the trio, and the one a feature drawn IN PLAN wants — a wall raked about a
    standing vertical is one line in this section and a fitted surface in either other."""
    return (
        cq.Workplane("XY")
        .polyline(_ring(section)).wire()
        .extrude(abs(z1 - z0))
        .val()
        .translate((0.0, 0.0, min(z0, z1)))
    )


def _round_z(solid, r):
    """Round a box solid's four standing-vertical (Z) corner edges by r — the
    print-bed corner relief, about the Z axis the pieces print along. r <= 0
    leaves the corners square (an inset radius can shrink past nothing).

    Each quadrant owns only two of the box's four vertical arrises; its other
    two are the Y-seam, a telescoping mating face with no exterior corner to
    relieve. Rounding the whole box here and letting the Y-split hand each
    piece its share gives front pieces their front-left/right verticals, back
    pieces their back-left/right, and leaves the seam square by construction."""
    if r <= 0:
        return solid
    return cq.Workplane(obj=solid).edges("|Z").fillet(r).val()


def _column_arc(inner, sx, sy):
    """The centre one corner column's face arc is swung from — the INTERIOR CORNER.

    THE COLUMN IS THE RELIEF'S CONGRUENT TWIN. The relief outside is a QUARTER TURN of
    `corner_round` tangent to both outer faces; a mirror is congruent or it is not a mirror,
    so the face is a quarter turn of the same radius — same arc, same length — and the only
    place such a turn fits inside the cavity with its ends on the two inner faces is swung
    from the corner they meet at."""
    ix0, ix1, iy0, iy1, _iz0, _iz1 = inner
    return (ix0 if sx < 0 else ix1), (iy0 if sy < 0 else iy1)


def _corner_column(inner, sx, sy, grow, z):
    """One corner column as a solid over the height span `z`, grown `grow` into the room.

    THE ARC IS THE WHOLE OF IT AND THE CORNER BEHIND IT IS SOLID. The column is everything
    within `column_round` of the interior corner; `_cavity` takes the difference, so what
    becomes material is that disc's share of the AIR and the wall keeps the rest. Nothing
    stands between the column and the cove it rises out of — a second arc back there would
    be a through slot the column's whole height, and its only free surface is the face.

    Growing swells the disc, which is the offset read on that one surface."""
    px, py = _column_arc(inner, sx, sy)
    z0, z1 = z
    return _zcyl(column_round + grow, px, py, z0, z1)


def _column_pillar(inner, sx, sy, zj):
    """One column AND the lip's own skin where it wraps it — the whole of what a body meets
    at a standing vertical, and the whole of what gives way to one.

    The lip and the wall under it are struck as the cavity's skin (`_lip_band`), so at a
    vertical they do not stop at the column: they WRAP its face and stand one `wall` further
    inboard than the pillar does, floor slab to rim. A body reaching into a corner meets that
    wrap before it meets the column, and a relief measured on the column alone is a relief
    that leaves the thing actually in the way standing.

    `zj` is that Y column's own seam, so the wrap ends where its lip's rim does. Above it the
    pillar is the column and nothing else."""
    z = (inner[4] - 1.0, inner[5] + 1.0)
    post = _corner_column(inner, sx, sy, 0.0, z)
    wrap = _lip_band(inner, (inner[4], zj + z_rise)).intersect(
        _corner_column(inner, sx, sy, wall, z))
    return post.fuse(wrap)


def _column_along():
    """How far along a wall's INNER face a column reaches, from the interior corner.

    Its CUSP stands on that face at one radius — where the quarter turn lands — and the lens
    closes back toward the corner from there, so a body anywhere on that wall meets the cusp
    and nothing of the column is further along than it."""
    return column_round


def wall_flat_from_corner():
    """How far in from a standing vertical a wall's inner face is FLAT — what anything
    BEARING on that face has to stand clear of.

    The relief rolls the face away `corner_round - wall` from each corner. Where that corner
    carries a COLUMN the flat ends sooner still: the lens's cusp stands on this face and the
    section closes back toward the corner from there, so a flange carried past it bears on
    curve either way. Struck across every corner rather than one, the way `wall_band_corner_y`
    is, because the ±X walls answer as a pair and a body reads the fence before it knows which
    end it is at."""
    flat = corner_round - wall
    return max(flat, _column_along()) if column_corners else flat


def _column_depth():
    """How far a column reaches out of the cove it rises from, across the corner's diagonal.

    The face stands one radius off the corner there; the cove the wall already turned stands
    `(corner_round - wall) * (sqrt2 - 1)` off it, and the column is everything between."""
    return column_round - (corner_round - wall) * (math.sqrt(2.0) - 1.0)


def _cavity(inner, inset=0.0, z=None):
    """The box's AIR at `inset` in from every interior face — the rounded cavity less the
    columns standing in its corners.

    Everything that has to stand inside the cavity is held inside this, so a collar or a
    lip segment meets a column exactly the way it meets a wall. The wall rounds shrink with
    the inset (square once one reaches zero) and the columns grow by it: one offset, read
    from the two sides of the same surface."""
    ix0, ix1, iy0, iy1, iz0, iz1 = inner
    z0, z1 = (iz0, iz1) if z is None else z
    air = _round_z(_ybox(ix0 + inset, ix1 - inset, iy0 + inset, iy1 - inset, z0, z1),
                   corner_round - wall - inset)
    for sx, sy in column_corners:
        air = air.cut(_corner_column(inner, sx, sy, inset, (z0 - 1.0, z1 + 1.0)))
    return air


# --- box dimensions, driven by the placed contents -------------------------

# What stands in each ±X wall's Y-seam corner, measured — not tabulated — so it
# follows the contents instead of drifting from them. Filled by _dims() (the one
# function that reads the placed parts), keyed by the footprint and depth probed,
# and read by `_level_clear` to ask whether one particular height is usable. A
# wall with nothing in the way gets no entry, and `_level_clear` reads that absence as
# "nothing known to be in the way".
#
# THE MODULE STATE HERE IS ONE COPY'S, which is what the `__main__` guard's alias at the foot
# of this file is for: `_dims` fills this dict and `_level_clear` reads it, and a run that
# exported the pieces out of a second copy of this module would read an empty one. What a
# measurement wants instead is the `Box`, which is struck once and passed to whatever builds
# from it — `Box.column_reliefs` is a measurement for that reason and not a dict here.
_wall_block = {}

# Air round a body where a column is cut back for it, per side. The pocket is struck on the
# body's own BOX and not its solid: what stands in a column is a body's corner, a corner is
# what a hand has to get past, and a pocket that hugged a casting's every feature would be a
# pocket nothing could be lowered into.
column_relief_slip = 1.0


def _cradle_relief(room, station):
    """One corner pocket a cradle rail crosses, floored on the rail's own groove.

    THE GROOVE OWNS THE FLOOR TO ITS MOUTH. Fore of the mouth this holds the station's exact
    grip datum — a box cut to the pocket's insertion floor there hangs the groove floor as a
    shelf over 0.7 mm of pocket air at every plane the two cutters cross. From the mouth the
    floor falls 1:1 to the insertion floor and runs out on it: one floor from seated stop to
    aft reach, and the groove's fit figures never retyped."""
    x0, x1, y0, y1, z0, z1 = room
    face, _cx0, _cx1, fz0, fz1, _root = station
    grip = fz0 - cond_slot_half(fz1 - fz0)
    mouth = cond_slot_mouth(face)
    return _yz_prism(x0, x1, [(y0, grip), (mouth, grip), (mouth + (grip - z0), z0),
                              (y1, z0), (y1, z1), (y0, z1)])


def _column_relief(inner, sx, sy, room, zj, cradle=()):
    """One column's pocket for the body standing in it. Clipped to the PILLAR — the column and
    the lip's skin wrapping it (`_column_pillar`) — so what a pocket can ever take is that and
    never the wall behind it or the boss beside it.

    A pocket a cradle rail crosses is floored by that rail's groove to the groove's mouth and
    by its own insertion floor aft of it (`_cradle_relief`): the room was measured round the
    flange the groove takes, so the station whose face is the room's own fore plane, whose
    flange stands inside the room's height, and whose rail crosses the room's width is the one
    that owns the fore floor. Every other pocket is its box."""
    x0, x1, y0, y1, z0, z1 = room
    crossed = [s for s in cradle
               if abs(s[0] - y0) < 1e-6 and z0 < s[3] and s[4] < z1
               and s[1] < x1 and x0 < s[2]]
    body = _cradle_relief(room, crossed[0]) if crossed else _ybox(*room)
    return body.intersect(_column_pillar(inner, sx, sy, zj))


def _column_relief_rise(inner, sx, sy, room, zj, up=1.0):
    """The walk one pocket's PRINT-UP FACE takes into the column beyond it — its ceiling where
    the piece's print up is the box's +Z (`up` = +1), its floor where it is −Z (`up` = −1) —
    and the piece that decides how much of it survives.

    A POCKET IS A BITE OUT OF A CORNER, and the corner is where its material is: the two faces
    toward it have column under them the whole height, and the two away from it open on the
    cavity. Cut flat, that face is a shelf hanging off the corner. Walked in off both HELD
    faces at `relief_chamfer` it stands one millimetre further up the build axis for every
    millimetre it reaches away from one, and the column closes back over the pocket a layer at
    a time. Its height is the pocket's own plan: at `min(width, depth)` the two walks have met.

    IT IS CUT BEFORE THE PIECE FUSES ANYTHING AND AGAIN WITH THE POCKET AFTER EVERYTHING. The
    first cut walks the shell itself; the second walks any rail or boss that subsequently grew
    over that same air. This makes the final face a question about the finished piece rather
    than a figure a row carries, and prevents an overlapping feature from restoring a short flat
    roof over the pocket."""
    x0, x1, y0, y1, z0, z1 = room
    held_x, free_x = (x1, x0) if sx > 0 else (x0, x1)
    held_y, free_y = (y1, y0) if sy > 0 else (y0, y1)
    lid = z1 if up > 0 else z0                # the pocket face on its print-up side
    wx, wy = up * abs(x1 - x0), up * abs(y1 - y0)
    return (_xz_prism(y0, y1, [(free_x, lid), (held_x, lid), (free_x, lid + wx)])
            .intersect(_yz_prism(x0, x1, [(free_y, lid), (held_y, lid), (free_y, lid + wy)]))
            .intersect(_column_pillar(inner, sx, sy, zj)))


def _block_key(x_in, sx, y0, y1, depth):
    return (round(x_in, 3), sx, round(y0, 3), round(y1, 3), round(depth, 3))


def _measure_wall_block(placed, inner, y0, y1, depth):
    """For each side wall, probe a Y-seam corner feature's own footprint against
    the placed contents and keep whatever stands inside it. Only what stands
    inside THIS footprint at THIS depth counts — a part may cross the wall's
    height band and still leave the corner alone, so a bounding box is not enough
    to judge it by."""
    ix0, ix1, iy0, iy1, iz0, iz1 = inner
    for x_in, sx in ((ix0, +1.0), (ix1, -1.0)):
        xa, xb = sorted((x_in, x_in + sx * depth))
        prism = _ybox(xa, xb, y0, y1, iz0, iz1)
        hits = [h for h in (prism.intersect(s) for s, _c in placed.values())
                if h.Volume() > 1.0]
        if not hits:
            continue
        block = hits[0]
        for h in hits[1:]:
            block = block.fuse(h)
        _wall_block[_block_key(x_in, sx, y0, y1, depth)] = block


def _y_corner(inner, y_joint):
    """The Y extent of the FRONT half's socket collar — one socket_r either side
    of the bore axis. Aft that is the lip rim, where the collar's face lands;
    forward it is the sliver of front wall the collar's own root takes, a hair
    ahead of the lip's fusion shoulder.

    One definition, read by the band _dims probes, the heights _bosses may place a
    level at, and the collar `_front_socket` builds — so a change to the boss
    cannot move one of the three and leave the others measuring somewhere else."""
    return (max(inner[2], _y_boss(y_joint) - socket_r), y_joint + lip_len)


def _y_corner_back(iy1, y_joint):
    """The Y extent of the BACK half's plug, from the seam mouth into the physical flank.

    Its forward `plug_dia` is the square registration pin inside the front socket. The
    rest carries that same section aft to `back_flank_start`, where both back pieces'
    thickened flank begins, so the boss emerges from the wall it belongs to instead of
    ending in front of it."""
    return y_joint, min(iy1, back_flank_start(y_joint))


def wall_band_corner_y(reach):
    """How far aft a body standing `reach` inboard of a ±X wall's inner face reaches before
    the box's own standing-vertical relief curves that wall away from it.

    The cavity is rounded `corner_round - wall` about a centre one radius in from each face,
    so at a back corner the wall leaves the body's plane along an arc. This is where the arc
    crosses that plane — and unlike a boss it is a bound at EVERY height, which makes it the
    aft end of what the band has to give. A body reaching further inboard than the radius is
    clear of the arc entirely and answers to the +Y wall itself.

    WHERE THAT CORNER CARRIES A COLUMN the arc is no longer what a body meets first: the lens
    stands in the air the arc left open, and its room-facing side is swung from the corner. The
    −X wall's back corner carries one and this still reads the arc, because nothing on that
    flank comes near either — the tap-water cradle stands 9.9 mm off the wall where the lens
    reaches 9, and every body aft of it stops 20 mm short of the rear plane. The reading this
    owes a column is owed on the flank whose bodies are IN it."""
    r = corner_round - wall
    if reach >= r:
        return rear_plane_y
    return (rear_plane_y - r) + math.sqrt(r * r - (r - reach) * (r - reach))


def wall_boss_aft_limit():
    """The aftmost station on a ±X wall that carries a boss its whole `mount_boss_out` long.

    THE STANDING CORNER IS THE FENCE HERE. The cavity's vertical corners are relieved
    `corner_round - wall` for the bed, so from that arc's centre plane aft the wall is no
    longer at `interior_x`: it curves inboard, a boss on it is shorter than the heat-set it
    carries, and where the arc crosses the boss tip there is no boss at all. The centre plane
    is the last station with the whole length under it, and it is a bound at every height, the
    relief running the box's full standing depth.

    A mounting pattern answers to this; an envelope answers to `wall_band_corner_y`, which is
    where the same arc crosses the plane the BODY stands on, further aft.

    A COLUMN IN THAT CORNER DOES NOT MOVE THIS. A boss is printed material and so is a lens,
    so a boss standing inside one comes out of the print as one body with it and keeps only
    its bore — absorbed, the way the condenser's cradle rail is. What a lens does fence is the
    BODY hung on that boss, whose own overhang is in air; that is `wall_band_corner_y`."""
    return rear_plane_y - (corner_round - wall)


def east_band_free_y():
    """The BACK half's free run of the ±X boss-chain bands, as `(y0, y1)` — the depth a body
    hung on that flank has aft of the Y seam.

    ONE Y SPAN CARRIES EVERY Y-SEAM LEVEL. The levels differ in height and share a station,
    so `y_seam + lip_len` is the aft face of all of them at once and no height has to be
    named to say where they stop. Aft of it the band meets the back corner's own relief
    (`wall_band_corner_y` at a wall seat's reach), which is the one thing on this flank that
    stands at every height.

    THE Z-SEAM STATIONS ARE NOT IN IT. Each is a collar `2 * socket_r` tall at the stated
    plane's own height (`z_seam`) — so a body standing clear of it in z passes it, and
    whether one does is a question about a placed pack. `enclosure_assembly.check_east_band`
    asks that against `seam_bosses`, which carries each boss's height as well as its
    station.

    Struck off the stated planes alone, `y_seam` and `rear_plane_y` — so a body reads it
    before the box that carries it has been sized, the same way it reads the wall itself
    through `interior_x`."""
    return (y_seam + lip_len, wall_band_corner_y(mount_boss_out))


def front_band_free_y(front_face):
    """The FRONT half's free run of the ±X boss-chain bands, as `(y0, y1)` — the run
    `east_band_free_y` says this half has and is not.

    ITS ENDS ARE THE FRONT WALL AND THE Y SEAM'S OWN CORNER. The Z seam stands no collar
    in this band any more: the rail is the seam's furniture on a flank, it lives in the
    seam's own `z_seam..z_seam + z_rise` storey, and a body under the mouth never meets
    it — `z-slide-lanes` is what reads a body that stands up into the storey the slide
    sweeps. So the run is the whole flank, front face to the Y boss's fore face.

    IT TAKES THE FRONT FACE because it cannot state it. The back half's two ends are both
    struck on planes the box states about itself — `y_seam` and `rear_plane_y` — but the front
    wall stands off whatever the pack puts nearest it, so a caller reading this before the box
    is sized has to say what that is. Everything after it is the same stated chain `_dims`
    builds the wall on."""
    iy0 = front_face - front_seam_clear
    return (iy0, _y_boss(y_seam) - socket_r)


def _level_clear(inner, y0, y1, z_boss, x_in, sx, depth):
    """Whether this wall can carry a cross-pin at this height. The test is the
    SOCKET's whole body — bore, heat-set and cap, out to `depth` and one socket_r
    either side of the axis — against what `_measure_wall_block` found standing in
    that corner. A level whose socket has no body is not a fastener, it is a hole
    in a wall."""
    block = _wall_block.get(_block_key(x_in, sx, y0, y1, depth))
    if block is None:
        return True
    xa, xb = sorted((x_in, x_in + sx * depth))
    bottom = inner[4] - floor_t if z_boss < z_seam else z_boss - socket_r
    probe = _ybox(xa, xb, y0, y1, bottom, z_boss + socket_r)
    return probe.intersect(block).Volume() <= 1e-6


def seam_bosses(inner, y_joint, splits):
    """Every boss the seam stands in a ±X boss-chain band, as `(y0, y1, z0, z1)` — what each
    one actually occupies of that wall, both walls' taken together.

    The lower socket jambs run from the handhold roofs through the middle collars; the upper
    collars occupy `2 * socket_r` about their bores. Read from the definitions that
    BUILD them (`_bosses`, `_y_corner`, `_z_rail_runs`), so a footprint cannot drift from
    the geometry it stands for.

    THE HEIGHT IS HALF THE ANSWER. A body hung on a flank clears a boss by standing beside it
    or by standing over it, and a reading with no z in it can only see the first — it would
    charge a body the whole height of a wall for a collar 16 mm tall. Outside the blocks'
    occupied heights, the band is the wall's own air.

    THE RAILS ARE IN THE ANSWER TOO. Each column's hooked rail runs its flanks' straight
    runs over the seam's own storey, mouth to rim. Both carry their full nominal foot first
    and place the hook at that foot's inboard edge. Both remain inside `side_band_inset`, so
    the band the pack keeps covers them. A row per column says so, at the run each column's
    rail actually takes."""
    r = socket_r
    front_y0, front_y1 = _y_corner(inner, y_joint)
    back_y0, back_y1 = _y_corner_back(inner[3], y_joint)
    yb0, yb1 = min(front_y0, back_y0), max(front_y1, back_y1)
    out = [(yb0, yb1, inner[4] - floor_t if z < z_seam else z - r, z + r)
           for _x_in, _x_ext, _sx, z in _bosses(inner, y_joint)]
    for col, zj in (("front", splits[0]), ("back", splits[1])):
        for _x_in, _sx, ry0, ry1, _lane in _z_rail_runs(inner, y_joint, col, None):
            out.append((ry0, ry1, zj, zj + z_rise))
    return out


def _in_a_boss(b, bosses):
    """Whether a placed body's bounding box meets any of `bosses` in BOTH y and z."""
    return any(b.ymin < y1 and b.ymax > y0 and b.zmin < z1 and b.zmax > z0
               for y0, y1, z0, z1 in bosses)


def _open_bands(spans, z0, z1, clear):
    """The heights in `[z0, z1]` a seam may land on, given the Z spans standing in
    that column: what the bodies leave open, inset `clear` at each end so the seam
    plane lands on neither. `[(lo, hi), ...]`, lowest first; a gap too thin to inset
    is not a band.

    A gap of exactly `2 * clear` IS a band — one height, no slack — because that is
    what a pack squeezed to its minimum leaves, and refusing it on a rounding bit
    would refuse a box that closes."""
    out, edge = [], z0
    for lo, hi in sorted(spans) + [(z1, z1)]:
        if lo > edge and lo - clear >= edge + clear - 1e-9:
            out.append((edge + clear, max(lo - clear, edge + clear)))
        edge = max(edge, hi)
    return out


def _clipped(bands, lo, hi):
    """`bands` held inside `[lo, hi]` — what falls wholly outside it drops out."""
    out = [(max(a, lo), min(b, hi)) for a, b in bands]
    return [(a, b) for a, b in out if b >= a - 1e-9]


def _bed_band(inner):
    """The heights a Z seam may take and leave both its pieces printable.

    The bottom piece runs the floor slab's underside to its seam RIM (`zj + z_rise`,
    where the station collars stop too); the top piece runs the seam plane to the top
    wall's outer face. Both print standing on a Z face, so the bed's Z bounds each of
    them, and each bound is one end of this band."""
    oz0, oz1 = inner[4] - floor_t, inner[5] + wall
    return oz1 - H2C_Z, oz0 + H2C_Z - z_rise


def _lip_band(inner, z, inset=0.0):
    """The Z-seam lip's own shape over a height span: the cavity's one-`wall` skin.

    `inset` pulls the skin's OUTER surface inboard and keeps its inner one — the lip the
    box builds stands `slide_slip` off every face the top piece slides along, because a
    slide the length of a column cannot run printed face on printed face the way a 13 mm
    drop could. The nominal skin (inset 0) is what the measures read: it is the lane the
    seam OWNS, a hair wider than the lip standing in it, conservative the way a probe
    should be.

    THE LIP IS NOT A BOX. It is struck as the cavity's skin (`_cavity`), so it carries the
    wall rounds at the standing verticals and WRAPS whatever column stands in one — the
    pillar telescopes into the piece above on the same one wall of overlap every other face
    uses. A rectangular band drawn to the same figures is neither: it reaches into corners
    the cavity has rounded away, and it misses the wrap entirely, which is the part that
    stands furthest inboard.

    `_lip_underwall` is struck from this same figure, so the wall below the mouth and the
    measures that read the seam's lane come off one shape."""
    z0, z1 = z
    return _cavity(inner, inset, (z0, z1)).cut(_cavity(inner, wall, (z0 - 1.0, z1 + 1.0)))


def _lip_denied(placed, inner, y_span, plate, y_joint):
    """The seam heights the pack denies ONE Y column's Z seam, as z spans.

    The seam's furniture on a flank is the RAIL: groove, arm and head together span
    `rail_reach_in` from `interior_x` over the seam's own storey, on the runs that column's
    rails take, wherever the seam lands. Both channel walls follow the inboard portion of
    their full nominal feet. So the lane measured is the actual profile on those runs, over
    the full height of the box — and a body standing in one
    denies the seam heights that would put the slide through it: from `z_rise` under its foot (the
    rim would be below it) to one `rail_flare_drop` over its crown, which is how far the arm's
    under-flare hangs below the seam and therefore how high above a crown a seam can still drop
    rail through it.

    A Z SEAM IS PER Y COLUMN AND SO IS ITS LANE. `y_span` is that column's half, cut
    at the Y joint; a body spanning the joint is charged to both columns, as it
    should be. What holds the rest of the lane open is the pack's own standoffs —
    `side_band_inset` at the flanks, which the rail stands inside."""
    ix0, ix1, _iy0, _iy1, iz0, iz1 = inner
    cy0, cy1 = y_span
    col = "front" if cy1 <= y_joint + 1.0 else "back"
    ring = None
    for x_in, sx, ry0, ry1, _lane in _z_rail_runs(inner, y_joint, col, plate):
        ya, yb = max(ry0, cy0), min(ry1, cy1)
        if yb <= ya + 1e-6:
            continue
        x_hk, _x_f, _x_a, x_h1 = _rail_x(x_in, sx, col)
        x_open = x_hk - sx * slide_slip
        lane = _ybox(min(x_open, x_h1), max(x_open, x_h1),
                     ya, yb, iz0, iz1)
        ring = lane if ring is None else ring.fuse(lane)
    out = []
    if ring is None:
        return out
    for solid, _c in placed.values():
        hit = ring.intersect(solid)
        if hit.Volume() > 1.0:
            b = hit.BoundingBox()
            out.append((b.zmin - z_rise, b.zmax + rail_flare_drop))
    return out


# Which columns' Z seams run THROUGH their own bodies rather than land in a band those
# bodies leave open. Filled by `_z_joints`, printed by main().
_z_seam_passes = {}


def _z_joints(placed, inner, stated, plate, y_joint):
    """The bottom↔top seam height per Y column: `(front, back)` — the one stated plane,
    both.

    `stated` is `z_seam`, and what is measured here is what it lands in: the band the bed
    leaves a column's two pieces (`_bed_band`), each column's own lip lane — the heights
    the pack leaves the lip's ring (`_lip_denied`) — and the open bands the column's
    bodies leave, which is what `_report_seams` reads. None of the bounds stops the cut:
    whatever the readings say, both seam heights come back and the box is cut on them."""
    iz0, iz1 = inner[4], inner[5]
    y_mid = (inner[2] + inner[3]) / 2.0
    bed_lo, bed_hi = _bed_band(inner)
    on_bed = bed_lo - 1e-9 <= stated <= bed_hi + 1e-9
    record_bound(Bound(
        "z-seam-bed", "The Z seam leaves every piece on the H2C's bed", on_bed,
        f"seam at {stated:.2f}, band {bed_lo:.2f}..{bed_hi:.2f}",
        f"inside the H2C's {H2C_Z:g} mm Z",
        ([] if on_bed else [
            f"the Z seam at {stated:.2f} leaves a piece off the H2C's {H2C_Z:g} mm bed: "
            f"the top pieces want it at or below {bed_hi:.2f} and the bottoms at or above "
            f"{bed_lo:.2f}. Move `z_seam` into that band"])))
    record_bound(Bound(
        "z-seam-two-pieces", "A column splits into two pieces the H2C can print",
        bed_hi >= bed_lo,
        f"{iz1 - iz0 + floor_t + wall:.2f} mm column, band {bed_lo:.2f}..{bed_hi:.2f}",
        f"a band inside the H2C's {H2C_Z:g} mm Z",
        ([] if bed_hi >= bed_lo else [
            f"a {iz1 - iz0 + floor_t + wall:.2f} mm column has no seam height leaving two pieces "
            f"inside the H2C's {H2C_Z:g} mm Z: the top piece wants the seam at or below "
            f"{bed_hi:.2f} and the bottom at or above {bed_lo:.2f}. It needs a third piece"])))
    spans = {"front": [], "back": []}
    for _n, (solid, _c) in placed.items():
        b = _boxes.boxed(solid)
        col = "front" if (b.ymin + b.ymax) / 2.0 < y_mid else "back"
        spans[col].append((b.zmin, b.zmax))
    for col, y_span in (("front", (inner[2], y_seam)), ("back", (y_seam, inner[3]))):
        whole = _clipped(_open_bands(spans[col], iz0, iz1, z_joint_clear), bed_lo, bed_hi)
        _z_seam_passes[col] = not any(lo - 1e-9 <= stated <= hi + 1e-9 for lo, hi in whole)
        lanes = _open_bands(_lip_denied(placed, inner, y_span, plate, y_joint),
                            bed_lo, bed_hi, 0.0)
        in_lane = any(lo - 1e-9 <= stated <= hi + 1e-9 for lo, hi in lanes)
        record_bound(Bound(
            f"z-seam-{col}-lane", f"The {col} column's lip ring is clear at the seam height",
            in_lane,
            f"seam at {stated:.2f}, lane "
            + (", ".join(f"{lo:.2f}..{hi:.2f}" for lo, hi in lanes) or "nowhere"),
            "a lane containing it",
            ([] if in_lane else [
                f"the {col} column's lip cannot run at {stated:.2f}: what reaches into its "
                f"ring leaves "
                + (", ".join(f"{lo:.2f}..{hi:.2f}" for lo, hi in lanes) or "no height")
                + " — move `z_seam`, or repack what stands in the ring"])))
    return stated, stated


def _dims(pack):
    """The box `pack` stands inside — its two shells, the plane it splits on, and the
    stations its walls carry. `pack` is a Pack (see `machine_of`).

    THE BOX IS ITS STATED SIZE and the pack has to fit in it. Width, depth and height are
    each measured against what the contents demand and each reading goes in the ledger, but
    the box that comes back is the one those three numbers describe — so a pack that overruns
    one gets a wall drawn through it, a red row saying by how much, and a clash in
    `pack-closes` at the body that overran. This is the only function that reads the placed
    parts, so it is where the ledger starts: `BOUNDS` is cleared here and refilled."""
    BOUNDS.clear()
    _wall_block.clear()
    _z_seam_passes.clear()
    placed = pack.placed
    bbs = [_boxes.boxed(s) for s, _c in placed.values()]
    czmin = min(b.zmin for b in bbs); czmax = max(b.zmax for b in bbs)
    # WIDTH — the appliance's headline dimension, and the whole point of the yaw. Stated
    # as `appliance_width` and struck symmetric about x = 0, the axis the pack is centred
    # on, the same way depth is `rear_plane_y` and height is `appliance_height`.
    #
    # The cavity every one of these bounds is measured against, and the seam heights that
    # ride it. Struck first because a boss's FOOTPRINT is what the width and height checks
    # both ask after, and a footprint is a station and a height together — the height comes
    # off the seams, and the seams come off the pack.
    ix0, ix1 = interior_x()
    iy0 = front_plane_y
    iy1 = rear_plane_y
    iz0 = min(czmin, 0.0)
    iz1 = (iz0 - floor_t) + appliance_height - ceiling_skin
    inner = (ix0, ix1, iy0, iy1, iz0, iz1)
    y_joint = y_seam
    splits = _z_joints(placed, inner, z_seam, pack.collet_plate, y_joint)
    # THE RIM'S OWN CEILING. Wall-rooted furniture stands on a piece's wall, and below the
    # rim the wall's inner face is the bottom piece's lip — so a valve tray's seat plate
    # spans wall to wall whole above the rim, and its FOOT runs below it inset on the lip's
    # own face (`_valve_trays`). The lip's ring cannot read one: it is printed material,
    # not pack, and a plate standing ON the rim is a touch with no volume in it. This reads
    # each wall root off the same outer valve row the pieces build it from. The lower band
    # between staggered rows stays inset to the lip faces. The bay's
    # floor is the one span that does stand on the rim and answers elsewhere
    # (`enclosure_assembly.check_bay_floor`); the pump clamp's collar storey belongs to the
    # removable assembly, so no fixed wall carries it.
    rim = max(splits) + z_rise
    decks = [floor for _plane, _sign, seats in pack.valve_trays
             for floor in _valve_tray.wall_root_floors(seats)]
    deck_floor = min(decks) if decks else iz1
    record_bound(Bound(
        "z-seam-under-deck", "The Z-seam rim stays under the flavour deck's lowest plate",
        rim < deck_floor - stated_bound_tol,
        f"rim at {rim:.2f}, lowest wall root at {deck_floor:.2f}",
        "air between them",
        ([] if rim < deck_floor - stated_bound_tol else [
            f"the lip's rim at {rim:.2f} reaches the deck's lowest wall-rooted plate at "
            f"{deck_floor:.2f} — a plate roots on a wall only above the rim. Lower "
            f"`z_seam`, or raise the deck"])))
    if pack.collet_plate and "condenser+fan" in placed:
        condenser_box = _boxes.boxed(placed["condenser+fan"][0])
        foot_air = plate_foot_envelope_clearance(
            pack.collet_plate, splits[0], condenser_box)
        foot_clear = math.isinf(foot_air) or foot_air > stated_bound_tol
        record_bound(Bound(
            "plate-foot-condenser-envelope",
            "The collet-plate feet stay outside the condenser+fan envelope",
            foot_clear,
            ("foot and envelope are disjoint in plan" if math.isinf(foot_air)
             else f"{foot_air:.2f} mm air over the complete bounding box"),
            "positive air outside the complete condenser+fan bounding box",
            ([] if foot_clear else [
                f"the +X collet-plate foot enters the condenser+fan bounding box by "
                f"{-foot_air:.2f} mm; shorten its reach, thin its section, or raise its "
                f"supportless underside"])))
    band_bosses = seam_bosses(inner, y_joint, splits)
    # What the pack still has to earn is the clearance. A body on the slab is held one
    # `side_band_inset` off the ±X walls where the seam's bosses stand — `seam_bosses`, the
    # same footprints the ceiling's own band takes below. Beside one, and over or under one,
    # the band is the wall's own air, and a body clear of all of them answers on its own reach.
    #
    # EVERY TERM CARRIES THE BODY IT CAME OFF, and on this axis both of them close flush. The
    # cold core packs its `side_band_inset` off `interior_x` on the slab, and the Wago wells
    # bore through the thickened ±X flanks to bottom on `interior_x` itself
    # (`front_top_flank_t`, `front_bottom_flank_t`), so a lever nut's back face IS that plane.
    # A reading with no air in it is a seat, and the name beside it is what says which.
    floor = [(n, b) for n, b in zip(placed.keys(), bbs)
             if b.zmin < wall + 1e-6 and _in_a_boss(b, band_bosses)]
    wide_need, wide_who = max(
        [(max(b.xmax, -b.xmin), n) for n, b in zip(placed.keys(), bbs)]
        + [(max(b.xmax, -b.xmin) + side_band_inset, n) for n, b in floor])
    record_bound(Bound(
        "box-width", "The pack stands inside the appliance's stated width",
        wide_need <= ix1 + stated_bound_tol,
        f"pack reaches x ±{wide_need:.2f} at {wide_who}, wall at ±{ix1:.2f}",
        f"inside a {appliance_width:g} mm appliance",
        ([] if wide_need <= ix1 + stated_bound_tol else [
            f"the pack reaches x ±{wide_need:.2f} but a {appliance_width:g} mm appliance walls "
            f"in at ±{ix1:.2f} — {wide_need - ix1:.2f} mm over. Raise `appliance_width` or "
            f"repack inboard"])))
    # AND BACK-TOP'S OWN FLANKS STAND FURTHER IN THAN THAT. `back_top_flank_face` is
    # `back_top_flank_t - wall` inboard of `interior_x` on that one piece, so a body that clears
    # the appliance's width can still be standing in its wall — and `box-width` cannot see it,
    # because the width it reads is the box's own. What this section may stand in is what the
    # wall gives a LANE to and nothing else: a Wago in its own well, bored back to `interior_x`,
    # and whatever lies in the ASSE drip pan's sleeve. A body is matched to a geometric well
    # by its CENTRE.
    bt0, bt1 = back_top_flank_face()
    bt_y0 = y_joint + lip_len + z_lip_y_margin
    bt_z0 = splits[1] + z_rise
    lanes = ([(sy - hy, sy + hy, sz - hz, sz + hz)
              for _sd, sy, sz, size, *_rest in pack.side_wells
              for hy, hz in (wago_half(size),)]
             + [(by0, by1, bz0, bz1) for _bx0, _bx1, by0, by1, bz0, bz1 in pack.pan_sleeve[0]])
    flank_rows = []
    for name, b in zip(placed.keys(), bbs):
        if b.ymax <= bt_y0 or b.zmax <= bt_z0:
            continue
        cy, cz = (b.ymin + b.ymax) / 2.0, (b.zmin + b.zmax) / 2.0
        if any(ly0 <= cy <= ly1 and lz0 <= cz <= lz1 for ly0, ly1, lz0, lz1 in lanes):
            continue
        pocket = next((r for r in pack.flank_reliefs if r[0] == name), None)
        west_face = pocket[1] if pocket is not None else bt0
        flank_rows.append((max(west_face - b.xmin, b.xmax - bt1), name))
    flank_rows.sort(reverse=True)
    flank_over, flank_who = flank_rows[0] if flank_rows else (-bt1, "nothing")
    flank_ok = flank_over <= stated_bound_tol
    record_bound(Bound(
        "back-top-flank-clear", "The pack stands clear of back-top's own flank face", flank_ok,
        f"least air {-flank_over:.2f} mm, at {flank_who}",
        f"outside x ±{bt1:.2f}, a {back_top_flank_t:g} mm flank",
        ([] if flank_ok else [
            f"{flank_who} stands {flank_over:.2f} mm inside back-top's flank at ±{bt1:.2f}. "
            f"Give it a lane the way the tray's sleeve has one, seat it in a well, or lower "
            f"`back_top_flank_t`"])))
    # The FRONT wall is the stated `front_plane_y` with its stated reliefs, and the pack is
    # read against the RELIEVED surface, body by body: a body whose footprint stands wholly
    # inside a relief answers to that relief's floor, and every other body to the plane
    # itself. The compressor's reading is its stated kiss on the refrigeration bay's floor.
    #
    # The +Y wall is the stated `rear_plane_y`, for the same reason the ceiling is the
    # stated `appliance_height`: depth is a bound, not a consequence. Taken off the pack it
    # would follow whichever body reached furthest back, and anything seated on this plane
    # would follow that body too, holding every clearance between the two constant.
    regions = _front_relief_regions(pack.pump_trays)
    front_rows = sorted(
        (b.ymin - _front_floor(regions, b, name), name)
        for name, b in zip(placed.keys(), bbs))
    front_ok = front_rows[0][0] >= -stated_bound_tol
    record_bound(Bound(
        "box-front", "The pack stands behind the front wall's relieved surface",
        front_ok,
        f"least air {front_rows[0][0]:.2f} mm, at {front_rows[0][1]}",
        f"on or behind the wall's own surface, plane {front_plane_y:g} and its reliefs",
        ([] if front_ok else [
            f"{name} stands {-air:.2f} mm inside the front wall's surface — deepen its "
            f"relief in `_front_relief_regions`, or repack it aft"
            for air, name in front_rows if air < -stated_bound_tol])))
    rear_need, rear_who = max((b.ymax + rear_seam_clear, n)
                              for n, b in zip(placed.keys(), bbs))
    record_bound(Bound(
        "box-depth", "The pack stands inside the appliance's stated depth",
        rear_need <= iy1 + stated_bound_tol,
        f"pack reaches y {rear_need:.2f} at {rear_who}, +Y wall at {iy1:.2f}",
        f"ahead of `rear_plane_y` {rear_plane_y:g}",
        ([] if rear_need <= iy1 + stated_bound_tol else [
            f"the pack reaches y {rear_need:.2f} but the +Y wall stands at {iy1:.2f} — "
            f"{rear_need - iy1:.2f} mm over. Raise `rear_plane_y` or repack forward"])))
    # The floor is a fixed Z=0 datum, not the lowest content — so parts can stand
    # on feet above it (the floor and the seam lip stay put). The CEILING is
    # the stated `appliance_height` measured from the floor slab's underside: the
    # thin machine's height is a bound, not a consequence, so the tallest content
    # does not lift it and slack above the pack is the column the unpacked
    # subsystems go in.
    #
    # What the contents demand, measured against the bound rather than setting it, so a pack
    # that outgrows it says so instead of quietly poking through the top wall. The ±X wall
    # bands are measured separately: ONE boss on each of them hugs the ceiling — the Y seam's
    # top level, `2 * socket_r` of collar hanging off the top wall — so content inside its
    # station and inside a boss chain of the wall answers for that collar as well as for its
    # own height.
    #
    # IT IS THAT COLLAR AND NO OTHER. Every other boss on the flank stands somewhere down the
    # wall with air over it, and charging a body the ceiling's collar because it shares a
    # station with one of them would reserve headroom for material a hundred millimetres
    # below. The body that answers here is the one standing under the top collar.
    pod_stack = 2.0 * socket_r + 1.5              # ceiling → top collar's underside + margin
    ceiling_boss = [b for b in band_bosses if b[3] >= iz1 - 1e-6]
    wall_band_top = max(
        (b.zmax for b in bbs
         if (b.xmin < ix0 + boss_in or b.xmax > ix1 - boss_in)
         and _in_a_boss(b, ceiling_boss)),
        default=iz0)
    need = max(czmax, wall_band_top + pod_stack)
    record_bound(Bound(
        "box-height", "The pack stands under the appliance's stated ceiling",
        need <= iz1 + stated_bound_tol,
        f"pack reaches z {need:.2f}, ceiling at {iz1:.2f}",
        f"under a {appliance_height:g} mm appliance",
        ([] if need <= iz1 + stated_bound_tol else [
            f"the pack reaches z {need:.2f} but a {appliance_height:g} mm appliance ceilings at "
            f"{iz1:.2f} — {need - iz1:.2f} mm over. Raise `appliance_height` or repack "
            f"downward"])))
    ox0, ox1 = ix0 - wall, ix1 + wall
    oy0, oy1 = iy0 - front_wall, iy1 + wall
    outer = (ox0, ox1, oy0, oy1, iz0 - floor_t, iz1 + ceiling_skin)
    # THE REMOVABLE FRONT IS THE FRONT OF THE APPLIANCE. Its show plane and the fixed walls
    # above and below the bay share one Y coordinate; the pump-to-deck lead is room inside the
    # wall, not a step outside it. Read the two independently so changing either construction
    # cannot quietly bring the protrusion back.
    pump_face_offset = outer[2] - pump_cartridge_front_y
    record_bound(Bound(
        "pump-cartridge-flush", "The pump cartridge is flush with the fixed front face",
        abs(pump_face_offset) <= stated_bound_tol,
        f"cartridge y {pump_cartridge_front_y:.3f}, fixed face y {outer[2]:.3f}",
        "the same plane",
        ([] if abs(pump_face_offset) <= stated_bound_tol else [
            f"the cartridge stands {pump_face_offset:.3f} mm ahead of the fixed front face. "
            "Seat the complete flavour pack at its common depth and carry the enclosure front "
            "to `pump_cartridge_front_y`"])))
    # The one thing the Y seam cannot do is cut the display housing: the facet is a
    # solid surface chamfered into the top-front arris and it prints as part of the
    # front-top piece, so the seam stands behind its back plane.
    # NOTHING RELIEVES INTO THE OUTERMOST `flute_backing` OF A FLUTED FACE. This is the rule the
    # whole skin stands on and the one a reader would otherwise have to take on trust.
    sections = flute_backed_sections()
    thin = [(what, mm) for what, mm in sections if mm < flute_backing - stated_bound_tol]
    record_bound(Bound(
        "flute-backed", "Every fluted face keeps a whole wall behind its grooves", not thin,
        f"thinnest of {len(sections)} stated sections is "
        f"{min(mm for _what, mm in sections):.4f} mm",
        f"at least {flute_backing:g} mm",
        [f"{what} carries {mm:.4f} mm, so a {flute_depth:g} mm groove leaves "
         f"{mm - flute_depth:.4f} behind it" for what, mm in thin]))
    # THE REEDED SKIN CLOSES ON THE BOX. `flute_count` is a whole number of grooves round the
    # whole outer plan, so the field has no station where it restarts and no seam where two
    # arrays meet — but the pitch that count lands on is a CONSEQUENCE and not a choice, and it
    # has to stay the coupon's or this box is not carrying the texture that was settled on.
    pitch = flute_pitch(outer)
    drift = abs(pitch - reeding.flute_pitch)
    record_bound(Bound(
        "flute-closes", "The reeded field closes on the box at the coupon's own pitch",
        drift <= flute_pitch_drift,
        f"{flute_count} grooves round {plan_perimeter(outer):.2f} mm, {pitch:.4f} mm centres",
        f"within {flute_pitch_drift:g} mm of the coupon's {reeding.flute_pitch:g}",
        ([] if drift <= flute_pitch_drift else [
            f"the field lands on {pitch:.4f} mm centres, {drift:.4f} off the coupon's "
            f"{reeding.flute_pitch:g}. `flute_count` wants to be near "
            f"{plan_perimeter(outer) / reeding.flute_pitch:.1f}"])))
    # AND IT PUTS THE Y SEAM IN A GROOVE. That seam is the one straight line running the full
    # height of both side walls, and it runs ALONG the flutes rather than across them — so it
    # can be put where a joint reads as the shadow already there instead of a line on a flat.
    # This is what picks one `flute_count` out of the several that close near the coupon's
    # pitch, and without it the choice would be arbitrary.
    segments = _plan_segments(outer)
    seam_arc = segments[0][1] + segments[1][1] + (y_joint - (outer[2] + corner_round))
    miss = min(seam_arc % pitch, pitch - seam_arc % pitch)
    record_bound(Bound(
        "flute-hides-seam", "The Y seam runs down a groove, not across a land",
        miss <= flute_seam_miss,
        f"{miss:.4f} mm off a groove centre, in a groove {reeding.flute_width:g} mm wide",
        f"within {flute_seam_miss:g} mm of a centre",
        ([] if miss <= flute_seam_miss else [
            f"the Y seam lands {miss:.4f} mm off the nearest groove centre, which puts the "
            f"joint on a land where it is a line on a flat. Retune `flute_count`"])))
    # AND THE PUMP BAY'S INTERIOR THROAT TAKES THE COMPLETE CAVITY WIDTH. The removable
    # cartridge continues out through both former side skins; this bound names only the
    # unobstructed interior planes, while `pump-cartridge-full-front-wall` reads ownership of
    # the complete exterior front-wall band from the built solids.
    bx0, bx1 = bay_x_span(inner)
    record_bound(Bound(
        "pump-bay-cavity-throat", "The pump bay throat reaches both cavity side planes",
        abs(bx0 - inner[0]) <= stated_bound_tol and abs(bx1 - inner[1]) <= stated_bound_tol,
        f"bay x {bx0:.3f}..{bx1:.3f}, cavity x {inner[0]:.3f}..{inner[1]:.3f}",
        "the same two planes",
        ([] if (abs(bx0 - inner[0]) <= stated_bound_tol
                and abs(bx1 - inner[1]) <= stated_bound_tol) else [
            "a fixed jamb stands inside a cavity plane and narrows the withdrawal throat. "
            "Carry `bay_x_span` to the cavity's complete X span"])))
    facet_back = housing_back_y(outer)
    record_bound(Bound(
        "y-seam-clears-facet", "The Y seam stands behind the display housing",
        y_joint >= facet_back + 2.0,
        f"seam at {y_joint:.2f}, housing back plane at {facet_back:.2f}",
        f"aft of {facet_back + 2.0:.2f}",
        ([] if y_joint >= facet_back + 2.0 else [
            f"the Y seam at {y_joint:.2f} cuts the display housing, whose back plane is at "
            f"{facet_back:.2f} — the facet has to stay whole in the front pieces. Move "
            f"`y_seam` aft of {facet_back + 2.0:.2f}, or bring `display_housing_back` "
            f"forward"])))
    # The vertical cut squares off slab the funnel's throat wants, and what stops it is the
    # display's own SEATS — the inset the cover plate drops into and the bezel counterbore
    # under it. The PCB hole is not one of them: `display_pcb_cut_through` drives it past the
    # back on purpose, to take a socket collar clean through.
    seats = max(_seat_back(display_inset_depth, display_inset_slope / 2.0),
                _seat_back(display_bezel_depth, display_bezel_cut_slope / 2.0))
    record_bound(Bound(
        "display-housing-seats", "The housing's back cut keeps a wall behind the display's seats",
        display_housing_back >= seats + wall,
        f"cut at {display_housing_back:.2f} aft of the front face, seats reach {seats:.2f}",
        f"a {wall:g} mm wall behind them, so aft of {seats + wall:.2f}",
        ([] if display_housing_back >= seats + wall else [
            f"`display_housing_back` {display_housing_back:.2f} stands "
            f"{seats + wall - display_housing_back:.2f} mm forward of where the display's "
            f"seats leave room — the deeper of the inset and the bezel counterbore reaches "
            f"{seats:.2f} aft of the front face, and the cut opens its back into the box. "
            f"Take `display_housing_back` aft of {seats + wall:.2f}"])))
    # What the seam's own furniture lands in: the socket collar's footprint, at the full
    # section the screw chain needs, which is the band `_bosses` places a level inside.
    # The plug opposite it stands within that same footprint at a shallower reach.
    fy0, fy1 = _y_corner(inner, y_joint)
    _measure_wall_block(placed, inner, fy0, fy1, boss_in)
    # WHAT EACH LIP'S OWN WALL COSTS THE CAVITY. A flank under a Z seam is `2 * wall` thick
    # from the slab to the rim (`_lip_underwall`), so on three sides of each bottom piece the
    # room stops one `wall` inboard of `inner`. The pack already stands that far off every one
    # of them — `front_seam_clear` and `rear_seam_clear` at the ±Y walls, `side_band_inset` at
    # the ±X ones — and the MQ-6, the one body that touches a flank at all, is seated on this
    # skin's own face (`lip_face_x`). A body that stands in it anyway is a body the wall is
    # drawn through, which is a reading and not an assumption.
    #
    # WHAT IS MEASURED IS THE FLAT WALL AND NOT THE PILLARS. This skin wraps every column
    # standing in a vertical, and a pillar GIVES WAY to a body standing in it — the wrap with
    # the column, since a body meets the two as one thing (`_column_pillar`). Charging a body
    # for the corner it is already relieved out of would report a clash the box does not build,
    # so the pillars come out and `_report_columns` says what they gave.
    under = []
    for zj, (cy0, cy1) in ((splits[0], (iz0 - 1.0, y_joint)),
                           (splits[1], (y_joint, iy1 + 1.0))):
        band = _lip_underwall(inner, y_joint, zj).intersect(
            _ybox(ix0 - 1.0, ix1 + 1.0, cy0, cy1, iz0 - 1.0, iz1 + 1.0))
        if zj == splits[0] and pack.pump_trays:
            # The front flat's skin goes to the bay (`_front_flat_lip_drop`), so the band
            # read here is the band the pieces build.
            band = band.cut(_front_flat_lip_drop(inner, zj))
        for sx, sy in column_corners:
            band = band.cut(_column_pillar(inner, sx, sy, splits[0] if sy < 0 else splits[1]))
        for name, (solid, _c) in placed.items():
            hit = band.intersect(solid)
            if hit.Volume() > 1e-3:
                b = hit.BoundingBox()
                under.append((name, hit.Volume(), b.zmin, b.zmax))
    record_bound(Bound(
        "wall-under-lip", "The pack stands clear of the wall under each Z-seam lip",
        not under,
        (f"{len(under)} bodies in it" if under else "clear on all three sides of both pieces"),
        f"one `wall` ({wall:g} mm) off the ±Y walls and the ±X ones below each seam",
        ([] if not under else
         [f"{name} stands {vol:.1f} mm³ inside it, z {z0:.1f}..{z1:.1f}"
          for name, vol, z0, z1 in under]
         + ["the lip's wall carries to the slab so its shoulder is not a soffit, so a body "
            "against a flank down there is a body the wall runs through. Repack it inboard, "
            "or seat it on `lip_face_x` the way the MQ-6's can is"])))
    # WHAT THE COLUMNS GIVE UP. Measured here with everything else the placed pack decides,
    # against the same `inner` the columns are struck on.
    reliefs = []
    for sx, sy in column_corners:
        pillar = _column_pillar(inner, sx, sy, splits[0] if sy < 0 else splits[1])
        for name, (solid, _c) in placed.items():
            hit = pillar.intersect(solid)
            if hit.Volume() <= 1e-6:
                continue
            # ONE POCKET PER LUMP THE BODY ACTUALLY STANDS IN, and not one for its whole
            # envelope. A brick's box is the brick; a condenser block's box is mostly air, and
            # a pocket struck on it would hollow the column over its whole height for the two
            # sheet flanges that are really in there. Each lump the intersection comes back in
            # gets its own box, so what a column gives up is what a body occupies.
            for lump in hit.Solids():
                b = lump.BoundingBox()
                # NO SLIP TOWARD THE TWO WALLS THIS COLUMN STANDS ON. A body in a corner has
                # its own standoff from each of them already — on the ±X wall that standoff IS
                # the tip of the boss it seats on, and a millimetre of air taken there is a
                # millimetre off the seat. The slip is for the faces a hand comes at.
                reliefs.append((sx, sy, name, (
                    b.xmin - (0.0 if sx < 0 else column_relief_slip),
                    b.xmax + (0.0 if sx > 0 else column_relief_slip),
                    b.ymin - (0.0 if sy < 0 else column_relief_slip),
                    b.ymax + (0.0 if sy > 0 else column_relief_slip),
                    b.zmin - column_relief_slip, b.zmax + column_relief_slip)))

    # THE PUMP BAY: the complete span between the side-wall interior planes. Its fixed lintel
    # answers to the pump-neutral datum: the installed motor crown plus the pump station's
    # independent service drop. `pump_bay_roof_relief` opens the underside upward from that
    # nominal roof without carrying the pump, collet plate or manifold with it.
    bx0, bx1 = bay_x_span(inner)
    crowns = [b.zmax for name, b in zip(placed.keys(), bbs)
              if name.startswith("pump-") and name.endswith("-motor")]
    pump_bay = ((bx0, bx1,
                 max(crowns) + pump_station_drop + bay_crown_air + pump_bay_roof_relief)
                if crowns else None)
    if pump_bay and pack.pump_trays:
        floor_top = bay_floor_z(pack.pump_trays)[1]
        head_floor = pump_skirt_support_z(pack.pump_trays) - _tray.head_front_below_skirt
        head_air = head_floor - floor_top
        roof_air = pump_bay[2] - max(crowns)
        head_target = (pump_relief_z_air + pump_cartridge_z_clearance + pump_bay_floor_relief
                       - pump_station_drop + _tray.head_depth - _tray.skirt_depth
                       - _interface.pump_seated_drop - _tray.head_front_below_skirt)
        roof_target = pump_station_drop + bay_crown_air + pump_bay_roof_relief
        vertical_ok = (head_air >= fits.running
                       and floor_top - z_seam >= 4.0
                       and abs(head_air - head_target) <= stated_bound_tol
                       and abs(roof_air - roof_target) <= stated_bound_tol)
        record_bound(Bound(
            "pump-bay-vertical-datums",
            "The pump bay keeps its fixed floor and roof datums around the lowered pumps",
            vertical_ok,
            f"head floor air {head_air:.2f} mm, motor-to-lintel air {roof_air:.2f} mm",
            f"{head_target:.2f} mm head-to-floor and {roof_target:.2f} mm motor-to-lintel",
            ([] if vertical_ok else [
                "the fixed bay faces do not spend the pump service offset and their own reliefs "
                "independently. Strike `bay_floor_z` and `pump_bay` from the pump-neutral datum"])))
    # The wall-block probes above are solids and deliberately do not escape this placement
    # pass. What the drawing needs from them is the numeric ladder they admitted; carry that
    # ladder on the Box so a downstream action can reproduce the same joint without the pack.
    y_bosses = tuple(_bosses(inner, y_joint))
    z_passes = tuple(_z_seam_passes[col] for col in ("front", "back"))
    return Box(pack, inner, outer, y_joint, splits, y_bosses, z_passes,
               tuple(reliefs), pump_bay)


# --- display facet (solid surface) -----------------------------------------

def _facet_geom(outer):
    p = _swept_top.profile(outer)
    a = math.radians(display_facet_angle_deg)
    dy = display_facet_slope * math.cos(a)
    dz = display_facet_slope * math.sin(a)
    return a, p["normal"], p["origin"], dy, dz


def housing_back_y(outer):
    """The Y the display housing reaches back to — the vertical plane
    `display_housing_back` aft of the box's front face, cut the full width. The
    frontmost the Y seam may sit, since the whole facet belongs to the front top
    piece; and where the top wall resumes, which is the forward wall of the frame
    the funnel's collar stands in.

    ONE PLANE, NOT A REACH OFF THE 45°. The slab behind the face is
    `display_facet_thickness` thick measured perpendicular to it, which would put
    its back plane at a Y that walks with the slope and with the thickness — and
    at the top face that plane stands aft of everything the display needs, over
    the funnel's own throat. This states where the slab stops instead."""
    return outer[2] + display_housing_back


def pcb_ridge(outer):
    """Intersection of the display pocket's up-slope end and the housing back.

    The station sets the supporting rib's crown. Its normal depth is the housing
    thickness; its slope coordinate follows the actual PCB pocket.
    """
    p = display_plane(outer)
    r = (p.origin
         + p.yDir * (display_body_offset_slope + display_pcb_slope / 2.0)
         - p.zDir * display_facet_thickness)
    return r.y, r.z


def _ridge_join(outer, fore):
    """The bulkhead rises toward the PCB ridge on a 45-degree supporting face."""
    ry, rz = pcb_ridge(outer)
    jog = rz - abs(ry - fore)
    return jog, (fore + ridge_wall_t,
                 jog - ridge_wall_t * (math.sqrt(2.0) - 1.0))


def _ridge_stations(outer, plate, bay):
    """The two electrical stations in the rib's straight section, `(x, y, z)` each: the pump
    jack's aperture centre on the box centreline, and the enclosure-display loom's bore east of
    it.

    THE JACK'S RECEPTACLE STANDS ON THE PLATE CAP'S CROWN. Its boss's lower wall lands on
    `bay[2]`, which puts the aperture centre `POCKET_H / 2 + RECEPTACLE_WALL - POCKET_RISE`
    above that plane, so on this Z-bedded piece the boss roots on the crown and the rib and
    nothing of it hangs. The loom keeps the height it had on the centreline and moves only in
    X — east, onto the flank it arrives on, and far enough that its sleeve and the boss keep
    solid stock between them."""
    ry, rz = pcb_ridge(outer)
    fore, foot = plate["aft_y"], bay[2]
    jog, _crown = _ridge_join(outer, fore)
    z_loom = (foot + jog) / 2.0
    z_jack = (foot + _keystone.POCKET_H / 2.0 + _keystone.RECEPTACLE_WALL
              - _keystone.POCKET_RISE)
    centre = display_centre_x(outer)
    return ((centre, fore, z_jack),
            (centre + display_loom_x_offset, fore, z_loom))


def pump_jack_station(box):
    """The pump jack's aperture centre on the ridge wall's fore face, `(x, y, z)`."""
    if not (box.pack.collet_plate and box.pump_bay):
        raise ValueError("the pump jack needs the collet plate and pump bay")
    return _ridge_stations(box.outer, box.pack.collet_plate, box.pump_bay)[0]


def _seat_back(depth, half_slope):
    """A pocket's aft extent, measured from the enclosure's front plane."""
    a = math.radians(display_facet_angle_deg)
    p = _swept_top.profile((0, 0, 0, 0, 0, 0))
    return p['origin'][1] + half_slope * math.cos(a) + depth * math.sin(a)


def display_centre_x(outer):
    """The X the display's glass is centred on — the box's own middle, since the
    facet runs wall to wall. Read by the counterbore that receives it and by
    `enclosure_assembly`'s placement of the reference body, so the housing and
    the part in it cannot land on two different centres."""
    return (outer[0] + outer[1]) / 2.0


def _halfspace(origin, normal, extent):
    """Solid filling the +normal side of the plane through origin."""
    plane = cq.Plane(origin=cq.Vector(*origin), xDir=cq.Vector(1, 0, 0), normal=cq.Vector(*normal))
    return cq.Workplane(plane).rect(4 * extent, 4 * extent).extrude(extent).val()


def _facet_wedge(outer):
    """The solid removed to cut the display facet — the +normal half-space, over the
    box's WHOLE WIDTH. There is no lateral window: the chamfer runs wall to wall, so
    the top-front arris comes off in one plane and the cut needs no X term at all.
    Re-cut after the socket collars so they too are chamfered to the facet plane rather
    than poking through it."""
    ox0, ox1, oy0, oy1, oz0, oz1 = outer
    a, normal, origin, dy, dz = _facet_geom(outer)
    extent = max(ox1 - ox0, oy1 - oy0, oz1 - oz0) + 100.0
    return _halfspace(origin, normal, extent)


def flank_x_at(y, outer):
    """The ±X exterior SURFACE's own distance from x = 0 at depth `y` — the wall's plane down
    the flat, and `corner_round`'s arc wherever the turn has begun.

    A BORE STRUCK ON A PLANE LEAVES LESS BEHIND A TURN. `interior_x` stands one `wall` in from
    the flat, so anything run to it leaves exactly `wall` down the middle of a face and less
    than that anywhere the round has carried the surface inboard. What has to leave a stated
    section behind the surface — `flute_backing` above all, since a flute is cut into that
    same surface — reads this and not the plane."""
    ox1, oy0, oy1 = outer[1], outer[2], outer[3]
    if oy0 + corner_round <= y <= oy1 - corner_round:
        return ox1
    off = min(abs(y - (oy0 + corner_round)), abs(y - (oy1 - corner_round)), corner_round)
    return (ox1 - corner_round) + math.sqrt(corner_round ** 2 - off ** 2)


def _plan_segments(outer):
    """The outer plan boundary as (kind, length, data), walked from the FRONT WALL'S
    CENTRELINE heading +X — four straight runs and the four `corner_round` quarter turns
    between them, in order, each carrying its own length so a walk is an arc-length walk.

    THE DATUM IS x = 0 ON THE FRONT WALL, which is the plane the whole machine is struck
    about. A field whose datum sits there is symmetric in x whatever its pitch, because the
    half-perimeter either way round is the same walk mirrored.

    There is no turn at the Y seam and none is wanted: that arris is a telescoping mating
    face, square by construction (`_round_z`), and the two pieces that meet on it present one
    continuous plan between them."""
    ox0, ox1, oy0, oy1 = outer[0], outer[1], outer[2], outer[3]
    r = corner_round
    run_x = (ox1 - ox0) - 2.0 * r
    run_y = (oy1 - oy0) - 2.0 * r
    turn = math.pi * r / 2.0
    return (
        ("line", run_x / 2.0, ((0.0, oy0), (1.0, 0.0), (0.0, -1.0))),
        ("arc", turn, ((ox1 - r, oy0 + r), -math.pi / 2.0, r)),
        ("line", run_y, ((ox1, oy0 + r), (0.0, 1.0), (1.0, 0.0))),
        ("arc", turn, ((ox1 - r, oy1 - r), 0.0, r)),
        ("line", run_x, ((ox1 - r, oy1), (-1.0, 0.0), (0.0, 1.0))),
        ("arc", turn, ((ox0 + r, oy1 - r), math.pi / 2.0, r)),
        ("line", run_y, ((ox0, oy1 - r), (0.0, -1.0), (-1.0, 0.0))),
        ("arc", turn, ((ox0 + r, oy0 + r), math.pi, r)),
        ("line", run_x / 2.0, ((ox0 + r, oy0), (1.0, 0.0), (0.0, -1.0))),
    )


def _bay_storey_segments(inner, outer, bay, plate):
    """The phase path round the INSIDE of the bay's storey, from −X mouth edge to +X.

    IT IS THE OPEN BOX'S PLAN WALKED INDOORS. Material on the left, so the normal it hands
    back points into the room: the two front-wall cut edges, the two open flanks and the tee
    wall between them. Every segment carries its own length, so this is an arc-length walk
    like the closed outer field even though this run has no corner turns.

    ITS DATUM IS x = 0 ON THE TEE WALL — the plane the whole machine is struck about, and the
    same plane the outer plan's datum stands on, so both fields put a groove there and each is
    symmetric in x about it. It is walked from the middle out (`flute_rails`), which is why
    the segments read from one mouth edge straight through to the other.

    ITS TWO LONG OUTBOARD STRETCHES ARE AIR. From the front-wall interior plane to the tee wall
    the side wall is cut away over this whole storey (`_bay_cut`), so these two segments carry
    the global arc coordinate across each window but never become flute rails. The central
    segment carries phase across the lower tee face, which is berthed or hidden; above it the
    final closure face is on another Y plane. `flute_rails` therefore strikes only two separate
    open runs, one on each actual mouth ledge.

    AND IT DOES NOT CLOSE. What lies between the two mouth edges is the drawer, not a surface; a run
    stops at its own two ends and the field ramps out on them the way it ramps out on any edge,
    which is what keeps the flutes off the mouth arris (`flute-clears-jamb`)."""
    bx0, bx1 = bay_x_span(inner)
    fore = inner[2]                        # the flank opening begins on the front-wall plane
    aft = plate["aft_y"]                   # the tee wall's fore face, the storey's back
    ledge = bx0 - outer[0]                 # exposed front-wall section, mouth to exterior
    window = aft - fore
    return (
        ("line", ledge, ((bx0, fore), (-1.0, 0.0), (0.0, 1.0))),
        ("line", window, ((outer[0], fore), (0.0, 1.0), (1.0, 0.0))),
        ("line", outer[1] - outer[0], ((outer[0], aft), (1.0, 0.0), (0.0, -1.0))),
        ("line", window, ((outer[1], aft), (0.0, -1.0), (-1.0, 0.0))),
        ("line", ledge, ((outer[1], fore), (-1.0, 0.0), (0.0, 1.0))),
    )


def seam_cap_z():
    """THE PLANE THE Z SEAM'S OWN FURNITURE TOPS OUT UNDER, one `wall` over the lip rim.

    Under it stand the lip, the rail heads, the stop blocks and every lane the top piece
    sweeps them in; over it front-bottom stands nothing at all. So it is the plane a body
    riding in front-top has to be above before it may reach out to the side wall, and the
    floor the bay's interior flute storey is struck on. Across the removable front band the
    cradle replaces this closure; aft of the opening the ordinary seam furniture remains."""
    return z_seam + z_rise + wall


def plate_outline(plate):
    """The release band's rectangular X/Z extent within the continuous bay bulkhead."""
    x0, x1, z0, z1 = plate["x0"], plate["x1"], plate["z0"], plate["z1"]
    return [(x0, z0), (x1, z0), (x1, z1), (x0, z1)]


def bay_storey_z(bay):
    """The interior bay-surround band carrying its own flute run.

    The removable cradle itself begins lower, on the bay floor. This narrower band begins at
    the seam furniture's ceiling because that is where an exposed interior surround exists
    behind the installed cradle."""
    return seam_cap_z(), bay[2]


#: A run's point and outward normal at an arc length — `flute_skin.walk`, which is where it
#: lives because the cold core's skin is struck along runs of the same kind.
_walk = _flute_skin.walk


def plan_perimeter(outer):
    """How far it is round the box's outer plan once — what `flute_count` divides."""
    return sum(length for _kind, length, _data in _plan_segments(outer))


def flute_pitch(outer):
    """The spacing the field actually lands on. It is a CONSEQUENCE of `flute_count`, not a
    figure of its own, because a stated pitch would leave the perimeter with a remainder and
    the remainder has to go somewhere — one wrong land, at whichever station the array
    happened to close on. `flute-closes` is what holds it near the coupon's."""
    return plan_perimeter(outer) / flute_count


def plan_at(s, outer):
    """The outer plan boundary's point and OUTWARD normal at arc length `s` from the datum.

    THE PLAN CLOSES, so any `s` is on it: the walk is taken modulo the perimeter and the box
    has no station where the field restarts."""
    segments = _plan_segments(outer)
    return _walk(segments, s % sum(length for _k, length, _d in segments))


def flute_rails(box, berthed=()):
    """Every run this box's field is struck along.

    THE OUTER PLAN IS ONE OF THEM. The bay storey's two mouth ledges are two more open rails;
    its intervening windows and hidden tee span only advance the global arc coordinate
    (`_bay_storey_segments`). Every surface is struck at the same `flute_pitch` from a datum on
    x = 0, so each keeps the same phase and neither is told the other exists.

    `berthed` carries the lower cradle, top clamp and the collet plate's shadow envelope.
    What a fitted body hides is not show face and gets no flutes
    (`flute_skin._shadow_mask`); which of them hides what is measured, not listed."""
    outer = box.outer
    rails = [_flute_skin.Rail(at=lambda s: plan_at(s, outer),
                              length=plan_perimeter(outer),
                              plain=(disposal_field(outer),))]
    if box.pump_bay and box.pack.collet_plate:
        segments = _bay_storey_segments(box.inner, outer, box.pump_bay, box.pack.collet_plate)
        run = sum(length for _kind, length, _data in segments)
        cursor = -run / 2.0
        # Segments 1 and 3 cross the two open flanks, and segment 2 crosses the lower tee face
        # hidden by the installed cartridge/plate. They preserve phase between the two real
        # mouth ledges but are not cutter paths: late-fused guide and cap faces stand on their
        # opposite sides. Each ledge is open, so its two actual free edges fade normally.
        for index, segment in enumerate(segments):
            length = segment[1]
            if index in (0, 4):
                start = cursor
                one = (segment,)
                rails.append(_flute_skin.Rail(
                    at=lambda s, one=one, start=start: _walk(one, s - start),
                    length=length, start=start, closed=False,
                    band=bay_storey_z(box.pump_bay), berthed=tuple(berthed),
                    mouth=(0.0, -1.0)))
            cursor += length
    return rails


def flute_centres(outer):
    """Every groove's arc length, the datum's first. `flute_count` of them, closing on the
    perimeter exactly."""
    pitch = flute_pitch(outer)
    return tuple(k * pitch for k in range(flute_count))


@functools.lru_cache(maxsize=8)
def _rounded_outer(outer):
    """The outer box with rounded standing corners and the swept display top — the
    print silhouette the half is clipped to so nothing pokes past it. A full-width facet raises
    no new standing vertical: it runs out into the ±X walls' own rounds, which are already
    relieved.

    IT IS A PLAIN BOX AND THE SHOW SURFACE IS NOT. The flutes are cut into the MESH the printer
    reads (`flute_skin.py`), not into this solid, because the fade that stops them is a field
    over the whole surface and not a figure a prism can carry: it has to follow an opening's
    rim, a diagonal arris and a level seam with one rule. What this shape is, then, is the
    surface the flutes are measured FROM — every station in that field is struck on the plan
    this returns.
    """
    ox0, ox1, oy0, oy1, oz0, oz1 = outer
    box = _round_z(_ybox(ox0, ox1, oy0, oy1, oz0, oz1), corner_round)
    return _swept_top.silhouette(outer, box, corner_round)


def _shell_with_facet(inner, outer):
    """The curved exterior, display housing and skirt surrounds around the cavity."""
    ix0, ix1, iy0, iy1, iz0, iz1 = inner
    ox0, ox1, oy0, oy1, oz0, oz1 = outer
    a, normal, origin, dy, dz = _facet_geom(outer)
    extent = max(ox1 - ox0, oy1 - oy0, oz1 - oz0) + 100.0

    inner_box = _cavity(inner)
    outer_chamfered = _rounded_outer(outer)

    back_origin = (origin[0] - display_facet_thickness * normal[0],
                   origin[1] - display_facet_thickness * normal[1],
                   origin[2] - display_facet_thickness * normal[2])
    keepout = _halfspace(back_origin, normal, extent).intersect(
        _ybox(ox0 - extent, ox1 + extent,
              oy0 - extent, housing_back_y(outer),
              oz0 - extent, oz1 + extent))
    inner_clipped = inner_box.cut(keepout)

    shell = outer_chamfered.cut(inner_clipped)
    plane = display_plane(outer)
    for side in (-1, 1):
        shell = shell.fuse(_display_retention.stock(side).moved(cq.Location(plane)))
    return cq.Workplane(obj=shell)


def display_plane(outer):
    """The display face as a workplane centred on the glass — the frame everything let into the
    facet is struck in, and the frame `enclosure_assembly` poses the cover plate onto. Its
    +X is the box's, its +Y runs UP the slope, and its normal points out at the user, so a
    feature cut to depth `d` is extruded `-d`."""
    _a, normal, origin, _dy, _dz = _facet_geom(outer)
    center = (display_centre_x(outer), origin[1], origin[2])
    return cq.Plane(origin=cq.Vector(*center), xDir=cq.Vector(1, 0, 0), normal=cq.Vector(*normal))


def _display_cuts(outer):
    """Cover reveal, glass seat, PCB clearance and the two skirt pockets."""
    plane = display_plane(outer)
    def local(shape):
        return shape.moved(cq.Location(plane))
    inset = _swept_top.rounded_prism(
        display_inset_x, display_inset_slope, _interface.display_inset_corner_r,
        -display_inset_depth, 1.0)
    bezel = _swept_top.rounded_prism(
        display_bezel_cut_x, display_bezel_cut_slope, display_corner_r + fits.slip,
        -display_bezel_depth, 1.0)
    pcb_depth = display_facet_thickness + display_pcb_cut_through
    pcb = (cq.Workplane('XY').box(display_pcb_x, display_pcb_slope, pcb_depth + 1.0)
           .translate((display_body_offset_x, display_body_offset_slope,
                       (1.0 - pcb_depth) / 2.0)).val())
    cut = inset.fuse(bezel).fuse(pcb)
    for side in (-1, 1):
        cut = cut.fuse(_display_retention.pocket(side))
    return local(cut)


# --- wall through-holes -----------------------------------------------------

# The roof angle of every horizontal round through-hole, measured up from the print bed.
#
# THE COMMITTED BACK-TOP PET-GF PROFILE IS THE LIMIT. Its automatic-support threshold is 35
# degrees. The 36-degree exact-profile coupon is support-free, so the cutter keeps one whole
# degree of margin. The line is tangent to the nominal circle: the fitting still gets its whole
# round pass envelope below it, while no wider or taller peak is cut than this angle requires.
teardrop_roof_angle = 36.0


def _port_cuts(ports, y0, y1, up=1.0):
    """The through-holes of one wall's port list, as cutters spanning y0..y1
    (a wall's thickness with a margin either side). The pack owns both layouts,
    since it places the bodies the bands are measured from
    (../y-wall-of-back-top/README.md); the two walls differ only in which list and
    which span, so they are cut by the same code.

    A ROUND port is round through its working section and closes on the same tangent teardrop
    roof as every other Y-axis bore in these standing prints, struck on the side of the axis
    that looks print-up — `up` is the piece's print-up in the machine's frame (`_teardrop_y`).
    Rectangular connectors keep the aperture their own housings require, plus the supported
    surface allowance at the print-down roof. The opposite locating edge stays nominal."""
    out = []
    for kind, hx, hz, *size in ports:
        if kind == "round":
            out.append(_teardrop_y(size[0] / 2.0, hx, hz, y0, y1, up))
        else:
            wx, wz, *radius = size
            out.append(_supported_cut(
                _rect_cut_y(hx, hz, wx, wz, radius[0] if radius else 0.0, y0, y1), up))
    return out


def _rect_cut_y(hx, hz, wx, wz, radius, y0, y1):
    """One rectangular through-hole in a ±Y wall, spanning y0..y1, with the corner radius
    its port declares. A hole given none is cut square."""
    cut = (cq.Workplane("XY").box(wx, y1 - y0, wz)
           .translate((hx, (y0 + y1) / 2.0, hz)))
    return (cut.edges("|Y").fillet(radius) if radius else cut).val()


def _rect_cut_x(hy, hz, wy, wz, radius, x0, x1):
    """The same read on a ±X side wall, spanning x0..x1."""
    cut = (cq.Workplane("XY").box(x1 - x0, wy, wz)
           .translate(((x0 + x1) / 2.0, hy, hz)))
    return (cut.edges("|X").fillet(radius) if radius else cut).val()


@functools.lru_cache(maxsize=1)
def _disposal_flat():
    """Centered warning outlines in XY, with their bottom at zero and relief along +Z."""
    def text(line, size):
        return cq.Workplane("XY").text(
            line, size, disposal_raise + disposal_embed,
            font=disposal_font, kind=disposal_kind, combine=False,
            halign="center", valign="center").val()

    em = disposal_cap_height / text("H", 1.0).BoundingBox().ylen
    for letter in set("".join(disposal_lines)) - set(" ."):
        height = text(letter, em).BoundingBox().ylen
        if height < 6.4:
            raise ValueError(f"disposal warning {letter!r} is only {height:.3f} mm high")
    rows = [text(line, em) for line in disposal_lines]
    row_height = max(row.BoundingBox().ylen for row in rows)
    leading = row_height + disposal_line_gap
    letters = []
    for index, row in enumerate(reversed(rows)):
        bounds = row.BoundingBox()
        letters.append(row.translate(cq.Vector(
            -(bounds.xmin + bounds.xmax) / 2.0,
            index * leading + (row_height - bounds.ylen) / 2.0 - bounds.ymin, 0.0)))
    return cq.Compound.makeCompound(letters)


def disposal_letters(outer):
    """Raised letters facing +Y, reading left to right along -X with their caps along +Z."""
    ox0, ox1, _oy0, oy1, oz0, _oz1 = outer
    return (_disposal_flat()
            .rotate((0, 0, 0), (1, 0, 0), 90.0)
            .rotate((0, 0, 0), (0, 0, 1), 180.0)
            .translate(cq.Vector((ox0 + ox1) / 2.0,
                                 oy1 - disposal_embed, oz0 + disposal_bottom)))


def disposal_field(outer):
    """The flat wall under the warning, including a quiet margin on all four sides."""
    bounds = disposal_letters(outer).BoundingBox()
    field = (bounds.xmin - disposal_margin, bounds.xmax + disposal_margin,
             outer[3] - wall, outer[3] + disposal_raise,
             bounds.zmin - disposal_margin, bounds.zmax + disposal_margin)
    if field[0] < outer[0] + corner_round or field[1] > outer[1] - corner_round:
        raise ValueError("the disposal warning's flat field reaches a rounded rear corner")
    return field


def disposal_figures(outer):
    field = disposal_field(outer)
    return {
        "DISPOSAL_CAP_HEIGHT": f"{disposal_cap_height:g} mm",
        "DISPOSAL_RELIEF": f"{disposal_raise:g} mm",
        "DISPOSAL_BOTTOM": f"{disposal_bottom:g} mm",
        "DISPOSAL_FIELD_WIDTH": f"{field[1] - field[0]:.1f} mm",
        "DISPOSAL_FIELD_HEIGHT": f"{field[5] - field[4]:.1f} mm",
        "DISPOSAL_MARGIN": f"{disposal_margin:g} mm",
    }


def _nameplate(solid, plate, outer, y_outer, zlo, zhi, up=1.0):
    """Flush pocket, two rigid snap shoulders and the pump's rear bearing ledge.

    The compliant tabs belong to the face-down nameplate. The wall receives
    them through straight slots opening into the enclosure. The lower end of
    each slot gets the print-direction allowance; the retaining shoulders
    keep their flat bearing faces. The full pump-bearing top stays at its
    placement datum and receives the enclosure's supported-face compensation.
    """
    if plate is None or not (zlo <= plate.z <= zhi):
        return solid
    return _nameplate_fit.apply(solid, plate, y_outer, wall=wall,
                                supported=fits.supported_surface, up=up)


def _port_chip(px, pz, width, rise, y0, y1):
    """One station's outline as a solid spanning `y0..y1` — a D lying on its back: a half circle
    of `width` below the bore's axis, and a rectangle that wide standing `rise` above it.

    The pocket and the boss behind it are the same shape at two sizes, so both are struck here.
    Built from primitives rather than sketched, so no plane's own chirality reaches the shape."""
    r = width / 2.0
    barrel = cq.Solid.makeCylinder(r, y1 - y0, cq.Vector(px, y0, pz), cq.Vector(0, 1, 0))
    return (barrel.intersect(_ybox(px - r, px + r, y0, y1, pz - r, pz))
            .fuse(_ybox(px - r, px + r, y0, y1, pz, pz + rise)))


def _port_field(solid, field, ports, y_outer, wall_at=None, up=1.0):
    """The pocket each port chip lies in, cut INTO the +Y wall's outer face — what the customer
    meets is a flush face: colour and wall in one plane, with no pad standing off it.

    THE STOCK UNDER EVERY CHIP IS THE WALL'S OWN. The pocket is `proud` deep, and a station
    standing in a relieved band keeps `wall` and the chip's own `proud` as retained stock,
    bottoming on the nut land the wall's relief is cut to (`_back_top_wall_relief_cut`) — so
    there is nothing to fuse here. `enclosure_assembly.PORT_FIELD_WEB` is the reading that
    keeps the POCKETS apart.

    The pocket is cut on every piece it reaches, so one straddling the seam is cut on both
    halves of it. Everything the wall carries through a station it carries through that
    station's land too, so `ports` is bored here past the deepest land: the wall's holes cross
    every station whole, roofed toward the piece's print-up `up` (`_port_cuts`). The chip's
    own D pocket reads no `up`: the separately printed bulkhead ring matches it, and it is only
    `field.proud` deep."""
    if field is None:
        return solid
    at = (lambda _x, _z: wall) if wall_at is None else wall_at
    deep = y_outer
    for px, pz, _width, _rise in field.pockets:
        # WHAT THIS LOOP OWES THE BORES BELOW IS ONLY HOW FAR INBOARD A LAND CAN STAND.
        # `proud` is what a chip's pocket costs a `wall`-thick face; a wall carrying more
        # section than that has already made it back and keeps its bare inner face. Read at
        # the station, because this wall is not one thickness (`back_wall_t_at`).
        t = at(px, pz)
        proud = max(0.0, field.proud - (t - wall))
        deep = min(deep, (y_outer - t) - proud)
    for px, pz, width, rise in field.pockets:
        solid = solid.cut(_supported_cut(
            _port_chip(px, pz, width, rise, y_outer - field.proud, y_outer + 1.0), up))
    for cutter in _port_cuts(ports, deep - 1.0, y_outer + 1.0, up):
        solid = solid.cut(cutter)
    return solid


def _x_port_cuts(ports, x0, x1, up=1.0):
    """`_port_cuts` read on a ±X side wall: each hole is (kind, y, z, *size) on the
    wall's own plane, and the cutter spans x0..x1 through it. Its supported crown is opened
    toward this piece's print-up; the nominal axis and opposite edge remain fixed."""
    out = []
    for kind, hy, hz, *size in ports:
        if kind == "round":
            out.append(_supported_cut(cq.Solid.makeCylinder(
                size[0] / 2.0, x1 - x0, cq.Vector(x0, hy, hz), cq.Vector(1, 0, 0)), up))
        else:
            wy, wz, *radius = size
            out.append(_supported_cut(
                _rect_cut_x(hy, hz, wy, wz, radius[0] if radius else 0.0, x0, x1), up))
    return out


# --- funnel opening (Zone C) ------------------------------------------------

def _funnel_frame(inner, outer):
    """What the top wall has left to give the collar, `(x_lo, x_hi, y_lo, y_hi)`: BEHIND the
    display facet's own back plane, inboard of the ±X boss chains, and ahead of the back
    wall.

    THE FRONT IS A DIFFERENT KIND OF EDGE FROM THE OTHER THREE. On those three the frame runs
    out into a free edge, and the collar stands one `funnel.brim_margin` inside it: the
    flange overhangs the collar by `brim_overhang` to catch the wall and hold the funnel out of
    the box, and the margin is the wider of the two, so a full overhang's width of top wall
    still remains outboard of the brim's edge. Forward the wall runs straight on into the
    display housing, whose back is the vertical `housing_back_y` — and the slab ahead of that
    cut is what the brim's front flange lands on. The front's requirement is
    `funnel_front_ledge`, the top wall kept between that plane and the throat itself, and it
    stands in this frame. `with_funnel` asks the margin of the three free edges."""
    ix0, ix1, _iy0, iy1, _iz0, _iz1 = inner
    return (ix0 + boss_in + funnel_chain_gap,           # clear of the −X chain's bosses
            ix1 - boss_in - funnel_chain_gap,           # clear of the +X chain's bosses
            housing_back_y(outer) + funnel_front_ledge, # behind the display housing
            iy1 - wall)                                 # ahead of the +Y wall


def _funnel_hole(centre):
    """Rectangle (x0, x1, y0, y1) of the funnel opening in the top wall: the placed funnel's
    collar — funnel.py's own dims at the box's own `funnel` centre.

    The funnel is pushed as far FORWARD as `_funnel_frame` allows, and reaches aft for
    whatever plan area its capacity needs — so the opening may cross the Y seam. Both halves
    take their share of the cut and the collar bridges it; what the seam gives up there is its
    top-wall lip over the hole's span, which the mouth shelf's own relief already accounts
    for (`_funnel_cut`).

    Plan arithmetic off one centre. `with_funnel` states what that collar owes its frame."""
    cx, cy = centre
    return (cx - _funnel.collar_w / 2.0, cx + _funnel.collar_w / 2.0,
            cy - _funnel.collar_d / 2.0, cy + _funnel.collar_d / 2.0)


def _funnel_cut_plan(centre):
    """The collar opening with one running clearance on all four plan faces."""
    x0, x1, y0, y1 = _funnel_hole(centre)
    return (x0 - funnel_collar_air, x1 + funnel_collar_air,
            y0 - funnel_collar_air, y1 + funnel_collar_air)


@functools.cache
def _funnel_keepout_source():
    """The filled funnel below its brim, with normal running air on every face.

    The opening includes the liquid volume. Its top ends at the brim's underside,
    leaving the enclosure's flange-bearing surface at z = 0.
    """
    envelope, _cavity, meta = _funnel.build_solids(outer_air=funnel_collar_air)
    below_brim = (cq.Workplane("XY")
                  .box(meta["out_w"] + 2.0, meta["out_d"] + 2.0,
                       1.0 - meta["end_z"], centered=(True, True, False))
                  .translate((meta["out_cx"], meta["out_cy"], meta["end_z"] - 1.0))
                  .val())
    collar_limit = _swept_top.rounded_prism(
        _funnel.collar_w + 2.0 * funnel_collar_air,
        _funnel.collar_d + 2.0 * funnel_collar_air,
        _funnel.collar_corner_r + funnel_collar_air,
        -funnel_collar_air - 0.01, 1.0)
    brim_band = _ybox(-meta['out_w'], meta['out_w'], -meta['out_d'], meta['out_d'],
                      -funnel_collar_air - 0.01, 1.0).cut(collar_limit)
    return envelope.cut(brim_band).intersect(below_brim).clean()


def _funnel_keepout(outer, centre):
    """The funnel envelope placed with its brim underside on the enclosure top."""
    cx, cy = centre
    return _funnel_keepout_source().translate((cx, cy, funnel_seat_z(outer)))


def funnel_seat_z(outer):
    """The inset brim's bearing plane, one brim thickness below the roof."""
    return outer[5] - _funnel.brim_thickness


def with_funnel(box, centre):
    """`box` carrying the funnel collar's plan centre, and the three bounds that centre states
    against the frame the top wall has left.

    SEATING THE THROAT IS MEASURING IT, and this is the one door: a Box carries a funnel centre
    only by coming through here. The three readings are plan arithmetic on `centre` and the
    box's own two shells, taken the moment the centre is known and owing nothing to the cut the
    throat is later punched with.

    THE COLLAR IS SEATED WHICHEVER WAY THEY READ. One outside its frame is cut where it stands,
    so the throat that runs into a pod or off the facet is in the pieces to look at, beside the
    row that names it."""
    x0, x1, y0, y1 = _funnel_hole(centre)
    lims = _funnel_frame(box.inner, box.outer)
    tol = 1e-6
    inside = not (x0 < lims[0] - tol or x1 > lims[1] + tol
                  or y0 < lims[2] - tol or y1 > lims[3] + tol)
    record_bound(Bound(
        "funnel-collar-frame", "The funnel collar stands in the frame the top wall has left",
        inside,
        f"collar x {x0:.2f}..{x1:.2f}, y {y0:.2f}..{y1:.2f}",
        f"frame x {lims[0]:.2f}..{lims[1]:.2f}, y {lims[2]:.2f}..{lims[3]:.2f}",
        ([] if inside else [
            f"funnel collar (x {x0:.2f}..{x1:.2f}, y {y0:.2f}..{y1:.2f}) violates the "
            f"top-wall frame (x {lims[0]:.2f}..{lims[1]:.2f}, "
            f"y {lims[2]:.2f}..{lims[3]:.2f})"])))
    # One margin of top wall on the three sides that run out into a free edge, and the
    # brim fits it. The front is the ledge above and is measured on `lims[2]` instead.
    fits = _funnel.brim_overhang <= _funnel.brim_margin + tol
    record_bound(Bound(
        "funnel-brim-overhang", "The funnel's brim overhang fits its top-wall margin", fits,
        f"overhang {_funnel.brim_overhang:.2f} mm",
        f"within brim_margin {_funnel.brim_margin:.2f} mm",
        ([] if fits else [
            f"funnel brim overhang {_funnel.brim_overhang:.2f} exceeds its top-wall "
            f"margin {_funnel.brim_margin:.2f} — the flange hangs off the frame"])))
    # AND THE +Y EDGE IS BACK-TOP'S OWN CEILING. Aft of the throat the top surface is back-top's
    # slab, from the collar's aft edge to back-top's own +Y face, so what the brim lands on there
    # is that slab and the margin is its depth behind the collar.
    aft = back_top_wall_face() - y1
    got = (x0 - lims[0], lims[1] - x1, aft)
    clear = not any(g < _funnel.brim_margin - 1e-6 for g in got)
    record_bound(Bound(
        "funnel-brim-margin", "The funnel collar keeps a brim margin at each free edge", clear,
        f"−X {got[0]:.2f}, +X {got[1]:.2f}, +Y {got[2]:.2f} mm",
        f"each at least brim_margin {_funnel.brim_margin:.2f} mm",
        ([] if clear else [
            f"funnel collar crowds the top-wall frame: free-edge margins "
            f"(−X {got[0]:.2f}, +X {got[1]:.2f}, +Y {got[2]:.2f}) "
            f"— each owes brim_margin {_funnel.brim_margin:.2f}. Frame is "
            f"x {lims[0]:.2f}..{lims[1]:.2f}, y {lims[2]:.2f}..{lims[3]:.2f}; the collar it "
            f"has room for is {lims[1] - lims[0] - 2.0 * _funnel.brim_margin:.1f} × "
            f"{lims[3] - lims[2] - _funnel.brim_margin:.1f}"])))
    # AND THE FRONT EDGE, WHICH IS NOT A FREE ONE. Forward the flange runs out over the display
    # housing's roof, and that roof stops at the facet's own arris — the line where the 45°
    # meets the top face. A brim reaching past it overhangs the chamfer and bears on nothing.
    # The landing asked for is one `wall`, the same ligament `display-housing-seats` keeps
    # behind the display's own seats: at the arris itself the slab under the flange is a
    # feather edge, and a wall in from it the wedge is the wall's own section deep.
    arris = _swept_top.profile(box.outer)["roof"][0]
    brim_y0 = y0 - _funnel.brim_overhang
    lands = brim_y0 >= arris + wall - tol
    record_bound(Bound(
        "funnel-brim-lands", "The funnel's brim lands on top wall ahead of the throat", lands,
        f"brim front at y {brim_y0:.2f}, facet arris at {arris:.2f}",
        f"a {wall:g} mm landing, so at or aft of {arris + wall:.2f}",
        ([] if lands else [
            f"the brim's front edge stands at y {brim_y0:.2f} and the top face begins at the "
            f"facet's arris, y {arris:.2f} — the flange reaches "
            f"{arris + wall - brim_y0:.2f} mm past the landing it owes and hangs over the 45°. "
            f"Take `funnel_front_y` aft of {arris + wall + _funnel.brim_overhang:.2f}, or "
            f"shorten the facet"])))
    return box._replace(pack=box.pack._replace(funnel=centre))


def _funnel_cut(inner, outer, centre):
    """Rounded inset brim pocket and the filled, slipped funnel envelope below it."""
    cx, cy = centre
    seat = funnel_seat_z(outer)
    pocket = _swept_top.rounded_prism(
        _funnel.collar_w + 2.0 * (_funnel.brim_overhang + funnel_collar_air),
        _funnel.collar_d + 2.0 * (_funnel.brim_overhang + funnel_collar_air),
        _funnel.brim_corner_r + funnel_collar_air,
        seat, outer[5] + 1.0, cx, cy)
    throat = _swept_top.rounded_prism(
        _funnel.collar_w + 2.0 * funnel_collar_air,
        _funnel.collar_d + 2.0 * funnel_collar_air,
        _funnel.collar_corner_r + funnel_collar_air,
        inner[5] - wall - 1.0, seat + 0.01, cx, cy)
    return pocket.fuse(throat).fuse(_funnel_keepout(outer, centre))


def _ceiling_corbels(solid, inner, outer, centre, y_joint, y_bosses=()):
    """The flat ceiling's two side strips on a top piece, corbelled: a 45° underside
    rising off each ±X wall to nothing at the funnel opening's edge, so a top piece —
    printing mouth-down — lays every ceiling layer on the one below it. The strip's own
    span is wall-rooted on one side and open over the opening on the other.

    The corbel runs the housing's back plane to the Y-seam furniture's fore face, and a
    second one carries the lip's ceiling tongue, struck one `wall` lower on the tongue's
    own underside: its funnel-side span roots on the ceiling collar's chain-deep face and
    its wall-side span reaches the plug tip. Together they carry the whole tongue into the
    mouth it telescopes into; the collar band itself is the collar's own D, fill and web.

    OVER THE BOSS THE TONGUE STANDS ON THE COLLAR. The socket collar is a box `2 * socket_r`
    about its bore, so its crown is a flat land the whole width of the boss and the whole
    depth of the lip, one `socket_r` over the level the wall was pinned at, and the tongue's
    section runs straight up off it. Where a wall carries no pinned level under the tongue
    the 45° walk from the plug tip is what roots it."""
    hole_x0, hole_x1, _hole_y0, _hole_y1 = _funnel_cut_plan(centre)
    iz1 = inner[5]
    y0 = housing_back_y(outer)
    yb = _y_boss(y_joint)
    for hole_x, wall_x, sx in ((hole_x1, inner[1], -1.0),
                               (hole_x0, inner[0], +1.0)):
        deep = abs(wall_x - hole_x)
        solid = solid.fuse(_xz_prism(y0, yb - socket_r,
                                     [(hole_x, iz1), (wall_x, iz1),
                                      (wall_x, iz1 - deep)]))
        chain = wall_x - (boss_in if wall_x > 0 else -boss_in)
        tz = iz1 - wall - fits.running - ceiling_lip_drop
        solid = solid.fuse(_xz_prism(yb - socket_r, y_joint + lip_len,
                                     [(hole_x, tz), (chain, tz),
                                      (chain, tz - abs(chain - hole_x))]))
        _xs, x_tip, _xh, x_cap = _boss_x(wall_x - sx * wall, sx)
        # THE BOSS CORBEL STANDS ON THE COLLAR'S WHOLE CROWN. The half-slip belongs
        # to the plug's slide path, not to this solid collar; both sections share
        # `yb - socket_r` as their fore face, with no half-slip land between them.
        by0, by1 = yb - socket_r, y_joint + lip_len
        walk = tz - abs(x_cap - x_tip)
        crown = max((z_boss + socket_r for x_in, _x_ext, bsx, z_boss in y_bosses
                     if x_in == wall_x and bsx == sx and z_boss + socket_r < tz),
                    default=walk)
        if crown > walk:
            solid = solid.fuse(_ybox(min(x_tip, x_cap), max(x_tip, x_cap),
                                     by0, by1, crown, tz))
        else:
            solid = solid.fuse(_xz_prism(by0, by1,
                                         [(x_tip, tz), (x_cap, tz), (x_tip, walk)]))
    return solid


# --- split joint: telescoping lip + X-axis corner cross-pins ----------------
#
# Six stations cross the seam, at the floor, below the Z seam and under the ceiling
# on both ±X walls. Each mates the walls of the overlap — the back plug's −Y face on the
# back mouth, the front socket collar's +Y face on the lip rim — and the two are
# COAXIAL by construction (one y_boss, one z_boss feed both halves); the overlap
# (lip_len) is derived from exactly those matings, not chosen freely. An M3 SHCS
# drives in from the ±X exterior; outboard→inboard the joint reads: head
# counterbore, then the pin body ending on the full-thickness back flank's face,
# then the heat-set pilot filling the rest of the M3x10 span, then a one-wall cap.
#   * BACK half = PIN: a rectangular section from the ±X exterior to the heat-set,
#     continuing aft into the full-thickness flank. The upper block joins the ceiling;
#     the lower and middle stations share a jamb above the handhold. The screw-clearance and
#     head counterbore pass through both.
#   * FRONT lip = SOCKET: a collar carrying the heat-set and its deep inboard cap.
#     The upper passage opens through the ceiling tongue; the lower passage opens
#     through the handhold ceiling and Z-seam rim to receive the complete jamb.
# The head seats in the ±X wall; the shank crosses the pin body into the front
# heat-set, cross-pinning the two halves along X.
#
# Each stands on the joint's own overlap down its whole length: the plug in the back
# wall, the collar on the front lip's side band, which runs the piece's full height
# the way a telescoping lip does. The two lower levels share one jamb per wall.

def _seam_level(inner, y0, y1, want, away, limit, x_in, sx, depth):
    """A cross-pin level as close to `want` as the side walls allow, searched in
    the `away` direction (−1 below a seam, +1 above its rim) and no further than
    `limit`. The pin wants to be near the end of the piece it pins, but the
    manifold stack denies this wall a socket body over one band, so the level
    slides along the seam to the nearest height that can actually hold one. Each
    wall is searched on its own — the two are independent screws, and a height
    one wall cannot use is no reason to move the other off its seam. Returns
    None where the wall has no usable height at all; main() reports the levels
    each wall ended up with, so an absent one is visible rather than silent."""
    z = want
    while (z - limit) * away <= 0:
        if _level_clear(inner, y0, y1, z, x_in, sx, depth):
            return z
        z += away * 1.0
    return None


def _seam_middle_z():
    """The middle insert's complete collar ends on the bottom piece's Z-seam plane."""
    return z_seam - socket_r


def _handhold_levels(inner):
    """Standing floor, lifting ceiling and the full section above it."""
    bed = inner[4] - floor_t
    roof = bed + handhold_height + fits.supported_surface
    return bed, roof, roof + handhold_roof


def _seam_lower_z(inner):
    """The lower insert's complete collar stands above the handhold ceiling."""
    return inner[4] - floor_t + handhold_height + handhold_roof + socket_r


def _bosses(inner, y_joint):
    """Per-boss tuple (x_in, x_ext, sx, z_boss): the inner ±X wall face the screw
    passes through, its matching exterior face, sx = +1 (left) / −1 (right)
    inboard, and the bore-axis height.

    The Y seam runs the box's whole height and BOTH columns cross it, so it is
    pinned above the handholds, just below the Z seam and under the ceiling. Each column's
    hooked rails hold its own Z seam closed along the whole run; the three screw
    levels stand the columns against each other.

    A level sits as near the end it pins as its OWN wall allows — the two walls
    are independent screws, so each is searched separately and they need not
    agree. The manifold stack denies the −X wall a socket body over one band, so
    its levels there slide to the nearest height that can hold one.

    The upper axes stand `seam_screw_end_inset` under the ceiling. The lower pair stands
    one complete collar above each handhold's roof section; the middle pair stands one
    `socket_r` below the Z seam. Both bottom stations share the jamb over the handhold."""
    ix0, ix1, iy0, iy1, iz0, iz1 = inner
    zt = iz1 - seam_screw_end_inset
    zf = _seam_lower_z(inner)
    fy0, fy1 = _y_corner(inner, y_joint)
    out = []
    for x_in, sx in ((ix0, +1.0), (ix1, -1.0)):
        at = (lambda want, away, limit, x=x_in, s=sx:
              _seam_level(inner, fy0, fy1, want, away, limit, x, s, boss_in))
        wanted = [(zf, +1.0, zt)]                                  # a wall above the floor
        middle = _seam_middle_z()
        wanted.append((middle, -1.0, middle))                      # a complete bottom collar
        wanted.append((zt, -1.0, zf))                              # under the ceiling
        levels = []
        for want, away, limit in wanted:
            z = at(want, away, limit)
            # A level shoved this near one already placed is the same fastener
            # twice, with the two collars merged into one blob — drop it and let
            # the wall carry one there.
            if z is None or any(abs(z - k) < 2.0 * socket_r for k in levels):
                continue
            levels.append(z)
        for z_boss in sorted(levels):
            out.append((x_in, x_in - sx * wall, sx, z_boss))
    return out


def _boss_x(x_ext, sx):
    """Inboard X stations from the ±X exterior, each sized to its job: the
    screw-head seat; the pin/heat-set boundary on the full-thickness back flank's
    physical face; the heat-set pilot's blind end at the M3x10 tip; and the pod cap
    one wall past it.

    The first two stations put each pin's inboard face flush with its back flank.
    `seam_heatset_depth` absorbs the remaining screw span without moving the blind
    end or cap, and its construction above guarantees a complete insert plus the
    required screw-tip relief."""
    x_seat = x_ext + sx * head_cbore_depth
    x_tip = x_seat + sx * seam_pin_shank_len
    x_heat = x_tip + sx * seam_heatset_depth
    x_cap = x_heat + sx * socket_cap
    return x_seat, x_tip, x_heat, x_cap


def _back_plug(x_ext, sx, z_boss, y_joint, root_z):
    """The back half's Y-seam pin, mouth to full-thickness flank, exterior to insert face.

    Each pin is a rectangular block joined to its piece's end slab. The two lower stations
    share one jamb on the handhold roof; the upper station joins the ceiling. Each front passage
    opens through that same end slab."""
    _xs, x_tip, _xh, _xc = _boss_x(x_ext, sx)
    r = plug_dia / 2.0
    y0, y1 = _y_corner_back(rear_plane_y, y_joint)
    xa, xb = sorted((x_ext, x_tip))
    return _ybox(xa, xb, y0, y1, min(root_z, z_boss - r), max(root_z, z_boss + r))


def _front_socket(x_in, x_ext, sx, z_boss, y_joint, inner):
    """FRONT socket: a collar round the slot — a block standing off the ±X wall's
    inner face, from that face out to the cap over the insert's blind end, one
    `wall` of material round the slot its whole length.

    Its aft face lands on the lip rim (`_y_boss` + socket_r, which is what `lip_len`
    is struck from) and its forward face a hair ahead of the lip's own fusion
    shoulder, so it stands on the lip band down its whole length.

    THE COLLAR IS A BOX, `2 * socket_r` on a side about the bore's axis. A round pipe
    has no printable half on a standing print: tangent to the flat under it, it leaves a
    crevice either side of the touching line — an overhang that starts at zero degrees —
    and it closes overhead on a crown laid across its own bore. So the section is squared
    onto the flats it meets. The lower and middle collars share a straight jamb to
    the handhold roof; the upper collar stands on a 45° web down the lip's own face. It is also the
    footprint `seam_bosses` already reports, so what a check reads and what stands on the
    wall are one shape.

    Bore, heat-set and the plug's slide path are cut afterwards."""
    _xs, _xt, _xh, x_cap = _boss_x(x_ext, sx)
    xa, xb = sorted((x_in, x_cap))
    yb = _y_boss(y_joint)
    iz0 = inner[4]
    if z_boss < z_seam:
        return _ybox(xa, xb, yb - socket_r, yb + socket_r,
                     iz0 - floor_t, z_boss + socket_r)
    boss = _ybox(xa, xb, yb - socket_r, yb + socket_r,
                 z_boss - socket_r, z_boss + socket_r)
    if z_boss - socket_r > iz0 + 0.01:
        lip_in = x_in + sx * wall
        drop = abs(x_cap - lip_in)
        floor = z_boss - socket_r
        boss = boss.fuse(_xz_prism(yb - socket_r, yb + socket_r,
                                   [(lip_in, floor), (x_cap, floor),
                                    (lip_in, floor - drop)]))
    return boss


def _front_pin_slot(x_in, x_tip, z_boss, y_boss, y_joint, ceiling=None, floor=None):
    """The pin's straight passage, open aft, with its fore face on the Y-seam mouth.

    The upper passage opens through the ceiling tongue. Its lower face is one running
    clearance below the corner block; its inboard face is the screw/insert interface.
    The lower passage opens through both handhold ceiling and Z-seam rim. The floor scarf and
    upper pin's lower seat register the two columns vertically; the middle passage
    needs no cap over its pin."""
    b = socket_bore_dia / 2.0
    bore_y = y_boss + split_slip / 2.0
    bx0, bx1 = sorted((x_in, x_tip))
    y0, y1 = bore_y - b, y_joint + lip_len + 1.0
    roof = z_boss + b if ceiling is None else ceiling + wall + 1.0
    if floor is not None:
        roof = z_seam
    bottom = z_boss - b if floor is None else floor - 1.0
    return _ybox(bx0, bx1, y0, y1, bottom, roof)


def _front_cuts(x_in, x_ext, sx, z_boss, y_boss, y_joint, ceiling=None, floor=None):
    """The front pin passage and its coaxial heat-set pilot, past the insert interface."""
    _xs, x_tip, x_heat, _xc = _boss_x(x_ext, sx)
    heat = _xcyl(heatset_dia / 2.0, y_boss, z_boss, x_tip, x_heat)
    slot = _front_pin_slot(x_in, x_tip, z_boss, y_boss, y_joint, ceiling, floor)
    return slot.fuse(_supported_cut(heat))


def _screw_cut(x_ext, sx, z_boss, y_boss, up=1.0):
    """M3 shank clearance from the ±X exterior through the plug to the heat-set,
    plus the SHCS head counterbore at the exterior — the seat one wall outboard
    of the heat-set. The head keeps its complete round pass and bearing envelope;
    `_teardrop_x` gives only the crown on the print's up side a tangent printable
    roof. `up` is that print up along the box's Z for the piece carrying the pin, ±1."""
    _xs, x_tip, _xh, _xc = _boss_x(x_ext, sx)
    shank = _xcyl(screw_clear_dia / 2.0, y_boss, z_boss, x_ext - sx * 1.0, x_tip)
    cbore = _teardrop_x(head_cbore_dia / 2.0, y_boss, z_boss,
                        x_ext - sx * 1.0, x_ext + sx * head_cbore_depth, up=up)
    return _supported_cut(shank, up).fuse(cbore)


def _front_lip(inner, y_joint):
    """The front half's rear lip: a full-`wall` band telescoping +Y into the back
    half and running on its inner wall. It runs one `wall` back into the body
    cavity (the fusion shoulder / telescoping stop) and forward over the overlap
    to the rim.

    THE SHOULDER IS FLUSH AND THE TONGUE IS NOT, and the step between them is at
    the mouth. Fore of `y_joint` the band's outer face is the body's own inner
    wall — one solid with the body, nothing shaved. Aft of it the band stands in
    the other piece, so its three outer faces come in one `fits.running`, and the
    step they come in on is the plane the back half's mouth is struck on: it
    passes the mouth in the first millimetre of travel and leads the rest of the
    lip in behind it. Printed Z-down the side segments are
    vertical bands and the −Y mouth is a vertical face, so it needs no frame
    bevel; corners stay square, concentric with the square seam mouth it
    telescopes into (the box's rounded verticals are at the front and +Y walls, not
    the seam). The bore stays open its whole length — the fusion shoulder is the
    one-wall overlap where the band meets the body wall (out to y_joint), NOT a
    slab across the seam.

    THREE-SIDED here: both side walls and the ceiling. The floor is lapped too —
    every seam laps, none butts — but by a different means, because the floor is
    the one seam face whose inner side is not free. This proud tongue is the wall
    or ceiling continuing one `wall` INTO the cavity, and on the free faces that
    space is empty; on the floor the cold core rides there, so a proud floor tongue
    would drive straight into it. The floor's overlap therefore lives inside the
    slab as a full-thickness tongue with a 45° scarf nose (`_floor_scarf`), not
    standing proud — the right overlap for a bearing face. So the lip proper stays
    three-sided, and the floor carries its own joint. The ceiling segment remains
    a cantilever that juts one overlap past the body and wants print support; the
    floor tongue lies on the bed, and only its scarf nose rises at 45°. The side-wall
    segments, vertical to the bed, are free."""
    ix0, ix1, iy0, iy1, iz0, iz1 = inner
    y0, y1 = y_joint - wall, y_joint + lip_len
    lip_top = iz1 - ceiling_lip_drop
    shoulder = _ybox(ix0, ix1, y0, y_joint, iz0, iz1)
    tongue = _ybox(ix0 + fits.running, ix1 - fits.running, y_joint, y1,
                   iz0, lip_top - fits.running)
    inner_box = _ybox(ix0 + wall + fits.running, ix1 - wall - fits.running,
                      y0 - 1.0, y1 + 1.0, iz0 - 1.0, lip_top - wall - fits.running)
    return shoulder.fuse(tongue).cut(inner_box)


def _y_lip_channel(inner, y_joint, bosses):
    """THE Y TELESCOPE'S OWN CARVING — cut LAST of a front piece's work, so the section
    standing aft of the mouth is the section that runs in the back half's register,
    whatever the piece has since fused into that band: its own flank stock
    (`_front_top_flanks`), a socket's web, a corbel, a tray's foot. `_front_lip` draws
    the tongue at that section and this is what holds it there. `_z_rail_channels` is
    the same cut on the other seam.

    THE SOCKET BLOCKS STAND OUT OF ITS FLANKS. Fore of the mouth each block roots on the
    box's interior face; through the overlap it finishes on the tongue's slipped outer face,
    the surface which actually enters the back half. Two lower jambs and two upper collars locate
    this joint in X. The lip runs clear of the wall above the jambs, and the crowns are carved
    with everything else; no one-running-fit strip continues past the tongue beside a collar.

    The upper corner blocks travel in straight passages open through the ceiling tongue.
    The shared lower/middle jambs travel in passages open through handhold ceiling and Z seam.
    Both passages stop at the screw/insert interface in X."""
    ix0, ix1, _iy0, _iy1, iz0, iz1 = inner
    y0, y1 = y_joint, y_joint + lip_len + 1.0
    zlo, zhi = iz0 - floor_t - 1.0, iz1 + ceiling_skin + 1.0
    flanks = _ybox(ix0 - 1.0, ix0 + fits.running, y0, y1, zlo, zhi).fuse(
        _ybox(ix1 - fits.running, ix1 + 1.0, y0, y1, zlo, zhi))
    yb = _y_boss(y_joint)
    for x_in, x_ext, sx, z_boss in bosses:
        _xs, _xt, _xh, x_cap = _boss_x(x_ext, sx)
        tongue_face = x_in + sx * fits.running
        xa, xb = sorted((tongue_face, x_cap))
        flanks = flanks.cut(_ybox(xa, xb, yb - socket_r, yb + socket_r,
                                  z_boss - socket_r, z_boss + socket_r))
        _xs, x_tip, _xh, _xc = _boss_x(x_ext, sx)
        flanks = flanks.fuse(_front_pin_slot(
            x_in, x_tip, z_boss, yb, y_joint,
            ceiling=iz1 if z_boss > z_seam else None,
            floor=iz0 - floor_t if z_boss < z_seam else None))
    return flanks.fuse(_ybox(ix0 - 1.0, ix1 + 1.0, y0, y1,
                            iz1 - ceiling_lip_drop - fits.running, zhi))


def _floor_scarf(inner, y_joint):
    """The Y seam's FLOOR overlap: a bed-supported, full-thickness tongue with
    a 45° scarf nose.

    The floor is the one seam face whose cavity side is occupied — the cold core
    rides on it — so it cannot carry the proud tongue the walls and ceiling do
    (`_front_lip`). Its overlap stays within the slab instead. The FRONT floor runs
    aft at the slab's whole `floor_t` thickness, then tapers to the cavity-side datum
    over one `floor_t` — the run is the rise, which is what makes the nose 45° on a
    slab of any section; the BACK floor gives up that envelope and keeps the matching
    bed-side wedge under the nose. The tongue's broad underside is on the print bed
    and the only rising face is 45°, so neither half asks support for the core's
    bearing surface. Assembled, the top remains one plane at z=iz0.

    Each flank is a plumb face standing one `fits.running` off the side wall beside
    it. The nose is raked, and the tongue's is struck `scarf_axial` short of the
    relief's, which stands the two rakes one `fits.running` apart where they pass.

    Returns (tongue, relief): the solid the FRONT half fuses and the matching
    envelope the BACK half cuts."""
    ix0, ix1, _iy0, _iy1, iz0, _iz1 = inner
    zbed = iz0 - floor_t
    root = y_joint - 1.0                              # robust face overlap into front slab
    tongue_tip = y_joint + lip_len - scarf_axial
    tongue_flat = tongue_tip - floor_t
    relief_tip = y_joint + lip_len
    relief_flat = relief_tip - floor_t
    tongue = _yz_prism(
        ix0 + fits.running, ix1 - fits.running,
        [(root, zbed), (tongue_flat, zbed), (tongue_tip, iz0), (root, iz0)])
    relief = _yz_prism(
        ix0, ix1,
        [(root, zbed - 1.0), (relief_flat, zbed - 1.0),
         (relief_flat, zbed), (relief_tip, iz0), (root, iz0)])
    return tongue, relief


def _socket_floor_relief(x_ext, sx, inner, y_joint):
    """The back floor's recess for the front socket jamb's full-thickness foot.

    The scarf continues between these two feet. Each foot closes on a rectangular
    recess with one running clearance at its inboard and aft faces."""
    _seat, x_tip, _heat, x_cap = _boss_x(x_ext, sx)
    xa, xb = sorted((x_tip, x_cap + sx * fits.running))
    return _ybox(xa, xb, y_joint, _y_boss(y_joint) + socket_r + fits.running,
                 inner[4] - floor_t - 1.0, inner[4])


# Boss Y position — one value feeds the plug AND the socket, so they are
# coaxial by construction. Placed so the plug's −Y face mates the back mouth;
# the derived lip_len then lands the socket collar's +Y face on the lip rim.
def _y_boss(y_joint):
    return y_joint + plug_dia / 2.0


# --- handholds through the standing floor -----------------------------------

def _handhold_y():
    return handhold_y - handhold_length / 2.0, handhold_y + handhold_length / 2.0


def _handhold_cutter(inner, x_ext, sx):
    """The downward-open finger space, with round ceiling-to-end-wall corners."""
    bed, roof, _crown = _handhold_levels(inner)
    y0, y1 = _handhold_y()
    _seat, _tip, _heat, cap = _boss_x(x_ext, sx)
    xa, xb = sorted((cap - sx * handhold_wall, x_ext - sx))
    cutter = _ybox(xa, xb, y0, y1, bed - 1.0, roof)
    corners = []
    for edge in cutter.Edges():
        b = edge.BoundingBox()
        if (abs(b.zmin - roof) < 1e-6 and abs(b.zmax - roof) < 1e-6
                and b.xlen > 1.0 and b.ylen < 1e-6):
            corners.append(edge)
    return cutter.fillet(handhold_corner_r, corners)


def _handhold_backing_lap(inner, y_joint, x_ext, sx, y_side):
    """The inner wall's 45-degree plan scarf, through the height under the lifting ceiling.

    Front and back share the same three-millimetre wall. The front nose stops one running
    fit short of the back's matching rake; both slide on the enclosure's Y closure motion.
    Returns the front's trimming cut or the back's mating wall."""
    bed, roof, _crown = _handhold_levels(inner)
    _seat, _tip, _heat, cap = _boss_x(x_ext, sx)
    outer_face = cap - sx * handhold_wall
    tip = y_joint + lip_len
    short = scarf_axial if y_side == "front" else 0.0
    points = [(cap, tip - handhold_wall - short),
              (outer_face, tip - short),
              (outer_face, tip + wall), (cap, tip + wall)]
    vertices = [cq.Vector(x, y, bed - (1.0 if y_side == "front" else 0.0))
                for x, y in points]
    wire = cq.Wire.makePolygon(vertices + [vertices[0]])
    return cq.Solid.extrudeLinear(
        wire, [], cq.Vector(0, 0, roof - bed + (1.0 if y_side == "front" else 0.0)))


def _handhold_frame(inner, y_joint, x_ext, sx, y_side):
    """A roof, inner wall and two end walls, rooted on the floor at the opening's ends."""
    bed, _roof, crown = _handhold_levels(inner)
    y0, y1 = _handhold_y()
    _seat, tip, _heat, cap = _boss_x(x_ext, sx)
    xa, xb = sorted((x_ext, cap))
    start, end = ((y0 - handhold_wall, y_joint) if y_side == "front"
                  else (y_joint, y1 + handhold_wall))
    frame = _ybox(xa, xb, start, end, bed, crown)
    if y_side == "back":
        # The front socket carries the roof's inboard part through the overlap.
        xa, xb = sorted((tip, cap + sx * fits.running))
        frame = frame.cut(_ybox(xa, xb, y_joint,
                                _y_boss(y_joint) + socket_r + fits.running, bed - 1.0, crown))
        frame = frame.fuse(_handhold_backing_lap(inner, y_joint, x_ext, sx, y_side))
    return frame


def _handholds(solid, inner, y_joint, y_side):
    """Both bottom openings, including the seam's own jamb and floor tongue in their cuts."""
    bed, roof, _crown = _handhold_levels(inner)
    y0, y1 = _handhold_y()
    for x_in, sx in ((inner[0], 1.0), (inner[1], -1.0)):
        x_ext = x_in - sx * wall
        solid = solid.fuse(_handhold_frame(inner, y_joint, x_ext, sx, y_side))
        solid = solid.cut(_handhold_cutter(inner, x_ext, sx))
        if y_side == "front":
            solid = solid.cut(_handhold_backing_lap(inner, y_joint, x_ext, sx, y_side))
        solid = solid.clean()
        rim = []
        for edge in solid.Edges():
            b = edge.BoundingBox()
            if (abs(b.xmin - x_ext) < 1e-6 and abs(b.xmax - x_ext) < 1e-6
                    and b.ymin >= y0 - 1e-6 and b.ymax <= y1 + 1e-6
                    and b.zmin >= bed - 1e-6 and b.zmax <= roof + 1e-6
                    and b.zmax > bed + 1e-6):
                rim.append(edge)
        if not rim:
            raise ValueError(f"{y_side} handhold at X{x_ext:g} has no exterior lifting edge")
        solid = solid.fillet(handhold_edge_r, rim)
    return solid


# --- bottom↔top joint: the HOOKED SLIDE --------------------------------------
#
# The BOTTOM piece carries the lip, the hooked arms on its straight flank runs, the
# stop blocks at their closed ends and the corner fills; the TOP piece carries the
# foot each head stands over and the notch that swallows it. BOTH TOPS ENTER FORE OF
# HOME AND SLIDE AFT — front-top over the front wall's own plane, in open air ahead
# of the box; back-top over the open Y-seam mouth — each foot's aft end face landing
# on its stop block's, which is the column's Y datum. Everything else closes one
# `slide_slip` behind that contact.
#
# A TOP COMES OFF THE WAY IT WENT ON, FORWARD. Back-top's escape is fore into
# front-top, which stands in it. Front-top's escape is fore into open air, and what
# holds it there is the Y seam's upper pair of screws — the plug back-top carries,
# in the socket front-top's lip carries. Two screws out and front-top draws straight
# off the front of the box, the back column and whatever the box is built under
# never touched.


def _z_rail_runs(inner, y_joint, col, plate, chase=()):
    """The runs one column's rails occupy, one row per ±X flank:
    `(x_in, sx, y0, y1, lane_aft)` — where that flank carries the head, the stop
    block and the top piece's foot. Every run is OPEN at `y0` and CLOSED at `y1`, and
    which way round those fall is which way that column travels: `lane_aft` is how
    far PAST the stop the channel carries its FULL section (`_z_rail_channels`).

    THE TWO COLUMNS ARE MIRRORED, AND EACH TOP DRAWS OFF THE END OF THE BOX IT STANDS
    AT. Front-top enters fore of home and slides aft; back-top enters aft of home and
    slides fore. So the front pair parts toward the room and the back pair toward the
    wall, and neither has to be lifted over the other to come apart.

    A RUN IS WHAT THE SWEEP LEAVES, and the sweep is the whole question: a top piece
    passes over every station of the flank on the side it comes FROM, so a rail may
    stand only where that piece's own solid can open for it. On both columns what
    stands on that side is the Y-seam band — front-top's carries the TONGUE with it —
    and every one of those faces is inboard, which a channel may cut. So on both the
    lane runs clear off the piece's own end, NOTHING has to be swept around, and each
    run reaches a structural limit rather than a horizon: the front's is
    `wall + z_lip_y_margin` short of the joint, where the Y telescope's overlap
    begins; the back's is the rear wall's own corner round. The front opens on the
    tee wall (`plate["wall_aft_y"]`), the back on that same corner."""
    iy0, iy1 = inner[2], inner[3]
    out = []
    for x_in, sx in ((inner[0], +1.0), (inner[1], -1.0)):
        if col == "front":
            y0 = plate["wall_aft_y"] if plate else iy0 + column_round + wall
            y1 = y_joint - wall - z_lip_y_margin
            lane_aft = y_joint + lip_len + z_lip_y_margin
        else:
            # BACK-TOP ENTERS AFT AND SLIDES FORE — the front column mirrored, so a hand
            # draws either top off the end of the box it already stands at. WHAT SWEEPS A
            # RUN IS WHAT THE TOP CARRIES ON THE SIDE IT COMES FROM, and on this column
            # that is its own Y-seam band alone: an inboard surface a channel may open, the
            # way front-top's tongue is. So this run needs no horizon either — it reaches
            # the rear wall's own corner, and the lane runs clear off the piece's fore end.
            y0 = iy1 - corner_round
            y1 = y_joint + lip_len + z_lip_y_margin
            lane_aft = y_joint - 1.0
        out.append((x_in, sx, y0, y1, lane_aft))
    return out


def _z_rail_travel(inner, y_joint, col, plate, chase=()):
    """How far a column's top slides, entry to home — the longest run's engagement
    plus `rail_entry` of approach. One figure per column, because the piece is
    rigid and the longest rail is the one that has to clear its channel first."""
    runs = _z_rail_runs(inner, y_joint, col, plate, chase)
    return max(abs(r[3] - r[2]) for r in runs) - rail_stop_len + rail_entry


def _rail_nominal_foot_face(col, sx):
    """The common nominal flank face one column can carry through its Z-seam foot.

    A foot belongs to BOTH pieces: the top presents its caught face and the bottom carries the
    head under it. Use the shallower of their two nominal sections if those ever differ, so the
    joint never invents stock one of its pieces does not have."""
    top, bottom = ((front_top_flank_face(), front_bottom_flank_face()) if col == "front"
                   else (back_top_flank_face(), back_bottom_flank_face()))
    return min(top[0], bottom[0]) if sx > 0.0 else max(top[1], bottom[1])


def _rail_foot_face(x_in, sx, col):
    """The inboard edge of one top foot.

    Both columns carry their full nominal flank section to the caught face and place the arm
    there. The front column derives its collet-plate ends from this moving envelope, so the
    plate clears the deeper foot through the whole slide instead of truncating the wall."""
    return _rail_nominal_foot_face(col, sx)


def _rail_hook_lap(col):
    """The overlap one column's head carries over its top foot."""
    return back_hook_lap if col == "back" else front_hook_lap


def _rail_x(x_in, sx, col):
    """The rail's X stations about the foot's inboard face, read inboard: the head's
    outboard face one column-specific hook overlap back over that foot, the arm's sliding face
    `slide_slip` past it, and the arm's back."""
    x_f = _rail_foot_face(x_in, sx, col)
    x_hk = x_f - sx * _rail_hook_lap(col)
    x_a = x_f + sx * slide_slip
    x_h1 = x_a + sx * hook_arm
    return x_hk, x_f, x_a, x_h1


def _rail_channel_span(x_in, sx, col):
    """The channel cutter's two X edges and the foot face between them.

    Back-top's material-backed horizontal roof is only `x_open` to `x_f`; past the foot face,
    `x_f` to `x_d` is already open machine interior and the cutter merely clears the arm there.
    Front-top mirrors the outboard channel wall through the flank face, making one symmetric
    45-degree gable whose ridge is exactly that face."""
    x_hk, x_f, _x_a, x_h1 = _rail_x(x_in, sx, col)
    x_open = x_hk - sx * slide_slip
    x_arm_clear = x_h1 + sx * slide_slip
    x_d = x_arm_clear if col == "back" else 2.0 * x_f - x_open
    if (x_d - x_f) * sx + stated_bound_tol < (x_arm_clear - x_f) * sx:
        raise ValueError("the rail channel ends before the arm's running-clear envelope")
    return x_open, x_f, x_d


def rail_catch_air(col):
    """Running play plus one strand allowance for each print-down mating face."""
    supported_faces = 2 if col == "back" else 1
    return slide_slip + supported_faces * fits.supported_surface


def _z_rail_heads(inner, y_joint, zj, col, plate, chase=()):
    """The BOTTOM piece's whole share of its Z seam above the mouth: the hooked
    rails — an ARM standing on the mouth down each straight run, its HEAD stepping
    outboard over the groove the top's foot slides in — and the stop block closing
    each run's far end. There is no other lip: the top's own walls sweep every
    station of the flank on the way in, and outside the runs the seam is the mouth
    bearing on the shoulder with nothing proud of it.

    THE HEAD IS THE CATCH, AND ITS FACES ARE SQUARE. Its underside is flat and the
    foot's top face under it is flat: lifting the top lands the two on each other
    along the whole run, full faces bearing from the first micron. That underside
    is the joint's one down-looking flat — the column's hook overlap plus `slide_slip` proud,
    an abrupt ledge at the TOP of a piece that prints floor-down. The arm's base falls back
    to the lip's underwall on a 45° under-flare. The head's open end tapers `rail_lead` in
    plan, so the foot finds the head before the head finds it.

    THE STOP BLOCK IS THE DATUM. It fills the arm's whole section plus the head's
    lap over `rail_stop_len` at the closed end, and the foot's end face landing on
    it is the slide's home: the one nominal contact in the joint, a flat printed
    face on a flat printed face, once per rail."""
    z_foot, rim = zj + hook_foot, zj + z_rise
    catch_z = z_foot + rail_catch_air(col)
    if rim - catch_z < wall:
        raise ValueError("supported Z-rail catch leaves less than one wall of head stock")
    out = None
    for x_in, sx, y0, y1, _lane in _z_rail_runs(inner, y_joint, col, plate, chase):
        sy = 1.0 if y1 > y0 else -1.0        # open end to closed: the way this column goes
        x_hk, x_f, x_a, x_h1 = _rail_x(x_in, sx, col)
        arm = _xz_prism(y0, y1, [(x_a, zj), (x_a, catch_z),
                                 (x_hk, catch_z), (x_hk, rim),
                                 (x_h1, rim), (x_h1, zj)])
        # The arm's base falls back to the lip's underwall on a 45° under-flare, its
        # hanging face at the one angle a floor-down piece hangs anything at.
        # The under-flare roots half a millimetre outboard of the common nine-millimetre
        # face that carries this column, with the broad head lying over its full-section foot.
        wall_face = _rail_nominal_foot_face(col, sx)
        x_uw = wall_face - sx * 0.5
        drop = rail_flare_drop                    # equals abs(x_h1 - x_uw): the fall is the run
        arm = arm.fuse(_xz_prism(y0, y1, [(x_uw, zj), (x_h1, zj), (x_uw, zj - drop)]))
        # The plan taper at the OPEN end, whichever end that is: the head's lap falls back
        # to the arm's own sliding face over `rail_lead`, the cut reaching INTO the run,
        # every face of it vertical.
        lead = _xy_prism(z_foot - 1.0, rim + 1.0, (
            (x_a, y0), (x_hk - sx * 1.0, y0),
            (x_hk - sx * 1.0, y0 + sy * rail_lead)))
        arm = arm.cut(lead)
        yb0, yb1 = sorted((y1 - sy * rail_stop_len, y1))
        block = _ybox(min(x_hk, x_h1), max(x_hk, x_h1), yb0, yb1, zj, rim)
        piece = arm.fuse(block)
        out = piece if out is None else out.fuse(piece)
    return out


def _z_rail_feet(inner, y_joint, zj, col, plate, chase=()):
    """The TOP piece's foot slabs, one per rail — the material past its own wall's
    inner face that makes the mouth band a full-section FOOT for the head to stand
    over, fused before every pocket and carved to the slide's own section by the
    channel cut at the END of the piece's work.

    Each is one box: the box interior face out to the foot's face, mouth to the
    caught face, the run less the stop block — so its end face at the closed end IS
    the face that lands home. It is rooted to the wall down its whole height. Front-top
    prints that face up from its mouth; back-top prints it down from its ceiling and support
    carries it. On both columns the foot carries the full nominal flank section to the seam,
    and the hook lies over its inboard part. The collet plate's ends are derived from the
    front rail's complete moving envelope."""
    z_foot = zj + hook_foot
    out = None
    for x_in, sx, y0, y1, _lane in _z_rail_runs(inner, y_joint, col, plate, chase):
        sy = 1.0 if y1 > y0 else -1.0
        y1 -= sy * rail_stop_len
        if col == "back":
            # The open end runs one `wall` on into the rear corner column, so the foot meets
            # the column's round on its whole section instead of leaving a crescent of air
            # between its square end and the arc.
            y0 -= sy * wall
        _hk, x_f, _a, _h1 = _rail_x(x_in, sx, col)
        x_root = x_in - sx * 1.0
        slab = _ybox(min(x_root, x_f), max(x_root, x_f),
                     min(y0, y1), max(y0, y1), zj, z_foot)
        out = slab if out is None else out.fuse(slab)
    return out


def _rail_keep(inner):
    """The region a channel cut may reach — everything standing at least one `wall`
    inside the box's EXTERIOR surface, corner rounds included, struck off the outer
    faces rather than the interior ones so a wall thicker than `wall` is still openable
    behind its own show skin. A channel clipped to this can open the flank's own seam
    band and turn a corner into a pillar's base without ever nicking the surface it
    sweeps past."""
    ix0, ix1, iy0, iy1, iz0, iz1 = inner
    return _round_z(_ybox(ix0, ix1, (iy0 - front_wall) + wall, iy1,
                          iz0 - floor_t - 1.0, iz1 + wall + 1.0),
                    corner_round - wall)


def _z_rail_channels(inner, y_joint, zj, col, plate, chase=()):
    """The TOP piece's channel voids, one per rail — cut LAST of the piece's work, so
    everything the piece fused near a flank is carved to the slide's own section.

    TWO PROFILES DOWN ONE LANE. Fore of the stop face the void is the arm's berth
    and the NOTCH over the foot: inboard of the foot's face it opens from the mouth —
    the arm's own lane, `slide_slip` off its back — and outboard it opens from the
    foot's broad, flat caught face up, `slide_slip` deeper than the head, stopping one slip
    outboard of the head. On the back column the cutter has one horizontal top plane across
    its whole clearance width. In the finished part only its outboard span, from the standing
    channel wall to the foot face, closes against material; back-top's ceiling-down print
    accepts support beneath that broad roof just as it does beneath the caught face. On the front
    column alone a 45° gable closes the roof `slide_slip` over the arm's cap, so that
    mouth-down print lays nothing flat across the void. AFT of the
    stop face the front column's void is the FULL section, mouth to gable: everything
    of that piece standing aft of the stop — the flank's own seam band, the wall
    under the lip's cavity, the Y-seam tongue's own flank segment — sweeps over the
    stop block, the head and the arm on its way in, and this is the lane it does it
    in. The back column needs no deep zone: its `lane_aft` is the stop itself,
    because the rear horizon has already emptied the lane behind it.

    THE LANE RUNS OFF THE FRONT PIECE'S AFT END. It carries the full section as far
    as `lane_aft`, past the tongue's own tip, so the flank's mouth band comes out as
    one unbroken rebate from the run to the end of the piece with no blunt face
    standing in it — and nothing aft of the run is left to be swept around, which is
    what lets the run reach its own structural limit instead of a horizon. The
    tongue crosses the seam at full section ABOVE THE GABLE, which is the height the
    Y telescope actually bears on. At the front column's Y/Z crossing the channel opens
    from the flank's inboard face to the tongue's slipped outer face below one broad
    45-degree roof. That roof rises aft from the full Y-joint wall; the symmetric channel
    gable resumes above it with no separate strip between the two clearances.
    The cut is CLIPPED to `_rail_keep`, so at a corner it
    stops one `wall` inside the exterior round instead of slotting the show skin. The
    channels occupy only the inboard portion of their full-section feet and leave a complete
    exterior wall plus the uncut outer edge of the foot. Both keep the flutes' whole backing
    (`flute_backed_sections`)."""
    z_foot, rim = zj + hook_foot, zj + z_rise
    z_roof = rim + slide_slip
    keep = _rail_keep(inner)
    out = None
    for x_in, sx, y0, y1, lane_aft in _z_rail_runs(inner, y_joint, col, plate,
                                                   chase):
        sy = 1.0 if y1 > y0 else -1.0
        stop = y1 - sy * rail_stop_len
        # One slip outboard of the head is the channel's own standing wall. It lies in the
        # full-section foot, carrying the nominal flank through the seam while leaving a fixed
        # exterior skin and the foot's outer edge intact. `_rail_channel_span` supplies the
        # matching flat back cutter top or symmetric front gable from that wall. On back-top,
        # only x_open..x_f intersects material and therefore becomes the finished roof;
        # x_f..x_d is machine-interior air reserved for the arm.
        x_open, x_f, x_d = _rail_channel_span(x_in, sx, col)
        x_peak = (x_open + x_d) / 2.0
        z_peak = z_roof + abs(x_d - x_open) / 2.0
        # Back-top's broad, material-backed horizontal roof is carried by slicer support.
        # Front-top uses a gable because that piece prints with this mouth down.
        roof = ([(x_d, z_roof), (x_open, z_roof)] if col == "back" else
                [(x_d, z_roof), (x_peak, z_peak), (x_open, z_roof)])
        void = _xz_prism(y0, stop, [
            (x_open, z_foot), (x_f, z_foot), (x_f, zj - 1.0), (x_d, zj - 1.0),
            *roof])
        if (lane_aft - stop) * sy > 0:
            void = void.fuse(_xz_prism(stop, lane_aft, [
                (x_open, zj - 1.0), (x_d, zj - 1.0), *roof]))
        if col == "front":
            # THE TWO SEAMS CROSS HERE. Front-top's Y tongue ends one running-fit slip
            # inside `x_in`, while this channel's standing wall ends at `x_open`. Below the
            # roof the crossing opens the complete span from the flank's inboard face `x_f`
            # to `x_in`; `_rail_keep` leaves the exterior wall whole fore of the joint.
            # The one broad 45-degree roof from `x_open` to `x_f` rises one-for-one in Y
            # from the full wall at `y_joint`, so each returning line stands on the line
            # before it and the tongue resumes at full section above it.
            rise = lane_aft - y_joint
            floor = zj - 1.0 - rise
            crossing = _xz_prism(y_joint, lane_aft, [
                (x_f, floor), (x_in, floor), (x_in, z_roof),
                (x_open, z_roof), (x_peak, z_peak)])
            crossing = crossing.transformGeometry(cq.Matrix([
                [1.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0],
                [0.0, 1.0, 1.0, -y_joint],
            ]))
            void = void.fuse(crossing)
        void = void.intersect(keep)
        out = void if out is None else out.fuse(void)
    return out


def _lip_ring(inner, gap, z0, z1, inset=0.0):
    """One `_lip_band` skin over a height span, less the `gap` y-span — the shape both the
    lip and the wall under it are cut from, so the two come out of one figure and fuse into
    one wall with no step where they meet.

    THE TWO ASK FOR DIFFERENT GAPS, which is the whole reason this takes one rather than
    striking it. A gap is room for a telescope, and only the lip is one. And only the lip
    takes the `inset`: it is the piece that slides."""
    ix0, ix1 = inner[0], inner[1]
    ring = _lip_band(inner, (z0, z1), inset)
    return ring.cut(_ybox(ix0 - 1.0, ix1 + 1.0, gap[0], gap[1], z0 - 1.0, z1 + 1.0))


def _lip_underwall(inner, y_joint, zj):
    """The wall under a bottom piece's lip: the same skin, floor slab to the fusion
    shoulder, so the wall is `2 * wall` thick from the slab to the lip rim.

    THE LIP'S UNDERSIDE WOULD OTHERWISE BE A SOFFIT — one `wall` wide, pointing at the
    bed, running three sides of a piece that prints floor-down, with nothing under it to
    print on. A band fused onto a one-`wall` wall is a ledge; a band the wall has been
    that thick all the way up to is a wall. This is the material that makes it the second
    one, and the piece comes off the bed with no bridge in it and no support to pick out.

    IT IS NOT PART OF THE SEAM. The lip's own band rides the seam height, which is what
    `_lip_denied` reasons about and what the search moves; this stands between the floor
    and that band wherever the band ends up. What has to be clear of it is the pack, and
    the pack already stands one `wall` off both ±Y walls (`front_seam_clear`,
    `rear_seam_clear`) and one boss chain off both ±X ones (`side_band_inset`) — every
    face this skin is on. It runs to the SEAM MOUTH and not to one `wall` under it: the
    last `wall` before the mouth is no more a telescope than the first one off the slab,
    and stopping short of the mouth is what put a slit down the flank the first time. `wall-under-lip` measures that rather than assuming it, and
    `lip_face_x` is the flank a body down there meets.

    AND ITS GAP IS OPENED ONE WAY, which is where it parts from the lip's. This is wall,
    not a telescope: nothing it meets has to slide anywhere, so the only thing it owes room
    to is the OTHER piece's Y lip, aft of the joint. Carried to the joint on its own side it
    simply fuses into its own piece's Y lip and the flank comes out one unbroken `2 * wall`
    from the front wall to the Y rim. Opened the lip's way instead — off the joint in BOTH
    directions — it would stop `wall + z_lip_y_margin` short of a tongue that starts one
    `wall` short, and what stands between the two is nothing: a `z_lip_y_margin`-wide,
    one-`wall`-deep channel running the flank's whole height, blind on the slab and open
    only at the rim. That is not a gap for anything, it is a slit down the piece's most
    loaded corner — a blind channel down the one place the piece is asked to hold, and the
    slicer would draw its two faces as separate walls with nothing tying them."""
    return _lip_ring(inner, (y_joint, y_joint + lip_len + z_lip_y_margin),
                     inner[4], zj)


def mq6_chute_reach(sz):
    """How high the MQ-6's can ever rides in front-bottom's west skin, off its own station —
    `(the top of the can's sweep, the inner end of the roof closed over it)`.

    THE CARD IS ONLY HELD TO THE CHUTE'S X ONCE ITS FOOT IS IN THE POSTS' GROOVES, and a groove
    opens at the post's crown one half card above the station, so the can's highest ride is with
    the card's foot at that mouth — one whole `mq6_card_z` above where it seats. The roof closes
    at 45° ACROSS THE THREE-MILLIMETRE SKIN, not across the can's nineteen-millimetre width, so
    its rise is the skin's own depth. Read by the skin that cuts the chute and by the vent that
    has to stay a wall from it, so neither can drift off the other."""
    half = mq6_can_yz / 2.0 + mq6_slot_press
    crown = sz + mq6_card_z + half
    skin = front_bottom_flank_face()[0] - lip_face_x()[0]
    return crown, crown + skin


def _mq6_chute(sy, sz):
    """The MQ-6 can's exact straight-drop envelope through front-bottom's west skin.

    In the wall's YZ section the round can sweeps through one card height, so the opening is a
    CAPSULE: two semicircles joined by the can centre's vertical travel.  It is not the capsule's
    rectangular bounding box — those four corners are air no installed or moving part occupies.

    Across X, the wall-side section is that exact capsule.  At the skin's inboard face only its
    upper boundary has risen by the skin depth, making the printed ceiling a 45-degree roof while
    leaving the can's lower and side clearance where the can itself earns it.  The two repeated
    end sections merely carry the cut cleanly through both faces of the skin."""
    lx0, _lx1 = lip_face_x()
    fx0, _fx1 = front_bottom_flank_face()
    half = mq6_can_yz / 2.0 + mq6_slot_press
    travel = mq6_card_z
    rise = fx0 - lx0

    def profile(workplane, roof_rise):
        top_axis = sz + travel + roof_rise
        return (
            workplane
            .moveTo(sy - half, sz)
            .lineTo(sy - half, top_axis)
            .threePointArc((sy, top_axis + half), (sy + half, top_axis))
            .lineTo(sy + half, sz)
            .threePointArc((sy, sz - half), (sy - half, sz))
            .wire()
        )

    chute = profile(cq.Workplane("YZ", origin=(lx0 - 1.0, 0.0, 0.0)), 0.0)
    chute = profile(chute.workplane(offset=1.0), 0.0)
    chute = profile(chute.workplane(offset=rise), rise)
    chute = profile(chute.workplane(offset=1.0), rise)
    return chute.loft(ruled=True).val()


def _front_bottom_flank_skin(inner, west_cradle, y_joint, zj):
    """The extra skin inboard of front-bottom's two flanks, slab to seam mouth, WELLED on the
    west where the MQ-6's can reaches into it.

    The strips are struck like back-bottom's. THE WELL IS THE CAN AND NOT THE BOARD: the card
    itself stands the can's whole height off this flank and never enters the section, and what
    does enter is one Ø`mq6_can_yz` cylinder — so the well is that silhouette off the station
    (`enclosure_assembly.mq6_cradle`), opened one `mq6_slot_press` round, and the can bottoms on
    `lip_face_x` at the back of it.

    AND IT IS A CHUTE, not a pocket — THE CAN'S OWN SWEEP AND NOT A MILLIMETRE OVER IT. The card
    comes down into its posts from above carrying the can with it, so a well closed over the
    seated can's crown is a well the can cannot enter. WHAT SETS THE TOP IS WHERE THAT DESCENT
    STARTS BEING HELD TO THIS X: the card is loose in the bay's lane until its foot enters the
    grooves, and a groove opens at the post's crown one half card above the station — so the
    highest the can ever rides in this skin is with the card's foot at that mouth, one whole
    `mq6_card_z` above where it seats. Above that the card is in an open hand and the skin is
    skin. THE SECTION IS THE ROUND CAN'S SWEPT CAPSULE, not the rectangle around it: the four
    corners of that rectangle clear no installed or moving part. AND THE ROOF CROSSES THE SKIN,
    NOT THE CAN. The opening is nineteen millimetres across the can in Y but only three
    millimetres through this added skin in X. Its wall-side capsule starts on the exact top of
    the can's sweep; only that upper boundary rises at 45° to the skin's inboard face. Every
    layer therefore grows off the wall below it, while a Y gable would spend one needless can
    radius in height and leave flat three-millimetre bridges where the vent slots intersected
    it. The posts reject a card turned round on their own — the can would stand into their east
    cheeks — so nothing up here was orienting anything. Cut here rather than left to the cradle,
    because what the cradle builds is posts standing on a face and this is the face they stand
    on. THE EAST STRIP NEEDS NO WELL: the only body against that flank is the condenser's block,
    and the block is stood off this very face."""
    lx0, lx1 = lip_face_x()
    fx0, fx1 = front_bottom_flank_face()
    west = _ybox(lx0, fx0, inner[2], y_joint, inner[4], zj)
    for _sx, sy, sz in west_cradle:
        west = west.cut(_mq6_chute(sy, sz))
    return west.fuse(_ybox(fx1, lx1, inner[2], y_joint, inner[4], zj))


def _plate_foot(inner, plate, zj):
    """The two feet beneath the integral collet plate — front-bottom's own, one per end.

    The top face is the seam plane, matching the plate's `z0`. Each foot continues
    `_front_bottom_flank_skin` inboard from `front_bottom_flank_face`, forming one
    continuous land `plate_foot_reach` wide at each end. The tub is
    hollow under the plate's middle.

    Each land reaches `plate_foot_reach` inboard of the flank. Its `plate_foot_y` run is
    centred on the plate's two Y faces, with equal stock fore and aft; the mouth face
    fore of it is the flank's own, unbroken and flush.

    The underside rises at 45° from the flank. The sloped face grows off that wall and
    keeps the +X foot above the condenser+fan's complete bounding box."""
    fx0, fx1 = front_bottom_flank_face()
    t, top = plate_foot_t, zj
    ym = (plate["fore_y"] + plate["aft_y"]) / 2.0
    y0, y1 = ym - plate_foot_y / 2.0, ym + plate_foot_y / 2.0
    drop = plate_foot_reach * math.tan(math.radians(plate_foot_corbel_angle))
    out = None
    for x_face, into in ((fx0, 1.0), (fx1, -1.0)):
        x_in = x_face + into * plate_foot_reach
        foot = _xz_prism(y0, y1, [
            (x_in, top), (x_face, top),
            (x_face, top - t - drop), (x_in, top - t)])
        out = foot if out is None else out.fuse(foot)
    return out


def _plate_foot_clearance(plate, zj, xmin, xmax, ymin, ymax, zmax):
    """Least vertical air between either plate foot and one stated rectangular envelope."""
    ym = (plate["fore_y"] + plate["aft_y"]) / 2.0
    y0, y1 = ym - plate_foot_y / 2.0, ym + plate_foot_y / 2.0
    if min(y1, ymax) <= max(y0, ymin):
        return math.inf
    slope = math.tan(math.radians(plate_foot_corbel_angle))
    clearances = []
    for x_face, into in zip(front_bottom_flank_face(), (1.0, -1.0)):
        x_in = x_face + into * plate_foot_reach
        lo, hi = sorted((x_face, x_in))
        overlap_lo = max(lo, xmin)
        overlap_hi = min(hi, xmax)
        if overlap_hi <= overlap_lo:
            continue
        run = max(abs(overlap_lo - x_in), abs(overlap_hi - x_in))
        clearances.append(zj - plate_foot_t - run * slope - zmax)
    return min(clearances, default=math.inf)


def plate_foot_envelope_clearance(plate, zj, envelope):
    """Least vertical air between either plate foot's underside and a bounding box below it.

    Only the common X/Y footprint is read. The condenser+fan is carried as a calipered envelope,
    so this is the clearance its whole box receives even where its simplified solid is air."""
    return _plate_foot_clearance(
        plate, zj, envelope.xmin, envelope.xmax,
        envelope.ymin, envelope.ymax, envelope.zmax)


def plate_foot_condenser_clearance(plate, zj, pack):
    """The condenser top and least plate-foot air, from the serialized pack's own stations.

    `cond_cradle` carries the block's exact X extent and `cond_airway` carries its complete Z
    extent. The feet stand wholly inside that airway's Y band, so the two end recesses cannot
    change whether their plan footprints overlap. These are the same placed-body calipers used
    to strike those stations, available both in a live design run and in the geometry-free
    enclosure action."""
    if not (pack.cond_cradle and pack.cond_airway):
        raise ValueError("the collet-plate feet have no condenser envelope to read")
    ym = (plate["fore_y"] + plate["aft_y"]) / 2.0
    foot_y0, foot_y1 = ym - plate_foot_y / 2.0, ym + plate_foot_y / 2.0
    airway_y0, airway_y1, _airway_z0, condenser_top = pack.cond_airway
    if foot_y0 < airway_y0 - stated_bound_tol or foot_y1 > airway_y1 + stated_bound_tol:
        raise ValueError(
            f"the collet-plate foot y={foot_y0:g}..{foot_y1:g} is not wholly over the "
            f"condenser airway y={airway_y0:g}..{airway_y1:g}; its serialized stations no "
            "longer state the complete envelope needed by the documentation")
    condenser_x0 = min(station[1] for station in pack.cond_cradle)
    condenser_x1 = max(station[2] for station in pack.cond_cradle)
    return condenser_top, _plate_foot_clearance(
        plate, zj, condenser_x0, condenser_x1,
        airway_y0, airway_y1, condenser_top)


def _back_bottom_flank_skin(inner, y_joint, zj):
    """The extra skin inboard of back-bottom's two flanks, slab to seam mouth.

    IT IS TWO PLAIN STRIPS and not the cavity's own offset shell, because it is not a
    telescope and it meets no corner: the lip above it still rides `lip_face_x` and still
    wraps the standing verticals, and this stands under that, between the slab and the mouth,
    where the piece is already `2 * wall` and simply becomes `back_bottom_flank_t`.

    ITS Y RUN STARTS AFT OF THE OTHER PIECE'S Y LIP and runs to the +Y wall's inner face, so
    it fuses into that wall at one end and clears the telescope at the other. That start is the
    same plane `_lip_underwall` opens its own gap to — front-bottom's tongue reaches `lip_len`
    past the joint, and a skin struck on the joint itself is a skin drawn through it."""
    lx0, lx1 = lip_face_x()
    fx0, fx1 = back_bottom_flank_face()
    y0 = back_flank_start(y_joint)
    return (_ybox(lx0, fx0, y0, inner[3], inner[4], zj)
            .fuse(_ybox(fx1, lx1, y0, inner[3], inner[4], zj)))


# --- the pump bay's own machinery -------------------------------------------

def bay_x_span(inner):
    """The bay's two mouth edges: the side walls' interior planes.

    The pump-cartridge storey carries no front corner columns. This is the interior throat;
    the removable cradle continues through the former side skins to the appliance's exterior
    planes (`_cap_x_span`)."""
    return inner[0], inner[1]


def _pump_relief_regions(pump_trays):
    """One pocket per pump in the front wall's section, as (x0, x1, z0, z1, floor), struck
    off its station — across, the clamp collar's own half-width and a slip; in height, the
    head's hang under the station to the collar's crown over it; floored on
    `pump_relief_floor`, the plane the cradle's aft body reaches.

    ITS OWN Z0 FOLLOWS THE PUMP STATION. The fixed bay floor is struck independently by
    `bay_floor_z`; the removable block starts on that bearing plane and `_bay_cut` recesses
    only the fixed shell perimeter below it for the lower running gap."""
    out = []
    for cx, _cy, cz in pump_trays:
        hw = _tray.half_width() + 1.0
        out.append((cx - hw, cx + hw, cz - _tray.head_depth - pump_relief_z_air,
                    cz + _tray.depth() + pump_relief_z_air, pump_relief_floor))
    return out


def _front_relief_regions(pump_trays):
    """Every region the front wall's section is relieved over: the stated refrigeration
    pockets and the pumps' own."""
    return list(fridge_reliefs) + _pump_relief_regions(pump_trays)


def _front_relief_cuts(inner, regions, slip=0.0):
    """The relief pockets cut out of the front wall: a box to each region's floor, its
    ceiling rising at `relief_chamfer` to the mouth so the pocket prints in a standing
    wall with no flat over it.

    `slip` closes each pocket in by that much on all four of its standing faces and
    stands its floor that much aft — the outline a piece standing in these pockets is
    held off the wall by, which is what the cartridge face follows.

    A region whose band reaches below the cavity floor crosses into the bottom
    slab — the plate strip's running clearance. Aft of the interior plane the slab
    is material, not mouth air, so the below-floor share of the cut ends on that
    plane and rises aft at `relief_chamfer` to the cavity floor: the clearance runs
    out on a ramp, one surface from relief floor to cavity floor with no standing
    step in the slab."""
    iy0 = inner[2]
    iz0 = inner[4]
    cuts = []
    for x0, x1, z0, z1, floor in regions:
        x0, x1, z0, z1 = x0 + slip, x1 - slip, z0 + slip, z1 - slip
        floor = floor + slip
        depth = iy0 - floor
        cuts.append(_ybox(x0, x1, floor, iy0 + 1.0, max(z0, iz0), z1))
        cuts.append(_yz_prism(x0, x1, [(floor, z1), (iy0 + 1.0, z1 + depth + 1.0),
                                       (iy0 + 1.0, z1)]))
        if z0 < iz0:
            cuts.append(_yz_prism(x0, x1, [(floor, z0), (iy0, z0),
                                           (iy0 + (iz0 - z0), iz0), (floor, iz0)]))
    return cuts


def _front_floor(regions, b, name=""):
    """The front-wall surface one placed body faces: the deepest relief whose region holds
    its whole (x, z) footprint, or the interior plane itself. The compressor answers to the
    stated `fridge_reliefs` — its bbox spans both pockets while only its plate strip and
    power box cross the plane — which is the stated kiss `box-front` reads at 0.00."""
    floors = [front_plane_y]
    if name == "compressor":
        floors += [floor for _x0, _x1, _z0, _z1, floor in fridge_reliefs]
    for x0, x1, z0, z1, floor in regions:
        if (b.xmin >= x0 - 1e-6 and b.xmax <= x1 + 1e-6
                and b.zmin >= z0 - 1e-6 and b.zmax <= z1 + 1e-6):
            floors.append(floor)
    return min(floors)


def _front_flat_lip_drop(inner, zj):
    """The front wall's share of the Z lip and its underwall skin, given up across the bay.

    THE BAY FLOOR STANDS IN THIS BAND AND THE PUMP HEADS RUN DOWN THROUGH IT ON THEIR WAY
    OUT, so the flat span cannot carry a lip there at any height. Below the seam the wall is
    one `front_wall` section, slab to mouth. The exterior corner skins keep their wraps and
    the front Z-joint closes in those skins rather than in an inboard pump-bay jamb: the bay
    throat reaches both cavity side planes, so the two front pillars are subtracted from this
    cut rather than from the span it is struck on."""
    bx0, bx1 = bay_x_span(inner)
    # EVERY FACE OF THIS CUT IS THE SKIN'S OWN, not a hair past it. The skin (`_lip_band`)
    # stands exactly one `wall` proud of the cavity face and bears on the slab, so a cut struck
    # on `inner[2]`, `inner[2] + wall` and `inner[4]` takes all of it and stops. Each of those
    # three planes is a face of a body this has no business in — the front wall fore, the
    # cavity aft, the floor slab below — and two of them are datums the box stands things ON.
    # `_cond_cradle`'s fore rail stands on both: it roots on `front_plane_y`, which IS
    # `inner[2]`, and its base runs down to `inner[4]`. Reaching past either leaves that rail
    # bearing on air over the whole bay span — a tenth of a millimetre clear of the wall it is
    # the datum off, bridging a millimetre notch in the slab — and joined to the piece along
    # the one line y = inner[2] + wall, z = inner[4]. That line is an edge with four faces:
    # rail and slab meeting along an arris with no volume between them, which is a
    # non-manifold edge and what a slicer refuses the file for. Aft the same rule reads off
    # the cavity — an overshoot there runs out at the jamb, where the wall has already turned,
    # and leaves faces of no width at all, six edges under a micron.
    drop = _ybox(bx0, bx1,
                 inner[2], inner[2] + wall,
                 inner[4], zj + z_rise + 1.0)
    for sx, sy in column_corners:
        if sy < 0:
            drop = drop.cut(_column_pillar(inner, sx, sy, zj))
    return drop


def _pump_full_width_band(inner, outer, bay, pump_trays, y_aft,
                          lower_inset=0.0, upper_inset=None):
    """The complete removable front-wall band, clipped only by the appliance silhouette.

    It begins on the outside of the front face, runs aft to `y_aft`, and owns both former
    front-top side skins as well as the flat face between them. The fixed opening uses neither
    inset. The cradle uses `lower_inset` and `upper_inset` for its flat running gaps above the
    sill and below the lintel. Omitting `upper_inset` keeps a symmetric inset for callers that
    state one figure."""
    upper_inset = lower_inset if upper_inset is None else upper_inset
    z0 = bay_floor_z(pump_trays)[1] + lower_inset
    z1 = bay[2] - upper_inset
    return _rounded_outer(outer).intersect(
        _ybox(outer[0] - 1.0, outer[1] + 1.0,
              outer[2] - 1.0, y_aft, z0, z1))


def _pump_cartridge_outer(outer):
    """The lower cradle's plan silhouette, flush with the fixed enclosure.

    The front wall reaches the cartridge's show plane, so the same outline supplies its front,
    rounded corners and side faces. The pump station remains one flute depth behind that plane;
    the field's groove floors therefore retain the pocket's complete printable backing."""
    return outer


def _pump_upper_x_span(cx):
    """One upper insertion well's X faces, on the tube pair's exact outer boundary."""
    return cx - cap_slot_half, cx + cap_slot_half


def _pump_front_smooth_skin(pump_trays):
    """Smooth stock between the flush face and the clamp's upper insertion wells."""
    return _pump_upper_well_fore_y(pump_trays) - pump_cartridge_front_y


def _pump_upper_well_fore_y(pump_trays):
    """The upper well's flat fore face, one running clearance ahead of the clamp."""
    return (min(cy - _tray.half_width() for _cx, cy, _cz in pump_trays)
            - clamp_drop_air)


def _pump_upper_well_aft_y(plate):
    """The upper insertion wells open through the cartridge's flat aft face."""
    return bay_back_y(plate)


def _pump_cartridge_front_flute_rail(outer):
    """The flush face and its two front corner turns, on the enclosure's flute datum.

    This open rail covers the front half of the same plan the fixed walls carry. The side rail
    takes over at both tangencies, so the cartridge retains the enclosure's phase without a
    translated step or a plain return."""
    face = _pump_cartridge_outer(outer)
    front_run = (face[1] - face[0] - 2.0 * corner_round) + math.pi * corner_round
    return _flute_skin.Rail(
        at=lambda s: plan_at(s, face), length=front_run,
        start=-front_run / 2.0, closed=False)


def _pump_cartridge_side_flute_rail(outer):
    """The enclosure-phase field on the cartridge's two outer side faces.

    This open run starts at the +X front tangency, walks round the back of the box and ends at
    the -X front tangency. The front rail carries the face and its two corner turns; this rail
    carries the two cartridge flank bands on the same unbroken plan and phase."""
    segments = _plan_segments(outer)
    start = sum(length for _kind, length, _data in segments[:2])
    length = sum(length for _kind, length, _data in segments[2:7])
    return _flute_skin.Rail(
        at=lambda s: plan_at(s, outer), length=length,
        start=start, closed=False)


def _bay_cut(inner, outer, bay, pump_trays, plate):
    """The full-width opening between the sill, lintel and flat rear bulkhead."""
    return _supported_cut(_pump_full_width_band(
        inner, outer, bay, pump_trays, bay_back_y(plate), lower_inset=0.0))


def bay_back_y(plate):
    """The bulkhead's cartridge-facing plane, continuous from floor to lintel."""
    return plate["fore_y"]


def _front_top_flank_bedding_cut(inner, y0, y1, zj):
    """The air under front-top's two grown flank faces over one Y band.

    Each physical flank begins on the seam rim at the box's interior face and rises at 45
    degrees to its own six-millimetre-inboard face. Below that start the room side is open all
    the way to the bed. Material belonging to another construction may meet the face, but may
    not continue below either part of that boundary as a second, offset skin. Keeping the exact
    two prisms in one helper lets the flank itself, the Y tongue and a wall-to-wall valve tray
    all finish on the same planes."""
    ix0, ix1 = inner[0], inner[1]
    fx0, fx1 = front_top_flank_face()
    rim = zj + z_rise
    out = None
    for x_in, x_face in ((ix0, fx0), (ix1, fx1)):
        cut = _xz_prism(y0, y1, [
            (x_in, zj - 1.0), (x_face, zj - 1.0),
            (x_face, rim + abs(x_face - x_in)),
            (x_in, rim),
        ])
        out = cut if out is None else out.fuse(cut)
    return out


def _front_top_flanks(inner, outer, box, y_joint, zj):
    """THE SECTION FRONT-TOP'S ±X WALLS CARRY BEYOND `wall`, standing inboard of `interior_x`
    (`front_top_flank_t`). Fused before any of this piece's flank furniture, so a pocket, a
    well or a port cut afterwards is cut out of the whole of it.

    THE FACE CONTINUES THROUGH THE SEAM AS EACH RAIL'S FOOT. `_z_rail_feet` carries the
    section from `interior_x` to this same nominal face, mouth to caught face. Front-bottom's
    head overlaps the inboard five millimetres of that foot and places its arm one
    `slide_slip` beyond it (`_z_rail_heads`). The channel cut then carves the arm's berth and
    its 45° roof out of only that inboard stock. The mouth bears on the shoulder; the rails
    register and retain.

    The pump-bay bulkhead joins this stock from its flat fore face to the tee-journal
    datum. The slide channels begin aft of that datum."""
    ix0, ix1, _iy0, _iy1, _iz0, iz1 = inner
    fx0, fx1 = front_top_flank_face()
    plate = box.pack.collet_plate
    y0, y1 = outer[2] - 1.0, y_joint + lip_len
    rim = zj + z_rise
    band = None
    for x_in, x_face in ((ix0, fx0), (ix1, fx1)):
        seg = _ybox(min(x_in, x_face), max(x_in, x_face), y0, y1, rim, iz1)
        band = seg if band is None else band.fuse(seg)
    # AND ITS UNDERSIDE RISES AT `relief_chamfer` INSTEAD OF HANGING. This piece beds on
    # its own seam rim and builds in +Z, so a section square at the rim would put a
    # `depth`-wide ledge over the tongue's lane pointing straight at the plate — the
    # soffit `_lip_underwall` exists one storey down to avoid. Taken back at 45° it is a
    # wall the print grows into off the flank it stands on. The same helper finishes every
    # construction which meets this face.
    band = band.cut(_front_top_flank_bedding_cut(inner, y0 - 1.0, y1 + 1.0, zj))
    # Everything this piece's own walls were already bored for, struck out before the section
    # is fused rather than re-cut after it: the Y seam's bosses, whose cuts were made in
    # `build_front_half`, and the panel holes through both faces.
    yb = _y_boss(y_joint)
    for x_in, x_ext, sx, z_boss in box.y_bosses:
        band = band.cut(_front_cuts(
            x_in, x_ext, sx, z_boss, yb, y_joint,
            ceiling=iz1 if z_boss > z_seam else None,
            floor=inner[4] - floor_t if z_boss < z_seam else None))
    for cutter in _port_cuts(box.pack.front_ports, outer[2] - 5.0, inner[2] + 5.0):
        band = band.cut(cutter)
    for cutter in _x_port_cuts(box.pack.east_ports, fx1 - 5.0, outer[1] + 5.0):
        band = band.cut(cutter)
    for cutter in _x_port_cuts(box.pack.west_ports, outer[0] - 5.0, fx0 + 5.0):
        band = band.cut(cutter)
    return band


def _back_top_wall(inner, outer, box, zj, up=1.0):
    """THE SECTION BACK-TOP'S +Y WALL CARRIES BEYOND `wall`, standing inboard of `rear_plane_y`
    (`back_top_wall_t`). Fused before this piece's own back-wall work, so the port field's
    pockets, the C14's bores and the nameplate's seat are all cut out of the whole of it.

    IT BEGINS AT THE RIM AND NOT AT THE MOUTH. What stands in this wall below the rim is
    back-bottom's own tongue, and the lane it rises into is exactly the section this would add —
    so there is nothing to add there. Below the rim that wall is already `2 * wall`, carried to
    the slab as the lip's own skin (`_lip_underwall`); above it, this. One section, top to
    bottom, and the rim is where the two meet rather than a step in either.

    `up` IS THE PIECE'S PRINT-UP IN THE MACHINE'S FRAME, and it decides how the section starts
    on the rim. For `up < 0` (`BACK_TOP_UP`) the piece beds on its ceiling's outer face, the
    section's face on the rim looks print-up, and it starts square: a free flat, and the whole
    section stands on the rim. For `up > 0` the piece beds on its seam rim, that same face
    looks print-down over the lip's lane, and it rises at `relief_chamfer` off the rim instead,
    the way `_back_top_flanks`' does on the two walls that turn out of this one — what the ramp
    gives up is `depth` of height in a band the lip's travel never reaches. Every hole and
    relief in the wall reads the same `up` (`_port_cuts`, `_back_top_wall_relief_cut`)."""
    ix0, ix1, _iy0, iy1, _iz0, iz1 = inner
    rim, depth = zj + z_rise, back_top_wall_t - wall
    band = _ybox(ix0, ix1, back_top_wall_face(), iy1, rim, iz1)
    if up > 0:
        band = band.cut(_yz_prism(ix0 - 1.0, ix1 + 1.0,
                                  [(iy1, rim), (back_top_wall_face(), rim),
                                   (back_top_wall_face(), rim + depth)]))
    # The wall's own holes, bored in `build_back_half` before this stood here.
    for cutter in _port_cuts(box.pack.back_ports, iy1 - 5.0, outer[3] + 5.0, up):
        band = band.cut(cutter)
    return band.cut(_back_top_wall_relief_cut(box.pack.port_field, up))


def _back_top_wall_relief_cut(field, up=1.0):
    """Every station's relief. One hosting no port station is the whole extra section given
    back — floored on `rear_plane_y`, its print-roof rising at `relief_chamfer` to the mouth —
    so what clamps on that face lands on the section it always had (the C14's tunnel roots on
    exactly that emptied plane).

    A RELIEF WITH A PORT STATION IN IT IS A NUT LAND AND NOT A POCKET. What the CO2 station
    needs is `port_clamp_stack` and not `wall`: the wall keeps the whole clamped section —
    `wall` of skin plus the chip's own `field.proud` — and gives back only the last millimetre
    down to the land, as ONE drafted plug from the wall's own face to the land's outline. Its
    two sides and its print-floor edge run `station_land_draft` in plan for the depth they
    fall; its print-roof edge keeps the relief's own `relief_chamfer` line. Cut as one solid,
    there is no emptied pocket for a boss to make back, so the one-millimetre perimeter ledge a
    boss-in-pocket leaves cannot exist.

    THE PRINT-ROOF IS THE ONLY FACE THAT NEEDS THE ANGLE, the same way the pump reliefs'
    ceilings do: the wall stands vertical on the bed, so a pocket's print-floor is printed on
    and its sides stand on their own section, and what would be laid over air is the run at the
    print-top. `up` is the piece's print-up in the machine's frame and says which edge that is:
    the pocket's machine-top edge `rz + hz` for `up > 0`, its machine-bottom edge `rz - hz` for
    `up < 0` (`BACK_TOP_UP`). The angled face runs from that edge at the mouth to one `depth`
    (or one `fall`) toward print-down at the floor, and the opposite edge is flat."""
    face, floor = back_top_wall_face(), rear_plane_y
    depth = floor - face
    pockets = field.pockets if field is not None else ()
    out = None
    for _who, rx, rz, wx, wz in back_top_wall_reliefs:
        hx, hz = wx / 2.0, wz / 2.0
        # The pocket's print-roof edge and its print-floor edge, in the machine's Z.
        roof, sill = rz + up * hz, rz - up * hz
        landed = any(abs(px - rx) <= hx and abs(pz - rz) <= hz
                     for px, pz, _w, _r in pockets)
        if landed:
            land_y = floor - field.proud
            fall = land_y - face                # the retained stock's one millimetre
            d = station_land_draft
            x0, x1 = rx - hx, rx + hx

            def ring(y, g, gt):
                # `g` is the draft's growth on the sides and the sill, `gt` the chamfer's on
                # the roof, each read outward from the land's own outline.
                za, zb = sill - up * g, (roof - up * fall) + up * gt
                zlo, zhi = min(za, zb), max(za, zb)
                return cq.Wire.makePolygon(
                    [cq.Vector(x0 - g, y, zlo), cq.Vector(x1 + g, y, zlo),
                     cq.Vector(x1 + g, y, zhi), cq.Vector(x0 - g, y, zhi)],
                    close=True)
            cut = cq.Solid.makeLoft(
                [ring(face - 1.0, d, fall), ring(face, d, fall), ring(land_y, 0.0, 0.0)],
                True)
        else:
            back = roof - up * depth            # the roof's line on the relief's floor
            cut = _ybox(rx - hx, rx + hx, face, floor, min(sill, back), max(sill, back))
            cut = cut.fuse(_yz_prism(rx - hx, rx + hx,
                                     [(face, back), (floor, back), (face, roof)]))
        out = cut if out is None else out.fuse(cut)
    return out


def _back_top_flank_tie_cut(box):
    """The ASSE anchor's shared zip-tie cavity opens upward into the air under the ceiling.
    Its span comes from the placed cradle's two tie bands, so the added flank stock gives up the
    one continuous mouth from the cavity's own west edge to the nominal face. It runs to the
    ceiling and needs no roof: the slab is open to the lane over the same span
    (`_ceiling_tie_channel_relief`)."""
    if not box.pack.asse_cradle:
        return None
    z_axis, _sections, ties, _dn = box.pack.asse_cradle
    face, floor = back_top_flank_face()[0], lip_face_x()[0]
    mouth_z = z_axis + asse_cradle_up + 1.0
    tie_y0, tie_y1 = _asse_tie_channel_span(ties)
    return _ybox(min(face, floor), max(face, floor), tie_y0, tie_y1,
                 mouth_z, box.inner[5] + 1.0)


def _flank_body_pockets(piece, pockets):
    """Body clearance in the west flank with a supported, 45-degree lower return.

    Back-top prints ceiling-down. The return below the pocket closes that small
    recess progressively while its locating barrel seat stays untouched.
    """
    for _name, x0, x1, y0, y1, z0, z1 in pockets:
        depth = x1 - x0
        piece = piece.cut(_xz_prism(y0, y1, [
            (x0, z0), (x0, z1), (x1 + 1.0, z1),
            (x1 + 1.0, z0 - depth - 1.0)]))
    return piece


def _front_top_flank_pockets(piece, pockets):
    """Shallow native-yoke pockets with complete wall stock and 45-degree roofs."""
    for name, x0, x1, y0, y1, z0, z1 in pockets:
        side = 1.0 if x0 + x1 > 0.0 else -1.0
        face, floor = sorted((abs(x0), abs(x1)))
        depth = floor - face
        remaining = appliance_width / 2.0 - floor - _interface.flute_depth
        if remaining < wall - stated_bound_tol:
            raise ValueError(f"{name} flank pocket leaves only {remaining:g} mm behind fluting")
        piece = piece.cut(_xz_prism(y0, y1, [
            (side * (face - 1.0), z0), (side * floor, z0),
            (side * floor, z1), (side * (face - 1.0), z1 + depth + 1.0),
        ]))
    return piece


def _back_top_flanks(inner, outer, box, y_joint, zj, up=1.0):
    """THE SECTION BACK-TOP'S ±X WALLS CARRY BEYOND `wall`, standing inboard of `interior_x`
    (`back_top_flank_t`). Fused before any of this piece's flank furniture, so the Wago wells,
    the +X mounting bosses and every bore below are cut out of the whole of it. `up` is the
    piece's print up along the box's Z, ±1; the section's underside at the rim and its resume
    over the pan sleeve's lid answer to it.

    IT BEGINS PAST THE Y TELESCOPE. The front half's lip runs to `y_joint + lip_len` on this
    wall surface (`_front_lip`), and in Y the band starts where `_lip_underwall` starts one
    storey down, `z_lip_y_margin` past that rim, so the closing front half never lands on its
    step. In Z the nominal band starts over the hooked rail's rim on a mouth-down print, the
    way `_back_top_wall` does, and at the foot's caught face on the ceiling-down one; below it
    `_z_rail_feet` carries the full nominal section from the seam mouth to the
    caught face, with the arm and its broad back-column head placed at that face's inboard edge.
    The channel cut runs last and opens exactly that moving profile. Every back plug reaches
    this Y plane, so its registration section roots directly in the full-thickness flank.

    AND THE PAN'S SLEEVE KEEPS ITS BLOCK. The ASSE drip pan withdraws through this flank, and the
    pack states the sleeve as one box rooted on the wall's own inner face with the berth cut back
    out of it (`_pan_sleeve`). Struck out of this section rather than re-cut through it: the tray
    stays where it is and at the size it is, and what stands round it is the sleeve's own section
    instead of this one."""
    ix0, ix1, _iy0, iy1, _iz0, iz1 = inner
    fx0, fx1 = back_top_flank_face()
    y0 = back_flank_start(y_joint)
    # Over the rail's rim on a mouth-down print; down to the foot's caught face on the
    # ceiling-down one, so the channel's standing wall outboard of the notch is this section's
    # own and the foot's outer edge carries nothing over air.
    rim = zj + z_rise if up > 0 else zj + hook_foot
    depth = back_top_flank_t - wall
    band = None
    for x_in, x_face in ((ix0, fx0), (ix1, fx1)):
        seg = _ybox(min(x_in, x_face), max(x_in, x_face), y0, iy1, rim, iz1)
        # ITS UNDERSIDE ANSWERS TO THE PRINT. With `up` positive the piece beds on its seam rim
        # and builds in +Z, and a section square at the rim would put a `depth`-wide ledge over
        # the lip's lane pointing straight at the plate — the soffit `_lip_underwall` exists one
        # storey down to avoid; taken back at `relief_chamfer` it is a wall the print grows
        # into, and what the ramp gives up is `depth` of height in a band that has nothing
        # standing in it. With `up` negative the piece beds on its ceiling, the underside is
        # the band's own top face in the print, and the section stands square from the rim.
        if up > 0:
            seg = seg.cut(_xz_prism(y0 - 1.0, iy1 + 1.0,
                                    [(x_in, rim), (x_face, rim), (x_face, rim + depth)]))
        band = seg if band is None else band.fuse(seg)
    for bx0, bx1, by0, by1, bz0, bz1 in box.pack.pan_sleeve[0]:
        band = band.cut(_ybox(bx0 - 1.0, bx1 + 1.0, by0, by1, bz0, bz1))
        # AND WHERE IT RESUMES OVER THE BLOCK'S LID IT TAKES THE SECTION IT TAKES AT THE RIM.
        # With `up` positive that is the `relief_chamfer` ramp on the same plane: what the
        # block's mouth leaves standing here is this section's `depth`, and struck square it is
        # a ledge over the pan's opening. With `up` negative the resume is square, its face on
        # the lid looking print-up.
        if up > 0:
            band = band.cut(_xz_prism(by0, by1,
                                      [(bx0, bz1), (fx0, bz1), (fx0, bz1 + depth)]))
    # The PRV chase stands its own share of this band later (`_vent_chase`): each piece
    # carries the height of the rib it owns, so neither crosses into the other's travel.
    # The one thing this wall was already bored for on the back half: the tray's own withdrawal
    # slot, cut in `build_back_half` before this stood here.
    for cutter in _x_port_cuts(box.pack.west_ports, outer[0] - 5.0, fx0 + 5.0, up=up):
        band = band.cut(cutter)
    relief = _back_top_flank_tie_cut(box)
    return band.cut(relief) if relief is not None else band


def _ceiling_tie_reliefs(box, lane):
    """The pockets over the ceiling's own anchors where a zip tie has to pass: each anchor's tie
    band and no more of the rib's length — the rib's reach plus the tie's thickness and its
    routing air either side, from the axis plane up to the channel's roof, one
    `tube_anchor_cavity_depth` over the crown on the flow meter's anchors and the tube ribs
    alike. The rib itself is fused back afterwards; what stays open is the tie's own room round
    the band."""
    face = back_top_ceiling_face()
    pockets = []
    meter = box.pack.flow_meter_anchors
    if meter:
        x_axis, z_axis, seat_r, bands = meter
        reach = seat_r + flow_meter_anchor_wall + tie_t + tie_cav_buffer
        roof = min(lane, z_axis + seat_r + wall + tube_anchor_cavity_depth
                   + fits.supported_surface)
        for by0, by1 in bands:
            mid = (by0 + by1) / 2.0
            pockets.append(_ybox(x_axis - reach, x_axis + reach,
                                 mid - tie_cav_w / 2.0, mid + tie_cav_w / 2.0,
                                 face - 1.0, roof))
    for mid, u, n, seat_r, *_stand in (box.pack.tube_anchors or ()):
        if tuple(int(round(c)) for c in n) != (0, 0, 1):
            continue
        origin = tuple(mid[k] - u[k] * tube_anchor_len / 2.0 for k in range(3))
        band = tuple(origin[k] + u[k] * tie_cav_wall for k in range(3))
        crown = seat_r + wall
        pockets.append(_anchor_rib(band, u, n, tie_cav_w,
                                   crown + tie_t + tie_cav_buffer, 0.0,
                                   min(lane - mid[2], crown + tube_anchor_cavity_depth
                                       + fits.supported_surface)))
    return pockets


def _ceiling_tie_channel_relief(box, lane):
    """The tap-water chain's shared tie channel through the slab: over the span the two zip ties
    take (`_asse_tie_channel_span`), from back-top's -X flank face east to the far edge of the
    chain's own pocket, the lane is open. A loop comes west over the chain's crown through the
    lane and drops into the anchor's cavity through the mouth the flank leaves it
    (`_back_top_flank_tie_cut`)."""
    if not box.pack.asse_cradle:
        return None
    _z_axis, _sections, ties, _dn = box.pack.asse_cradle
    tie_y0, tie_y1 = _asse_tie_channel_span(ties)
    fx0, _fx1 = back_top_flank_face()
    candidates = [x1 for who, _x0, x1, y0, y1, _top in box.pack.ceiling_reliefs
                  if who == "asse1022-assembly" and y0 <= tie_y1 and y1 >= tie_y0]
    if not candidates:
        raise ValueError("the ASSE tie channel has no chain ceiling pocket to open into")
    east = max(candidates)
    if east <= fx0 + stated_bound_tol:
        raise ValueError(
            f"the ASSE tie channel ends at x={east:.3f}, not inboard of its flank mouth "
            f"x={fx0:.3f}")
    return _ybox(fx0, east, tie_y0, tie_y1, back_top_ceiling_face() - 1.0, lane)


def _back_top_ceiling(solid, inner, y_joint, box):
    """Back-top's ceiling slab fused on: the stock between the grown flanks, less the funnel's own
    plan, less every pocket the pack, the ceiling's anchors and the tie channel ask of it. Fused
    and cut before this piece's own furniture, the way its two sections are, so a rib rooted on
    the lane is fused into the pocket the slab left it, and the ASSE anchor's V, the chain's
    bores and the wells are cut out of the slab where they reach it."""
    lane = inner[5]
    face = back_top_ceiling_face()
    stock = back_top_ceiling_stock(y_joint, lane)
    if box.pack.funnel:
        x0, x1, y0, y1 = _funnel_cut_plan(box.pack.funnel)
        stock = stock.cut(_ybox(x0, x1, y0 - 1.0, y1, face - 1.0, lane + 2.0))
    for who, x0, x1, y0, y1, top in box.pack.ceiling_reliefs:
        if who == "c14-inlet":
            cx, cz, _wx, _wz, _r = _c14_aperture(box.pack.c14, box.pack.back_ports)
            pocket = (c14_pocket_prism(c14_pocket_slip, y0, y1)
                      .translate((cx, 0.0, cz)).val())
            stock = stock.cut(pocket)
            continue
        roof = min(top, lane)
        if roof <= face + stated_bound_tol:
            continue
        stock = stock.cut(_ybox(x0, x1, y0, y1, face - 1.0, roof))
    for pocket in _ceiling_tie_reliefs(box, lane):
        stock = stock.cut(pocket)
    channel = _ceiling_tie_channel_relief(box, lane)
    if channel is not None:
        stock = stock.cut(channel)
    return solid.fuse(cq.Workplane(obj=stock).clean().val())


def _pump_cartridge_face_region(inner, outer, bay, pump_trays, plate):
    """The exterior shell the lower cradle owns.

    It spans the complete rounded front and both side skins through the cradle's Y+ edge.
    Its show face shares the fixed enclosure's front plane, with one flute depth between that
    plane and the pump pocket datum. The same corner radius returns into the side planes. That
    complete plan begins on the cradle's own bed plane and continues plumb to one flat
    `pump_cartridge_top_clearance` below the lintel, without a bevel, ramp, starter strip or shelf.
    The matching lower Z clearance is cut into the fixed shell perimeter by `_bay_cut`, outside
    the interior bearing floor."""
    proud = _pump_cartridge_outer(outer)
    return _pump_full_width_band(
        inner, proud, bay, pump_trays, pump_cartridge_aft_y(pump_trays, plate),
        lower_inset=0.0, upper_inset=pump_cartridge_top_clearance)


def cap_split_z(pump_trays):
    """The holder station datum; the seated physical flange lies pump_seated_drop below it."""
    return min(cz for _cx, _cy, cz in pump_trays)


def cap_drop_start_z(pump_trays):
    """The upper insertion wells' tolerance-overlapped start below the bracket plane."""
    return cap_split_z(pump_trays) - 0.001


def cap_base_z(pump_trays):
    """The fitted cap's broad underside, two millimetres above its holder datum."""
    return cap_split_z(pump_trays) + cap_bridge_rise


def cap_terminal_opening_z(box):
    """The fitted motor bore's upper end; the wider open crown begins here."""
    return (max(cz for _cx, _cy, cz in box.pack.pump_trays)
            + _tray.motor_crown + bay_crown_air - pump_cartridge_z_clearance)


def cap_crown_z(box):
    """The surrounding crown meets the cartridge's top edge around two open motor ends."""
    return box.pump_bay[2] - pump_cartridge_top_clearance


def cap_head_seat_z(box):
    """Each clamp screw's head seat, struck from the screw itself: the M3×60's tip lands at the
    blind end of the cradle's long insert. The crown-down print retreats that bridged annulus
    by the supported-surface allowance; the pilot gives the screw tip the same extra depth."""
    return (cap_split_z(box.pack.pump_trays) - cap_heatset_len + cap_screw_len
            + PIECE_PRINT_UP["pump-cap"] * fits.supported_surface)


def pump_skirt_support_z(pump_trays):
    """The fitted flat land; the physical skirt rests here below the holder station datum."""
    return cap_split_z(pump_trays) - _tray.skirt_depth - _interface.pump_seated_drop


def pump_skirt_band_aft_y(pump_trays):
    """Where the skirt opening's 3 mm upper band ends: the least Y+ the cradle keeps."""
    return max(cy + _tray.skirt_open_y_max + _tray.skirt_upper_band
               for _cx, cy, _cz in pump_trays)


def pump_cartridge_aft_y(pump_trays, plate):
    """The cartridge's one flat back, cradle and clamp alike: the bay bulkhead less its kiss.

    At full seat the tubes are bottomed and the carrier is on its aft stop. The flat back
    preserves the complete skirt band, spending at most one hundredth of a millimetre of the
    preferred plate air when the independently stated measured stations meet there."""
    nominal_aft = bay_back_y(plate) - cap_kiss
    band = pump_skirt_band_aft_y(pump_trays)
    aft = max(nominal_aft, band)
    air = bay_back_y(plate) - aft
    if air < cap_kiss - cap_kiss_station_allowance - 1e-9:
        raise ValueError(
            f"the bay bulkhead at Y{bay_back_y(plate):g} stands inside the skirt opening's "
            f"upper band, which ends at Y{band:g}: the cradle cannot keep its "
            f"{_tray.skirt_upper_band:g} mm behind the pumps and "
            f"{cap_kiss - cap_kiss_station_allowance:g} mm minimum plate air")
    return aft


def _clamp_lane_edge(pump_trays):
    """The cradle's centre clearance's X edge above the bracket plane: the lane between the two
    upper wells, run `clamp_lane_overlap` into each so the clamp's spine drops through one
    continuous opening."""
    return (min(abs(cx) - _tray.half_width() for cx, _cy, _cz in pump_trays)
            + clamp_lane_overlap)


def cap_screw_ys(inner, plate):
    """The top clamp's two screw stations, fore and aft of the centre lane's mid-depth.

    Both stand between the pumps, clear of their bosses, fittings and tubes."""
    mid = (inner[2] + (plate["fore_y"] - 2.0)) / 2.0
    return mid - cap_screw_off, mid + cap_screw_off


def _outlet_fore_miter_wedges(cx, cy, cz):
    """Both passages' fore closures for one pump: the wide flare's own 45 degree seam plane,
    carried from the body room's edge to the 73 mm opening envelope on each side.

    Cut from the pump's fused lower void; the opening's fore boundary is the room's own
    flare plane, one plane from the narrow half out to the envelope."""
    body_half, y0, open_half, _y_open = _tray.outlet_fore_miter(cap_pump_air)
    z0 = cz + _tray.outlet_axis_z - cap_fitting_half - 1.0
    reach = open_half + 1.0
    out = []
    for sx in (-1.0, 1.0):
        out.append(_xy_prism(z0, cz, [
            (cx + sx * body_half, cy + y0),
            (cx + sx * reach, cy + y0 + (reach - body_half)),
            (cx + sx * reach, cy + y0 - 1.0),
            (cx + sx * body_half, cy + y0 - 1.0)]))
    return out


def _outlet_under_tangent_wedges(cx, cy, cz):
    """Both passages' under-circle joints for one pump: the steep tangent plane from the case
    lower ramp's seam edge to each circular opening, over the tube-side room's own Y run.

    Fused into the pump's lower void before the fore miters close it; between the room's seam
    and each circle the opening's outboard boundary is this one plane — tangent to the circle,
    standing on the ramp's own seam, with no wall-plane band between them."""
    seam_z, u_wall, u_q, z_q = _tray.outlet_under_tangent(cap_pump_air)
    y0 = cy + _tray.outlet_passage_start_y(cap_pump_air)
    y1 = cy + _tray.skirt_body_open_y_bounds[1]
    out = []
    for sx in (-1.0, 1.0):
        hx = cx + sx * _tray.outlet_pitch / 2.0
        wall = hx + sx * u_wall
        out.append(_xz_prism(y0, y1, [
            (wall, cz + seam_z),
            (hx + sx * u_q, cz + z_q),
            (wall - sx * 1.0, cz + z_q),
            (wall - sx * 1.0, cz + seam_z)]))
    return out


def _pump_lower_well(pump_trays):
    """One fitted lower head well, in the pump frame, with its skirt support clearance."""
    support_top = pump_skirt_support_z(pump_trays) - min(cz for _cx, _cy, cz in pump_trays)
    return _tray.drop_well(cap_pump_air, support_top=support_top).val()


def _pump_drop_voids(box):
    """The two straight Z insertion wells through the lower cradle.

    BELOW THE BRACKET the well is `pump_tray.drop_well` on `cap_pump_air` — the two-piece
    bench case's own cavity, the solid `kamoer_kphm400.build_head` clips this pump to, carried
    up its axis so every station stands as open as the widest one under it. It brings the
    case's figures with it: 56 mm across at the narrow half, 64 at the centre, 70 at the
    outlet face where the fittings stand, the corner radii, and the flat step under the 8 mm
    skirt. The step supports X-, Y- and X+ continuously; on Y+ it supports only the centre
    between the two tube passages. From that outlet face, two individual
    fitting passages run aft to the block's own face. Each keeps a circular lower half around
    its tube axis and a straight 13.25 mm shaft above it. The two shafts' outside edges, the
    tube-side case room and the upper well share one 73 mm opening boundary. Each passage's
    fore end closes on the flare's own 45 degree seam plane, run from the body room's edge out
    to that boundary; under each circle, the room's seam edge joins it on one steep tangent
    plane standing on the case ramp's own seam. The wall between and outside them remains
    printed stock.

    ABOVE THE BRACKET each 73 mm well passes the molded flange, pump and complete
    clamp, opening through the cartridge's flat aft face. The centre clearance joins
    the two wells over the clamp spine. At the seat the upper wells stop on the bracket
    plane, leaving the fitted head room and its bearing lands below."""
    trays, plate = box.pack.pump_trays, box.pack.collet_plate
    drop_start = cap_drop_start_z(trays)
    top = box.pump_bay[2] + 1.0
    lower_source = _pump_lower_well(trays)
    out = []
    for cx, cy, cz in trays:
        lower = lower_source.moved(cq.Location(cq.Vector(cx, cy, cz)))
        outlet_face = cy + _tray.head_half - _tray.outlet_relief
        outlet_axis = cz + _tray.outlet_axis_z
        fittings = None
        for sx in (-1.0, 1.0):
            hx = cx + sx * _tray.outlet_pitch / 2.0
            # Carry the complete circle-and-shaft passage through the tube-side body room.
            # Its overlap with that room is free volume; the circle joins the 13.25 mm shaft
            # tangent to the 73 mm upper boundary.
            y0 = cy + _tray.outlet_passage_start_y(cap_pump_air)
            y1 = pump_cartridge_aft_y(trays, plate) + 1.0
            circle = _ycyl(cap_fitting_half, hx, outlet_axis, y0, y1)
            shaft = _ybox(
                hx - cap_fitting_half, hx + cap_fitting_half,
                y0, y1, outlet_axis, top)
            opening = circle.fuse(shaft)
            fittings = opening if fittings is None else fittings.fuse(opening)
        # The upper well carries the same exact tube-pair boundary as the lower room and shafts.
        upper_x0, upper_x1 = _pump_upper_x_span(cx)
        upper = _ybox(upper_x0, upper_x1,
                      _pump_upper_well_fore_y(trays),
                      _pump_upper_well_aft_y(plate),
                      drop_start, top)
        body = lower.fuse(fittings)
        for wedge in _outlet_under_tangent_wedges(cx, cy, cz):
            body = body.fuse(wedge)
        for wedge in _outlet_fore_miter_wedges(cx, cy, cz):
            body = body.cut(wedge)
        out.append(body.fuse(upper))

    edge = _clamp_lane_edge(trays)
    out.append(_ybox(-(edge + clamp_drop_air), edge + clamp_drop_air,
                     _pump_upper_well_fore_y(trays), _pump_upper_well_aft_y(plate),
                     drop_start, top))
    return out


def _cap_x_span(bay):
    """The lower cradle's exterior side faces: the appliance's complete stated width."""
    _bx0, bx1, _top = bay
    edge = bx1 + wall
    return -edge, edge


def _pull_center_z(plate):
    """The fixed release-band midpoint that locates the pull floors."""
    return (plate["z0"] + plate["z1"]) / 2.0


def pull_z_span(box):
    """The pull floor and supported roof, with a quarter-millimetre allowance above the pocket."""
    bottom = bay_floor_z(box.pack.pump_trays)[1]
    crown = box.pump_bay[2] - pump_cartridge_top_clearance
    floor = _pull_center_z(box.pack.collet_plate) - pull_floor_below_tubes
    return floor, crown - (floor - bottom) + fits.supported_surface


def pull_y_span(pump_trays, plate):
    """Both pockets on the nominal cartridge run, independent of terminal band stock."""
    mid = (pump_cartridge_front_y + bay_back_y(plate) - cap_kiss) / 2.0
    return mid - pull_run / 2.0, mid + pull_run / 2.0


def _cradle_pulls(box):
    """Two side pockets with flat floors and roofs and rounded YZ corners."""
    edge = _cap_x_span(box.pump_bay)[1]
    deep = edge - pull_depth
    z0, z1 = pull_z_span(box)
    if z1 - z0 <= 2.0 * pull_corner_r:
        raise ValueError(
            f"a cradle pull from Z{z0:g} to Z{z1:g} "
            f"cannot carry its {pull_corner_r:g} mm corner rounds")
    y0, y1 = pull_y_span(box.pack.pump_trays, box.pack.collet_plate)
    out = []
    for sx in (+1.0, -1.0):
        section = ((sx * (edge + 1.0), z0), (sx * deep, z0),
                   (sx * deep, z1), (sx * (edge + 1.0), z1))
        cutter = _xz_prism(y0, y1, section)
        corners = [edge for edge in cutter.Edges()
                   if edge.BoundingBox().ylen < 1e-6 and edge.BoundingBox().xlen > 1.0]
        out.append(cutter.fillet(pull_corner_r, corners))
    return out


def _round_cradle_pull_rims(solid, box):
    """Round the complete exposed perimeter of each hand pocket."""
    solid = solid.clean()
    edge = _cap_x_span(box.pump_bay)[1]
    y0, y1 = pull_y_span(box.pack.pump_trays, box.pack.collet_plate)
    z0, z1 = pull_z_span(box)
    for x in (-edge, edge):
        rim = []
        for candidate in solid.Edges():
            b = candidate.BoundingBox()
            if (abs(b.xmin - x) < 1e-6 and abs(b.xmax - x) < 1e-6
                    and b.ymin >= y0 - 1e-6 and b.ymax <= y1 + 1e-6
                    and b.zmin >= z0 - 1e-6 and b.zmax <= z1 + 1e-6):
                rim.append(candidate)
        if not rim:
            raise ValueError(f"cradle pull at X{x:g} has no exterior hand-contact edge")
        solid = solid.fillet(pull_edge_r, rim)
    return solid


def pump_cartridge_figures(box):
    """The cradle, clamp, fitting opening and pull dimensions written into the docs."""
    if not (box.pump_bay and box.pack.pump_trays):
        return {}
    bay, trays, plate = box.pump_bay, box.pack.pump_trays, box.pack.collet_plate
    edge = _cap_x_span(bay)[1]
    y0, y1 = pull_y_span(trays, plate)
    aft = pump_cartridge_aft_y(trays, plate)
    pull_floor, pull_top = pull_z_span(box)
    clamp_edge = max(abs(cx) + _tray.half_width() for cx, _cy, _cz in trays)
    clamp_fore = min(cy - _tray.half_width() for _cx, cy, _cz in trays)
    clamp_aft = aft
    clamp_base = cap_base_z(trays)
    clamp_crown = cap_crown_z(box)
    floor_top = bay_floor_z(trays)[1]
    cartridge_top = bay[2] - pump_cartridge_top_clearance
    head_floor = pump_skirt_support_z(trays) - _tray.head_front_below_skirt
    motor_crown = max(cz + _tray.motor_crown - _interface.pump_seated_drop
                      for _cx, _cy, cz in trays)
    foot_low = (box.splits[0] - plate_foot_t
                - plate_foot_reach * math.tan(math.radians(plate_foot_corbel_angle)))
    condenser_top, foot_air = plate_foot_condenser_clearance(
        plate, box.splits[0], box.pack)
    return {
        "PUMP_STATION_DROP": f"{pump_station_drop:.4g} mm",
        "PUMP_BAY_FLOOR_RELIEF": f"{pump_bay_floor_relief:.4g} mm",
        "PUMP_BAY_ROOF_RELIEF": f"{pump_bay_roof_relief:.4g} mm",
        "PUMP_BAY_FLOOR_Z": f"{floor_top:.6g} mm",
        "PUMP_BAY_FLOOR_STOCK": f"{floor_top - z_seam:.6g} mm",
        "PUMP_BAY_LINTEL_Z": f"{bay[2] + fits.supported_surface:.6g} mm",
        "PUMP_CARTRIDGE_TOP_AIR": f"{pump_cartridge_top_clearance + fits.supported_surface:.4g} mm",
        "PUMP_HEAD_FLOOR_AIR": f"{(head_floor - floor_top):.4g} mm",
        "PUMP_MOTOR_LINTEL_AIR": f"{(bay[2] + fits.supported_surface - motor_crown):.4g} mm",
        "PUMP_CARTRIDGE_BOTTOM_Z": f"{floor_top:.6g} mm",
        "PUMP_CARTRIDGE_TOP_Z": f"{cartridge_top:.6g} mm",
        "PUMP_CARTRIDGE_RISE": f"{(cartridge_top - floor_top):.6g} mm",
        "PULL_RISE": f"{(pull_top - pull_floor):.4g} mm",
        "PULL_RUN": f"{pull_run:.4g} mm",
        "PULL_DEPTH": f"{pull_depth:.4g} mm",
        "PULL_CORNER_R": f"{pull_corner_r:.4g} mm",
        "PULL_EDGE_R": f"{pull_edge_r:.4g} mm",
        "PULL_FLOOR_Z": f"{pull_floor:.5g} mm",
        "PULL_TOP_Z": f"{pull_top:.6g} mm",
        "PULL_FLOOR_LIGAMENT": f"{(pull_floor - floor_top):.4g} mm",
        "PULL_ROOF_LIGAMENT": f"{(cartridge_top - pull_top):.4g} mm",
        "PULL_RIM_FLOOR_LIGAMENT": f"{(pull_floor - pull_edge_r - floor_top):.4g} mm",
        "PULL_RIM_ROOF_LIGAMENT": f"{(cartridge_top - pull_top - pull_edge_r):.4g} mm",
        "PULL_CENTER_Z": f"{((pull_floor + pull_top) / 2.0):.5g} mm",
        "PULL_LEDGE": f"{y0:.4g} mm",
        "PULL_AFT_LEDGE": f"{y1:.4g} mm",
        "PULL_CENTER_Y": f"{(y0 + y1) / 2.0:.4g} mm",
        "PULL_FORE_STOCK": f"{(y0 - pump_cartridge_front_y):.4g} mm",
        "PULL_AFT_STOCK": f"{(aft - y1):.4g} mm",
        "CLAMP_SPAN": f"{2.0 * clamp_edge:.4g} mm",
        "CLAMP_RISE": f"{(clamp_crown - clamp_base):.5g} mm",
        "CLAMP_BASE_Z": f"{clamp_base:.5g} mm",
        "CLAMP_CROWN_Z": f"{clamp_crown:.5g} mm",
        "CLAMP_LINTEL_AIR": f"{(bay[2] + fits.supported_surface - clamp_crown):.4g} mm",
        "CLAMP_PUMP_Y_SHIFT": f"{abs(clamp_pump_y_shift):.4g} mm",
        "CLAMP_SCREW_LEN": f"{cap_screw_len:.4g} mm",
        "CLAMP_SCREW_PITCH": f"{2.0 * cap_screw_off:.4g} mm",
        "CLAMP_HEAD_SEAT_DEPTH": f"{(clamp_crown - cap_head_seat_z(box)):.4g} mm",
        "CLAMP_HEAD_SEAT_Z": f"{cap_head_seat_z(box):.6g} mm",
        "CLAMP_INSERT_LEN": f"{cap_heatset_len:.4g} mm",
        "CLAMP_SCREW_LANE": f"{2.0 * (min(abs(cx) for cx, _cy, _cz in trays)
                                     - _tray.boss_half - cap_boss_air):.4g} mm",
        "CLAMP_BOSS_AIR": f"{cap_boss_air:.4g} mm",
        "CLAMP_DROP_AIR": f"{clamp_drop_air:.4g} mm",
        "CLAMP_FRONT_SKIN": f"{(clamp_fore - clamp_drop_air - pump_cartridge_front_y):.4g} mm",
        "CLAMP_AFT_WALL": f"{(clamp_aft - max(cy + clamp_pump_y_shift + _tray.boss_half
                                                for _cx, cy, _cz in trays)):.4g} mm",
        "CLAMP_BRIDGE_RISE": f"{cap_bridge_rise:.4g} mm",
        "CLAMP_TERMINAL_OPENING": f"{2.0 * cap_terminal_opening_r:g} mm",
        "CLAMP_TERMINAL_OPENING_Z": f"{cap_terminal_opening_z(box):.6g} mm",
        "PUMP_SEATED_DROP": f"{_interface.pump_seated_drop:g} mm",
        "CAP_TUBE_OPEN_SPAN": f"{2.0 * cap_slot_half:.4g} mm",
        "CAP_TUBE_PART_SPAN": f"{2.0 * _tray.outlet_half:.4g} mm",
        "CAP_TUBE_OPEN": f"{2.0 * cap_fitting_half:.5g} mm",
        "CAP_TUBE_PART": f"{_tray.fitting_w:.4g} mm",
        "CAP_TUBE_PITCH": f"{_tray.outlet_pitch:.4g} mm",
        "CAP_TUBE_RADIAL_AIR": f"{cap_fitting_half - _tray.fitting_w / 2.0:.4g} mm",
        "CAP_TUBE_START_Y": f"{min(cy for _cx, cy, _cz in trays) + _tray.outlet_passage_start_y(cap_pump_air):.6g} mm",
        "PUMP_SKIRT_DEPTH": f"{_tray.skirt_depth:.4g} mm",
        "PUMP_SKIRT_SUPPORT_AIR": f"{_tray.skirt_support_air:.4g} mm",
        "PUMP_SKIRT_SUPPORT_Z": f"{pump_skirt_support_z(trays):.6g} mm",
        "PUMP_SKIRT_BODY_Y": f"{_tray.skirt_body_y:.4g} mm",
        "PUMP_SKIRT_OPEN_Y": f"{_tray.skirt_body_open_y:.4g} mm",
        "PUMP_SKIRT_XY_AIR": f"{_tray.skirt_support_xy_air:.4g} mm",
        "PUMP_SKIRT_BODY_Y_MINUS_EDGE":
            f"{(trays[0][1] + _tray.skirt_body_open_y_bounds[0]):.6g} mm",
        "PUMP_SKIRT_BODY_Y_PLUS_EDGE":
            f"{(trays[0][1] + _tray.skirt_body_open_y_bounds[1]):.6g} mm",
        "PUMP_SKIRT_Y": f"{_tray.skirt_y:.4g} mm",
        "PUMP_SKIRT_Y_MINUS_EDGE":
            f"{(trays[0][1] + _tray.skirt_open_y_max
                  - _tray.skirt_y_plus_air - _tray.skirt_y):.6g} mm",
        "PUMP_SKIRT_Y_PLUS_EDGE":
            f"{(trays[0][1] + _tray.skirt_open_y_max
                  - _tray.skirt_y_plus_air):.6g} mm",
        "PUMP_SKIRT_Y_PLUS_AIR": f"{_tray.skirt_y_plus_air:.4g} mm",
        "PUMP_SKIRT_Y_MINUS_LAND": f"{_tray.skirt_support_y_minus:.4g} mm",
        "PUMP_SKIRT_Y_PLUS_LAND": f"{_tray.skirt_support_y_plus:.4g} mm",
        "PUMP_SKIRT_Y_PLUS_OPEN_EDGE":
            f"{(trays[0][1] + _tray.skirt_open_y_max):.6g} mm",
        "PUMP_SKIRT_UPPER_BAND": f"{_tray.skirt_upper_band:.4g} mm",
        "PUMP_SKIRT_UPPER_BAND_AFT":
            f"{(trays[0][1] + _tray.skirt_open_y_max
                  + _tray.skirt_upper_band):.6g} mm",
        "PUMP_CARTRIDGE_AFT_Y": f"{aft:.6g} mm",
        "PUMP_SKIRT_AFT_STOCK":
            f"{(aft - max(cy + _tray.skirt_open_y_max for _cx, cy, _cz in trays)):.4g} mm",
        "CARTRIDGE_BULKHEAD_KISS": f"{(bay_back_y(plate) - aft):.4g} mm",
        "PUMP_FACE_OFFSET": f"{(box.outer[2] - pump_cartridge_front_y):.4g} mm",
        "PUMP_STATION_LEAD": f"{pump_station_lead:.4g} mm",
        "PUMP_SHOW_GROWTH": f"{pump_show_growth:.4g} mm",
        "PUMP_FACE_SKIN": f"{(min(cy for _cx, cy, _cz in trays) + _pump_lower_well(trays).BoundingBox().ymin - pump_cartridge_front_y):.4g} mm",
        "PUMP_OUTLET_BULKHEAD_AIR": f"{(bay_back_y(plate) - max(cy + _tray.head_half for _cx, cy, _cz in trays)):.4g} mm",
        "PUMP_FACE_BACKING": f"{(_pump_front_smooth_skin(trays) - flute_depth):.4g} mm",
        "PUMP_UPPER_SMOOTH_SKIN": f"{_pump_front_smooth_skin(trays):.4g} mm",
        "PUMP_UPPER_FLUTED_SKIN": f"{(_pump_front_smooth_skin(trays) - flute_depth):.4g} mm",
        "PUMP_UPPER_WELL_AFT": f"{_pump_upper_well_aft_y(plate):.6g} mm",
        "CRADLE_EDGE": f"{edge:.4g} mm",
        "CRADLE_WIDE": f"{2.0 * edge:.4g} mm",
        "PLATE_STEP_Z": f"{seam_cap_z():.4g} mm",
        "PLATE_FOOT_X": f"{plate_foot_reach:.4g} mm",
        "PLATE_FOOT_Y": f"{plate_foot_y:.4g} mm",
        "PLATE_FOOT_T": f"{plate_foot_t:.4g} mm",
        "PLATE_FOOT_ANGLE": f"{plate_foot_corbel_angle:.4g}°",
        "PLATE_FOOT_LOW_Z": f"{foot_low:.6g} mm",
        "PLATE_FOOT_COND_Z_AIR": f"{foot_low - condenser_top:.4g} mm",
        "PLATE_FOOT_COND_AIR": f"{foot_air:.4g} mm",
        "BAY_BACK_Y": f"{bay_back_y(plate):.6g} mm",
        "BAY_BULKHEAD_T": f"{plate['wall_aft_y'] - bay_back_y(plate):.6g} mm",
        "PLATE_STROKE": f"{plate['stroke']:.4g} mm",
        "PLATE_REST_GAP": f"{plate['rest_gap']:.4g} mm",
        "SLEEVE_TRAVEL": f"{(plate['stroke'] - plate['rest_gap']):.4g} mm",
    }


def bay_floor_z(pump_trays):
    """The bay floor's two planes: its underside on front-top's own seam mouth, and its top
    on the plane the pump cartridge's filled bearing block reaches down to.

    THE FLOOR IS THIS PIECE'S FIRST LAYERS. Front-top beds on the seam plane, so a floor
    struck there lies on the bed and nothing under it hangs. Its top answers to the
    pump-neutral station: `_pump_relief_regions` follows the installed pumps, so
    `pump_station_drop` restores the fixed reference and `pump_bay_floor_relief` opens that
    sill downward. `pump_cartridge_z_clearance` remains the stationary-perimeter gap below
    the removable face.

    AND IT IS ONE PLANE ACROSS THE WHOLE MOUTH. The filled block's flat bearing sill, the
    stationary sill the fixed shell perimeter stops on, and the removable exterior face's own
    bed plane are all this figure, so the bay's floor reads flat from the front wall's section
    through to the bay bulkhead."""
    # The relief pocket follows the pump; adding its independent drop returns the fixed bay
    # reference, and the floor relief is spent downward from there.
    return z_seam, (min(z0 for _x0, _x1, z0, _z1, _floor in _pump_relief_regions(pump_trays))
                    - pump_cartridge_z_clearance + pump_station_drop
                    - pump_bay_floor_relief)


def _flank_lip_drop(inner, plate, y_joint, zj):
    """The Z-seam lip given up on BOTH FLANKS over the front run — front-bottom stops
    standing a wall up into front-top there, and nothing above has to open for one.

    `_front_flat_lip_drop`'s twin, turned a quarter: that one gives the lip up across the
    bay's own flat, this one gives it up round the corners and back down each flank as far
    as the tee wall's aft face (`plate["wall_aft_y"]`) — which is where the front column's
    RAIL then starts (`_z_rail_runs`). What the telescope was doing over that run is done
    better by what stands there now — the seam's cap over it, the bay floor bedded through
    it, the tee wall across it — and a lip that registers nothing is a wall poking into a
    cavity cut to receive it."""
    # Down to the mouth and NOT past it: below the seam this run is front-bottom's own wall,
    # which the drop has no business in — only the lip standing proud of the mouth.
    return _flank_lip_run(inner, plate, y_joint, (zj, zj + z_rise + wall + 1.0))


def _flank_lip_run(inner, plate, y_joint, z):
    """The drop's OUTLINE over a z band given: wall to wall and back to the tee wall's aft
    face.

    `_flank_lip_drop` asks for the lip's own band, which is what a piece is cut on.
    `_lip_denied` asks for the whole column, because it reads which seam HEIGHTS a body
    denies rather than what one seam cuts — and the two have to come off this one outline
    or the second is answering about a lip the box does not build."""
    lo, hi = z
    # WALL TO WALL, and not jamb to jamb. Between the jambs the front flat has already given
    # its lip up (`_front_flat_lip_drop`) and nothing else of the bottom piece stands over
    # the mouth here, so reaching across costs nothing — and stopping ON the jamb would put
    # this cut's own side plane on the one plane three other cuts already end on.
    return _ybox(inner[0] - wall - 1.0, inner[1] + wall + 1.0,
                 inner[2] - wall - 1.0, plate["wall_aft_y"], lo, hi)


def _bay_floor(inner, y_joint, plate, pump_trays):
    """The continuous bay floor, from the front face through the rear bulkhead.

    Its underside is the seam plane and its top carries the cartridge. The bulkhead
    grows from the full floor section. The final rail cuts open the two flank lanes.
    """
    z0, z1 = bay_floor_z(pump_trays)
    rim = z_seam + z_rise
    bx0, bx1 = bay_x_span(inner)
    aft = plate["wall_aft_y"]
    slab = _ybox(inner[0], inner[1], front_plane_y, aft, z0, z1)
    for x_in, edge in ((inner[0], bx0), (inner[1], bx1)):
        if abs(edge - x_in) > 1e-9:
            slab = slab.fuse(_ybox(min(x_in, edge), max(x_in, edge),
                                   front_plane_y, aft, z1, rim))
    return slab


def _tee_wall(inner, y_joint, plate, bay):
    """One bay bulkhead from floor to lintel, joined to both flanks.

    Each circular tube passage retains a full flat annular release bearing. The larger aft journal clears the
    tee collar and leaves the collet's release shoulder on the stated Y plane. The
    carrier bearing body joins the aft face around those four journals.
    """
    slab = _ybox(inner[0], inner[1], bay_back_y(plate),
                  plate["wall_aft_y"], z_seam, bay[2])
    for hx, hz in plate["holes"]:
        slab = slab.cut(_ycyl(
            plate["hole_d"] / 2.0, hx, hz,
            bay_back_y(plate) - 1.0, plate["aft_y"] + 1.0))
        slab = slab.cut(_tee_bore(plate, hx, hz))
    return slab


def _tee_carrier_clearances(inner, plate, carrier):
    """Four continuous hardware wells and common faces behind the moving carrier.

    One face clears the tie heads and the complete lap's lateral entry. The lower and upper
    web bearings remain broad flat lands between wells. The common clearance ends on the
    flank interior, preserving the service opening's full wall section.
    """
    if not carrier:
        return ()
    air = carrier["guide_slide_air"]
    fixed_y = carrier["body_fore_y"]
    aft = carrier["body_aft_y"]
    web_z0, web_z1 = carrier["web_z"]
    backing_room = _ybox(
        inner[0], inner[1],
        carrier["body_face_y"], aft + 1.0,
        web_z0 - air, web_z1 + air + fits.supported_surface)
    fore_guide = _tee_carrier_fore_guide(carrier)
    cuts = [backing_room.cut(fore_guide, fore_guide.mirror("YZ"))]
    for x, z in plate["holes"]:
        cuts.append(_teardrop_y(plate["bore_r"], x, z, fixed_y - 1.0, aft + 1.0))
    for xs, ys, zs in (*carrier["tee_wells"], *carrier["aft_valve_cavities"],
                       *carrier["floor_cavities"]):
        cuts.append(_supported_cut(_ybox(*xs, *ys, *zs)))
    return tuple(cuts)


def _tee_carrier_fore_guide(carrier):
    """The floor-rooted land beneath the service tab's fore retaining shoulder."""
    air = carrier["guide_slide_air"]
    return _ybox(carrier["grip_rim_x"][0] - air, carrier["service_recess_x"][1],
                 carrier["grip_rim_y"][0] + carrier["release_offset_y"] - air,
                 carrier["release_fore_stop_y"] - air,
                 carrier["web_z"][0] - air - wall,
                 carrier["grip_rim_z"][0] - air)


def _tee_carrier_fixed_features(inner, plate, carrier):
    """Filled guide body and common floor joining the tee wall, valve trays and flanks."""
    if not carrier:
        return None
    body = _ybox(inner[0], inner[1], carrier["body_fore_y"],
                 carrier["body_aft_y"], plate["z0"], carrier["body_top_z"])
    body = body.fuse(_ybox(
        inner[0], inner[1], carrier["body_fore_y"],
        carrier["body_floor_aft_y"], plate["z0"],
        carrier["web_z"][0] - carrier["guide_slide_air"]))
    for cutter in _tee_carrier_clearances(inner, plate, carrier):
        body = body.cut(cutter)
    return body


def _tee_carrier_service_slots(carrier):
    """Open finger slots, bar guides, internal recesses for inside-out assembly, and the two
    spring seats in the recesses' fore walls.

    Above each bar, the outer strip of its retaining tongue runs in a short channel whose
    aft end is the travel limit beyond nominal rest. The full-height entry passage sits inboard of that strip.
    Each return spring rides in its bar's fore face and bears on a blind seat bored into the
    recess's fore wall, on the bar's own axis.
    """
    if not carrier:
        return ()
    slot_roof = carrier["service_slot_z"][1] + fits.supported_surface
    cuts = []
    for station in carrier["spring_stations"]:
        cuts.append(_teardrop_y(carrier["spring_bore_d"] / 2.0, station["x"], station["z"],
                                station["seat_floor_y"], carrier.get("fixed_seat_wall_y", station["seat_mouth_y"]) + 1.0))
    for name in ("service_slot", "service_recess"):
        x0, x1 = carrier[name + "_x"]
        y0, y1 = carrier[name + "_y"]
        z0, z1 = carrier[name + "_z"]
        if name == "service_slot":
            z1 = slot_roof
        opening = _ybox(x0, x1, y0, y1, z0, z1)
        if name == "service_recess":
            opening = opening.cut(_ybox(
                carrier["stop_channel_inner_x"], x1 + 1.0,
                carrier["stop_channel_aft_y"], y1 + 1.0,
                slot_roof, z1 + 1.0))
            opening = opening.cut(_tee_carrier_fore_guide(carrier))
        cuts.extend(opening if side > 0 else opening.mirror("YZ")
                    for side in (-1, 1))
    return tuple(cuts)


def _tee_carrier_fixed_cups(carrier):
    """Integral round extensions over the unmoved fixed spring-floor datums."""
    if not carrier or not carrier.get("fixed_seat_outer_d"):
        return ()
    inner=carrier["spring_bore_d"]/2
    outer=carrier["fixed_seat_outer_d"]/2
    root=carrier["fixed_seat_wall_y"]-.1
    return tuple(_ycyl(outer,s["x"],s["z"],root,s["seat_mouth_y"]).cut(
        _ycyl(inner,s["x"],s["z"],root-.1,s["seat_mouth_y"]+.1))
        for s in carrier["spring_stations"])


def _ridge_keystone(slab, station, t):
    """The pump jack's receptacle in the ridge wall: `riteav_keystone`'s aperture, ease, pocket,
    two catches and boss, turned to face the pump bay.

    THE MODULE LOOKS +Y OUT OF THE WALL AND THIS WALL'S USER FACE LOOKS -Y, so the receptacle is
    struck at the origin and given a half turn about Z before it is carried to the station: X
    is the module's own mirror plane, the ease stays over the aperture's top edge, and the jack
    goes in from the cavity behind the rib, tang first, swinging down onto the lower catch.

    THE RIB IS THE LIP. `ridge_wall_t` is `riteav_keystone.LIP_D`, so the aperture passes the
    whole rib and the pocket, the catches and the boss that carries them stand aft of it. The
    boss's lower wall lands on the bay bulkhead's crown (`_ridge_stations`), so the block roots on
    the crown and the rib and hangs nowhere on this Z-bedded piece.

    Fused, cut, fused: the boss first, then the receptacle through boss and rib together, then
    the catches, which a cut running after them would take off."""
    x, y_face, z = station
    block, catches = _keystone.receptacle_boss(0.0, 0.0, 0.0, -t)
    cutter, _bands = _keystone_pocket_cut(0.0, 0.0, 0.0)

    def turned(shape):
        return (shape.rotate((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), 180.0)
                .translate((x, y_face, z)))

    if block is not None:
        bb = block.BoundingBox()
        pw = _keystone.POCKET_W - _keystone.FIT_SLIP + 2.0 * fits.slip
        ph = _keystone.POCKET_H - _keystone.FIT_SLIP + 2.0 * fits.slip
        hx, hz = pw / 2.0 + _keystone.RECEPTACLE_WALL, ph / 2.0 + _keystone.RECEPTACLE_WALL
        block = _ybox(-hx, hx, bb.ymin, bb.ymax,
                       _keystone.POCKET_RISE - hz, _keystone.POCKET_RISE + hz)
        slab = slab.fuse(turned(_supported_cut(block)))
    slab = slab.cut(turned(_supported_cut(cutter)))
    if catches is not None:
        slab = slab.fuse(turned(_keystone_catches(catches, up=1.0)))
    return slab


def _ridge_wall(inner, outer, plate, bay, funnel):
    """A wall-width rib joins the bay bulkhead to the display housing and funnel seat.

    Its straight lower section carries the pump jack, machine-display loom passage
    and fixed pump-lead clip. The crown follows a 45° rise to the display pocket;
    the aft face continues to the underside of the funnel bearing. Display and
    retention-pocket cuts pass through the completed rib. Its cavity-facing roof
    can take slicer support through the open display and funnel apertures.
    """
    ry, rz = pcb_ridge(outer)
    fore, foot, t = plate["aft_y"], bay[2], ridge_wall_t
    jog, aft_crown = _ridge_join(outer, fore)
    funnel_front = _funnel_cut_plan(funnel)[2]
    housing_back = housing_back_y(outer)
    ceiling = funnel_seat_z(outer) - funnel_seat_thickness
    slab = _yz_prism(
        inner[0], inner[1],
        [(fore, foot),                                          # the bay's back, on the crown
         (fore, jog),                                           # where it meets the end wall
         (ry, rz),                                              # the ridge
         (housing_back, ceiling),                               # closes into the housing
         (funnel_front, ceiling),                               # the opening's front underside
         aft_crown,                                             # the one roof's aft crown
         (fore + t, foot)])
    jack, loom = _ridge_stations(outer, plate, bay)
    slab = slab.cut(_teardrop_y(cable_bore_dia / 2.0, loom[0], loom[2],
                                fore - 1.0, fore + t + 1.0))
    slab = _ridge_keystone(slab, jack, t)

    clip_end = inner[1] - pump_jack_clip_edge_land
    clip_start = clip_end - _cable_clip.RUN
    if clip_start <= jack[0] + _keystone.panel_footprint()[0] / 2.0:
        raise ValueError("the pump-jack cable clip no longer clears the receptacle boss")
    # The seat follows the loom's height while keeping a full wall thickness below
    # the ridge crown. The lead reaches down into the seat where the crown sets its height.
    clip_z = min(loom[2] - _cable_clip.seat_top(),
                 aft_crown[1] - wall - _cable_clip.HEIGHT)
    return _cable_clip.apply(
        slab,
        origin=(clip_start, fore + t, clip_z),
        outward=(0.0, 1.0, 0.0),
        along=(1.0, 0.0, 0.0),
        embed=0.0,
        wall_thickness=t,
    ).val()


def _flank_cable_clips(piece, box):
    """The +X flank's share of the run the ridge clip starts — `flank_clip_stations`, each the
    complete clip profile, embedded into front-top's flank and running aft.

    WHAT SETS THEIR HEIGHT IS THE SEAM COLLAR'S OWN 45°. The upper Y-seam socket stands on a web
    that falls at 45° off the collar's floor to the lip face (`_front_socket`), and the clip
    carries the same 45° under its upper arm (`cable_clip.channel_mouth`). Struck so the two are
    ONE PLANE, the aftmost clip's underside runs straight on into that web instead of stepping
    off it: what the print lays there is a single sloped face from the clip's fore end through
    the collar, and what a hand meets is one surface rather than three. The stations are then
    placed in Y and the plane places them in Z.

    THE CLIP'S UP IS THE PIECE'S PRINT-UP, as it is on the rib — `along × outward` is +Z for a
    face looking −X with the run going +Y — so these lay the way the ridge clip lays and neither
    asks the print a question the rib had not already answered.

    EVERY STATION IS BOUNDED BY WHAT IS ALREADY ON THE FACE. Ahead: the ridge clip's own proud
    face, where the corner turn ends and this face's air begins. Behind: each +X Wago tower,
    which stands `wago_engage` off `interior_x` and reaches into that air over its own Y band.
    And the Y seam, aft of which the face is back-top's. The stations are stated, so the bounds
    are checked rather than assumed."""
    plate = box.pack.collet_plate
    fx = front_top_flank_face()[1]
    z_origin = _seam_web_at(box, fx + flank_clip_embed) - _cable_clip.channel_mouth()
    z_band = (z_origin, z_origin + _cable_clip.HEIGHT)
    corner = plate["aft_y"] + ridge_wall_t + _cable_clip.DEPTH
    towers = [(st[1] - wago_half(st[3])[0], st[1] + wago_half(st[3])[0],
               st[2] - wago_half(st[3])[1], st[2] + wago_half(st[3])[1])
              for st in box.pack.side_wells if st[0] > 0]
    for y0, run in flank_clip_stations:
        y1 = y0 + run
        if y0 < corner - 1e-9:
            raise ValueError(
                f"a flank cable clip at y {y0:.2f} stands in the ridge clip's own body, which "
                f"ends at {corner:.2f} — the corner turn has nowhere to happen")
        if y1 > box.y_joint + 1e-9:
            raise ValueError(
                f"a flank cable clip reaches y {y1:.2f}, past the Y seam at {box.y_joint:.2f}")
        for ty0, ty1, tz0, tz1 in towers:
            if y0 < ty1 and y1 > ty0 and z_band[0] < tz1 and z_band[1] > tz0:
                raise ValueError(
                    f"a flank cable clip over y {y0:.2f}..{y1:.2f} runs into the +X Wago tower "
                    f"over y {ty0:.2f}..{ty1:.2f}")
        piece = _cable_clip.apply(
            piece,
            origin=(fx, y0, z_origin),
            outward=(-1.0, 0.0, 0.0),
            along=(0.0, 1.0, 0.0),
            embed=flank_clip_embed,
            wall_thickness=front_top_flank_t,
            run=run,
        ).val()
    return piece


def _seam_web_at(box, x_face):
    """Where the upper +X Y-seam socket's 45° web crosses the plane `x_face`, in Z.

    `_front_socket` stands that collar on a right triangle whose hypotenuse falls from the pod
    cap at the collar's floor to the lip face one `drop` below, and `drop` is the run — so the
    web is the plane `x + z = x_cap + floor` on this wall, and this is that plane read at one X.
    A feature that wants to continue the web rather than step off it strikes itself here."""
    tops = [b for b in box.y_bosses if b[0] > 0 and b[3] > z_seam]
    if not tops:
        raise ValueError(
            "front-top's +X flank has no Y-seam socket above the Z seam, and the flank cable "
            "clips are struck on that socket's own 45° web")
    x_in, x_ext, sx, z_boss = max(tops, key=lambda b: b[3])
    x_cap = _boss_x(x_ext, sx)[3]
    return x_cap + (z_boss - socket_r) - x_face


def _teardrop_y(r, x, z, y0, y1, up=1.0):
    """The cutter for a bore on Y, TEARDROPPED — a horizontal hole in a piece bedded on Z.

    A ROUND HOLE ON A HORIZONTAL AXIS HAS NO TOP. Its crown is where the arc turns over, and
    the layer that closes it is laid across the chord beneath with nothing under it. Two planes
    at `teardrop_roof_angle` stand on their tangent points and meet over the axis. Tangency makes
    this the smallest roof at that printable angle: half-width `r sin(a)`, tangent height
    `r cos(a)`, apex height `r / cos(a)`. The rest of the circle — which is what a bore locates
    and bears on — is untouched.

    `up` IS THE PIECE'S PRINT-UP IN THE MACHINE'S FRAME: +1.0 for a piece building in machine
    +Z, -1.0 for one building in machine -Z (back-top, `BACK_TOP_UP`). The crown a print cannot
    close is the side of the axis that looks print-up, so the roof stands there — tangent at
    `z + up r cos(a)`, apex at `z + up r / cos(a)`."""
    a = math.radians(teardrop_roof_angle)
    half = r * math.sin(a)
    tangent = z + up * r * math.cos(a)
    apex = z + up * r / math.cos(a)
    return _ycyl(r, x, z, y0, y1).fuse(
        _xz_prism(y0, y1, [(x - half, tangent), (x + half, tangent), (x, apex)]))


def _teardrop_x(r, y, z, x0, x1, up=1.0):
    """The same support-free horizontal bore as `_teardrop_y`, carried on X, with the same
    `up`: the roof stands on the side of the axis that looks print-up.

    The nominal circle remains whole away from the roof, so a round screw head or tool passes
    and bears exactly as it does in a cylindrical counterbore. Two tangent planes at
    `teardrop_roof_angle` replace only the circular crown a standing print cannot close."""
    a = math.radians(teardrop_roof_angle)
    half = r * math.sin(a)
    tangent = z + up * r * math.cos(a)
    apex = z + up * r / math.cos(a)
    return _xcyl(r, y, z, x0, x1).fuse(
        _yz_prism(x0, x1, [(y - half, tangent), (y + half, tangent), (y, apex)]))


def _tee_bore(plate, hx, hz):
    """The tee journal begins exactly at the collet's release-bearing plane.

    Its fore termination leaves the full release shoulder in the bulkhead. Only
    the open aft end overruns the wall for a clean through cut.
    """
    return _teardrop_y(
        plate["bore_r"], hx, hz,
        plate["aft_y"],
        plate["wall_aft_y"] + 1.0)


def _unified(solid):
    """One printed piece, with its coincident-plane seams merged.

    EVERY BOOLEAN LEAVES SPLITTERS. A cutter that fuses a bore to a channel standing on that
    bore's own axis lands the tangent arc on the piece as a seam across one plane, and the two
    faces either side of it are one surface reported as two. A volume cannot see them and a
    clash cannot either; on a section they read as a hole that is not there. The box carries
    them in the hundreds otherwise, so this is one call at the end of a piece rather than a
    guard at every fuse that makes one."""
    return cq.Workplane(obj=solid).clean()


def build_pump_cartridge(box, halves_cache=None):
    """THE LOWER CRADLE: the complete front face and the load-bearing cartridge body.

    Its filled block rides the bay floor while its exterior face begins on the same bed plane
    over a recessed fixed sill, ends on the flat back it shares with the clamp, and remains one piece through
    the complete removable front-wall height. Two open wells admit
    the pumps and top clamp in Z. Below the bracket plane those wells close to the head
    clearance, leaving the molded flanges on three cradle lands; four fitting-sized passages
    stay open through the whole drop path while the aft pull wall remains between them.

    Both tall side pulls have mirrored edge margins plus supported-roof allowance. The clamp has no pull feature.
    Two heat-set bores open upward from the centre spine for the clamp screws."""
    solid = _pump_cartridge_gross(box, halves_cache)
    for void in _pump_drop_voids(box):
        solid = solid.cut(void)
    for pull in _cradle_pulls(box):
        solid = solid.cut(pull)
    for bore in _cap_screws(box)[1]:
        solid = solid.cut(bore)
    return _unified(_round_cradle_pull_rims(solid, box))


def _pump_cartridge_gross(box, halves_cache=None):
    """The lower cradle before its pump wells, hand pulls and clamp fasteners are cut.

    The detachable face begins with its filled block on one common bed plane, above the fixed
    sill's Z-clearance gap, and ends `pump_cartridge_top_clearance` below the lintel. It bears on the bay
    floor back to the cartridge's flat back, one kiss fore of the bay bulkhead. Pump and clamp openings are cuts in this one body; the
    top clamp is built independently from the conformal collars it needs."""
    inner, outer = box.inner, box.outer
    bay, plate = box.pump_bay, box.pack.collet_plate
    if not bay or not plate:
        raise ValueError("a pump cartridge wants a bay and a collet plate, and this box "
                         "carries neither station — the pack has no pumps to pull")
    if halves_cache is not None and "pump-cartridge-gross" in halves_cache:
        return halves_cache["pump-cartridge-gross"]
    if halves_cache is not None and "front" in halves_cache:
        half = halves_cache["front"]
    else:
        half = build_front_half(box)
        if halves_cache is not None:
            halves_cache["front"] = half
    face = _pump_cartridge_face_region(inner, outer, bay, box.pack.pump_trays, plate)
    # Keep every cut and relief the fixed half already gives the band, then restore the complete
    # front nose through the bay cut. It overlaps both rounded corners through their side
    # tangencies, so it joins them with volume rather than meeting either flank on a line.
    solid = half.val().intersect(face)
    nose = face.intersect(_ybox(
        outer[0] - 1.0, outer[1] + 1.0,
        pump_cartridge_front_y - 1.0, outer[2] + corner_round + 0.01,
        bay_floor_z(box.pack.pump_trays)[1], bay[2]))
    solid = solid.fuse(nose)
    bx0, bx1, top = bay
    aft = pump_cartridge_aft_y(box.pack.pump_trays, plate)
    floor_top = bay_floor_z(box.pack.pump_trays)[1]
    # The filled body bears on the floor and reaches both cavity planes. The exterior shell's
    # complete flush front, rounded corners and side faces begin on that same bed plane and stand
    # plumb from there. The lower running gap is in the fixed shell perimeter, outside this
    # bearing floor. No fixed side skin frames the cradle.
    fill = _ybox(
        bx0, bx1, pump_relief_floor, aft,
        floor_top, top - pump_cartridge_top_clearance)
    solid = solid.fuse(fill).intersect(face.fuse(
        _ybox(bx0, bx1, pump_cartridge_front_y, aft, floor_top, top)))
    if halves_cache is not None:
        halves_cache["pump-cartridge-gross"] = solid
    return solid


def _pump_clamp_gross(box, halves_cache=None):
    """One broad cap with fitted octagonal bosses and cylindrical motor openings.

    The surrounding crown reaches the cartridge top. Two wider openings pass straight through
    that crown above the fitted motor bores, leaving the motor ends and terminals open."""
    if halves_cache is not None and "pump-clamp-gross" in halves_cache:
        return halves_cache["pump-clamp-gross"]
    trays, plate = box.pack.pump_trays, box.pack.collet_plate
    split = cap_split_z(trays)
    base = cap_base_z(trays)
    crown = cap_crown_z(box)
    fore = min(cy - _tray.half_width() for _cx, cy, _cz in trays)
    aft = pump_cartridge_aft_y(trays, plate)
    x0 = min(cx - _tray.half_width() for cx, _cy, _cz in trays)
    x1 = max(cx + _tray.half_width() for cx, _cy, _cz in trays)
    solid = _ybox(x0, x1, fore, aft, base, crown)
    for cx, cy, cz in trays:
        opening_y = cy + clamp_pump_y_shift
        solid = solid.cut(_tray.boss_room(cap_boss_air).moved(
            cq.Location(cq.Vector(cx, opening_y, split))))
        solid = solid.cut(_zcyl(
            _tray.can_half, cx, opening_y,
            split + _tray.boss_depth - 0.1, crown + 1.0))
        solid = solid.cut(_zcyl(
            cap_terminal_opening_r, cx, opening_y,
            cap_terminal_opening_z(box), crown + 1.0))
    if halves_cache is not None:
        halves_cache["pump-clamp-gross"] = solid
    return solid


def _cap_screws(box):
    """The clamp's two top-down screw bores and the cradle's two upward heat-set bores.

    Each M3×60 sits in a counterbore struck into the crown, runs the whole filled field, crosses
    the bridge clearance over the cradle spine and takes the complete long heat-set
    opened from the cradle's bracket plane; the pilot runs half a millimetre past its tip. The
    seat is placed by the screw (`cap_head_seat_z`), so the crown must stand at least one head
    over it, and both bores stand in the filled lane between the boss octagons with a wall to
    spare on each side."""
    trays, plate = box.pack.pump_trays, box.pack.collet_plate
    split, base, crown = cap_split_z(trays), cap_base_z(trays), cap_crown_z(box)
    seat = cap_head_seat_z(box)
    if crown - seat < cap_head_h:
        raise ValueError(
            f"an M3x{cap_screw_len:g} seats {crown - seat:.2f} mm under the clamp's crown at "
            f"Z{crown:g}, less than its {cap_head_h:g} mm head: the screw is too long for "
            f"the field it crosses")
    lane = min(abs(cx) for cx, _cy, _cz in trays) - _tray.boss_half - cap_boss_air
    if lane < head_cbore_dia / 2.0 + wall:
        raise ValueError(
            f"the two boss octagons leave {lane:.2f} mm of filled lane either side of the "
            f"clamp screws, under the {head_cbore_dia / 2.0 + wall:g} mm a counterbore and "
            f"one wall need")
    screw_tip = seat - cap_screw_len
    bore_tip = screw_tip - 0.5
    clear, sets = [], []
    for y in cap_screw_ys(box.inner, plate):
        clear.append(_zcyl(screw_clear_dia / 2.0, 0.0, y, base - 0.1, crown + 1.0)
                     .fuse(_zcyl(head_cbore_dia / 2.0, 0.0, y, seat, crown + 1.0)))
        sets.append(_zcyl(heatset_dia / 2.0, 0.0, y, bore_tip, split + 0.1))
    return clear, sets


def build_pump_cap(box, halves_cache=None):
    """THE TOP CLAMP: one filled field fitted around both pump heads.

    With the cartridge withdrawn from the enclosure, it lowers over both motor cans after the
    pumps stand in the cradle. Each opening takes its boss on the complete case-profile octagon
    and closes with one shoulder round the can. The broad underside, locating profiles and
    screw seats share the fitted holder datums. Two open motor-terminal wells cross the crown,
    level with the cartridge's top edge, and two M3×60 reach
    the cradle from counterbores in that crown. This piece carries no show face, plate stop or
    pull."""
    solid = _pump_clamp_gross(box, halves_cache)
    for bore in _cap_screws(box)[0]:
        solid = solid.cut(bore)
    return _unified(solid)


def build_front_half(box):
    """The whole front column, both pieces still joined at its Z seam."""
    inner, outer, y_joint = box.inner, box.outer, box.y_joint
    shell = _shell_with_facet(inner, outer).val()
    front = shell.intersect(_ybox(outer[0], outer[1], outer[2], y_joint, outer[4], outer[5]))
    # The fixed front wall's refrigeration reliefs, out of the section before anything stands
    # on it. The pump storey is the removable cartridge's complete full-width opening; its
    # fitted pump wells are cut in that cartridge, not repeated in the stationary sill below.
    for cutter in _front_relief_cuts(inner, fridge_reliefs):
        front = front.cut(cutter)
    front = front.fuse(_front_lip(inner, y_joint))
    # The floor's overlap: a full-thickness tongue on the bed, ending in a 45°
    # scarf nose within the slab (the core rides the cavity side, so the floor
    # cannot tongue proud like the walls). Lands in the bottom piece.
    front = front.fuse(_floor_scarf(inner, y_joint)[0])
    yb = _y_boss(y_joint)
    bosses = box.y_bosses
    # One collar per level, each standing on the lip band the lip has already put
    # down that wall.
    for x_in, x_ext, sx, z_boss in bosses:
        front = front.fuse(_front_socket(x_in, x_ext, sx, z_boss, y_joint, inner))
    # A collar's forward face stands ahead of the seam plane, so the topmost one can
    # poke into the display facet; trim it to that plane. The facet runs wall to
    # wall, so it needs no end wall — both ends are the exterior side walls, which
    # seal themselves.
    front = front.cut(_facet_wedge(outer))
    # Let the display into the facet (bezel counterbore + PCB through-hole); this
    # also clears whatever rib/wall material sits behind the facet in its path.
    front = front.cut(_display_cuts(outer))
    # Punch the funnel's throat through the top wall, behind the display.
    if box.pack.funnel:
        front = front.cut(_funnel_cut(inner, outer, box.pack.funnel))
    # The front wall's through-holes.
    for cutter in _port_cuts(box.pack.front_ports, outer[2] - 5.0, inner[2] + 5.0):
        front = front.cut(cutter)
    # East side-wall through-holes — the CO2 inlet's, low in the machine corridor.
    for cutter in _x_port_cuts(box.pack.east_ports, inner[1] - 5.0, outer[1] + 5.0):
        front = front.cut(cutter)
    for x_in, x_ext, sx, z_boss in bosses:
        front = front.cut(_front_cuts(
            x_in, x_ext, sx, z_boss, yb, y_joint,
            ceiling=inner[5] if z_boss > z_seam else None,
            floor=inner[4] - floor_t if z_boss < z_seam else None))
    # Clip any corner feature that pokes past the rounded print silhouette.
    front = front.intersect(_rounded_outer(outer))
    return cq.Workplane(obj=front)


def build_back_half(box):
    """The whole back column, both pieces still joined at its Z seam. The
    funnel opening crosses the Y seam, so this half takes its share of the
    cut — the collar bridges the seam."""
    inner, outer, y_joint = box.inner, box.outer, box.y_joint
    shell = _shell_with_facet(inner, outer).val()
    back = shell.intersect(_ybox(outer[0], outer[1], y_joint, outer[3], outer[4], outer[5]))
    # Give up the tongue envelope and keep the bed-side 45° wedge under its nose.
    # The assembled top stays flat under the core. Lands in the bottom piece.
    back = back.cut(_floor_scarf(inner, y_joint)[1])
    for x_ext, sx in dict.fromkeys((xe, s) for _xi, xe, s, z in box.y_bosses if z < z_seam):
        back = back.cut(_socket_floor_relief(x_ext, sx, inner, y_joint))
    if box.pack.funnel:
        back = back.cut(_funnel_cut(inner, outer, box.pack.funnel))
    yb = _y_boss(y_joint)
    bosses = box.y_bosses
    # One plug per level, standing on the back mouth off the wall it drives through.
    # The corner ahead of that mouth is the front lip's, whole; aft, the plug runs through
    # that lip's socket and into the full-thickness flank carrying it.
    for x_in, x_ext, sx, z_boss in bosses:
        back = back.fuse(_back_plug(
            x_ext, sx, z_boss, y_joint,
            root_z=outer[5] if z_boss > z_seam else outer[4]))
    # Clip any corner feature that pokes past the rounded print silhouette.
    back = back.intersect(_rounded_outer(outer))
    for x_in, x_ext, sx, z_boss in bosses:
        back = back.cut(_screw_cut(x_ext, sx, z_boss, yb,
                                   up=print_up("back", "top" if z_boss > z_seam else "bottom")))
    # Wall through-holes for the appliance's external connections — the
    # faucet umbilical (carb-water + two flavor), the tap-water inlet, and
    # the C14 mains inlet, all through the +Y wall of back-top in the band above the
    # cold core; their bodies hang in the band's open rear half.
    # Each bore's roof follows the print of the piece that carries its station.
    for side in ("top", "bottom"):
        ports = [p for p in box.pack.back_ports if (p[2] > z_seam) == (side == "top")]
        for cutter in _port_cuts(ports, inner[3] - 5.0, outer[3] + 5.0,
                                 up=print_up("back", side)):
            back = back.cut(cutter)
    # The ASSE drip pan's withdrawal slot through the −X wall, and the sleeve it lies in. The
    # sleeve's own cuts reach back through this wall, so the slot is opened here and reopened
    # there at the one shape.
    for side in ("top", "bottom"):
        ports = [p for p in box.pack.west_ports if (p[2] > z_seam) == (side == "top")]
        for cutter in _x_port_cuts(ports, outer[0] - 5.0, inner[0] + 5.0,
                                   up=print_up("back", side)):
            back = back.cut(cutter)
    back = _pan_sleeve(back, box.pack.pan_sleeve, outer[4] - 1.0, outer[5] + 1.0,
                       up=print_up("back", "top"))
    return cq.Workplane(obj=back)


# HOW FAR THE SLEEVE'S CORBEL RUNS OUT FROM THE WALL. The block's floor is one `wall` under the
# tray and the tray's own length carries it east off the flank, so printed Z−-down the whole
# plate arrives over air. Struck on the plane the block is stated on — the box's own interior —
# so a piece carrying a thicker flank there stands that much less of it proud; what stops it is
# the flavour line's lane, which is what crosses the band under the block (`fluid-28`).
pan_sleeve_corbel = 20.0

# THE MOISTURE-PLATE LEAD STAYS ON THE DRY SIDE OF THE PAN. The −X back-top flank is nine
# millimetres thick here, so the cable clip takes six millimetres of it and leaves three
# millimetres proud in the cabinet plus three millimetres of exterior backing. It runs below
# the sleeve's aft end, with a full dry gap under the sleeve and ahead of the actual rear wall.
# The lead's service loop rises from its forward ramp into the open pan.
pan_cable_clip_embed = 6.0
pan_cable_clip_rear_land = wall
pan_cable_clip_sleeve_gap = 2.0 * wall


def _pan_sleeve(solid, sleeve, z0, z1, up=1.0):
    """The ASSE drip pan's sleeve fused onto a −X wall and its berth cut back out, for a piece whose
    Z band holds the block's own top.

    The pack states the block as one world box rooted on that wall's inner face, and the berth
    as the two boxes the tray's own section makes. Fused THEN cut: the block closes the wall's
    slot on its way past and the berth reopens it, so the opening a hand meets from outside is
    the berth's own shape end to end.

    `up` is the print direction of the piece that carries the block. Printed mouth-down
    (`up > 0`) the block's floor looks print-down: a 45° corbel carries it, run the block's whole
    depth and rooted on the flank the block is rooted on, tapering to nothing `pan_sleeve_corbel`
    off it; what the corbel does not reach stays a soffit, since the tray is longer than any wedge
    off that one wall can hold and nothing stands under the block's east half to root a second one
    on. The rim rebate's roof is then one hipped rectangular transition: its lower perimeter stands
    on the exterior skin, the fore and aft jambs and the east backstop, its upper perimeter is the
    same rectangle inset by the lid's rise, and the four 45° faces meet on diagonal hips round the
    already-open mouth, so no short roof remains over material printed below it.

    Printed ceiling-down (`up < 0`) the block is a plain carcase: floor, jambs, backstop and a
    square lid. Its floor and the rebate's roof look print-up and carry themselves; its lid and
    the berth's floor look print-down over the tray's own room, which no material may fill, and
    the ASSE chain stands over the lid, so both are supported faces, reached from the slab through
    the open mouth. The pan lies on a flat floor either way.

    The sleeve has no electrical pocket: the moisture plate's continuous lead rises out of the
    open pan and is retained on the adjacent dry flank."""
    adds, cuts = sleeve
    blocks = [b for b in adds if z0 <= b[5] <= z1]
    for x0, x1, y0, y1, bz0, bz1 in blocks:
        # Carry the original floor section behind the recessed, supported berth.
        floor_stock = fits.supported_surface if up < 0.0 else 0.0
        solid = solid.fuse(_ybox(x0, x1, y0, y1, bz0 - floor_stock, bz1))
        if up > 0.0:
            solid = solid.fuse(_xz_prism(y0, y1,
                                         [(x0 + pan_sleeve_corbel, bz0), (x0, bz0),
                                          (x0, bz0 - pan_sleeve_corbel)]))
    for x0, x1, y0, y1, cz0, cz1 in (cuts if blocks else ()):
        solid = solid.cut(_supported_cut(_ybox(x0, x1, y0, y1, cz0, cz1), up))
    # The rebate is the larger plan box whose roof is exactly the central mouth's floor. Find
    # that relationship in the pack rather than naming either cut by position: the well overlaps
    # the rebate in Z, while only the mouth is contained face-to-face above it.
    roof_pairs = [
        (rebate, mouth)
        for rebate in cuts for mouth in cuts
        if abs(rebate[5] - mouth[4]) < 1e-6
        and rebate[0] <= mouth[0] + 1e-6 and rebate[1] >= mouth[1] - 1e-6
        and rebate[2] <= mouth[2] + 1e-6 and rebate[3] >= mouth[3] - 1e-6
        and (rebate[0] < mouth[0] - 1e-6 or rebate[1] > mouth[1] + 1e-6
             or rebate[2] < mouth[2] - 1e-6 or rebate[3] > mouth[3] + 1e-6)
    ] if (blocks and up > 0.0) else []
    if blocks and up > 0.0 and len(roof_pairs) != 1:
        raise ValueError(
            f"the pan sleeve has {len(roof_pairs)} contained rebate-to-mouth roof transitions; "
            "exactly one is required")
    if roof_pairs:
        rebate, mouth = roof_pairs[0]
        _rx0, rx1, ry0, ry1, _rz0, roof = rebate
        mx0, mx1, my0, my1, _mz0, top = mouth
        outer_x = min(b[0] for b in blocks) - wall
        rise = top - roof
        tx0, tx1 = outer_x + rise, rx1 - rise
        ty0, ty1 = ry0 + rise, ry1 - rise
        if (rise <= 0.0 or tx0 >= tx1 or ty0 >= ty1
                or tx0 > mx0 + 1e-6 or tx1 < mx1 - 1e-6
                or ty0 > my0 + 1e-6 or ty1 < my1 - 1e-6):
            raise ValueError(
                "the pan sleeve's hipped rebate roof does not finish round its mouth: "
                f"roof ({outer_x:g}, {rx1:g}) × ({ry0:g}, {ry1:g}) at z {roof:g}, "
                f"top ({tx0:g}, {tx1:g}) × ({ty0:g}, {ty1:g}) at z {top:g}, "
                f"mouth ({mx0:g}, {mx1:g}) × ({my0:g}, {my1:g})")
        lower = tuple(cq.Vector(*p) for p in (
            (outer_x, ry0, roof), (rx1, ry0, roof),
            (rx1, ry1, roof), (outer_x, ry1, roof)))
        upper = tuple(cq.Vector(*p) for p in (
            (tx0, ty0, top), (tx1, ty0, top),
            (tx1, ty1, top), (tx0, ty1, top)))

        # Six explicit planar faces keep every roof side an analytic plane in the STEP.
        def face(points):
            return cq.Face.makeFromWires(cq.Wire.makePolygon(points, close=True))

        faces = [face(tuple(reversed(lower))), face(upper)]
        faces.extend(face((lower[i], lower[(i + 1) % 4],
                           upper[(i + 1) % 4], upper[i]))
                     for i in range(4))
        hip = cq.Solid.makeSolid(cq.Shell.makeShell(faces))
        if not hip.isValid():
            raise ValueError("the pan sleeve's hipped rebate roof is not a valid solid")
        solid = solid.cut(hip)
    return solid


def pan_cable_clip_bounds(box):
    """The unchanged clip profile below the sleeve, outside the pan's withdrawal room.

    The rear land is measured from this piece's actual rear face. The complete 39 mm
    section stands below the sleeve's underside, leaving the declared dry gap above it.
    """
    if not box.pack.pan_sleeve or not box.pack.pan_sleeve[0]:
        return None
    blocks = box.pack.pan_sleeve[0]
    if len(blocks) != 1:
        raise ValueError(f"the pan cable clip needs one sleeve block; got {len(blocks)}")
    face = back_top_flank_face()[0]
    run_end = back_top_wall_face() - pan_cable_clip_rear_land
    run_start = run_end - _cable_clip.RUN
    z_high = blocks[0][4] - pan_cable_clip_sleeve_gap
    z_low = z_high - _cable_clip.HEIGHT
    if run_start < box.y_joint + wall or z_low < box.splits[1] + wall:
        raise ValueError("the pan cable clip no longer fits on the dry back-top flank")
    return (face - pan_cable_clip_embed, run_start, z_low,
            face + _cable_clip.projection(pan_cable_clip_embed), run_end, z_high)


def _pan_cable_clip(solid, box, up=1.0):
    """The partially embedded SIG-9 service-loop clip beside the ASSE drip pan.

    THE PROFILE'S UP IS THE PRINT'S. `cable_clip`'s section is asymmetric in its own up — its
    two hooked arms grow off the wall on faces that print free only with that up along the
    build axis — and `apply` derives that up from `along` and `outward`. `up` is the piece's
    print up along the box's Z, ±1: the run is laid along −Y where it is positive and along +Y
    where it is negative, and the origin is the profile's lower corner at the start of
    whichever run that is, so the clip stands over the same Y run and the same Z band either
    way."""
    bounds = pan_cable_clip_bounds(box)
    if bounds is None:
        return solid
    _x0, run_start, z_low, _x1, run_end, z_high = bounds
    face = back_top_flank_face()[0]
    if up > 0:
        origin, along = (face, run_end, z_low), (0.0, -1.0, 0.0)
    else:
        origin, along = (face, run_start, z_high), (0.0, 1.0, 0.0)
    return _cable_clip.apply(
        solid,
        origin=origin,
        outward=(1.0, 0.0, 0.0),
        along=along,
        embed=pan_cable_clip_embed,
        wall_thickness=back_top_flank_t,
    ).val()


def _floor_bosses(solid, inner, stations, y0, y1, z0, z1):
    """The floor slab's mounting bosses added to a PIECE, for the stations whose plan point
    the piece owns and whose slab it holds.

    Each station is `(x, y, tip, dia)`: the two plan coordinates the boss stands on, the plane
    its top face reaches, and the section the donor's own bore leaves it. The plane is where
    the screw's washer comes to rest — just under the crown of the grommet the post rises
    through — so the post runs UP from the slab's own inner face to it and the insert bore is
    cut back down from it. What the slab gives a screw is the standoff the body asked for, and
    what it gives the rubber is a squeeze that stops where the printed material does.

    The ±X walls take their bodies on the flank and the slab takes them from underneath, which
    is the whole difference between this and `_east_bosses`: the shaft runs on Z, the band that
    selects a station is the piece's Y column, and a station only lands on a piece whose Z band
    reaches the floor."""
    if z0 > inner[4] + 1e-6:
        return solid                       # a top piece has no slab to stand a post on
    for sx, sy, tip, dia in stations:
        if not (y0 <= sy <= y1):
            continue
        if (dia - floor_heatset_dia) / 2.0 < boss_ligament:
            raise ValueError(
                f"the floor post at ({sx:g}, {sy:g}) is Ø{dia:g}, which leaves "
                f"{(dia - floor_heatset_dia) / 2.0:g} of material round a Ø{floor_heatset_dia:g} "
                f"insert bore — under the {boss_ligament:g} a ±X wall boss keeps round its own. "
                f"This station's donor bore takes a smaller insert than the M5.")
        solid = solid.fuse(_zcyl(dia / 2.0, sx, sy, inner[4], tip))
        solid = solid.cut(_zcyl(floor_heatset_dia / 2.0, sx, sy,
                                tip - floor_heatset_depth - mount_bore_relief, tip))
    return solid


def _east_boss_stem(wall_x, station, up=1.0):
    """One +X-wall boss's D-shaped horizontal stem, before its insert bore is cut.

    The circle is the insert's annulus. Its print-down half is filled out to a flat chord over
    the boss's whole run, so the free face is a D rather than a circle and the face that looks
    print-down is one plane for a wedge to carry. `up` is the piece's print-up in machine Z:
    +1.0 puts the chord under the hole at `sz - r`, −1.0 puts it over the hole at `sz + r`. The
    body still meets only the boss's own `mount_boss_dia`-wide footprint: the two filled corners
    lie inside the same square and grow wallward, away from the body.
    """
    sy, sz, tip = station[:3]
    r = mount_boss_dia / 2.0
    z0, z1 = (sz - r, sz) if up > 0 else (sz, sz + r)
    return _xcyl(r, sy, sz, tip, wall_x).fuse(
        _ybox(tip, wall_x, sy - r, sy + r, z0, z1))


def _east_boss_d_fill(wall_x, station, up=1.0):
    """Only the two corners on the print-down side that turn the established round stem into a
    D — `up` as `_east_boss_stem` reads it."""
    sy, sz, tip = station[:3]
    r = mount_boss_dia / 2.0
    cylinder = _xcyl(r, sy, sz, tip, wall_x)
    z0, z1 = (sz - r, sz) if up > 0 else (sz, sz + r)
    chord = _ybox(tip, wall_x, sy - r, sy + r, z0, z1)
    return chord.cut(cylinder)


def _east_wedge(wall_x, sz, ylo, yhi, reach, up=1.0):
    """One wall-rooted 45 degree wedge on the print-down side of a boss at `sz`, folded on the
    D's chord at `sz - up * r`, from `reach` back to the wall, over the Y band `ylo..yhi`. For
    `up` of +1.0 it hangs under the chord and falls to the wall; for −1.0 it stands over the
    chord and climbs to it."""
    r = mount_boss_dia / 2.0
    drop = wall_x - reach
    chord = sz - up * r
    return _xz_prism(ylo, yhi, [(wall_x, chord), (reach, chord), (wall_x, chord - up * drop)])


def _east_boss_corbel(wall_x, station, up=1.0):
    """One boss's object-profiled 45 degree wedge from its carried chord to the +X wall, on the
    boss's print-down side — under the hole for `up` of +1.0, over it for −1.0.

    `station[5]`, when present, is the Y span the wedge is offered over instead of the boss's
    own width — a bar's, shared by both the holes that stand in it.

    `station[3]` is the inboard plane the wedge may reach. It is the mounting face unless an
    installed body crosses that wedge; `enclosure_assembly.wall_mounts` derives a setback from
    that body's exact solid. Optional `station[4]` Y bands are the parts of that same boss width
    outside the blocker that `east_boss_wings` lets stand: there the wall-rooted wedge still
    reaches the mounting face instead of holding an entire seven-millimetre boss back for a
    blocker that occupies only one side. The D stem remains whole over the blocker itself, where
    the purchased body already leaves too little Z room for a slicer to grow support.

    AND A SETBACK THAT REACHES THE WALL LEAVES NO WEDGE AT ALL. The wedge is rooted on the wall
    and runs 45 degrees off it, so a blocker standing within its own clearance of that face has
    taken the whole depth a wedge could occupy — there is nothing to build, not a zero-depth one.
    That band goes without, the D stem still carries the hole across it, and any `clear_bands`
    beside the blocker still take the full wall-rooted wedge. Returns None when none survives.
    """
    sy, sz, tip = station[:3]
    web_tip = station[3] if len(station) > 3 else tip
    clear_bands = station[4] if len(station) > 4 else ()
    r = mount_boss_dia / 2.0
    span = station[5] if len(station) > 5 else (sy - r, sy + r)
    if web_tip < tip - stated_bound_tol:
        raise ValueError(
            f"east boss at ({sy:g}, {sz:g}) has corbel tip x={web_tip:g}; "
            f"expected at least its own mounting face {tip:g}")

    out = None
    if web_tip < wall_x - stated_bound_tol:
        out = _east_wedge(wall_x, sz, span[0], span[1], web_tip, up)
    for ylo, yhi in clear_bands:
        if ylo < span[0] - 1e-6 or yhi > span[1] + 1e-6 or yhi <= ylo:
            raise ValueError(
                f"east boss at ({sy:g}, {sz:g}) has invalid clear corbel band "
                f"y={ylo:g}..{yhi:g}; expected inside {span[0]:g}..{span[1]:g}")
        band = _east_wedge(wall_x, sz, ylo, yhi, tip, up)
        out = band if out is None else out.fuse(band)
    return out


def east_boss_wings(span, bands):
    """Which clear `bands` of a corbel offered over `span` stand as wall-rooted wings, and
    which stand down: `(standing, dropped)`, each a tuple of `(ylo, yhi)`.

    A WING IS READ BY WHAT IT LEAVES. A wing at each end of the span leaves the run between
    them rooted at both ends, and that run is a bridge the slicer lays with nothing under it:
    relay #2's upper bar keeps a 2.5 mm wing at either end and bridges the 15 mm between. Any
    other set of wings leaves an open-ended flat, hung or supported exactly as it would be with
    no wing at all, and the wings stand only while they carry more of the span than that flat
    is. Below that they stand down together and the boss offers its whole floor, with nothing
    standing against whatever carries it: the main board's forward upper hole, where the pin
    field leaves 1.53 mm of a 7 mm floor clear, keeps no wing."""
    bands = tuple(sorted((float(lo), float(hi)) for lo, hi in bands if hi > lo))
    if not bands:
        return (), ()
    lo, hi = span
    at_both_ends = (bands[0][0] <= lo + stated_bound_tol
                    and bands[-1][1] >= hi - stated_bound_tol)
    carried = sum(b - a for a, b in bands)
    if at_both_ends or carried > (hi - lo) - carried:
        return bands, ()
    return (), bands


def east_boss_pairs(stations):
    """Which of `stations` share one bar, as index pairs: two holes at one mounting face, on one
    line along Y or Z, within `mount_bar_reach` of each other. Each hole joins at most one
    pair, the nearest first."""
    cands = []
    for i, a in enumerate(stations):
        for j in range(i + 1, len(stations)):
            b = stations[j]
            if abs(a[2] - b[2]) > stated_bound_tol:
                continue
            dy, dz = abs(a[0] - b[0]), abs(a[1] - b[1])
            if dy <= stated_bound_tol:
                along = dz
            elif dz <= stated_bound_tol:
                along = dy
            else:
                continue
            if along <= stated_bound_tol or along > mount_bar_reach + stated_bound_tol:
                continue
            cands.append((along, i, j))
    taken, pairs = set(), []
    for _along, i, j in sorted(cands):
        if i in taken or j in taken:
            continue
        taken.update((i, j))
        pairs.append((i, j))
    return pairs


def _east_bar(wall_x, a, b):
    """The flat-topped bar two paired holes share, before its bores: one box from the mounting
    face to the wall over both holes' footprints and the run between them."""
    (ya, za, tip), (yb, zb, _tip) = a[:3], b[:3]
    r = mount_boss_dia / 2.0
    return _ybox(tip, wall_x, min(ya, yb) - r, max(ya, yb) + r, min(za, zb) - r, max(za, zb) + r)


def _east_bar_fill(wall_x, a, b, up=1.0):
    """Only what the bar adds past the two D stems it joins — the material whose clearance is
    in question. `up` is the stems' print-up (`_east_boss_stem`)."""
    return (_east_bar(wall_x, a, b)
            .cut(_east_boss_stem(wall_x, a, up)).cut(_east_boss_stem(wall_x, b, up)))


def _east_bar_support(wall_x, a, b, up=1.0):
    """The material a pair of stations adds, before their bores — the bar always, and each
    hole's corbel wherever a blocker has left it any depth to stand in, on the print-down side
    `up` names. A pair side by side carries one wedge across the bar's whole span, which both
    holes state (`station[5]`); a pair stood one over the other is carried by the hole nearest
    print-down — the lower for `up` of +1.0, the upper for −1.0 — and the other hole's wedge
    stands inside what the bar and that carrying wedge already fill."""
    out = _east_bar(wall_x, a, b)
    for station in (a, b):
        corbel = _east_boss_corbel(wall_x, station, up)
        if corbel is not None:
            out = out.fuse(corbel)
    return out


def _east_boss_support(wall_x, station, up=1.0):
    """The material one +X-wall mounting station adds, before its bore — the D stem always, and
    the corbel wherever a blocker has left it any depth to stand in, both on the print-down side
    `up` names."""
    stem = _east_boss_stem(wall_x, station, up)
    corbel = _east_boss_corbel(wall_x, station, up)
    return stem if corbel is None else stem.fuse(corbel)


def _east_bosses(solid, roots, outer, stations, fills, y0, y1, z0, z1, up=1.0):
    """The +X wall's mounting bosses added to a PIECE, for the stations inside the depth and
    height band that piece owns — so a boss lands in the piece whose wall carries it, whole,
    and no piece grows a column standing in another's air.

    IT STANDS ON THE FACE THIS PIECE PUTS THERE and not on the box's own. `interior_x` is the
    frame every station is struck in and the plane the pack is packed to, but back-top carries
    `back_top_flank_t` where the box carries one `wall` — so a boss drawn to the box's plane is
    drawn six millimetres into stock that piece has already filled in, and what emerges past the
    face is whatever the station happened to leave. `piece_root_faces` is that plane, and the
    same reading tells this builder how much of a boss there is to stand at all.

    IT IS CARRIED FROM THE PIECE'S OWN PRINT-DOWN SIDE. `up` is the piece's print-up in machine
    Z: +1.0 where the piece beds on its machine Z− face, and every D chord and wedge hangs under
    its hole; −1.0 where it beds on its machine Z+ face, and the same chord and wedge stand over
    the hole and climb to the wall. The stations, bores and bands read the same either way.

    Each station is `(y, z, tip, web_tip, clear_bands)`: the two plan coordinates the boss
    stands on, the plane its top face reaches — the body's own mounting face, where its hole
    pattern lies — the plane its 45 degree wedge may reach across the blocker, and any Y
    bands where it can reach the mounting face. The last two are omitted when the whole wedge
    reaches. Where an installed body crosses only part of the candidate wedge, `wall_mounts`
    keeps assembly air around that part without throwing away the clear side's corbel; the
    D-shaped stem still reaches the mounting face across the whole hole.

    ON THE PIECE AND NOT ON THE HALF, because the Z seam's own socket collar is fused
    piece-side: where a station's height meets a mounting boss's, the two share the same
    material, and a bore cut before that collar is fused is a bore the collar fills back in.
    Cut here, the boss fuses nothing where the collar already stands and is bored through it
    all the same.

    The stem's flat, `mount_boss_dia`-wide chord on its print-down side matches the wedge it
    carries. Its other half stays round around the insert, so the body's mounting pad remains
    compact; no arbitrary round pipe is left between the support and the mounting face.

    THE FOUR AUTHORED FILLS ARE BOXES, NOT A NEW PAIRING RULE. `fills` carries their exact bounds
    and any station whose ordinary wedge that box replaces. The ground stud keeps its D stem and
    bore under a full-width ceiling column; the upper main-board/relay field gets one low pad
    round its three clear stations; and relay 1's two vertical pairs each get one ceiling column.
    Their separate wedges are omitted so every underside is one flat supported face. All four
    fuse before the bores are cut.

    A PAIR OF HOLES ON ONE LINE IS ONE BAR (`east_boss_pairs`): the two stems and the run
    between them are one flat-topped box with two bores in it, on one corbel — the print-down
    hole's for a pair stood one over the other, and one offered across the bar's whole span for
    a pair side by side, which `wall_mounts` profiles against the installed pack the way it
    profiles a single boss. What a paired board meets is one pad, not two posts."""
    mine = [s for s in stations if y0 <= s[0] <= y1 and z0 <= s[1] <= z1]
    replaced = tuple(
        site
        for _name, _bounds, replaced_corbels in fills
        for site in replaced_corbels
    )

    def replaces_corbel(station):
        return any(abs(station[0] - sy) <= stated_bound_tol
                   and abs(station[1] - sz) <= stated_bound_tol
                   for sy, sz in replaced)

    pairs = east_boss_pairs(mine)
    paired = {k for pair in pairs for k in pair}
    for k, station in enumerate(mine):
        sy, sz, tip = station[:3]
        # A STATION STANDING UNDER `east_boss_min_stand` OFF THAT FACE GROWS NOTHING. The body is
        # already on the wall to within the air its own screw closes, so the wall is its mounting
        # face: a stem struck for that much emerges as a fraction-of-a-millimetre step across the
        # flank with a sliver edge round it, and its wedge comes out shorter still.
        if k in paired or roots[1] - tip < east_boss_min_stand - stated_bound_tol:
            continue
        support = (_east_boss_stem(roots[1], station, up)
                   if replaces_corbel(station)
                   else _east_boss_support(roots[1], station, up))
        solid = solid.fuse(support)
    for i, j in pairs:
        if roots[1] - mine[i][2] >= east_boss_min_stand - stated_bound_tol:
            omit = (replaces_corbel(mine[i]), replaces_corbel(mine[j]))
            if any(omit) and not all(omit):
                raise ValueError(
                    "an east mounting fill must replace both corbels of a paired bar or neither")
            support = (_east_bar(roots[1], mine[i], mine[j])
                       if all(omit)
                       else _east_bar_support(roots[1], mine[i], mine[j], up))
            solid = solid.fuse(support)
    for _name, bounds, _replaced_corbels in fills:
        fx0, fx1, fy0, fy1, fz0, fz1 = bounds
        cy, cz = (fy0 + fy1) / 2.0, (fz0 + fz1) / 2.0
        if not (y0 <= cy <= y1 and z0 <= cz <= z1):
            continue
        if fy0 < y0 - stated_bound_tol or fy1 > y1 + stated_bound_tol:
            raise ValueError(
                f"east mounting fill y={fy0:g}..{fy1:g} crosses its piece band "
                f"{y0:g}..{y1:g}")
        if fz0 < z0 - stated_bound_tol or fz1 > z1 + stated_bound_tol:
            raise ValueError(
                f"east mounting fill z={fz0:g}..{fz1:g} crosses its piece band "
                f"{z0:g}..{z1:g}")
        solid = solid.fuse(_ybox(fx0, fx1, fy0, fy1, fz0, fz1))
    for station in mine:
        sy, sz, tip = station[:3]
        if roots[1] - tip >= east_boss_min_stand - stated_bound_tol:
            # Keep the manufacturer's complete radial ligament behind the relieved insert
            # crown. Only this local boss grows; the component's seating plane is unchanged.
            solid = solid.fuse(_supported_cut(_east_boss_stem(roots[1], station, up), up))
        # THE BORE STILL STARTS AT THE BODY'S OWN FACE, stem or no stem. `roots` is one plane and
        # the piece is not: a station standing where the flank has already turned into its rear
        # corner meets a face inboard of that plane, and a bore struck on the plane leaves that
        # much of a membrane capped over the insert's mouth. Struck from `tip` it opens whatever
        # is actually between the body and the wall, and where nothing is, it cuts air.
        # AND THE BORE STOPS WHERE THE SURFACE SAYS, not where the plane does. Run its full
        # relief it ends on `interior_x`, which is one `wall` behind the flat and less than
        # that behind a corner round — and a flute is cut into that same surface, so a station
        # standing on the turn would put a groove over an insert with too little between them.
        # It gives up relief before it gives up `flute_backing`; `boss-bore-seats` reads what
        # is left against the insert's own depth.
        solid = solid.cut(_supported_cut(
            _xcyl(heatset_dia / 2.0, sy, sz, tip,
                   east_boss_bore_end(sy, tip, outer)), up))
    return solid


def east_boss_bore_end(sy, tip, outer):
    """How far out a +X mounting boss's insert bore may run — its full relief, or as far as
    `flute_backing` behind the shallowest surface over the bore's own footprint, whichever
    stops first."""
    edge = min(flank_x_at(sy - heatset_dia / 2.0, outer),
               flank_x_at(sy + heatset_dia / 2.0, outer))
    return min(tip + heatset_depth + mount_bore_relief, edge - flute_backing)


def _side_wells(solid, inner, stations, y0, y1, z0, z1, up=1.0):
    """A side wall's Wago wells added to a PIECE, for the stations inside the depth and
    height band that piece owns — the same band test `_east_bosses` makes, so a well lands
    whole in the piece whose wall carries it.

    Each station is `(side, y, z, size, clear_z, supportless_roof[, column])`: which flank the
    well is grown on (+1 east, −1 west), its centre on that wall, the 221 it takes, the plane on
    the tower's print-down side its wedge may not cross, which of the two lid forms the pocket's
    print-down face keeps, and — where the assembly has read the air from the tower's print-down
    face to `clear_z` and found no placed body in it — that the tower STANDS ON THAT PLANE as a
    column, its own section carried straight to it, instead of wearing a wedge.

    `up` IS THE PIECE'S PRINT-UP in machine Z, +1.0 where the piece beds on its machine Z− face
    and −1.0 where it beds on its Z+ face. Every face this builder carries is carried on the
    print-down side: the tower's wedge hangs under it for +1.0 and stands over it for −1.0, and
    the pocket's tabbed lid is its roof for +1.0 and its floor for −1.0. The pocket's other face
    keeps the complete `wago_well_wall` section.

    A ROW IS ONE TOWER. Wells at one height on one wall, each within a pitch of the next, stand
    in one tower spanning the row from the first well's end to the last's, on one wedge run the
    whole length; every well's pocket and lid are then cut to its own connector size at its own
    station. The common outer envelope takes the deepest and tallest member. The row is spaced
    by the lever and not by the wall (`wago_pitch`), so separate towers would otherwise stand a
    slit apart — or, where adjacent sizes differ, overlap with a fraction-of-a-millimetre step.
    Filling both leaves one fore face, two ends and one carried face with the pockets in it. The
    levers work on the lug's wire half, inboard of that face, and swing in the room as before.

    The tower stands off the wall's inner face and the cavity is cut from that face
    outward past its own end, so the pocket opens INBOARD and bottoms on the wall. What
    the lug meets at the bottom of its travel is the wall itself, not a printed floor —
    the wall is the datum, so the ports stand at a height the wall states.

    A SUPPORTLESS LID IS TWO TABS, NOT A SOFFIT. The band on the pocket's print-down face
    keeps `wago_roof_tab` at each end and opens between them. That opening closes on one 45°
    plane folded on the wall at that face, so each tab is its own short bridge and the ramp lays
    every layer on the one below it. Where that face is the floor, the lug rests on the two
    tabs and the wall's press fit locates it.

    A FLAT LID keeps the complete `wago_well_wall` section across the pocket. It catches the
    lug across its full width and leaves any corbel or flank section standing on the well
    whole too. Only a station explicitly marked for this lid gives up the supportless opening.

    A 45° WEDGE CARRIES THE TOWER'S PRINT-DOWN FACE to the wall. `clear_z` is the plane the
    flank's air stops being the well's — the crown of whatever the station stands over for
    +1.0, the ceiling it stands under for −1.0 — and a wedge that would cross it is cut off
    flat there instead."""
    mine = sorted(
        (s for s in stations if y0 <= s[1] <= y1 and z0 <= s[2] <= z1),
        key=lambda s: (s[0], s[2], s[4] is None, 0.0 if s[4] is None else s[4], s[5], s[1]))
    rows = []
    for st in mine:
        side, sy, sz, size, clear_z, supportless_roof = st[:6]
        key = (side, sz, clear_z, supportless_roof)
        if rows and rows[-1][0] == key and sy - rows[-1][1][-1][1] <= wago_pitch + 1e-6:
            rows[-1][1].append(st)
        else:
            rows.append((key, [st]))
    for (side, sz, clear_z, supportless_roof), row in rows:
        face = inner[1] if side > 0 else inner[0]
        engage = max(wago_engage(st[3]) for st in row)
        half_z = max(wago_half(st[3])[1] for st in row)
        # inboard is −X on the east wall and +X on the west, so the tower and the pocket
        # both run from the wall towards the room
        tower = sorted((face, face - side * engage))
        ya = min(st[1] - wago_half(st[3])[0] for st in row)
        yb = max(st[1] + wago_half(st[3])[0] for st in row)
        # Pocket tabs are short bridges even where the centre is opened by a ramp.
        # Grow the backing along with the pocket so the lid keeps its full section.
        solid = solid.fuse(_ybox(
            tower[0], tower[1], ya, yb,
            sz - half_z - (fits.supported_surface if up < 0.0 else 0.0),
            sz + half_z + (fits.supported_surface if up > 0.0 else 0.0)))
        # the wedge is folded on the tower's print-down face and runs away from the tower,
        # toward `clear_z`, as far as it may — or, where every well in the row has read that air
        # clear, the tower's own section goes straight on to `clear_z` and stands on it
        zb = sz - up * half_z
        column = clear_z is not None and all(len(s) > 6 and s[6] for s in row)
        if column and up * (zb - clear_z) > 1e-6:
            solid = solid.fuse(_ybox(tower[0], tower[1], ya, yb, *sorted((zb, clear_z))))
            run = 0.0
        else:
            run = engage if clear_z is None else min(engage, up * (zb - clear_z))
        if run > 0.3:
            prof = [(face, zb), (face - side * engage, zb)]
            if run < engage - 1e-9:
                prof.append((face - side * (engage - run), zb - up * run))
            prof.append((face, zb - up * run))
            solid = solid.fuse(_xz_prism(ya, yb, prof))
        for _side, sy, _sz, size, _clear_z, _supportless_roof in (s[:6] for s in row):
            reach = wago_engage(size) + 1.0
            pocket = sorted((face, face - side * reach))
            stand_y, stand_z, _sx = wago_stand(size)
            pk_y = stand_y / 2.0 + wago_well_press
            floor_z = sz - (stand_z / 2.0 + wago_well_press)
            roof_z = sz + stand_z / 2.0 + wago_well_press
            floor_z -= fits.supported_surface if up < 0.0 else 0.0
            roof_z += fits.supported_surface if up > 0.0 else 0.0
            solid = solid.cut(_ybox(pocket[0], pocket[1],
                                    sy - pk_y, sy + pk_y, floor_z, roof_z))
            if supportless_roof:
                # the tabs and the ramp are on the pocket's print-down face, and the ramp
                # opens away from the pocket
                lid_z = roof_z if up > 0 else floor_z
                gap = pk_y - wago_roof_tab
                solid = solid.cut(_xz_prism(
                    sy - gap, sy + gap,
                    [(face, lid_z), (face - side * reach, lid_z),
                     (face - side * reach, lid_z + up * reach)]))
    return solid


# --- the PRV's chase, down the OUTSIDE of the west wall ----------------------
#
# The cold core's relief line leaves that core by a flank (`_internal_routes.prv_vent_cross_z`)
# and is cut flush with it. It arrives here pointing west, and this is what carries the
# discharge OUT OF THE BOX.
#
# ITS DEPTH COMES OUT OF A WALL THICKENED FROM THE INSIDE, into the band the core already
# stands off, and the outer face stays the plane `outer` names.
#
# THE LIP LANDS ON THE CORE. The rib's east face is the core's own west flank, so the mouth
# closes on that flank all round the tube's cut end. The core is located by its own two corner
# blocks and comes down as one unit (`cards/en-06-seat-cold-core`), so what the wall presents
# it is a target and not a fit: the mouth is `vent_channel_w` on a side against a tube less
# than half that across, and the balance is the room the core has to land in.
#
# Behind the mouth the passage turns DOWN. It is roofed by the rib and the wall's SKIN stands
# outboard of it, so the flank is unbroken at that height. `vent_duct_drop` under the mouth the
# skin opens, and the passage carries on as a three-walled groove.
#
# AND THE GROOVE ENDS BY RUNNING OUT. Its floor returns to the outer face on the same 45 degree
# support-free slope used by every relief on this standing print. The ramp is therefore exactly
# as tall as the chase is deep: enough to turn the flow west without dragging a long, accidental-
# looking scar down the show face. CO2 is heavier than air and falls from there on its own.
vent_channel_w = 12.0          # the channel, across — and the mouth, square on it
vent_rib_wall = 3.0            # PETG either side of the channel, behind it, and over the mouth
vent_duct_drop = 25.0          # the closed fall under the mouth, before the skin opens
vent_groove_drop = 25.0        # the open groove under that, which the duct discharges into
vent_ramp_angle = relief_chamfer  # support-free run-out from the channel floor to the show face


def _vent_chase(solid, inner, outer, stations, y0, y1, z0, z1, up=1.0):
    """The PRV vent's chase on a −X wall PIECE — the rib the piece whose band holds the
    discharge stands, and this piece's own height of the passage through it.

    One station, `(x, y, z)`: the core's own west flank and the tube's own axis where it comes
    through, in the machine's own frame. A RIB is fused up the wall's inner face OUT TO THAT
    FLANK, and the whole passage is cut back out of it in ONE profile — mouth, roofed duct, open
    groove and run-out ramp are one polygon, one passage, and what changes down it is how much
    of the wall is still standing outboard of it. The mouth is `vent_channel_w` square, on the
    tube's own axis, and its lip is the rib's east face — the face that lands on the core.

    THE TUNNEL'S CEILING IS ONE 45° X RAMP FROM THE −X WALL TO THE CORE. It begins at the
    square passage's roof on the liner inside the flank, then rises one millimetre in Z for every
    millimetre it advances in X through the wall and across the exposed rib. The cap follows that
    same plane one structural section above it. The wall is the root that already prints, so no
    part of this X-wall feature slopes in Y from the channel's jambs.

    NEITHER THE RIB NOR THE PASSAGE CROSSES THE SEAM. They part on different planes and for
    different reasons, and between them nothing of one piece stands in the other's travel.
    THE RIB PARTS ON THE RIM, which is the bottom piece's own top: below it the rib is the
    bottom's, above it there is no bottom piece to sweep and the top carries its own share
    with a `vent_rib_wall` liner on the west side. THE PASSAGE PARTS ON THE SEAM AND BOTH
    PIECES CUT IT. A piece keeping its own material in
    the duct's plan is a piece narrowing the duct, and below `groove_top` it is the wall
    itself that has to open — the discharge leaves through the flank there, and half that
    opening is the top piece's to give. Below the rim the piece's own skin is the duct's west
    face, as it is for the groove; above it the liner is.

    AND WHERE THE PASSAGE MEETS THE Z SEAM'S OWN BAND, THE RIB YIELDS AND THE PASSAGE DOES
    NOT. The rib is `vent_rib_wall` longer than its passage at each end, so a rib standing in
    the actual back rail band — the full-section foot followed by the hook profile — is two
    solid slabs swept the length of the rail as the top comes home. The passage is the hole
    through it and sweeps nothing, so it goes straight across: the rail gives up
    `vent_channel_w` where the one opening that has to cross it does, and the duct keeps its
    whole section.

    THE RIB RUNS OUT WITH THE RAMP. It stands behind the channel's floor, so it reaches as far
    down as that floor is still inboard of what the skin alone stands `vent_rib_wall` behind.
    Under that the ramp is cutting skin the wall already had, and the rib ends on the ramp's
    own slope.

    `up` is the print direction of the piece the share is cut for. Printed mouth-down (`up > 0`)
    the top share beds on the flank's 45° planes off the rim and hangs below none of them.
    Printed ceiling-down (`up < 0`) the share stands square on the rim, which looks print-up, and
    what looks print-down is the rib's own crown: a 45° wedge from the lip back to the flank's
    root carries it, and the mouth's floor is a `vent_channel_w` bridge between the passage's two
    jambs."""
    for sx, sy, sz in stations:
        half = vent_channel_w / 2.0 + vent_rib_wall
        rib_x = sx                                  # the lip, on the core's own flank
        floor_x = rib_x - vent_rib_wall             # the channel's back face, all the way down
        ramp_depth = floor_x - outer[0]
        ramp_rise = ramp_depth / math.tan(math.radians(vent_ramp_angle))
        vent = sz - vent_duct_drop - vent_groove_drop - ramp_rise
        # THE RIB IS ONE PIECE'S AND THE PASSAGE IS THE COLUMN'S. The discharge opens
        # through the wall at the ramp's foot, so the piece whose band holds that foot is
        # the one that stands the rib — but the passage crosses the Z seam, and a piece
        # that keeps its own material in the duct's plan is a piece narrowing the duct. So
        # both cut, and the joint gives up the same `vent_channel_w` on either side of it.
        if not (y0 <= sy <= y1 and vent < z1 and sz + half > z0):
            continue
        owns = z0 <= vent <= z1
        mouth_top = sz + vent_channel_w / 2.0
        # On the ceiling-bedded quadrant the mouth's lower edge is a supported
        # bridge. Its tube axis and the support-free roof keep their datums.
        mouth_bot = (sz - vent_channel_w / 2.0
                     - (fits.supported_surface if up < 0.0 else 0.0))
        groove_top = sz - vent_duct_drop            # where the skin opens
        ramp_top = groove_top - vent_groove_drop
        ramp_bot = ramp_top - ramp_rise              # where the floor has met the outer face
        # The ramp is carried one more millimetre of DEPTH past that, out into air.
        over = ramp_rise / ramp_depth
        # And the rib to where the skin alone stands `vent_rib_wall` behind the floor.
        rib_end = ramp_top - ramp_rise * ((floor_x - (inner[0] - vent_rib_wall))
                                          / ramp_depth)
        rim = z_seam + z_rise                       # the back column's own; the chase is its
        liner_x = inner[0] + slide_slip + vent_rib_wall
        passage_half = vent_channel_w / 2.0
        root_x = back_top_flank_face()[0]           # the exposed rib's actual wall root
        roof_root = mouth_top + (root_x - liner_x)  # one X ramp from the square passage's liner
        roof_run = rib_x - root_x
        if roof_run <= 0.0:
            raise ValueError(
                f"the PRV chase lip at x={rib_x:g} does not stand inboard of its "
                f"wall root x={root_x:g}")
        rib = _xz_prism(sy - half, sy + half,
                        [(inner[0], sz + half), (rib_x, sz + half),
                         (rib_x, ramp_top), (inner[0], rib_end)])
        # THE CAP FOLLOWS THE PASSAGE'S X RAMP. At `root_x` the roof has already climbed through
        # the flank from `liner_x`, so material stands across the channel's whole width and the
        # exposed rib continues the same wall-normal plane to the core. The lower rectangle is
        # already inside `rib`; including it here makes this one closed wedge before the two fuse.
        cap_root = roof_root + 2.0 * vent_rib_wall
        rib = rib.fuse(_xz_prism(
            sy - half, sy + half,
            ((root_x, sz + half), (rib_x, sz + half),
             (rib_x, cap_root + roof_run), (root_x, cap_root))))
        if up < 0.0:
            # THE CROWN'S OWN WEDGE, on a piece whose crown looks print-down: from the lip at
            # the rib's top back to the flank's root, rising one millimetre per millimetre.
            rib = rib.fuse(_xz_prism(
                sy - half, sy + half,
                ((rib_x, sz + half), (root_x, sz + half), (root_x, sz + half + roof_run))))
        # THE RIB KEEPS OUT OF THE JOINT'S BAND AND THE DUCT DOES NOT, because one of them
        # is material and the other is air. Over the seam's own storey the joint reaches
        # `rail_reach_in + slide_slip` inboard of the flank — head, foot, arm and channel —
        # and the rib is `vent_rib_wall` longer than its passage at each end, so a rib
        # standing in that band is two slabs that sweep the length of the rail as the top
        # comes home. The passage sweeps nothing: it is the hole. So the rib stops at the
        # band and the duct goes straight through it, `vent_channel_w` of the rail given up
        # to the one opening that has to cross it, and the duct keeps its whole section.
        _x_hk, _x_f, _x_a, x_h1 = _rail_x(inner[0], +1.0, "back")
        joint_lane = _ybox(inner[0] - 1.0, x_h1 + slide_slip,
                           sy - half - 1.0, sy + half + 1.0, z_seam, rim)
        rib = rib.cut(joint_lane)
        # AND EACH PIECE STANDS ITS OWN HEIGHT OF IT, the two parting on the seam's RIM,
        # which is the bottom piece's own top. Below the rim the rib is the bottom's and the
        # top's flank clears it — the band above is what `joint_lane` already took. Above the
        # rim there is no bottom piece at all, so the top carries its share and sweeps air.
        # NOTHING OF EITHER CROSSES INTO THE OTHER'S TRAVEL, so the top needs no berth cut
        # down its flank for a rib that was never in it.
        band = ((outer[4] - 1.0, rim) if owns else (rim, outer[5] + 1.0))
        share = rib.intersect(
            _ybox(outer[0] - 1.0, outer[1] + 1.0,
                  sy - half - 1.0, sy + half + 1.0, band[0], band[1]))
        if not owns and up > 0.0:
            # THE TOP SHARE BEDS ON THE FLANK'S ESTABLISHED PLANES AND HANGS BELOW NONE OF
            # THEM. From the box's interior face its underside is the flank band's one 45°
            # bedding plane off the seam rim (`_back_top_flanks`); where that plane crosses
            # the rail channel's east gable the underside follows the gable down, and from
            # the gable it rises one-for-one to the lip on the slope struck from `rim` at the
            # actual flank face, where more than `vent_rib_wall` remains below the square
            # mouth. Nothing of the share stands inside the channel's swept section, and the
            # run from the rail to the lip is still the piece below's to stand. IT IS TAKEN
            # OUT OF THE SHARE AND NOT OUT OF THE RIB, because a cutter carried below `rim`
            # to keep off a coincident plane reaches the ground half's own crest there.
            _x_open, _x_f, x_d = _rail_channel_span(inner[0], +1.0, "back")
            gable_bed = (slide_slip + x_d + inner[0]) / 2.0
            gable_lip = (slide_slip + x_d + root_x) / 2.0
            share = share.cut(_xz_prism(
                sy - half - 1.0, sy + half + 1.0,
                ((inner[0], rim - 1.0), (rib_x + 1.0, rim - 1.0),
                 (rib_x + 1.0, rim + (rib_x + 1.0 - root_x)),
                 (gable_lip, rim + (gable_lip - root_x)),
                 (gable_bed, rim + (gable_bed - inner[0])),
                 (inner[0], rim))))
        solid = solid.fuse(share)
        solid = solid.cut(_xz_prism(sy - vent_channel_w / 2.0, sy + vent_channel_w / 2.0,
                                    [(rib_x + 1.0, mouth_top),       # the mouth, through the lip
                                     (rib_x + 1.0, mouth_bot),
                                     (floor_x, mouth_bot),           # \ the floor, straight down
                                     (floor_x, ramp_top),            # /  behind duct and groove
                                     (outer[0] - 1.0, ramp_bot - over),   # the ramp, run out
                                     # The groove's open side closes on a 45-degree X roof.
                                     # Its visible root stays at `groove_top` on the show face;
                                     # the one-millimetre cutter overrun starts one lower, and
                                     # the inner point rises by the wall's exact three-millimetre
                                     # section, making the complete down-facing transition
                                     # support-free.
                                     (outer[0] - 1.0, groove_top - 1.0),
                                     (inner[0], groove_top + (inner[0] - outer[0])),
                                     (inner[0], rim),                # is the duct's west face;
                                     (liner_x, rim),                 # above it the liner is,
                                     (liner_x, mouth_top)]))         # and the rib roofs the duct
        # ONE WALL-NORMAL ROOF THROUGH THE FLANK AND THE EXPOSED RIB. The square passage keeps its
        # complete section at `liner_x`; from there every layer advances one millimetre toward the
        # core for every millimetre it rises. There is no separate Y hip inside the X wall.
        solid = solid.cut(_xz_prism(
            sy - passage_half, sy + passage_half,
            ((liner_x, mouth_top), (rib_x + 1.0, mouth_top),
             (rib_x + 1.0, mouth_top + (rib_x + 1.0 - liner_x)))))
    return solid


def _west_cradle(solid, inner, stations, y0, y1, z0, z1):
    """The −X strip's MQ-6 card slot added to a PIECE, for the stations inside the depth and
    height band that piece owns — the same band test `_side_wells` makes.

    Each station is `(x, y, z)`: the card's own mid-plane, and its centre along the strip and in
    height. Nothing else is passed, because nothing else varies — the slot is one board's
    envelope and one slip fit, read off the reference solid.

    TWO POSTS STAND ON THE SLAB, one at each end of the card's long run, rooted on the wall as
    well and grooved on the faces they turn toward each other. The card DROPS IN FROM ABOVE and
    lands on the shoulder at the foot of each groove — so a groove is blind at the bottom and
    open at the top, and the whole cradle grows UP off the slab: first layer on the bed, every
    layer after it on the one below, nothing over air and no support to pick out of a groove.
    That is what standing the card along the strip buys, and it is why it lies that way.

    THE GROOVES TAKE THE ENDS OF THE LONG RUN, and how much they may take is the CAN'S to say.
    The can is centred on the board and leaves half a millimetre at each long edge, so the ends
    are the only material clear of it — a post reaching further in than the can leaves is a post
    driven into the sensor. So the grip is `mq6_grip` or what the can leaves, whichever is less,
    and the two posts pass either side of the can rather than through it.

    THE EAST CHEEK IS CUT ACROSS THE HEADER. The pins face east off the card and the loom lands
    on them out of the bay, so a cheek running unbroken past them is a cheek nothing can reach
    through. The cut is struck on the header's own band — `header_span` states both how far in
    off the card's end the row stands and how far it runs — and it is taken at BOTH ends,
    because which end of the card the header lands at is the card's turn to state and not this
    slot's. IT RUNS TO THE TOP OF THE POST: up is where the loom comes from, and a cut closed at
    its crown would leave the cheek above it reaching sideways off the post over open air, which
    is the one thing this cradle exists to have none of.

    THE WALL IT IS STRUCK FROM IS THE ONE THAT IS THERE. The card stands under a Z seam, and a
    flank under a seam carries its lip's own wall down to the slab — so the datum is
    `lip_face_x` and not `interior_x`, `2 * wall` of flank and not one. The can bottoms on that
    plane, through the well `_front_bottom_flank_skin` opens for it, and
    `enclosure_assembly.build_mq6` seats the card on the same call."""
    span, off = _mq6.header_span()
    across = _mq6.PIN_SQ / 2.0 + mq6_header_relief
    grip = min(mq6_grip, (mq6_card_y - mq6_can_yz) / 2.0)
    for sx, sy, sz, *_foot in stations:
        if not (y0 <= sy <= y1 and z0 <= sz <= z1):
            continue
        gx0 = sx - mq6_card_x / 2.0 - mq6_slot_press
        gx1 = sx + mq6_card_x / 2.0 + mq6_slot_press
        px0, px1 = lip_face_x()[0], gx1 + mq6_rail_wall
        zb, zt = sz - mq6_card_z / 2.0, sz + mq6_card_z / 2.0
        for into in (1.0, -1.0):
            end = sy - into * mq6_card_y / 2.0
            # The post: slab to the card's own crown, rooted on the wall over its whole depth.
            pa, pb = sorted((end - into * mq6_rail_wall, end + into * grip))
            solid = solid.fuse(_ybox(px0, px1, pa, pb, inner[4], zt))
            # And its groove, open at the top so the card comes in from above and blind at the
            # bottom so it lands: what it lands ON is the post's own first `mq6_rail_wall`.
            ga, gb = sorted((end - into * mq6_slot_press, end + into * (grip + 1.0)))
            solid = solid.cut(_ybox(gx0, gx1, ga, gb, zb, zt + 1.0))
            # And the east cheek off the header's own band, from the pin field's foot CLEAR TO
            # THE TOP. Up, because the loom comes down out of the bay onto the pins and a cheek
            # over them is a cheek it cannot pass — and because a cut closed at its crown would
            # leave the cheek above it standing on nothing, reaching sideways off the post over
            # open air. Everything this cradle keeps runs to the bed.
            ha, hb = sorted((end + into * (mq6_card_y / 2.0 - off - across),
                             end + into * (mq6_card_y / 2.0 - off + across)))
            solid = solid.cut(_ybox(gx1, px1 + 1.0, ha, hb,
                                    sz - span - mq6_header_relief, zt + 1.0))
    return solid


def _cond_cradle_corbel(inner, station):
    """The crown rail's full-width 45° underside, rooted on the front wall."""
    face, cx0, cx1, fz0, fz1, root = station
    root_y = min([front_plane_y] + [f for rx0, rx1, rz0, rz1, f in fridge_reliefs
                                    if cx0 >= rx0 - 1e-6 and cx1 <= rx1 + 1e-6
                                    and rz0 <= (fz0 + fz1) / 2.0 <= rz1])
    free_y = face + cond_slot_grip
    reach = free_y - root_y
    return _yz_prism(cx0, cx1, ((root_y, root - reach),
                                (root_y, root), (free_y, root)))


def _cond_cradle(solid, inner, stations, y0, y1, z0, z1):
    """The condenser block's FORE rails added to a PIECE, one per fore flange, for the stations
    inside the depth and height band that piece owns.

    Each station is `(face, x0, x1, fz0, fz1, root)`: the plane the block's fore face comes to
    rest on, that flange's own width, its two faces in height, and how far the rail runs DOWN
    under it. A rail is one slab off the front wall's inner face, out to `cond_slot_grip` past
    the face — and the groove is cut out of that last stretch alone, so what stands fore of the
    block is solid material and the flange bottoms on it. THE RAIL IS THE DATUM: the block's
    reach into the bay is its own depth and not a number typed here.

    The BASE rail's `root` is the slab, so it comes out of the print as a corner bracket in one
    piece with both faces it stands on. The CROWN rail is one section under its own groove and its
    whole flat underside is carried back to the front wall on a 45° corbel. The rail reaches only
    `cond_slot_grip` past that wall, so the wedge is the same three millimetres deep and leaves the
    condenser's upper flange more than one wall above it.

    THE GROOVE IS STRUCK OFF THE FLANGE IT TAKES and not off a figure typed here: `cond_slot_half`
    reads the station's own sheet. At the seated wall stop its roof keeps that exact opening;
    from there it rises toward the bay at 45° until it runs through the rail's crown. The flange
    therefore keeps its datum and fit while the opening is never closed by a flat
    roof printed over material below it."""
    for face, cx0, cx1, fz0, fz1, root in stations:
        if not (y0 <= face <= y1 and z0 <= (fz0 + fz1) / 2.0 <= z1):
            continue
        half = cond_slot_half(fz1 - fz0)
        # The rail roots on the wall surface actually behind the block, which is the front
        # wall's own interior plane where no relief is struck over this station's span.
        root_y = min([front_plane_y] + [f for rx0, rx1, rz0, rz1, f in fridge_reliefs
                                        if cx0 >= rx0 - 1e-6 and cx1 <= rx1 + 1e-6
                                        and rz0 <= (fz0 + fz1) / 2.0 <= rz1])
        solid = solid.fuse(_ybox(cx0, cx1, root_y, face + cond_slot_grip,
                                 root, fz1 + half + cond_rail_wall))
        if root > inner[4] + 1e-6:
            solid = solid.fuse(_cond_cradle_corbel(
                inner, (face, cx0, cx1, fz0, fz1, root)))
        # The groove runs out past the rail's own aft end, so the flange enters from the bay. Its
        # floor remains flat; its roof rises one-for-one from the seated wall stop into that open
        # end, preserving the exact fit at `face` and removing the short material-rooted bridge.
        mouth = cond_slot_mouth(face)
        run = mouth - face
        solid = solid.cut(_yz_prism(
            cx0 - 1.0, cx1 + 1.0,
            ((face, fz0 - half), (mouth, fz0 - half),
             (mouth, fz1 + half + run), (face, fz1 + half))))
    return solid


def _cond_mount_corbel(inner, station):
    """The upper condenser finger's 45° underside, rooted on its standing east fin."""
    flank, my0, my1, bosses = station
    west = min(bx for bx, _by, _tip in bosses) - mount_boss_dia
    tip = max(t for _bx, _by, t in bosses)
    root = tip - cond_boss_t
    return _xz_prism(my0, my1, ((west, root), (flank, root),
                                (flank, root - (flank - west))))


def _cond_mount(solid, inner, station, y0, y1, z0, z1):
    """The condenser block's AFT mount added to a PIECE: one fin on the +X wall and a finger
    reaching west off it under each of the block's two mount holes.

    The station is `(flank, my0, my1, bosses)`: the plane the fin's own west face stands on —
    the block's east flank and one `cond_mount_clear` — the Y band the whole of this occupies,
    and one `(x, y, tip)` per hole, where `tip` is the face of the flange that screw pulls down.

    THE LOWEST FINGER RUNS TO THE SLAB, because nothing stands between its own tip and the floor
    and the block's aft end comes down on it. The upper one is one `cond_boss_t` deep and its
    whole underside is carried at 45° back to the standing fin. The wedge occupies the empty aft
    recess and stops on the fin's west face, one `cond_mount_clear` off the condenser; no column
    roots inside the block's own flanks."""
    if not station:
        return solid
    flank, my0, my1, bosses = station
    if not (y0 <= (my0 + my1) / 2.0 <= y1 and z0 <= inner[4] <= z1):
        return solid
    crown = max(t for _bx, _by, t in bosses)
    floor_tip = min(t for _bx, _by, t in bosses)
    if floor_tip - inner[4] < cond_bore_depth - 1e-6:
        raise ValueError(
            f"the lowest condenser flange stands {floor_tip - inner[4]:g} over the slab and the "
            f"boss under it carries a {cond_bore_depth:g} bore — a body set down closer than its "
            f"own insert is a body whose screw has nowhere to close. Stand it off by at least "
            f"that, or capture that flange the way the fore pair is captured.")
    west = min(bx for bx, _by, _t in bosses) - mount_boss_dia
    for bx, by, _tip in bosses:
        room = min(bx - west, inner[1] - bx, by - my0, my1 - by) - heatset_dia / 2.0
        if room < boss_ligament:
            raise ValueError(
                f"the condenser boss at ({bx:g}, {by:g}) keeps {room:g} of material round its "
                f"Ø{heatset_dia:g} insert bore, under the {boss_ligament:g} every boss in this "
                f"box keeps round one. The hole has moved off the band this finger stands in.")
    solid = solid.fuse(_ybox(flank, inner[1], my0, my1, inner[4], crown))
    for bx, by, tip in bosses:
        root = inner[4] if tip == floor_tip else tip - cond_boss_t
        solid = solid.fuse(_ybox(west, inner[1], my0, my1, root, tip))
    if crown > floor_tip + 1e-6:
        solid = solid.fuse(_cond_mount_corbel(inner, station))
    for bx, by, tip in bosses:
        solid = solid.cut(_zcyl(heatset_dia / 2.0, bx, by, tip - cond_bore_depth, tip))
    return solid


def vent_band(airway):
    """The height the condenser's vents are pierced over, as `(z0, z1)` — THE FAN'S FOOTPRINT
    ON THE FLANK, taken off the block where it stands.

    `cond_airway`'s last two figures are the placed block's own crown and base, so the fan's
    two insets are read against metal that is already somewhere rather than against a station
    typed here: raise the block and the vent rises with it. Everything else in the feature —
    the transoms, the free area, the window a reading is taken over — is struck off this one
    pair."""
    return airway[2] + cond_fan_rise, airway[3] - cond_fan_drop


def vent_transoms(airway):
    """The unpierced bands crossing that vent, as `((z0, z1), ...)`.

    THE LAYOUT IS THE BAND DIVIDED, not a list of stations. `cond_vent_transoms` transoms of
    `cond_vent_transom_h` leave `cond_vent_transoms + 1` equal slot segments, so the band closes
    on itself exactly and stays symmetric about its own mid-height whichever of the three figures
    moves. The assertion is that closure: it is the one thing arithmetic here can get wrong."""
    z0, z1 = vent_band(airway)
    run = (z1 - z0 - cond_vent_transoms * cond_vent_transom_h) / (cond_vent_transoms + 1)
    bands = tuple((z0 + (k + 1) * run + k * cond_vent_transom_h,
                   z0 + (k + 1) * run + (k + 1) * cond_vent_transom_h)
                  for k in range(cond_vent_transoms))
    closed = (cond_vent_transoms + 1) * run + cond_vent_transoms * cond_vent_transom_h
    assert abs(closed - (z1 - z0)) < 1e-9, "the vent's transoms do not close on its band"
    assert all(abs(lo + hi - (z0 + z1)) < 1e-9
               for (lo, _t), (_b, hi) in zip(bands, reversed(bands))), \
        "the vent's transoms are not symmetric about the band"
    return bands


def vent_segment(airway):
    """One slot segment — what a mullion stands free over between two transoms."""
    z0, z1 = vent_band(airway)
    return (z1 - z0 - cond_vent_transoms * cond_vent_transom_h) / (cond_vent_transoms + 1)


def vent_segments(airway):
    """The full-height opening courses between the transoms, bottom to top."""
    z0, z1 = vent_band(airway)
    out, lo = [], z0
    for tz0, tz1 in vent_transoms(airway):
        out.append((lo, tz0))
        lo = tz1
    out.append((lo, z1))
    return tuple(out)


def vent_grooves(outer, airway):
    """Every groove the condenser's vents pierce, as `((sx, y), ...)` — the flank's own sign and
    the groove's station on it, WALKED OFF ARC LENGTH and not counted off a wall.

    `flute_centres` is the field's own list and `plan_at` is what puts each one somewhere; a
    groove is on a flank when the plan's outward normal there is ±X. So the vent lands on groove
    centres by construction and follows the field if `flute_count` is ever retuned — there is no
    Y station typed anywhere in this feature.

    A GROOVE IS IN WHEN ITS WHOLE SLOT IS. The block's airway stops where its two recesses begin
    (`cond_airway`), and a slot running past that line opens on the sheet the box holds the block
    by rather than on the finstack."""
    if not airway:
        return ()
    ay0, ay1 = airway[0], airway[1]
    half = reeding.pierce_width / 2.0
    out = []
    for arc in flute_centres(outer):
        (_px, py), (nx, _ny) = plan_at(arc, outer)
        if abs(abs(nx) - 1.0) > 1e-9:
            continue
        if ay0 - stated_bound_tol <= py - half and py + half <= ay1 + stated_bound_tol:
            out.append((1.0 if nx > 0.0 else -1.0, py))
    return tuple(sorted(out))


def _vent_runs(solid, outer, airway, sx, y):
    """One groove's slot on one flank, as the (z0, z1) runs it comes out as.

    THE PIECE IS ASKED, not told. What the slot is cut out of is the flank, and what it must not
    break out of is anything ROOTED on the flank's inner face behind that same groove — so the
    reading is one probe `cond_vent_probe` deep and `cond_vent_clear` past both jambs. Whatever
    it finds takes its own height plus that same clearance above and below out of the band. A
    body standing free of that face is not in it and is not the vent's to answer for.

    THE TRANSOMS DIVIDE THE ONLY OPENING VOCABULARY. A rooted feature does not leave an odd short
    slit above itself: if its clearance reaches into one of the four equal segments, that whole
    segment stays solid. The outside therefore sees full segments or a deliberate fluted land,
    while the feature gets a wall-height root instead of a thin remnant between its crown and a
    one-off slot."""
    band = list(vent_band(airway))
    face = vent_flank_face(sx)
    half = reeding.pierce_width / 2.0
    xs = sorted((face - sx * cond_vent_probe, face - sx * stated_bound_tol))
    probe = _ybox(xs[0], xs[1], y - half - cond_vent_clear, y + half + cond_vent_clear,
                  band[0] - cond_vent_clear, band[1] + cond_vent_clear)
    occupied = tuple((b.zmin - cond_vent_clear, b.zmax + cond_vent_clear)
                     for b in (s.BoundingBox() for s in probe.intersect(solid).Solids()))
    segments = vent_segments(airway)

    def clear(segment):
        z0, z1 = segment
        return not any(max(z0, oz0) < min(z1, oz1) - stated_bound_tol
                       for oz0, oz1 in occupied)

    return tuple(segment for segment in segments if clear(segment))


def _vent_cutter(outer, sx, y, z0, z1):
    """One run, as the prism that cuts it: `reeding.pierce_width` across, struck down the
    groove's own centre, carried clean through the flank, and CLOSED AT BOTH ENDS BY A 45° HIP.

    The hip is `relief_chamfer`, the angle every relief on this box rises at, and it costs the
    show face nothing — a slot is narrower than the groove it lies in, so both hips sit down
    inside the groove's own shadow. It is also what makes the piece printable at either end: the
    piece stands on its floor and the build axis runs up this wall, so the sill only takes
    material away as the print climbs and the ceiling closes at exactly the angle the box
    supports nothing steeper than."""
    face = vent_flank_face(sx)
    skin = outer[1] if sx > 0.0 else outer[0]
    half = reeding.pierce_width / 2.0
    hip = half * math.tan(math.radians(relief_chamfer))
    return _yz_prism(face - sx * 1.0, skin + sx * 1.0,
                     ((y, z0), (y + half, z0 + hip), (y + half, z1 - hip), (y, z1),
                      (y - half, z1 - hip), (y - half, z0 + hip)))


def vent_measure(solid, outer, airway, sx):
    """One flank's vent, read off a BUILT PIECE — every opening the wall actually came out with,
    and from those the slots, the mullions between them, the height each mullion stands free
    over, and the free area the whole window opens.

    A READING, AND NOT PART OF THE DRAWING. `_realized` keeps a piece between builds, so a
    reading taken while cutting is a reading the second build never takes and no row says so —
    `build_pieces` draws and measures nothing. This is asked of the piece afterwards, by
    `enclosure_assembly.check_flank_vents` for the ledger and by `main` for the page, off one
    derivation either way.

    ONE CUT, AND EVERY FIGURE OFF IT. The flank's own mid-section is taken as a slab over the
    whole window and the whole band, and the piece is CUT OUT of it: what comes back is one solid
    per OPENING, which is what the vent is. So a run's height is that solid's height and no
    transom station is read back here, a slot's width is its width across the groove, a mullion is
    the gap between two neighbouring slots, and the free area is what all of them come to. Read at
    the mid-section because that is where a slot is a slot the whole way through.

    A MULLION STANDS FREE OVER THE OPENING BESIDE IT. Between two transoms the wall holds a
    mullion at its two ends and nowhere in between, so the tallest opening on the flank IS the
    tallest unbraced picket on it — the figure the transoms exist to set."""
    ay0, ay1 = airway[0], airway[1]
    bz0, bz1 = vent_band(airway)
    face = vent_flank_face(sx)
    skin = outer[1] if sx > 0.0 else outer[0]
    xs = sorted(((face + skin) / 2.0 - 0.1, (face + skin) / 2.0 + 0.1))
    window = _ybox(xs[0], xs[1], ay0, ay1, bz0, bz1)
    opened = window.cut(solid)
    boxes = sorted((b.ymin, b.ymax, b.zmin, b.zmax)
                   for b in (o.BoundingBox() for o in opened.Solids()))
    # The openings gathered back into the slots they belong to: two runs of one slot share a Y
    # span, and two slots never overlap in Y because a mullion stands between them.
    columns = []
    for ymin, ymax, zmin, zmax in boxes:
        if columns and ymin < columns[-1][1] - stated_bound_tol:
            columns[-1][1] = max(columns[-1][1], ymax)
            columns[-1][2].append((zmin, zmax))
        else:
            columns.append([ymin, ymax, [(zmin, zmax)]])
    slots = [hi - lo for lo, hi, _r in columns]
    mullions = [lo1 - hi0 for (_l0, hi0, _r0), (lo1, _h1, _r1) in zip(columns, columns[1:])]
    runs = [(hi - lo) for _l, _h, rs in columns for lo, hi in rs]
    return {"slots": slots, "mullions": mullions, "runs": runs,
            "tallest": max(runs, default=0.0),
            "open_mm2": opened.Volume() / (xs[1] - xs[0]),
            "band": (bz0, bz1)}


def _vent_chute_courses(sx, y, west_cradle, airway):
    """The courses one groove gives up to the MQ-6 chute — the ones the chute is actually IN.

    The chute is cut only from front-bottom's added inner skin. A vent in the next groove can
    therefore leave an unnamed strip of that skin between its slot jamb and the chute edge even
    though both openings are individually valid, so where the strip would be thinner than `wall`
    the groove stays solid rather than opening further into the chute and trading the nib for a
    leak in the sensor well. Grooves crossing the chute itself keep their vents, because there is
    no intervening material to protect.

    AND IT IS A HEIGHT AND NOT THE WHOLE COLUMN. What the strip is thin BESIDE is the chute, and
    `mq6_chute_reach` says where that stops — one card above the can's seat and a radius of gable
    over it. Above that the skin is whole across this groove and the next, so a course up there
    gives up nothing to a feature it does not reach; only the courses the chute's own clearance
    enters stay solid."""
    if sx > 0.0 or not west_cradle:
        return ()
    slot_lo = y - reeding.pierce_width / 2.0
    slot_hi = y + reeding.pierce_width / 2.0
    chute_half = mq6_can_yz / 2.0 + mq6_slot_press
    blocked = []
    for _x, cy, cz in west_cradle:
        chute_lo, chute_hi = cy - chute_half, cy + chute_half
        if slot_hi <= chute_lo:
            gap = chute_lo - slot_hi
        elif chute_hi <= slot_lo:
            gap = slot_lo - chute_hi
        else:
            continue
        if gap < wall - stated_bound_tol:
            top = mq6_chute_reach(cz)[1] + cond_vent_clear
            blocked.extend(course for course in vent_segments(airway)
                           if course[0] < top - stated_bound_tol)
    return tuple(blocked)


def _flank_vents(solid, inner, outer, airway, y0, y1, z0, z1, west_cradle=()):
    """The condenser's INTAKE and EXHAUST cut into a piece's ±X flanks, for the piece whose
    bands hold the block's airway.

    THE VENT IS THE FLUTES, PIERCED — one slot down the floor of every groove standing over the
    finstack, `reeding.pierce_width` across on the field's own centres, clean through the
    `2 * wall` a bottom piece's lipped flank carries (`_lip_underwall`). Both jambs run WITH the
    flute and the groove carries on past both ends of the slot at full depth, so nothing crosses
    a flute anywhere here and no edge this makes is one the skin stops on — which is a fact
    `flute_skin` reads for itself off the run's own two ends rather than being told.

    EVERY GROOVE AND NOT ALTERNATE. What a slot is measured against is the MULLION between two
    of them, and the coupon at `c14bb2fff` printed the schemes side by side: at this pitch a 3.1 mm
    slot down every groove leaves `reeding.mullion` of material carrying the exterior's four wall
    loops with `reeding.pierce_max` still overhead, and it is both more open and thicker at its
    thinnest than the same field pierced down alternate grooves at the full groove width.

    NO ORPHAN OPENING. If a rooted feature leaves a single aperture marooned beyond its solid
    land in one course, that aperture stays fluted wall too. Two adjacent openings are a grille;
    one isolated slit is the same accidental-looking nick the full-segment rule removes in Z.

    NO THIN STRIP BESIDE THE MQ-6 CHUTE. On the intake flank the two grooves whose slot jambs
    would stop less than one wall from that chute stay whole through the courses the chute
    reaches. The chute keeps its fitted outline and the wall keeps complete stock; neither
    opening is widened into the other merely to erase their narrow intersection — and above the
    chute both grooves vent like any other, there being nothing up there to leave a strip against.

    LAST OF THE FLANK'S WORK, after every rail, fin, pod and pocket either wall carries — because
    a slot is air, air a later step fuses back in is not a slot, and because what decides where
    each slot stops is what the piece has standing on that face when the cut is made."""
    if not airway:
        return solid
    ay0, ay1, az0, az1 = airway
    if not (y0 <= (ay0 + ay1) / 2.0 <= y1 and z0 <= (az0 + az1) / 2.0 <= z1):
        return solid
    runs = {}
    for sx, y in vent_grooves(outer, airway):
        blocked = _vent_chute_courses(sx, y, west_cradle, airway)
        got = tuple(course for course in _vent_runs(solid, outer, airway, sx, y)
                    if course not in blocked)
        runs.setdefault(sx, []).append((y, got))
    courses = vent_segments(airway)
    for sx, columns in runs.items():
        for course in courses:
            present = [course in got for _y, got in columns]
            for i, is_open in enumerate(present):
                neighbours = ((i > 0 and present[i - 1])
                              + (i + 1 < len(present) and present[i + 1]))
                if is_open and neighbours < cond_vent_island_min - 1:
                    y, got = columns[i]
                    columns[i] = (y, tuple(run for run in got if run != course))
    cutters = [_vent_cutter(outer, sx, y, rz0, rz1)
               for sx, columns in runs.items() for y, got in columns for rz0, rz1 in got]
    if not cutters:
        return solid
    return solid.cut(*cutters)


def vent_readings(pieces, box):
    """What the condenser's vents came out as, per flank sign, off the piece that carries them.

    THE PIECE IS FOUND THE WAY THE CUT FOUND IT — by whose own bands hold the block's airway
    (`_piece_bands`), which is the same test `build_piece` makes when it hands a station to the
    feature that cuts it. So this asks the piece that was cut and not a piece named here."""
    if not box.pack.cond_airway:
        return {}
    ay0, ay1, az0, az1 = box.pack.cond_airway
    for name, piece in pieces.items():
        if name.count("-") != 1:
            continue
        y0, y1, z0, z1 = _piece_bands(box, name)
        if y0 <= (ay0 + ay1) / 2.0 <= y1 and z0 <= (az0 + az1) / 2.0 <= z1:
            solid = piece.val() if hasattr(piece, "val") else piece
            return {sx: vent_measure(solid, box.outer, box.pack.cond_airway, sx)
                    for sx in (-1.0, 1.0)}
    return {}


def _core_stops(solid, inner, stations, y0, y1, z0, z1):
    """The cold core's two front corner blocks added to a PIECE, for the stations whose plan
    point the piece owns and whose slab it holds.

    Each station is `(cx, cy, r)`: the centre of the core's own corner round and that round's
    radius. Everything else the block is comes off those three and the box's own faces — it runs
    the ±X wall inboard to one round past the tangent, the slab up `core_stop_rise`, and one
    `core_stop_web` ahead of the core's outline the whole way.

    THE POCKET IS THAT OUTLINE, OFFSET ONE SLIP AND NOT A SHAPE OF ITS OWN: a bore on the round's
    own axis outboard of the tangent, a plane on the core's own front face inboard of it. So the
    web is the same 6 mm at the tangent, where a bore alone leaves it thinnest, and along the
    whole lap — and the block bears flat where the core is flat and round where it is round.

    Its underside is the slab and its outboard face the wall, so it comes out of the print as a
    corner bracket in one piece with both faces it stands on — the card slot's own form, on the
    body that needs no slot. The band test is `_floor_bosses`': the Y column selects the station
    and only a piece reaching the floor grows one."""
    if z0 > inner[4] + 1e-6:
        return solid                       # a top piece has no slab to stand one on
    for cx, cy, r in stations:
        if not (y0 <= cy <= y1):
            continue
        side = 1.0 if cx > 0.0 else -1.0
        slip = core_stop_slip / 2.0
        wall_x = inner[1] if side > 0 else inner[0]
        lap, face = cx - side * r, cy - r - slip
        tip = inner[4] + core_stop_rise
        solid = solid.fuse(_ybox(min(lap, wall_x), max(lap, wall_x),
                                 face - core_stop_web, cy, inner[4], tip))
        # The fuse above already welds the block to the slab at `inner[4]`, so that plane is
        # no longer a face of `solid` there — the notch's floor wants no overshoot past it, only
        # the block's own free top (`tip`) does. A cutter reaching below `inner[4]` would carve
        # into the slab itself rather than the block that stands on it.
        solid = solid.cut(_ybox(min(lap, cx), max(lap, cx), face, cy + 1.0,
                                inner[4], tip + 1.0))
        solid = solid.cut(_zcyl(r + slip, cx, cy, inner[4], tip + 1.0))
    return solid


def _core_holds(solid, inner, stations, y0, y1, z0, z1, face=None):
    """The cold core's two hold-down brackets added to a PIECE, for the stations inside the
    depth and height band that piece owns.

    Each station is `(x0, x1, aft, crown)`: the lane on the cap the bracket stands in, the
    core's own aft face, and the plane its cap presents. Its section is a right trapezoid on
    those two planes — the BEARING FACE along the crown from `core_hold_reach` forward of the
    core's aft face back to the wall, the LEG up the wall's inner face for `core_hold_rise`, and
    one straight from the head of that leg down to the foot's own tip, which is `core_hold_land`
    over the crown. The foot lands on the cap at 0, the way every other seat in this box lands
    on the face it takes.

    THAT STRAIGHT IS THE GUSSET. It leaves no re-entrant corner for the foot to bend at, and it
    is the bracket's machine-upper face, 25° off vertical. back-top prints on its ceiling's outer
    face (`BACK_TOP_UP`), so this is the face that looks print-down — a down-face 65° from the
    bed, steeper than the 45° every relief on this box is struck at, and every layer of it lands
    on the one below.

    THE BEARING FACE IS A PRINT-UP FLAT. It is flat and it is the lowest thing on the bracket in
    the machine's frame, and in this print it looks up: a free top face
    `core_hold_reach + rear_seam_clear` off the wall, with the leg and the gusset under it. The
    bracket takes no print support.

    AND ITS TIP CARRIES A LEAD. The core rides IN under these feet — through the open
    Y-seam mouth, aft to its seat, the crown sliding under the bearing face at the same
    zero the seat closes at — so the foot's fore arris is eased 45° up toward the tip.
    A crown arriving a hair high meets a ramp and is pressed down onto the slab's own
    datum instead of stopping on an edge."""
    face = inner[3] if face is None else face
    lead = 1.0
    for sx0, sx1, aft, crown in stations:
        if not (y0 <= aft <= y1 and z0 <= crown <= z1):
            continue
        tip, back = aft - core_hold_reach, face
        solid = solid.fuse(_yz_prism(sx0, sx1, (
            (tip + lead, crown), (back, crown), (back, crown + core_hold_rise),
            (tip, crown + core_hold_land), (tip, crown + lead))))
    return solid


# --- the tap-water chain's cradle on the −X wall ---------------------------
#
# The ASSE anchor's own section, and what it spends on either side of the chain's axis.
# How far the anchor's upper flank runs off the axis. It is SHORT: the chain's own top flat
# stands one `clearance-floor` under the ceiling, so a lip carried up to that flat's arris is a
# lip standing in the only air a tie could have used, and the zip tie climbs past this lip on its
# way over the chain. The lower flank's reach is not stated here at all — the station carries it,
# struck on the chain's own lowest arris, because an anchor deeper than the body it holds is PETG
# holding air.
asse_cradle_up = 9.0
asse_v_half = 60.0          # half the V's included angle, off the axis plane
asse_cradle_lip = 4.0       # block carried past the flanks, so the V cut is never clipped
# THE ZIP TIES' SHARED CAVITY THROUGH THE ANCHOR'S BACK, closed on every side but its two mouths.
#
# STRAIGHT ON THE WEST, THE ANCHOR'S OWN V ON THE EAST. The V's apex stands closest to that
# straight, so the cavity is narrowest at the axis and flares to both mouths: each mouth opens
# `wall / sin 60°` off its lip's own arris, on the block's face, and at the axis the flare
# leaves a zip tie pushed through the room to turn the vertex by cutting its corner.
#
# ONE CHANNEL SPANS BOTH ZIP TIE BANDS. Its fore and aft ends stand half `tie_cav_wide_w` beyond
# the corresponding tie centre, and the volume between them is open. The slicer's support under
# this horizontal passage is therefore one continuous body a hand can reach along the full span.
# The ceiling over the same span is open to the lane (`_ceiling_tie_channel_relief`), so the
# cavity's top mouth opens into the room the loop crosses.
#
# ITS TWO FLANKS ARE BOTH ONE `wall`. The cavity is what is LEFT between them — a `wall` off the
# anchor on the east and a `wall` off the side wall's own inner face on the west — so its width is
# a remainder and not a number, and every face of it is the section the rest of this box is.

# --- what a zip tie is, wherever one is cut for on this box --------------------
#
# Every cavity on this wall carries the same fastener, so its section is stated once here and the
# features read it. `enclosure_assembly.ASSE_TIE_T` is the same zip tie's THICKNESS, and it is stated
# over there because what it sets is the deck's own storey rather than anything printed.
# TWO ZIP TIES, AND WHAT PICKS BETWEEN THEM IS THE LOOP. A zip tie turns INSIDE the cavity, so what it
# reaches round is the body together with the web between that body and the cavity — the convex
# perimeter of the pair, and not of the wall the rib stands on:
#
#     carb-1 tube in its rib      [39.7 mm](LOOP_CARB_1)
#     DIGITEN arm in its anchor   [81.2 mm](LOOP_DIGITEN)
#     WR1110 barrel in its rib    [83.7 mm](LOOP_WR1110)
#     ASSE barrel in its anchor   105.2 mm
#
# A 4" tie closes about 69 mm of loop and takes the tube rib; the meter and regulator take the
# 6", which closes about 110. The ASSE barrel takes the 8", and an 8" tie is a 50 lb
# tie at 0.19" where the rest are 18 lb at 0.1" — so that anchor's cavity, alone on this box, is
# cut to the wider zip tie. Every other cavity here takes the same 0.1" section at any length.
tie_w = 2.5           # the 18 lb zip tie, across its width — 0.1"
tie_wide_w = 4.826    # and the 50 lb zip tie's — 0.19"
tie_t = 1.0           # both, through the thickness
tie_cav_buffer = 1.0        # the room a cavity carries over the zip tie
tie_cav_w = tie_w + tie_cav_buffer
tie_cav_wide_w = tie_wide_w + tie_cav_buffer
# Solid either side of a cavity, ALONG the run. A cavity is a hole through a rib, and this is what
# the rib keeps of itself at each end of that hole.
tie_cav_wall = 3.0


def _asse_tie_channel_span(ties):
    """The shared channel's Y ends, half a tie-cavity width past its outer tie centres."""
    if not ties:
        raise ValueError("the ASSE anchor needs at least one tie band to cut its channel")
    return (min(ties) - tie_cav_wide_w / 2.0,
            max(ties) + tie_cav_wide_w / 2.0)


def _asse_v(x_apex, z_axis, y0, y1, up, dn, x_east):
    """The room the chain lies in: a 120° V, apex west on its own axis, open east.

    ONE SHAPE FOR EVERY SECTION. Read off a hex's corner it lies on two whole flats; read off a
    round one's tangent it lies on two lines; and either way the section that sits deepest is
    the section that is widest, which is what makes the steps between them faces square to the
    axis rather than anything drawn here."""
    run = 1.0 / math.tan(math.radians(asse_v_half))
    return (
        cq.Workplane("XZ")
        .polyline(_ring([(x_apex, z_axis),
                         (x_apex + up * run, z_axis + up),
                         (x_east, z_axis + up),
                         (x_east, z_axis - dn),
                         (x_apex + dn * run, z_axis - dn)]))
        .wire()
        .extrude(-(y1 - y0))
        .val()
        .translate((0.0, y0, 0.0))
    )


def _asse_cradle(solid, inner, station, y0, y1, z0, z1, up=1.0):
    """The tap-water chain's cradle fused onto the −X wall, if this piece owns its band.

    THE CHAIN IS MADE UP BY HAND AND THIS IS WHAT THAT COSTS. Five fittings on one axis, each
    threaded to its neighbour "snug + 1 turn", so neither the length of the run nor the clock any
    one of them lands at is a number this wall can know. What the wall can know is the SECTION
    each one presents about the axis, because that is the fitting's own — so the anchor is cut to
    each in turn, the steps between them catch the barrel fore and aft, and the fit across the V
    is a slip and not a socket.

    WHAT A TIE CAN AND CANNOT DO HERE. A tie is a closed loop, and a loop round this chain has to
    pass over its top flat — so the storey the chain lies on is struck to leave that channel under
    the top wall, and the wall itself is never cut for it
    (`enclosure_assembly.DECK_CEILING_CLEAR`). The loop runs down the CAVITY through the back of
    this anchor, out under the block, east beneath the barrel, up its east flank, over the top flat
    through that channel, and back into the cavity. So it closes round the chain and the anchor's
    own back together, and what it pulls is the chain into the V.

    ONE SHARED CHANNEL SERVES BOTH ZIP TIES AND IS CLOSED ON EVERY SIDE BUT ITS TWO MOUTHS. It
    stands west of the apex with one `wall` of PETG between it and the anchor, so at no station is
    it anything but a hole through solid material. Its end faces remain centred around the two tie
    bands, and the open volume between them makes the printed support one removable piece.

    `up` is the print direction of the piece that carries the anchor. Printed mouth-down (`up > 0`)
    the block's underside looks print-down and a 45° corbel carries it, run the anchor's whole
    length and rooted on the wall the block is rooted on, tapering to nothing at the DEEPEST
    SECTION'S OWN V FOOT — the same apex the tie cavities are struck on — so under the barrel it
    carries that underside whole, and under a bored section, where the block reaches further east
    than any wedge off this wall may stand without meeting what hangs off the chain, it carries
    what it reaches. Printed ceiling-down (`up < 0`) the underside looks print-up and the block's
    TOP looks print-down — and the slab it prints from is right there over it. Outside the tie
    channel's span the block goes on up as a COLUMN, from the V's upper arris (or the bore's
    crossing of the top) back to the wall and up to the lane, standing on the slab through the
    chain's own pocket: nothing west of the arris stands in that air, so nothing over the block
    looks print-down and no wedge is asked to carry it. Over the span the loop needs that room, so
    the column is absent and the web between the cavity and the V is chamfered at 45° down into
    the cavity instead: the web's top is a slope the print lays on itself and a funnel the loop
    drops through. The two round seats' lower arcs look print-down inside their bores and are
    supported faces. The V's own two flanks stand 30° off vertical and carry themselves either way.

    NOTHING HERE HOLDS THE CHAIN UP. The V does that, on two faces of a section machined into the
    part; the ties only shut its mouth. Cut every tie and the chain still lies where it lies,
    which is the whole point of putting the load on printed geometry and the preload on nylon."""
    if not station:
        return solid
    z_axis, sections, ties, dn = station
    rise = asse_cradle_up
    run = 1.0 / math.tan(math.radians(asse_v_half))
    if not (y0 <= sections[0][0] and sections[-1][1] <= y1):
        return solid                       # a piece that does not own the whole run builds none
    if not (z0 <= z_axis - dn and z_axis + rise <= z1):
        return solid
    top = z_axis + rise
    for sy0, sy1, apex, seat_r, x_axis in sections:
        if seat_r is None:
            east = apex + dn * run + asse_cradle_lip
            solid = solid.fuse(_ybox(inner[0], east, sy0, sy1, z_axis - dn, top))
            solid = solid.cut(_asse_v(apex, z_axis, sy0, sy1, rise, dn, east + 1.0))
            continue
        # A ROUND SECTION LIES IN A BORE, cut out of the same block on the same storey the V takes.
        # The block's own top face crosses the arc INSIDE its widest point, so the two meet in a
        # wedge rather than along a tangent — which is what a feather is, and what a lip is not.
        # Below the axis the block runs past the circle entirely and the arc closes on the block's
        # east face at a right angle.
        solid = solid.fuse(_supported_cut(
            _ybox(inner[0], x_axis, sy0, sy1, z_axis - dn, top), up))
        # The round fitting stays on its stated axis; only the supported arc opens.
        solid = solid.cut(_supported_cut(_ycyl(seat_r, x_axis, z_axis, sy0, sy1), up))
    for ty in ties:
        if not (sections[0][0] <= ty <= sections[-1][1]):
            raise ValueError(
                f"_asse_cradle: tie band {ty:.2f} falls outside the anchor's run "
                f"[{sections[0][0]:.2f}, {sections[-1][1]:.2f}]. A zip tie's channel is cut through "
                f"the block at its own band, so a band off either end has no channel at all.")
    tie_y0, tie_y1 = _asse_tie_channel_span(ties)
    apex = min(w for _y0, _y1, w, _r, _a in sections)
    foot = apex + dn * run
    corbel = 0.0
    if up > 0.0:
        # THE CORBEL UNDER ALL OF THEM, on the deepest section's own V foot: that flank is the
        # furthest west anything of this anchor comes down to, so a 45° struck to it is the wedge
        # the narrowest section can carry whole and every wider one can stand on. Fused before the
        # ties' channel so it goes on through the corbel.
        corbel = foot - inner[0]
        solid = solid.fuse(_xz_prism(sections[0][0], sections[-1][1],
                                     [(foot, z_axis - dn), (inner[0], z_axis - dn),
                                      (inner[0], z_axis - dn - corbel)]))
    else:
        # THE COLUMNS OVER THE TOP, section by section, outside the tie channel's span; over the
        # span, the web's chamfer into the cavity. The cavity's east face at the top is the V's
        # apex stood off one `wall`, `rise` up the flank.
        cav_east = apex - wall / math.sin(math.radians(asse_v_half)) + rise * run
        lane = inner[5]
        for sy0, sy1, sapex, seat_r, x_axis in sections:
            if seat_r is None:
                lip = sapex + rise * run
            else:
                lip = x_axis - (math.sqrt(seat_r ** 2 - rise ** 2) if seat_r > rise else 0.0)
            # The column stands from the block's top to the lane and no further: what stands
            # over the lane is the top wall, and the piece's silhouette is already cut when this
            # fuses. Its east face is the lip's own vertical, so the block's section is one
            # rectangle from the seat's arris to the slab.
            climb = lane - top
            for wy0, wy1 in ((sy0, min(sy1, tie_y0)), (max(sy0, tie_y1), sy1)):
                if wy1 - wy0 > 1e-6 and climb > 1e-6:
                    solid = solid.fuse(_ybox(inner[0], lip, wy0, wy1, top, top + climb))
            cy0, cy1 = max(sy0, tie_y0), min(sy1, tie_y1)
            if cy1 - cy0 > 1e-6 and lip > cav_east + 1e-6:
                web = lip - cav_east
                solid = solid.cut(_xz_prism(cy0, cy1, [
                    (lip, top), (lip, top + 1.0), (cav_east - 1.0, top + 1.0),
                    (cav_east - 1.0, top - web - 1.0)]))
    # THE ZIP TIES' SHARED CHANNEL, cut after every section is fused so a neighbour's block cannot
    # fill it back in. Struck on the DEEPEST section's apex, which is the barrel's: that V
    # stands furthest west, so a cavity clear of it by one `wall` is clear of the other two by more
    # and the web comes out no thinner than stated at any station.
    #
    # IT IS THE WIDE ZIP TIE'S CAVITY. The barrel and this anchor make a 105 mm loop, past what a 4"
    # tie closes, so what shuts it is the 8" — and an 8" is a 50 lb tie, half again as wide as the
    # 18 lb zip tie the flow-meter anchors and the runs' ribs take.
    solid = solid.cut(_supported_cut(_asse_tie_cavity(
        apex, inner[0], z_axis, tie_y0, tie_y1, rise, dn + corbel), up))
    return solid


def _asse_tie_cavity(x_apex, x_wall, z_axis, y0, y1, up, dn):
    """The zip tie's cavity: STRAIGHT on the west, the ASSE anchor's own V on the east.

    Five points and one cut. The V's apex stands closest to that straight, so the cavity comes out
    narrowest in the middle and flared at both mouths — which is the reach where a hand needs it
    and the room to turn the vertex where a zip tie needs that, out of one shape rather than out of a
    chamfer and a round.

    The upper end runs one millimetre past the ceiling lane it opens into. The lower end stops
    on the anchor's own underside: east of the flank face that mouth already opens directly into
    air, and carrying the cutter lower would leave a separate one-millimetre notch in the flank.
    `dn` is what the caller has standing under the axis — the block's own storey and the corbel
    below it — because a tie's loop leaves this cavity by running east UNDER all of it, and a
    channel that stopped above the block would be stopped by the corbel."""
    run = 1.0 / math.tan(math.radians(asse_v_half))
    x_in = x_apex - wall / math.sin(math.radians(asse_v_half))   # a `wall` west of the anchor
    x_w = x_wall + wall                                          # and a `wall` off the side wall
    over_up, over_dn = up + 1.0, dn
    return (
        cq.Workplane("XZ")
        .polyline(_ring([(x_w, z_axis + over_up),
                         (x_in + over_up * run, z_axis + over_up),
                         (x_in, z_axis),
                         (x_in + over_dn * run, z_axis - over_dn),
                         (x_w, z_axis - over_dn)]))
        .wire()
        .extrude(-(y1 - y0))
        .val()
        .translate((0.0, y0, 0.0))
    )


# --- the flow meter's two anchors, off the top wall ------------------------
#
# A BORE, CONCENTRIC WITH THE BARREL IT TAKES. The arms are round, so the seat is round: half a
# cylinder on the arm's own axis, opening downward, and the arm comes straight up into it.
#
# THE ARC STOPS ON THE ARM'S OWN AXIS PLANE AND THE RIB CARRIES ONE `wall` PAST ITS WIDEST POINT.
# That plane is where the arc is widest, so the rib's own flanks stand `seat_r + wall` off the axis
# and each lip comes out a flat strip one `wall` across. An arc carried past its widest point runs
# out to nothing against the flank and leaves a feather no nozzle can lay down.
flow_meter_anchor_wall = 3.0
# The measured fixed collar is 7.2 mm long. Two 1.7 mm axial webs carry this light meter's
# 3.5 mm tie cavity inside that collar, leaving the full movable collet exposed. Each end web
# spans four 0.42 mm extrusion widths. The radial wall remains 3 mm, and the two ends each leave
# 0.15 mm of axial room.
flow_meter_anchor_end_wall = 1.7
flow_meter_anchor_len = tie_cav_w + 2.0 * flow_meter_anchor_end_wall
# The zip tie's cavity through each anchor, over the bore. Its floor is the SEAT'S OWN ARC offset out
# by one `wall` — concentric, so the web reads `wall` all the way round — and ITS CEILING IS THE
# TOP WALL'S OWN INNER FACE. The channel is everything left between them, deepest over the crown
# and flaring as the arc falls away to each mouth.
#
# The zip tie bears straight on that face and what stands over it is `wall`: the top wall's own
# section, which is already there. A plate of this rib's under it would be a second `wall` doing
# the first one's job.


def _digiten_bore(x_axis, z_axis, r, y0, y1, reach):
    """An anchor's own room: half a cylinder on the arm's axis, opening DOWNWARD, and the whole of
    the room under it.

    The arc runs from one axis-plane lip round the crown to the other, and the box under it carries
    the opening down clear of the rib — so what this cuts is the barrel's room and the air it comes
    up through, and the rib is left as a half-round hood with a flat lip on each side."""
    bore = cq.Solid.makeCylinder(r, y1 - y0, cq.Vector(x_axis, y0, z_axis), cq.Vector(0, 1, 0))
    under = _ybox(x_axis - r, x_axis + r, y0, y1, z_axis - r - reach, z_axis)
    return bore.fuse(under)


# --- the flavour manifold's valve trays -------------------------------------
#
# A VALVE TRAY IS A PLATE WALL TO WALL, with one four-socket `valve_seat` SUNK into it per valve
# on the deck it stands under. `valve_tray` states its thickness, its margin and its seat height
# and draws one in its own frame; this turns that onto the deck's own plane and fuses the plate
# into the piece, the way `_asse_cradle` fuses the ASSE anchor and `_flow_meter_anchors` the flow
# meter's two half-round seats — and then cuts the sockets and port channels out of it.
#
# THE PLATE IS THE BOSS. A boss is material round a socket, and a plate one socket and one wall
# thick is that material: a seat sunk into it leaves nothing standing off its face. Which is the
# whole point on this piece — it prints the plate VERTICAL, so a boss on it would be a Ø13.2
# cylinder cantilevered into air with its own underside to bridge, and there are thirty-two of
# them. Sunk, the port's channel is a notch running up the plate's own section. The socket is
# still a horizontal blind bore, though, and a round crown on that axis has no layer under it:
# `_valve_socket_cutters` carries its complete circular post room into the same tangent roof as
# every other horizontal bore on this box.
#
# NOTHING FASTENS A VALVE TO IT. The four corner posts press into their sockets and the valve's
# own round body boss lands on the plate's face, which is what sets its height — the same
# bargain the cold core's cap lid strikes under its own three valves, whose thinner lid stands
# the bosses instead.
def _valve_socket_cutters(plane, sign, seat_x, seat_z):
    """One tray seat's four complete post rooms with support-free roofs, in world coordinates.

    `valve_seat` owns the nominal socket: its radius, corner inset and axial floor/top. Turning
    that seat onto a Y deck puts its socket axes on Y and maps a local `(dx, dy)` corner to
    `(seat_x + dx, seat_z - sign*dy)`. The whole nominal circle remains inside `_teardrop_y`;
    only the unsupported world-Z crown is opened above its tangent points. Thus every round post
    still enters to the same floor and bears on the same lower and lateral arcs, while none of
    the thirty-two crowns asks the slicer for a separate interface island.
    """
    along = sorted((plane + sign * _seat.socket_floor_z,
                    plane + sign * (_seat.seat_top_z + 1.0)))
    return tuple(
        _teardrop_y(_seat.socket_radius, seat_x + dx, seat_z - sign * dz,
                    along[0], along[1])
        for dx in (-_seat.corner_inset_x, _seat.corner_inset_x)
        for dz in (-_seat.corner_inset_y, _seat.corner_inset_y)
    )


def _valve_trays(solid, inner, stations, y0, y1, z0, z1,
                 wall_aft_y=None, flank_bed_z=None):
    """Every valve tray whose deck falls in the depth and height band this piece owns.

    Each station is `(plane, sign, seats)`: the world Y the deck's valves stand their mounting
    faces on, which way their own +Z runs off it, and one `(x, z)` per valve. The plate's own
    extent is the seats' — wall to wall across, and one `valve_tray.reach` plus a margin either
    way along. Each wall root follows its outermost valve row; the lower band between staggered
    rows stays inside the lip faces, continuous with the tray's bedded foot.

    THE SEATS ARE SUNK AND SO IS THE PORT'S OWN CHANNEL. The plate is a socket and a wall thick
    (`valve_tray.THICK`), which is the material a boss would have been, so nothing is fused onto
    its face: the sockets and the channel are CUT, and the face itself is the plane the valve's
    round body boss lands on. A socket's nominal circle is carried whole into a tangent
    world-Z roof by `_valve_socket_cutters`, because the plate stands on Z and its bore lies on
    Y. Everything is struck in the valve's own frame at `plane`, its mounting plane, and turned
    onto the deck — the plate's face follows from `SEAT` and is not the datum anything here is
    placed on.

    A PLATE THAT OUTRUNS ITS OWN WALL IS CORBELLED AT THE ROOT. `wall_aft_y` is
    `collet_plate_spec`'s own `wall_aft_y` — the tee wall's aft face, the plane wall support
    actually ends at (`_tee_wall`). Where that plane falls strictly inside a plate's own
    near/far span, the plate stands on the wall for the inboard share of its thickness and
    overhangs open bay air for the rest: `far - wall_aft_y`, read off the two planes and never
    typed. The corbel rises 45° off the wall's own aft face and closes at the plate's own far
    face, so the flat downward band between the two stops existing — what a hand meets at
    either arris is the corbel meeting a vertical face, not a square step off the wall's crown.
    Struck before the per-seat sockets and port channels below, so a station that already
    breaks the plate's own edge breaks the corbel the same way. A footed plate's own near/far
    never brackets `wall_aft_y` (it stands on a different wall entirely), so this is a
    no-op there rather than a case split.

    THE SOCKET ANSWERS FOR THE POSTS, THE CHANNEL FOR THE PORT, AND NEITHER FOR THE BOSS OR
    THE BOX BEHIND THEM. `valve_tray.build_body_clearance` is what a fuse struck after them
    (the root corbel above) is cut on account of instead: the valve's boss and top box, read
    off `beduan_solenoid` again and grown one `PORT_SLIP`, wherever a station's own transform
    puts it — the four posts stay out of it on purpose, because they are exactly what the
    socket is cut to GRIP, and a second, looser cutter at the same station reams the grip out
    from under it. THE CHANNEL DOES ANSWER FOR THE PORT, BUT ONLY
    AS FAR AS THE PLATE'S OWN FLOOR — its length is struck to reach the plate, which is all a
    port ever used to graze. `wedge_depth` is carried into it below so the same channel reaches
    the corbel's own floor too: a wall the corbel roots on stands nowhere near a valve's port,
    so this only ever lengthens the channel where the root corbel actually adds one.

    THE WALL-TO-WALL PLATE ENDS ON FRONT-TOP'S OWN FLANK BEDDING PLANES. `flank_bed_z` is that
    piece's bed face when this tray belongs to it. The tray crosses the two grown flank sections,
    but it does not grow a second skin below either 45-degree underside; its plate, foot and any
    root corbel are trimmed as one feature before they join the enclosure."""
    for plane, sign, seats in stations:
        zs = [z for _x, z in seats]
        mid_z = (min(zs) + max(zs)) / 2.0
        half = _valve_tray.height(seats) / 2.0
        if not (y0 <= plane <= y1 and z0 <= mid_z <= z1):
            continue
        # The plate: its valve-side face on the plane the valve lands on, its back one `THICK`
        # outboard of that.
        face = plane - sign * _valve_tray.SEAT
        near, far = sorted((face, face - sign * _valve_tray.THICK))
        tray = _ybox(inner[0], inner[1], near, far, mid_z - half, mid_z + half)
        floor = mid_z - half
        wedge_depth = 0.0
        if wall_aft_y is not None and near < wall_aft_y < far:
            wedge_depth = far - wall_aft_y
            tray = tray.fuse(_yz_prism(inner[0], inner[1], [
                (far, floor), (wall_aft_y, floor), (wall_aft_y, floor - wedge_depth),
            ]))
        # THE PLATE'S FOOT: the plate's own whole section carried down to the piece's bed
        # face, its valve-side face one plane with the plate's, so the plate prints as a
        # wall standing on the bed with nothing left hanging. The valves' bottom ports and
        # the runs on them leave through the same channels the plate carries, run on down
        # to the foot's own bed edge. Inset one `wall` to the lip's own face — below the
        # rim that face is the bottom piece's lip, and the foot telescopes down it the way
        # every interior face does. The fore-facing tray's alone: under an aft-facing
        # plate the same band is the fold's own junction field, tees crossing every
        # section of it. The seats' wall-to-wall span stays above the rim
        # (`z-seam-under-deck`).
        foot_z0 = max(z0, inner[4])
        footed = sign < 0 and foot_z0 < mid_z - half - 1e-9
        if footed:
            lx0, lx1 = lip_face_x()
            tray = tray.fuse(_ybox(lx0, lx1, near, far, foot_z0, mid_z - half))
        # Each wall root carries its outer valve's full height. The inner seats' lower
        # band keeps the foot's inset, leaving the complete seam lip free at the flanks.
        for outside, inside, root in zip(
                inner[:2], lip_face_x(), _valve_tray.wall_root_floors(seats)):
            if root > floor + 1e-9:
                tray = tray.cut(_ybox(
                    min(outside, inside), max(outside, inside), near - 1.0, far + 1.0,
                    min(foot_z0, floor - wedge_depth) - 1.0, root))
        if flank_bed_z is not None:
            tray = tray.cut(_front_top_flank_bedding_cut(
                inner, near - 1.0, far + 1.0, flank_bed_z))
        solid = solid.fuse(tray)
        turn = cq.Location(cq.Vector(0, 0, 0), cq.Vector(1, 0, 0),
                           -90.0 if sign > 0 else 90.0)
        for sx, sz in seats:
            at = cq.Location(cq.Vector(sx, plane, sz))
            solid = solid.cut(_valve_tray.build_body_clearance().val().moved(turn).moved(at))
            for socket in _valve_socket_cutters(plane, sign, sx, sz):
                solid = solid.cut(socket)
            chan = 2.0 * (half + abs(sz - mid_z))
            if footed:
                chan = max(chan, 2.0 * (sz - foot_z0))
            chan += 2.0 * wedge_depth
            solid = solid.cut(_valve_tray.build_port_channel(chan + 2.0)
                              .val().moved(turn).moved(at))
    return solid


def _flow_meter_anchors(solid, roots, station, y0, y1, z0, z1, up=1.0):
    """The flow meter's two anchors hung off the top wall, for the piece that owns the ceiling.

    `roots` IS THE PIECE'S OWN INTERIOR AND NOT THE BOX'S (`piece_root_faces`). The rib's two
    ends climb to the face it roots on and the zip tie's channel is the room left between them, so
    the plane handed in here is the one that piece actually presents.

    One per fixed port collar and none over the body. The measured cover leaves one millimetre
    under the nominal ceiling; the lower collar axes leave room for the seats and tie passages.

    THE SEAT IS A BORE AND NOT A V, because the thing it takes is round. Half a cylinder on the
    barrel's own axis, `seat_r` across, so the seat and the barrel share a surface all the way round
    instead of touching on two lines. It stops on the barrel's own axis plane — the widest the arc
    gets — and the rib carries `flow_meter_anchor_wall` past that, so each lip is a flat strip one wall
    across. Carried any further round, the arc would run out to nothing against the flank.

    THE ZIP TIE IS THE LOAD PATH. A bore that opens downward carries nothing, so the two ties here
    are not the ASSE anchor's ties: cut them and the meter comes out of its anchors. What is hanging is
    a purchased part of a few tens of grams on two nylon zip ties.

    THE PRINT DECIDES WHAT THE RIB STANDS ON. On a piece whose print up is the box's +Z the rib
    HANGS OFF THE TOP WALL and starts on its two lips — one `flow_meter_anchor_wall` strip either
    side of the bore, the anchor's whole length, with nothing under them; everything over those
    lips is the arc closing inward on itself, so the hood carries its own crown and the lips are
    the only thing in it support has to reach. On a piece whose print up is the box's −Z the
    ceiling is on the bed and the rib STANDS on it, its seat an upward-opening cradle in the
    print with nothing in it laid over air."""
    if not station or z1 < roots[5] - 1e-6:
        return solid
    x_axis, z_axis, seat_r, bands = station
    reach = seat_r + flow_meter_anchor_wall
    for by0, by1 in bands:
        if not (y0 <= by0 and by1 <= y1):
            continue
        if by1 - by0 < flow_meter_anchor_len - 1e-6:
            raise ValueError(
                f"_flow_meter_anchors: the fixed collar is {by1 - by0:.2f} mm long and an anchor "
                f"is {flow_meter_anchor_len:.2f} — one zip tie's cavity with "
                f"`flow_meter_anchor_end_wall` at each end. The anchor must fit inside the "
                f"measured collar without reaching the housing or movable collet.")
        mid = (by0 + by1) / 2.0
        sy0, sy1 = mid - flow_meter_anchor_len / 2.0, mid + flow_meter_anchor_len / 2.0
        z_crown = z_axis + seat_r + wall          # one `wall` over the bore's own crown
        if roots[5] - z_crown < tie_t + 1e-6:
            raise ValueError(
                f"_flow_meter_anchors: a `wall` off the bore's crown leaves {roots[5] - z_crown:.3f} "
                f"mm under the top wall's inner face, and the zip tie is {tie_t:.3g} thick. The "
                f"storey the meter stands on is what gives way here "
                f"(`enclosure_assembly.DECK_CEILING_CLEAR`), not the wall.")
        # THE CAVITY IS WHAT IS NEVER FUSED, and nothing is cut for it. The rib is ONE box its whole
        # length up to `z_crown`, the two ends carried on up to the top wall, and ONE bore through
        # all of it. What the ends do not span IS the zip tie's channel — so it has no floor to draw,
        # no cut to make it, and no face for either to graze.
        #
        # The lower box runs the rib's whole length so the seat's own lip is ONE edge, and the rib
        # is UNIFIED before it joins the piece. A fuse imprints the seam of every solid that went
        # into it, so a rib fused straight onto the wall carries its lip in as many pieces as it
        # was laid down in — three here — and its bore in as many again.
        cy0, cy1 = mid - tie_cav_w / 2.0, mid + tie_cav_w / 2.0
        rib = _ybox(x_axis - reach, x_axis + reach, sy0, sy1, z_axis, z_crown)
        for ry0, ry1 in ((sy0, cy0), (cy1, sy1)):
            rib = rib.fuse(_ybox(x_axis - reach, x_axis + reach, ry0, ry1, z_crown, roots[5]))
        # The channel's floor between the two end webs is one `tie_cav_w` span, a bridge on the
        # piece where it looks print-down.
        rib = rib.cut(_digiten_bore(x_axis, z_axis, seat_r, sy0, sy1, reach))
        solid = solid.fuse(rib.clean() if hasattr(rib, "clean") else rib)
    return solid


# --- the tube anchors, one pattern wherever a wall can reach a run ----------
#
# THE SAME 120° V AGAIN, on the one body in this machine there are twenty of. A run is held at its
# two ends by the collets it is pushed into and by nothing between them, so what it does between
# them is sag — and a run that sags is not on the centreline `lines-clear` cleared. An anchor is a
# stop on that span: a seat the tube lies in, and a zip tie's cavity behind the seat, standing on
# whichever face of the box comes near enough to reach it.
#
# A ROUND SEAT ON A ROUND BODY. The section is struck in the anchor's own frame — `u` along the
# tube, `n` from the tube toward the face the rib roots on — and the seat is a bore concentric
# with the tube, half of one, taken from the crown round to the tube's own AXIS PLANE. Stopping
# there is what keeps the lip printable: an arc run past its widest point closes back on the tube
# and ends in a feather, and an arc stopped on the axis plane ends in a flat face one `wall` wide.
#
# EVERY WORKING SECTION IN IT IS ONE `wall`. The rib reaches `seat_r + wall` off the axis, so the
# lip is a wall-wide strip; the cavity's floor is the seat's own arc offset one `wall`, so the web
# is a half-annulus of that thickness at every station of it; and the zip tie gets one `wall` of
# depth over that floor. If the body stands further from its root face, the rest is solid backing
# into that face rather than a needlessly deep void hanging the seat from its two end webs.
#
# THESE PIECES ARE POPULATED INVERTED ON THE BENCH. A seat hanging off the top wall is an
# upward-opening cradle at the moment a tube is laid in it and its zip tie threaded.
#
# Its length along the run is one zip tie's cavity with `tie_cav_wall` at each end.
tube_anchor_len = tie_cav_w + 2.0 * tie_cav_wall
# A 1 mm zip tie needs its own thickness plus routing air, not every millimetre between a small tube
# and a distant wall. One structural section leaves 2 mm beyond the zip tie and keeps a deep anchor
# boxed back into its root; shallower fitting anchors keep all the air they actually have.
tube_anchor_cavity_depth = wall
# Do not add a skin-thin backing merely to shave a fraction from an already compact channel.
# A capped channel must put at least the cavity's routing buffer back into the load path.
tube_anchor_backing_min = tie_cav_buffer
# A CORBEL IS A WEDGE THAT HAS TO FIT, and what it grows into is the band the box keeps clear
# against its own interior: `side_band_inset`, what a body on the floor stands off the wall where
# the seam's boss chain runs. A rib whose axis stands inside that band gets the whole wedge; a
# deeper one gets a truncated one, tapering out at the band's edge.
tube_anchor_corbel_reach = side_band_inset


def tube_anchor_tie_loop(seat_r: float) -> float:
    """The shortest zip tie that closes round a seated body and its rib together.

    A zip tie turns INSIDE the channel, so what it reaches round is the body with the rib's own
    back behind it — the convex perimeter of that pair, and not of the wall the rib stands on.
    Read on the bore, which is the section this box knows.

    The hull is the rib's rectangle with a cap of the bore over it: the channel's floor, the
    rib's two flanks down to the axis plane, a tangent from each corner onto the bore, and the
    arc between the two tangent points. Floor and flank are both `seat_r + wall`, so the
    rectangle is square and the whole figure is a function of the seat."""
    w = seat_r + wall
    return (4.0 * w + 2.0 * math.sqrt(w * w - seat_r * seat_r)
            + seat_r * (math.pi - 2.0 * math.acos(seat_r / w)))

# Which interior face each root direction names. The anchor states no height of its own: it is
# handed the tube, and the wall it stands on is where its rib stops.
_ROOT_FACE = {(-1, 0, 0): 0, (1, 0, 0): 1, (0, -1, 0): 2,
              (0, 1, 0): 3, (0, 0, -1): 4, (0, 0, 1): 5}


def _anchor_plane(origin, u, n):
    """The anchor's own workplane — profile drawn in (`t`, `n`), extruded along the tube.

    `t = n × u` rather than `u × n`, so the workplane's second axis comes out as `n` itself and a
    profile point's second coordinate is its own distance toward the root face."""
    t = (n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
    return cq.Plane(origin=cq.Vector(*origin), xDir=cq.Vector(*t), normal=cq.Vector(*u))


def _anchor_bore(origin, u, r, length):
    """The seat — a cylinder on the tube's own axis.

    The rib stands entirely on the root side of the axis plane, so a whole cylinder cut from it
    takes exactly the half the seat is and needs no half-space to trim it."""
    return cq.Solid.makeCylinder(r, length, cq.Vector(*origin), cq.Vector(*u))


def _anchor_rib(origin, u, n, length, reach, b0, b1):
    """The material the seat and its cavity are cut out of, root face to the seat's own flanks."""
    return (
        cq.Workplane(_anchor_plane(origin, u, n))
        .polyline(_ring([(-reach, b0), (reach, b0), (reach, b1), (-reach, b1)]))
        .wire()
        .extrude(length)
        .val()
    )


def _anchor_corbel(origin, u, n, length, a_hang, b_root, deep):
    """The 45 degree gusset on the print-down side of a rib's flank — `deep` beside it at the
    root face, tapering to nothing `deep` off that face and standing nowhere past there.

    `a_hang` is the flank that looks print-down, read against the piece's own print up by
    `_tube_anchors`, and the gusset grows outboard of that flank."""
    return (
        cq.Workplane(_anchor_plane(origin, u, n))
        .polyline(_ring([(a_hang, b_root - deep), (a_hang + math.copysign(deep, a_hang), b_root),
                         (a_hang, b_root)]))
        .wire()
        .extrude(length)
        .val()
    )


def _anchor_column(origin, u, n, length, a0, a1, b_root, b_lo=0.0):
    """The column on the print-down side of a rib's flank — the flank's own section from the
    root face `b_lo` toward the axis plane (0.0 is the whole section), carried on from the flank
    at `a0` to the face the print grows from at `a1`, so the rib stands on that face and nothing
    of this end looks print-down over what the column covers."""
    lo, hi = sorted((a0, a1))
    return (
        cq.Workplane(_anchor_plane(origin, u, n))
        .polyline(_ring([(lo, b_lo), (hi, b_lo), (hi, b_root), (lo, b_root)]))
        .wire()
        .extrude(length)
        .val()
    )


def tube_anchor_end_columns(station, roots, lane, up, face_z, depth=None):
    """The two world-aligned boxes a rib's end webs would stand in as columns — from the flank
    that looks print-down to the plane `face_z`, the piece's own print-bed face — or None for an
    end that has no such column: a rib whose flanks are level, whose tube runs along the build
    axis, or whose print-down flank does not look toward `face_z`. `depth` is how far off the
    root face the column stands, None for the flank's whole section to the axis plane and
    `tube_anchor_corbel_depth(station, roots, lane)` for the footprint the corbel would have
    had. `station` is `(mid, u, n, seat_r)` as `_tube_anchors` reads it, `roots` and `lane` the
    piece's root faces and the box's own, and the boxes are struck the way that builder strikes
    the rib; the assembly reads each against the pack to say which end stands (`stand`)."""
    mid, u, n, seat_r = station[:4]
    face = _ROOT_FACE.get(tuple(int(round(c)) for c in n))
    if face is None:
        return (None, None)
    sign = 1.0 if face % 2 else -1.0
    b_face = (roots[face] - mid[face // 2]) * sign
    b_lane = (lane[face] - mid[face // 2]) * sign
    reach = seat_r + wall
    b_crown = seat_r + wall
    b_root = b_lane if (b_face < b_lane - 1e-9 and b_face - b_crown < tie_t) else b_face
    t = (n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
    if abs(abs(t[2]) - 1.0) > 1e-6:
        return (None, None)
    a_hang = math.copysign(reach, -up * t[2])
    a_face = (face_z - mid[2]) / t[2]
    if abs(a_face) <= abs(a_hang) + 1e-6 or (a_face > 0) != (a_hang > 0):
        return (None, None)
    origin = tuple(mid[k] - u[k] * tube_anchor_len / 2.0 for k in range(3))
    b_lo = 0.0 if depth is None else max(0.0, b_root - depth)
    out = []
    for s0, s1 in ((0.0, tie_cav_wall), (tie_cav_wall + tie_cav_w, tube_anchor_len)):
        pts = [tuple(origin[k] + u[k] * s + n[k] * b + t[k] * a for k in range(3))
               for s in (s0, s1) for b in (b_lo, b_root) for a in (a_hang, a_face)]
        out.append(tuple(min(p[k] for p in pts) for k in range(3))
                   + tuple(max(p[k] for p in pts) for k in range(3)))
    return tuple(out)


def tube_anchor_corbel_depth(station, roots, lane):
    """How far off the root face a rib's corbel would stand — `tube_anchor_corbel_reach` past
    the box's own lane, capped at the rib's depth — which is also the footprint a column may
    take where the flank's whole section cannot."""
    mid, _u, n, _seat_r = station[:4]
    face = _ROOT_FACE.get(tuple(int(round(c)) for c in n))
    if face is None:
        return None
    sign = 1.0 if face % 2 else -1.0
    b_face = (roots[face] - mid[face // 2]) * sign
    b_lane = (lane[face] - mid[face // 2]) * sign
    b_crown = station[3] + wall
    b_root = b_lane if (b_face < b_lane - 1e-9 and b_face - b_crown < tie_t) else b_face
    return min(b_root, b_root - b_lane + tube_anchor_corbel_reach)


def tube_anchor_end_corbel_bounds(station, roots, lane, up):
    """The two world boxes enclosing the ordinary end-web corbels for `station`.

    Each box is the corbel's complete triangular prism: one `tie_cav_wall` end, its full
    `tube_anchor_corbel_depth` off the root face, and the same distance along the print-down
    flank. A rib with no print-down flank has no end-web corbels."""
    mid, u, n, seat_r = station[:4]
    depth = tube_anchor_corbel_depth(station, roots, lane)
    t = (n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2],
         n[0] * u[1] - n[1] * u[0])
    if depth is None or depth <= 1e-9 or abs(abs(t[2]) - 1.0) > 1e-6:
        return (None, None)
    a_hang = math.copysign(seat_r + wall, -up * t[2])
    a_tip = a_hang + math.copysign(depth, a_hang)
    tip_z = mid[2] + t[2] * a_tip
    return tube_anchor_end_columns(station, roots, lane, up, tip_z, depth)


def back_top_frames():
    """Back-top's `(roots, lane)` off stated figures alone — the box's interior the pack is struck
    against, and the faces this piece presents (`piece_root_faces`) — for a reader with no built
    Box, struck the way `back_top_ceiling_stock` is."""
    ix0, ix1 = interior_x()
    lane = (ix0, ix1, y_seam, rear_plane_y, z_seam, appliance_height - floor_t - wall)
    return piece_root_faces(lane, "back", "top"), lane


def back_top_owns(point):
    """Whether a station at `point` stands in back-top's band — aft of the Y seam, above the Z."""
    return point[1] > y_seam and point[2] > z_seam


def _tube_anchors(solid, roots, lane, stations, y0, y1, z0, z1, up=1.0):
    """Every tube anchor whose whole rib this piece owns.

    A station carries the tube and only the tube — where its axis runs, which way it points, what
    it seats on — and the box carries the face. So an anchor moves when its run moves and stops
    where the wall stops. A piece that owns only part of a rib builds none of it, the way every
    other station on these walls behaves.

    AND THE FACE IS THE PIECE'S OWN (`piece_root_faces`), not the box's interior. A station is
    struck in the box's frame because that is the frame the run is in; the plane its rib STOPS on
    is whatever the piece carrying it presents, and on the two pieces with a grown flank those two
    stand three and six millimetres apart. Measured to the wrong one the channel below is drawn
    inside the wall's own stock, which is a rib with no cavity in it at all.

    AND WHERE THAT FACE LEAVES NO CHANNEL, THE WALL GIVES THE RIB ITS LANE BACK. `lane` is the
    box's own interior — one `wall` inside the exterior, the plane every station was struck
    against — and a piece carrying stock inboard of it carries stock the rib was drawn to use. So
    that piece gives it up over the rib's footprint and the rib roots on `lane` instead. The wall
    keeps its full section everywhere the rib does not need it, and one `wall` stands behind
    the relief because `lane` is one `wall` in.

    THE RELIEF IS WIDER THAN THE RIB OVER THE TIE BAND ALONE, and there by the zip tie. What the
    loop runs down is the rib's two FLANKS, from the channel's floor to the tube's own axis plane
    (`tube_anchor_tie_loop`), so a relief cut to the rib's own reach would hand the zip tie a
    channel it could not leave. Over the cavity's own `tie_cav_w` it is carried
    `tie_t + tie_cav_buffer` past each flank instead — the same room over the zip tie every cavity
    on this box carries — and those two lobes are what the loop comes down. The rib's two
    `tie_cav_wall` ends take the rib's own reach, which the rib fills back: the wall keeps its
    full section everywhere the zip tie never arrives.

    THE CAVITY IS A REMAINDER: the rib stands one `wall` over the bore's crown down its whole
    length and its two `tie_cav_wall` ends carry on to the face it roots on. The `tie_cav_w`
    between them is the tie band, the one band the relief takes wide, and there the zip tie keeps
    at most `tube_anchor_cavity_depth` once there is enough excess reach to add substantial
    backing; that excess is filled from the root face. The crown is therefore always its floor and
    either the root face or that backing is its roof — neither is cut, so there is no cutter face
    to graze the opening.

    A FLANK THAT LOOKS PRINT-DOWN STANDS ON THE FACE THE PRINT GROWS FROM, AND ONLY WHERE IT
    CANNOT CARRIES A CORBEL. A station's fifth entry, `stand`, names per end web `(plane, depth)`:
    the plane that end stands on — the piece's own print-bed face, where the air from the flank
    to that face is free of every placed body (`enclosure_assembly.stand_anchors` reads it
    against the pack) — and how far off the root face the column stands, None for the flank's
    whole section where that air is free and the corbel's own depth where only that much is; or
    None for the end where a body stands even in that. An end that stands goes on as a COLUMN:
    the flank's section over that depth, straight to that plane (`_anchor_column`), so nothing
    of it looks print-down there. An end that cannot takes a 45 degree wedge rooted on the same face the
    rib is, growing off that face into `tube_anchor_corbel_reach`: a rib whose axis stands
    inside that band is a triangle, `b_root` deep at the root face and nothing at the tube's axis
    plane; a deeper one is a truncated wedge, out to the band's edge and no further, and the deep
    end of its flank keeps its flat. `up` is the piece's print up along the box's Z, ±1, and
    which flank hangs comes off the profile's own `a` axis read against it — the flank whose
    outward looks along −`up`. A rib rooted on the floor or the ceiling, or with its tube running
    along the build axis, has neither flank down and takes neither; a rib rooted on the face the
    piece beds on — a ceiling-rooted rib on a piece printed ceiling-down — stands on the slab
    with its seat an upward-opening cradle in the print. Column and corbel alike stand over the
    same two `tie_cav_wall` ends and stop at the tie band, because the tie comes down that flank
    to the axis plane over `tie_cav_w` and material there is the one path it has closed. The
    band of flank between the two ends bridges.

    THE ZIP TIE CLOSES ROUND THE TUBE AND THE RIB'S OWN BACK TOGETHER: through the cavity, out one
    flank, round the far side of the tube and back in the other. What it pulls is the tube into
    the bore, and the bore is what says where the tube is."""
    if not stations:
        return solid
    for station in stations:
        mid, u, n, seat_r = station[:4]
        stand = tuple(station[4]) if len(station) > 4 and station[4] else (None, None)
        face = _ROOT_FACE.get(tuple(int(round(c)) for c in n))
        if face is None:
            raise ValueError(
                f"_tube_anchors: root direction {n} names no interior face. An anchor stands on "
                f"one of the box's six faces, and that face is what its rib stops on.")
        sign = 1.0 if face % 2 else -1.0
        b_face = (roots[face] - mid[face // 2]) * sign      # the face this piece presents
        b_lane = (lane[face] - mid[face // 2]) * sign       # and the box's own, at or outboard of it
        reach = seat_r + wall              # the lip's outer edge
        b_crown = seat_r + wall            # one `wall` over the bore's own crown
        # Add the supported tie-passage allowance at the backing side of its gap.
        # The tube-bearing web keeps its complete wall section and the tube's axis.
        cavity_depth = tube_anchor_cavity_depth + fits.supported_surface
        b_root, relief = b_face, b_face < b_lane - 1e-9 and b_face - b_crown < tie_t
        if relief:
            b_root = b_lane                # the wall gives this rib its lane back
        if b_root - b_crown < tie_t:
            raise ValueError(
                f"_tube_anchors: a `wall` off the bore's crown leaves {b_root - b_crown:.3f} mm "
                f"under the face this rib roots on, and the zip tie is {tie_t:.3g} thick. What "
                f"gives way here is the run's own lane, not the wall: route it further off that "
                f"face, or anchor it to another one.")
        origin = tuple(mid[k] - u[k] * tube_anchor_len / 2.0 for k in range(3))
        # The rib's own extent, so a piece that owns part of it builds none of it.
        t = (n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
        span = [[origin[k] + u[k] * s + n[k] * b + t[k] * aa
                 for k in range(3)]
                for s in (0.0, tube_anchor_len)
                for b in (0.0, b_root)
                for aa in (-reach, reach)]
        if not (y0 <= min(p[1] for p in span) and max(p[1] for p in span) <= y1
                and z0 <= min(p[2] for p in span) and max(p[2] for p in span) <= z1):
            continue
        # THE CAVITY IS WHAT IS NEVER FUSED, and nothing is cut for it. The rib is ONE box its
        # whole length up to `b_crown`, the two ends carried on up to the face it roots on, and
        # ONE bore through all of it. In the central zip tie band, material comes back from a remote
        # root until only `tube_anchor_cavity_depth` remains, provided that backing itself is at
        # least `tube_anchor_backing_min`. That boxes a small tube's long rib into the wall without
        # changing either threading mouth or putting a fragile skin against them.
        #
        # The lower box runs the rib's whole length so the seat's own lip is ONE edge, and the rib
        # is UNIFIED before it joins the piece. A fuse imprints the seam of every solid that went
        # into it, so a rib fused straight onto the wall carries its lip in as many pieces as it
        # was laid down in — three here — and its bore in as many again.
        band = tuple(origin[k] + u[k] * tie_cav_wall for k in range(3))
        # The flank that looks print-down — None where the profile's `a` axis is level — and how
        # far off the root face its corbel grows: to the band's edge or the axis plane, whichever
        # it arrives at first.
        a_hang = None if abs(t[2]) < 1e-9 else math.copysign(reach, -up * t[2])
        corbel = min(b_root, b_root - b_lane + tube_anchor_corbel_reach)
        if relief:
            # THE RELIEF, cut before the rib is fused so the rib is what fills it. Its floor is
            # `lane`, so what stands behind it is the one `wall` this box carries everywhere. The
            # rib's own reach runs the whole length; the two lobes the zip tie comes down are the
            # tie band's, reach no further into the wall than the channel's own roof, and the
            # wall keeps its full section at the rib's two ends.
            solid = solid.cut(_anchor_rib(origin, u, n, tube_anchor_len,
                                          reach, b_face, b_lane))
            # This channel is only the air available before the declared root. A shallow
            # anchor must not gain clearance by cutting through its supporting wall.
            roof = min(b_root, b_crown + cavity_depth)
            if roof > b_face + 1e-9:
                solid = solid.cut(_anchor_rib(band, u, n, tie_cav_w,
                                              reach + tie_t + tie_cav_buffer, b_face, roof))
        rib = _anchor_rib(origin, u, n, tube_anchor_len, reach, 0.0, b_crown)
        for w, (s0, s1) in enumerate(((0.0, tie_cav_wall),
                                      (tie_cav_wall + tie_cav_w, tube_anchor_len))):
            end = tuple(origin[k] + u[k] * s0 for k in range(3))
            rib = rib.fuse(_anchor_rib(end, u, n, s1 - s0, reach, b_crown, b_root))
            if a_hang is None:
                continue
            if stand[w] is not None and abs(abs(t[2]) - 1.0) < 1e-6:
                # THIS END STANDS ON THE PRINT-BED FACE `stand` NAMES: the flank's section, over
                # the depth named, goes straight on to that plane in the direction the
                # print-down flank looks.
                plane, depth = stand[w]
                a_face = (plane - mid[2]) / t[2]
                b_lo = 0.0 if depth is None else max(0.0, b_root - depth)
                if abs(a_face) > abs(a_hang) + 1e-6 and (a_face > 0) == (a_hang > 0):
                    rib = rib.fuse(_anchor_column(end, u, n, s1 - s0, a_hang, a_face, b_root, b_lo))
                continue
            if corbel > 1e-9:
                rib = rib.fuse(_anchor_corbel(end, u, n, s1 - s0, a_hang, b_root, corbel))
        # THE CROWN OVER THE TIE BAND IS ONE FLAT `tie_cav_w` STRIP between the two end webs,
        # whichever way the piece prints: where it looks print-down it is a bridge that span
        # long, web to web, laid over the channel's air.
        if b_root - b_crown >= cavity_depth + tube_anchor_backing_min:
            rib = rib.fuse(_anchor_rib(band, u, n, tie_cav_w, reach,
                                       b_crown + cavity_depth, b_root))
        seat = _anchor_bore(origin, u, seat_r, tube_anchor_len)
        supported_seat = abs(u[2]) < 1.0 - 1e-6 and n[2] * up >= -1e-6
        if supported_seat:
            # Side-rooted circular seats have a print-down arc. Extend the exterior stock
            # along with that arc so the complete nominal wall remains behind the added
            # room. Ceiling-bedded open cradles and vertical bores need no such allowance.
            rib = _supported_cut(rib, up)
            seat = _supported_cut(seat, up)
        rib = rib.cut(seat)
        solid = solid.fuse(rib.clean() if hasattr(rib, "clean") else rib)
    return solid


def _c14_aperture(stations, ports):
    """The rounded rectangle the C14's shroud reaches out through, picked out of a wall's own
    port list by the two heat-set stations that straddle it — `(x, z, across_x, across_z, r)`.

    THE HOLE AND THE STATIONS ARE ONE PLACEMENT: `enclosure_assembly.c14_cutout` and
    `enclosure_assembly.c14_stations` are both struck on `C14_STATION`, and both screws sit ON
    the mating axis, so the aperture is the rect port standing midway between them. A tunnel
    built round a hole that is not cut is a plug, and this is where that reads."""
    (x0, z0), (x1, z1) = stations[0], stations[-1]
    cx, cz = (x0 + x1) / 2.0, (z0 + z1) / 2.0
    for kind, hx, hz, *size in ports:
        if kind == "rect" and abs(hx - cx) < 1e-6 and abs(hz - cz) < 1e-6:
            wx, wz, *radius = size
            return cx, cz, wx, wz, (radius[0] if radius else 0.0)
    raise ValueError(
        f"the C14's two stations straddle (x {cx:.4g}, z {cz:.4g}) and this wall's port list "
        f"carries no rounded rectangle there. A tunnel built round a hole that is not cut is a "
        f"plug, so the pack states one or the other and not both halves of a placement.")


def _c14_tunnel_geometry(inner, outer, stations, ports, z0, z1, up=1.0):
    """The C14 tunnel's material and cutters — for the stations in `z0..z1`.

    THE RECEPTACLE DOES NOT BEAR ON THIS WALL. It bears on the seating face, one
    `c14_tunnel_len` inboard of the wall, and the customer's cord reaches it down a bore that is
    the aperture itself and nothing else: the tunnel grows entirely OUTWARD of the hole, so
    neither its section nor its two bores ever stand in the plug's way.

    THE TUNNEL IS ONE BLOCK. From the pocket's mouth — `c14_pocket_depth` fore
    of the seating face — to the wall, it is one rectangle of the half extents `c14_mount_half`
    reads: the bore's section, the inserts' ligaments and the pocket's wall, whichever asks for
    more on each axis. Its fore face is one plane, its flanks are two, and the flange's pocket
    stands inside it everywhere. The block is clipped to the room, so above the aperture its
    crown runs out into the top wall.

    THIS STATION BELONGS TO CEILING-BEDDED BACK-TOP. `up` must therefore be `BACK_TOP_UP`: the
    block's crown fuses into the ceiling slab, and its opposite horizontal face looks print-up.
    What remains over air is the bore's own roof, a bridge the aperture's width between the two
    block flanks.

    THE FLANGE DROPS INTO ITS OWN PROFILE. The pocket is the purchased flange's exact
    rounded/tapered outline at `c14_pocket_slip`, cut from the mouth to the seating face — the
    plane the flange bears on, which does not move, and neither does either insert. Fore of the
    mouth its exact slipped outline runs `c14_insertion_relief` further in Y- through the fixed
    +X strip, so the two-ear moulding has a straight approach to its seat.

    THE INSERTS ENTER THE SEATING FACE, from inside the machine like every other insert on this
    box, and bottom on the wall's own inner face. The station is relieved back to `wall`
    (`back_top_wall_reliefs`), so what stands over each blind end is `socket_cap` of wall and
    the tunnel is the whole of what is left.

    IT ROOTS ON `back_wall_t_at` AND NOT ON `inner`. The piece holding these stations carries
    `back_top_wall_t` over most of this wall, so the plane the tunnel stands on is the section
    read at the aperture — a tunnel rooted on the box's own rear plane would start a section
    inside a wall that is thicker than that plane anywhere the relief does not reach. Beyond the
    relief's ends the block's last millimetres stand inside that thicker wall, which is fused
    stock and not a face."""
    if not stations or not all(z0 <= sz <= z1 for _sx, sz in stations):
        return None
    if up != BACK_TOP_UP:
        raise ValueError(
            f"the C14 station belongs to ceiling-bedded back-top ({BACK_TOP_UP:g} print-up), "
            f"not a piece with print-up {up:g}")
    cx, cz, wx, wz, r = _c14_aperture(stations, ports)
    cap = back_wall_t_at(cx, cz)
    if abs(cap - socket_cap) > stated_bound_tol:
        raise ValueError(
            f"the C14's aperture passes {cap:.2f} mm of wall and the cap over an insert's blind "
            f"end is {socket_cap:g}. The tunnel runs one `heatset_depth` off that wall, so at "
            f"any other section it holds either half an insert or a cap and half a tunnel.")
    for sx, sz in stations:
        if abs(back_wall_t_at(sx, sz) - cap) > stated_bound_tol:
            raise ValueError(
                f"the C14's station at (x {sx:.4g}, z {sz:.4g}) stands on "
                f"{back_wall_t_at(sx, sz):.2f} mm of wall and the aperture it straddles on "
                f"{cap:.2f} — one relief no longer covers this tunnel's fastening field, so an "
                f"insert would bottom on a plane the tunnel does not root on.")
    aft = outer[3] - cap
    fore = aft - c14_tunnel_len
    mouth = fore - c14_pocket_depth
    hx, hz = c14_mount_half(wx, wz, max(abs(sx - cx) for sx, _sz in stations))
    # The block keeps the one section `c14_mount_half` states. Its crown enters the grown
    # ceiling slab by more than one wall, joining the two as one continuous volume.
    block = _ybox(cx - hx, cx + hx, mouth, aft, cz - hz, cz + hz)
    feature = _supported_cut(block, up).intersect(
        _ybox(inner[0], inner[1], mouth, aft, inner[4], inner[5]))
    # The cord bore continues through the wall and tunnel. The exact flange pocket opens through
    # the block's fore face and continues inboard through the +X strip for assembly access; its
    # stopped +Y end is the face the flange bears on.
    flange_pocket = (c14_pocket_prism(
        c14_pocket_slip, mouth - c14_pocket_overcut - c14_insertion_relief, fore)
        .translate((cx, 0.0, cz)).val())
    bore = _supported_cut(
        _rect_cut_y(cx, cz, wx, wz, r, fore, outer[3] + 1.0).fuse(flange_pocket), up)
    inserts = tuple(_supported_cut(
        _ycyl(heatset_dia / 2.0, sx, sz, fore, fore + heatset_depth), up)
                    for sx, sz in stations)
    return feature, bore, inserts


def _keystone_pocket_cut(x, z, y_face):
    """The unchanged jack's face and body with the enclosure's static mating clearance.

    The purchased reference supplies the body envelope, lip depth, catch stations and swing
    ease. Its illustrative receptacle dimensions do not set this printed part's fit.
    """
    aperture_w = _keystone.FACE_W + 2.0 * fits.slip
    aperture_h = _keystone.FACE_H + 2.0 * fits.slip
    pocket_w = _keystone.POCKET_W - _keystone.FIT_SLIP + 2.0 * fits.slip
    pocket_h = _keystone.POCKET_H - _keystone.FIT_SLIP + 2.0 * fits.slip
    y_lip, y_back = y_face - _keystone.LIP_D, y_face - _keystone.DEPTH
    aperture = _rect_cut_y(x, z, aperture_w, aperture_h, 0.0,
                           y_lip - 0.01, y_face + 0.01)
    pocket = _rect_cut_y(x, z + _keystone.POCKET_RISE, pocket_w, pocket_h, 0.0,
                        y_back - 0.01, y_lip + 0.01)
    top = z + aperture_h / 2.0
    ease = _yz_prism(x - aperture_w / 2.0, x + aperture_w / 2.0,
                     [(y_face, top), (y_lip, top),
                      (y_lip, top + _keystone.ease_rise())])
    return aperture.fuse(pocket).fuse(ease), (y_lip, y_back)


def _keystone_catches(catches, up):
    """Retain each catch's complete section at its pocket root and relieve its bridge face."""
    loose = catches.Solids()
    lower = min(loose, key=lambda s: s.BoundingBox().zmin)
    pocket_growth = max(0.0, fits.slip - _keystone.FIT_SLIP / 2.0)
    out = None
    for part in loose:
        sign = -1.0 if part.isSame(lower) else 1.0
        rooted = part.fuse(part.translate((0, 0, sign * pocket_growth)))
        # Lower catch's top faces print-down in a ceiling-bedded print, upper catch's
        # underside in a floor-bedded print. Moving its complete section preserves retention.
        if sign * up > 0.0:
            rooted = rooted.translate((0, 0, up * fits.supported_surface))
        out = rooted if out is None else out.fuse(rooted)
    return out


def _keystone_receptacle_geometry(inner, outer, station, z0, z1, up=1.0):
    """The keystone receptacle's fixed material and cutter.

    The pocket needs the full module-standard height. Its printed surround is clipped to the
    interior-ceiling plane if a station ever carries it that high; at a lower station the clip
    is inert and the whole receptacle stands in this wall.

    THE BOSS STANDS ON A 45° WEB ON ITS PRINT-DOWN SIDE, the same one a port chip's boss and a
    +X mounting boss stand on. `up` is the piece's print-up in the machine's frame: for `up > 0`
    the web is under the block, falling from the free face's bottom edge to the wall; for
    `up < 0` (`BACK_TOP_UP`) it is over the block, rising from the free face's top edge to the
    wall at `b.ymax`. ITS FIGURE IS THE BLOCK'S OWN BOX — the wall face it roots on, the free
    face it ends at, and the reach between them — and it takes the same ceiling clip.

    Returns ``(feature, cutter, catches)``. The cutter is kept separate because it has to pass
    through both the additive boss and the wall already present in the piece; the catches are
    kept separate because they are fused only after that cut."""
    if station is None:
        return None
    x, z = station
    if not z0 <= z <= z1:
        return None
    y_face = outer[3]
    block, catches = _keystone.receptacle_boss(x, z, y_face, y_face - back_wall_t_at(x, z))
    if block is not None:
        # Preserve the receptacle's three-millimetre surrounding section after applying
        # the shared base fit to the purchased body's nominal dimensions.
        bb = block.BoundingBox()
        pw = _keystone.POCKET_W - _keystone.FIT_SLIP + 2.0 * fits.slip
        ph = _keystone.POCKET_H - _keystone.FIT_SLIP + 2.0 * fits.slip
        hx, hz = pw / 2.0 + _keystone.RECEPTACLE_WALL, ph / 2.0 + _keystone.RECEPTACLE_WALL
        block = _ybox(x - hx, x + hx, bb.ymin, bb.ymax,
                       z + _keystone.POCKET_RISE - hz, z + _keystone.POCKET_RISE + hz)
    feature = _supported_cut(block, up) if block is not None else None
    if block is not None:
        b = block.BoundingBox()
        edge = b.zmin if up > 0 else b.zmax      # the block's print-down edge
        feature = feature.fuse(_yz_prism(
            b.xmin, b.xmax,
            [(b.ymax, edge), (b.ymin, edge),
             (b.ymax, edge - up * (b.ymax - b.ymin))]))
        below_ceiling = _ybox(
            outer[0] - 1.0, outer[1] + 1.0,
            outer[2] - 1.0, outer[3] + 1.0,
            outer[4] - 1.0, inner[5])
        feature = feature.intersect(below_ceiling)
        if catches is not None:
            catches = catches.intersect(below_ceiling)
    cutter, _bands = _keystone_pocket_cut(x, z, y_face)
    if catches is not None:
        catches = _keystone_catches(catches, up)
    return feature, _supported_cut(cutter, up), catches


def _keystone_receptacle(solid, inner, outer, station, z0, z1, up=1.0):
    """Fuse the keystone's receptacle to its back-wall piece and open it.

    A KEYSTONE IS HELD BY A RECEPTACLE AND NOT BY A HOLE. `riteav_keystone` states the whole of
    it — an aperture at the show face, a lip behind it, a pocket taller than the aperture, an
    ease over the aperture's top edge the body swings through, and two catches at the pocket's
    back the tang and the latch snap over. This wall gives the lip its depth out of its own
    section, and a boss standing inboard gives the rest.

    THE BOSS IS FUSED, THEN THE POCKET IS CUT, THEN THE CATCHES ARE FUSED BACK. The catches
    stand inside the pocket, and a cut running after them would take them off again.

    AND THE BOSS STANDS ON A 45° WEB ON ITS PRINT-DOWN SIDE. `up` is the piece's print-up in
    the machine's frame; the block's face that looks print-down is its reach off the wall of
    ceiling starting in air, and the web is that reach taken back to the wall at
    `relief_chamfer` (`_keystone_receptacle_geometry`)."""
    geometry = _keystone_receptacle_geometry(inner, outer, station, z0, z1, up)
    if geometry is None:
        return solid
    feature, cutter, catches = geometry
    if feature is not None:
        solid = solid.fuse(feature)
    solid = solid.cut(cutter)
    if catches is not None:
        solid = solid.fuse(catches)
    return solid


def _c14_tunnel(solid, inner, outer, stations, ports, z0, z1, up=1.0):
    """Fuse the complete C14 surround to its back-wall piece and open its bores. `up` is the
    piece's print-up in the machine's frame (`_c14_tunnel_geometry`)."""
    geometry = _c14_tunnel_geometry(inner, outer, stations, ports, z0, z1, up)
    if geometry is None:
        return solid
    feature, bore, inserts = geometry
    # The tunnel block is one surround with the wall, clipped on the interior-ceiling plane
    # where its crown reaches it.
    solid = solid.fuse(feature)
    # The bore, opened through everything standing round it. The wall's own cutters run to its
    # inner face and this one runs to the tunnel's, so the hole is one rectangle end to end.
    solid = solid.cut(bore)
    for cutter in inserts:
        solid = solid.cut(cutter)
    return solid


def _piece_bands(box, name):
    """The Y and Z bands one quadrant owns, as `(y0, y1, z0, z1)` — what every station is tested
    against before the piece grows or cuts it. Each band runs a millimetre past the shell at its
    outer end and stops on the seam at its inner one, so a station on a seam plane belongs to
    exactly one piece."""
    y_side, z_side = name.split("-")
    zj = box.splits[0] if y_side == "front" else box.splits[1]
    y0, y1 = ((box.outer[2] - 1.0, box.y_joint) if y_side == "front"
              else (box.y_joint, box.outer[3] + 1.0))
    z0, z1 = ((box.outer[4] - 1.0, zj) if z_side == "bottom"
              else (zj, box.outer[5] + 1.0))
    return y0, y1, z0, z1


def build_piece(box, y_side, z_side, halves_cache=None):
    """One of the four printable pieces: the full front/back column split at
    its seam (`box.splits` — the one stated plane, both columns), the bottom
    taking the Z lip, the hooked rails, the stop blocks and the corner fills, the
    top taking the foot slabs, the channel and the corner reliefs. The Y-seam
    bosses' under-seam level sits under that plane, so it lands in — and pins —
    the two bottom pieces; the over-rim level the two tops."""
    inner, outer, y_joint = box.inner, box.outer, box.y_joint
    ox0, ox1, oy0, oy1, oz0, oz1 = outer
    zj = box.splits[0] if y_side == "front" else box.splits[1]
    up = print_up(y_side, z_side)
    if halves_cache is not None and y_side in halves_cache:
        half = halves_cache[y_side]
    else:
        half = build_front_half(box) if y_side == "front" else build_back_half(box)
        if halves_cache is not None:
            halves_cache[y_side] = half
    solid = half.val()
    plate = box.pack.collet_plate if (box.pump_bay and box.pack.collet_plate) else None
    if z_side == "bottom":
        piece = solid.intersect(_ybox(ox0 - 1.0, ox1 + 1.0, oy0 - 1.0, oy1 + 1.0,
                                      oz0 - 1.0, zj))
        col = _ybox(ox0 - 1.0, ox1 + 1.0,
                    oy0 - 1.0 if y_side == "front" else y_joint,
                    y_joint if y_side == "front" else oy1 + 1.0,
                    oz0 - 1.0, oz1 + 1.0)
        # The wall that carries the seam's furniture down to the slab, so a head stands
        # on a wall and not in air. Fused before every pocket, so a well or a groove cut
        # into this flank later is cut out of the whole `2 * wall` of it.
        piece = piece.fuse(_lip_underwall(inner, y_joint, zj).intersect(col))
        if y_side == "front":
            # And front-bottom's own extra section on the west flank, welled round the card.
            piece = piece.fuse(_front_bottom_flank_skin(
                inner, box.pack.west_cradle, y_joint, zj).intersect(col))
            # And the two feet the collet plate stands on, which carry that same face inboard
            # under the plate's ends. Fused with the skin, before every pocket, so anything cut
            # into this flank later is cut out of the whole of it.
            if box.pump_bay and box.pack.collet_plate:
                piece = piece.fuse(
                    _plate_foot(inner, box.pack.collet_plate, zj).intersect(col))
        if y_side == "back":
            # And back-bottom's own extra section inboard of that, on the two flanks only.
            # Fused with them and before every pocket for the same reason: a well cut into
            # this flank later is cut out of the whole `back_bottom_flank_t` of it.
            piece = piece.fuse(_back_bottom_flank_skin(inner, y_joint, zj).intersect(col))
        if y_side == "front" and box.pump_bay:
            # The front flat's share of both skins goes to the bay's floor and the heads
            # that pass through its berth; the flat sill is front-top's.
            piece = piece.cut(_front_flat_lip_drop(inner, zj))
            # And both flanks over the same run, round the corners to the tee wall's aft
            # face — the rail starts on that face and nothing crosses the seam fore of it.
            piece = piece.cut(_flank_lip_drop(inner, box.pack.collet_plate, y_joint, zj))
        # The rail heads and their stop blocks — the whole of what stands proud of this
        # piece's mouth, what the top's channel swallows on the way in and its return
        # rides at home.
        piece = piece.fuse(_z_rail_heads(inner, y_joint, zj, y_side, plate,
                                         box.pack.vent_chase))
    else:
        piece = solid.intersect(_ybox(ox0 - 1.0, ox1 + 1.0, oy0 - 1.0, oy1 + 1.0,
                                      zj, oz1 + 1.0))
        # FRONT-TOP'S OWN ±X SECTION, first of everything this piece does to its flanks. The
        # wells, the trays and every bore below are struck on `interior_x` and cut AFTER this,
        # so each one is cut out of the whole section rather than out of the skin it replaced —
        # which is what leaves a lever nut bottoming exactly where it bottomed before.
        if y_side == "front" and box.pack.collet_plate:
            piece = piece.fuse(_front_top_flanks(inner, outer, box, y_joint, zj))
            # The Y tongue is part of these same two flanks. Its shoulder and slipped overlap
            # continue through the seam, but their bed-facing edge stays on the flank's one
            # established 45-degree plane; no separate strip or end cap hangs below it where
            # the Z-rail channel crosses the tongue.
            piece = piece.cut(_front_top_flank_bedding_cut(
                inner, y_joint - wall - 1.0, y_joint + lip_len + 1.0, zj))
        # AND BACK-TOP'S OWN, first of everything that piece does to its flanks, for the same
        # reason: the wells and the +X bosses below are struck on `interior_x` and cut after
        # this, so each is cut out of the whole section rather than out of the skin it replaced.
        if y_side == "back":
            piece = piece.fuse(_back_top_flanks(inner, outer, box, y_joint, zj, up=up))
        # The rails' foot slabs, one per flank — fused with the sections above, before
        # every pocket, and carved to the slide's own profile by the channel cut at the
        # END of this piece's work, so everything later fused near a flank is carved too.
        piece = piece.fuse(_z_rail_feet(inner, y_joint, zj, y_side, plate,
                                        box.pack.vent_chase))
        if y_side == "back":
            # BACK-TOP'S OWN +Y SECTION, first of everything this piece does to that wall — so
            # the port field, the C14's bores and the nameplate's seat are cut out of the
            # section rather than out of the skin it replaced.
            piece = piece.fuse(_back_top_wall(inner, outer, box, zj, up=up))
            # AND ITS CEILING, the slab this piece prints on, with every pocket the pack asks
            # of it already open. Here for the same reason the two sections above are: the ASSE
            # anchor's V, the chain's bores, the wells and every bore below are cut AFTER this, so
            # each is cut out of the slab where it reaches it rather than filling a pocket back in.
            piece = _back_top_ceiling(piece, inner, y_joint, box)
    piece = piece.intersect(_rounded_outer(outer))
    # THE COLUMN RELIEFS' CEILINGS, ahead of every fuse this piece makes. The pockets are cut
    # last, where a relief has to be; the 45° walk their ceilings take into the column is cut
    # HERE, so a pocket the piece goes on to roof is roofed and one nothing stands over keeps
    # the walk (`_column_relief_rise`).
    for sx, sy, _name, room in box.column_reliefs:
        piece = piece.cut(_column_relief_rise(
            inner, sx, sy, room, box.splits[0] if sy < 0 else box.splits[1], up=up))
    zlo, zhi = _piece_bands(box, f"{y_side}-{z_side}")[2:]
    if y_side == "back":
        rear = back_top_wall_face() if z_side == "top" else None
        # The port field: its pockets are cut into the wall's outer face, so the face the
        # customer meets is flush, and its bores run past the deepest nut land — a bore that
        # crosses the wall crosses the whole station.
        piece = _port_field(piece, box.pack.port_field, box.pack.back_ports, oy1,
                            None if rear is None else back_wall_t_at, up=up)
        # And the C14's tunnel, on whichever piece holds its two stations. Last on this wall
        # because its bore reaches further inboard than the field's own cutters do — those run
        # to the boss each stands behind, and this one runs the whole depth of the tunnel.
        piece = _c14_tunnel(piece, inner, outer, box.pack.c14, box.pack.back_ports, zlo, zhi,
                            up=up)
        # And the keystone's receptacle, reaching further inboard again — the boss carrying the
        # pocket the jack snaps into stands past where the field's own bosses stop.
        piece = _keystone_receptacle(piece, inner, outer, box.pack.keystone, zlo, zhi, up=up)
    # The +X wall's mounting bosses, on whichever piece holds each one's station. Last of
    # all, so a bore is cut through every column that has already been fused around it.
    ylo, yhi = _piece_bands(box, f"{y_side}-{z_side}")[:2]
    piece = _east_bosses(piece, piece_root_faces(inner, y_side, z_side), outer,
                         box.pack.east_bosses, box.pack.east_mount_fills,
                         ylo, yhi, zlo, zhi, up=up)
    # The +X wall's Wago wells, on whichever piece holds each one's station. After the
    # bosses for the same reason those go after the seam's own bosses: a pocket cut here is a
    # pocket nothing later fuses back in.
    piece = _side_wells(piece, inner, box.pack.side_wells, ylo, yhi, zlo, zhi, up=up)
    # The floor slab's, on whichever piece holds each one's plan station. Only the bottom
    # pieces have a slab to stand one on, and `_floor_bosses` drops any station outside.
    piece = _floor_bosses(piece, inner, box.pack.floor_bosses, ylo, yhi, zlo, zhi)
    # The −X wall's card slot, last of all: its bottom rail lands on the same slab those posts
    # rise from, so cutting its grooves after them is what keeps a groove a groove.
    piece = _west_cradle(piece, inner, box.pack.west_cradle, ylo, yhi, zlo, zhi)
    # The condenser block's four flanges, on the same slab and the walls either side of it: the
    # fore rails off the front wall, the aft fin off the +X one. After the floor's posts for the
    # card slot's own reason — a rail rooted on the slab is rooted on whatever is standing there.
    piece = _cond_cradle(piece, inner, box.pack.cond_cradle, ylo, yhi, zlo, zhi)
    piece = _cond_mount(piece, inner, box.pack.cond_mount, ylo, yhi, zlo, zhi)
    # The cold core's own two: the front corner blocks on the same slab those rails root on, and
    # the hold-down brackets a storey up on the +Y wall. The blocks carry a bore, so they go on
    # with the other pockets — after everything that could fuse material back into one.
    piece = _core_stops(piece, inner, box.pack.core_stops, ylo, yhi, zlo, zhi)
    piece = _core_holds(piece, inner, box.pack.core_holds, ylo, yhi, zlo, zhi,
                        back_top_wall_face() if (y_side, z_side) == ("back", "top") else None)
    # And the core's relief, which leaves it by a flank and needs somewhere to go: the rib is
    # fused before the channel is cut out of it, which is the same order the card slot takes.
    piece = _vent_chase(piece, inner, outer, box.pack.vent_chase, ylo, yhi, zlo, zhi, up=up)
    # And the tap-water chain's, on the same wall a storey up. After the tray's rails, whose
    # band it stands over, and last like every other pocket: its tie slots are cut out of the
    # ASSE anchor this fuses, so nothing may fuse into them afterwards.
    piece = _asse_cradle(piece, inner, box.pack.asse_cradle, ylo, yhi, zlo, zhi, up=up)
    # And the flow meter's two anchors off the ceiling, on the piece whose band holds them.
    #
    # BOTH BUILDERS ROOT ON THIS PIECE'S OWN INTERIOR and not on the box's. A rib's cavity is the
    # room its two ends leave under the face it stops on, so the plane they are drawn to has to be
    # the plane this piece puts there (`piece_root_faces`). On back-top that plane is the lane, and
    # the slab stands off each rib's room (`_ceiling_tie_reliefs`).
    roots = piece_root_faces(inner, y_side, z_side)
    piece = _flow_meter_anchors(piece, roots, box.pack.flow_meter_anchors, ylo, yhi, zlo, zhi,
                                up=up)
    # And the flavour manifold's valve trays, on whichever piece owns each deck's band. A plate
    # wall to wall with its seats standing on it, so it goes on after the wells and the bosses
    # for the same reason they go after the seam's own bosses.
    # The wall the anchor tees stand in, behind the collet plate — BEFORE the valve trays,
    # because a tray's seats are cut out of whatever stands on that plane and this stands on it.
    if y_side == "front" and z_side == "top" and box.pump_bay and box.pack.collet_plate:
        piece = piece.fuse(_tee_wall(inner, y_joint, box.pack.collet_plate, box.pump_bay))
        # And the rib that stands on that wall's crown, carrying the ridge the display's
        # through-hole leaves across the housing's back. With the wall, because it stands on
        # it — and after the facet's own cuts, which the half took before it was split.
        piece = piece.fuse(_ridge_wall(
            inner, outer, box.pack.collet_plate, box.pump_bay, box.pack.funnel))
        # And that clip's continuation round the corner, on the flank this piece's own section
        # already put there. After `_side_wells`, whose tower is one of the two things bounding
        # a station on that face — a clip fused before the well was cut would be cut by it.
        piece = _flank_cable_clips(piece, box)
        if box.pack.tee_carrier:
            piece = piece.fuse(_tee_carrier_fixed_features(
                inner, box.pack.collet_plate, box.pack.tee_carrier))
    piece = _valve_trays(
        piece, inner, box.pack.valve_trays, ylo, yhi, zlo, zhi,
        wall_aft_y=(box.pack.collet_plate["wall_aft_y"] if box.pack.collet_plate else None),
        flank_bed_z=(zj if (y_side, z_side) == ("front", "top") else None),
    )
    # The removable cartridge bears on the floor joined to the bay bulkhead.
    if y_side == "front" and z_side == "top" and box.pump_bay and box.pack.collet_plate:
        piece = piece.fuse(_bay_floor(inner, y_joint, box.pack.collet_plate, box.pack.pump_trays))
    # Fixed fitting pockets remove only the flank stock. Restore the anchors afterwards so
    # their complete circular bearing webs, end roots and tie channels survive the relief.
    if (y_side, z_side) == ("back", "top"):
        piece = _flank_body_pockets(piece, box.pack.flank_reliefs)
    # And the runs' own anchors, on whichever face each one stands nearest. Last, for the same
    # reason the ASSE anchor is: every one of these is a rib with a cavity cut through it.
    piece = _tube_anchors(piece, roots, inner, box.pack.tube_anchors, ylo, yhi, zlo, zhi,
                          up=up)
    # And the nameplate — the pocket on the +Y wall's outer face, the plateau that floors it on
    # the inner one, and the two screw bosses standing off that. LAST of this wall's work, like
    # every other pocket: it is cut a screw seat deep, which is deeper than the wall's own stock,
    # so anything fused onto this face afterwards would stand in the plate's own seat. The cold
    # core's aft bracket is the one that does — its leg climbs this face right through the
    # plate's lane, and cut here it roots on the pocket's floor with the plateau, one continuous
    # section, instead of poking through into the plate.
    if y_side == "back":
        piece = _nameplate(piece, box.pack.nameplate, outer, oy1, zlo, zhi, up=up)
    # And the flat ceiling's two strips over the funnel opening's flanks, on the front
    # top alone — the piece whose ceiling is nothing but those strips.
    if y_side == "front" and z_side == "top" and box.pack.funnel:
        piece = _ceiling_corbels(piece, inner, outer, box.pack.funnel, y_joint, box.y_bosses)
    # The bay's opening, after every fuse that stands near it: what leaves through it is
    # the pump cartridge, and what it takes from this piece is what `build_pump_cartridge` keeps.
    if y_side == "front" and z_side == "top" and box.pump_bay:
        piece = piece.cut(_bay_cut(inner, outer, box.pump_bay, box.pack.pump_trays,
                                   box.pack.collet_plate))
    # And then the columns give up whatever the pack stands in them (`_column_relief`), which is
    # last of everything: a relief is air, and air a later step fuses back in is not a relief.
    # Clipped to the pillar — the column AND the lip's skin wrapping it (`_column_pillar`) —
    # so what a pocket can ever take is that and never the wall behind it or the boss beside it.
    # Their ceilings' 45° walk was first taken at the head of this piece's work. Take it again
    # here with the final pocket so a rail or boss fused since cannot put a flat roof back over
    # that air (`_column_relief_rise`).
    for sx, sy, _name, room in box.column_reliefs:
        piece = piece.cut(_column_relief(
            inner, sx, sy, room, box.splits[0] if sy < 0 else box.splits[1],
            box.pack.cond_cradle))
        piece = piece.cut(_column_relief_rise(
            inner, sx, sy, room, box.splits[0] if sy < 0 else box.splits[1], up=up))
    # And the condenser's two vents, which are the last cut this piece takes for the same reason
    # a relief is: they are air, and air a later step fuses back in is not a vent. What stops
    # each slot is read off the piece as it stands HERE — every rail, fin, pod, pocket and
    # relief on those two flanks already in it.
    piece = _flank_vents(piece, inner, outer, box.pack.cond_airway, ylo, yhi, zlo, zhi,
                         box.pack.west_cradle)
    if z_side == "top":
        # THE SLIDE'S OWN CARVING, after everything a top piece fuses. The channel is cut
        # through whatever now stands in the rail's lane — the foot slabs, the flank
        # sections, a valve tray's foot — so the section
        # the head sweeps is the section the piece actually presents, whatever later grew
        # there. The corner reliefs the same: the pillars stand off the band the bottom's
        # corner fills and flank rails sweep, and regrow on their 45° pair above it.
        piece = piece.cut(_z_rail_channels(inner, y_joint, zj, y_side, plate,
                                           box.pack.vent_chase))
    if y_side == "front":
        # AND THE Y TELESCOPE'S, on both storeys and for the same reason: the lip's own
        # section is the section this piece presents aft of the mouth, whatever has grown
        # into that band since the lip was drawn.
        piece = piece.cut(_y_lip_channel(inner, y_joint, box.y_bosses))
    # THE FUNNEL'S OWN AIR, after every feature a top piece can fuse. The ridge wall and
    # ceiling corbels terminate on this slipped opening, but this last pass makes the contract
    # unconditional: no later rail, boss or seam feature may grow material back into the
    # removable funnel's collar clearance.
    if z_side == "top" and box.pack.funnel:
        cx, cy = box.pack.funnel
        brim_front = cy - _funnel.collar_d / 2.0 - _funnel.brim_overhang
        brim_back = cy + _funnel.collar_d / 2.0 + _funnel.brim_overhang
        seat_stock = _ybox(inner[0], inner[1],
                           brim_front - funnel_seat_thickness,
                           brim_back + funnel_seat_thickness,
                           funnel_seat_z(outer) - funnel_seat_thickness, outer[5])
        if y_side == "back":
            # The brim keeps its complete bearing section. Outside that footprint,
            # the filled surround respects the pack's existing ceiling pockets.
            bearing = _swept_top.rounded_prism(
                _funnel.collar_w + 2.0 * _funnel.brim_overhang,
                _funnel.collar_d + 2.0 * _funnel.brim_overhang,
                _funnel.brim_corner_r,
                funnel_seat_z(outer) - funnel_seat_thickness,
                funnel_seat_z(outer), cx, cy)
            floor = funnel_seat_z(outer) - funnel_seat_thickness
            for _who, x0, x1, y0, y1, top in box.pack.ceiling_reliefs:
                roof = min(top, inner[5])
                if roof > floor:
                    relief = _ybox(x0, x1, y0, y1, floor - 1.0, roof)
                    seat_stock = seat_stock.cut(relief.cut(bearing))
        own_band = _ybox(outer[0]-1.0, outer[1]+1.0, ylo, yhi, zlo, zhi)
        piece = piece.fuse(seat_stock.intersect(own_band).intersect(_rounded_outer(outer)))
        if y_side == 'front':
            piece = piece.cut(_y_lip_channel(inner, y_joint, box.y_bosses))
        piece = piece.cut(_funnel_cut(inner, outer, box.pack.funnel))
        if y_side == 'front':
            piece = piece.cut(_display_cuts(outer))
    if y_side == 'front' and z_side == 'top':
        # The ceiling bearing and its corbels share the seam collar's stock.
        # Keep the insert pilots open through every contribution to that stock.
        for x_in, x_ext, sx, z_boss in box.y_bosses:
            if z_boss > z_seam:
                piece = piece.cut(_front_cuts(
                    x_in, x_ext, sx, z_boss, _y_boss(y_joint), y_joint,
                    ceiling=inner[5]))
    if y_side == "front" and z_side == "top" and plate:
        # Continue the same hardware wells through the finished part, including the
        # valve trays. Later fuses cannot leave shelves inside these common passages.
        for cutter in _tee_carrier_clearances(inner, plate, box.pack.tee_carrier):
            piece = piece.cut(cutter)
        # Flat guide openings continue through every wall, bearing body and seam feature.
        for slot in _tee_carrier_service_slots(box.pack.tee_carrier):
            piece = piece.cut(slot)
        # Add the closed circular cups after the common well/guide cutters so
        # those access volumes cannot erase their measured capture surfaces.
        for cup in _tee_carrier_fixed_cups(box.pack.tee_carrier):
            piece = piece.fuse(cup)
        piece = _front_top_flank_pockets(piece, box.pack.front_flank_reliefs)
    if y_side == "back" and z_side == "top":
        # Last on the flank: the channel is air, and no later wall feature may fill it back in.
        piece = _pan_cable_clip(piece, box, up=up)
    if z_side == "bottom":
        piece = _handholds(piece, inner, y_joint, y_side)
    if y_side == "back" and z_side == "bottom":
        disposal_field(outer)
        piece = piece.fuse(*disposal_letters(outer).Solids())
    return _unified(piece)


# --- reporting --------------------------------------------------------------

def _report_bay_sill(front_top, box):
    """Prove the stationary front sill is one uninterrupted section below the bay floor.

    The removable cartridge owns every pump-shaped opening above ``bay_floor_z``. Immediately
    below that plane the fixed wall is plain stock across the enclosure's complete rounded
    front: a pump-well cutter, clearance pocket or old jamb repeated in this band is a hole in
    the sill, not cartridge running air.
    """
    if not (box.pump_bay and box.pack.pump_trays):
        return
    outer = box.outer
    top = bay_floor_z(box.pack.pump_trays)[1]
    expected = _rounded_outer(outer).intersect(_ybox(
        outer[0] - 1.0, outer[1] + 1.0,
        outer[2] - 1.0, front_plane_y,
        top - pump_cartridge_z_clearance, top))
    missing = expected.cut(front_top.val()).Volume()
    if missing > stated_bound_tol:
        raise ValueError(
            "the fixed front sill is not one uninterrupted section immediately below the "
            f"pump bay floor: {missing:.6f} mm³ is missing")
    print(f"  bay sill:         one uninterrupted {pump_cartridge_z_clearance:g} mm "
          "witness band below the cartridge")


def _report_ridge_roof(half, box):
    """The supporting roof is planar, the finished solid valid and funnel air clear.

    Display and skirt pockets can interrupt the roof across its width.
    """
    if not (box.pump_bay and box.pack.collet_plate and box.pack.funnel):
        return
    inner, outer = box.inner, box.outer
    ry, rz = pcb_ridge(outer)
    fore, t = box.pack.collet_plate["aft_y"], ridge_wall_t
    _jog, aft_crown = _ridge_join(outer, fore)
    crown = cq.Vector(0.0, *aft_crown)
    hx0, hx1, opening_y, _hy1 = _funnel_cut_plan(box.pack.funnel)
    opening = cq.Vector(0.0, opening_y, funnel_seat_z(outer) - funnel_seat_thickness)
    roof_normal = cq.Vector(0.0, opening.z - crown.z, crown.y - opening.y).normalized()
    tol = 1e-4

    roof_faces = []
    for face in half.val().Faces():
        if face.geomType() != "PLANE":
            continue
        normal = face.normalAt()
        if (abs(abs(normal.dot(roof_normal)) - 1.0) <= tol
                and abs((face.Center() - crown).dot(roof_normal)) <= tol):
            roof_faces.append(face)

    grown = front_top_flank_t - wall
    lower_x0, lower_x1 = inner[0] + grown, inner[1] - grown

    funnel_foul = half.val().intersect(
        _funnel_keepout(outer, box.pack.funnel)).Volume()
    whole = (len(roof_faces) >= 1 and half.val().isValid()
             and funnel_foul <= stated_bound_tol)
    if not whole:
        raise ValueError(
            "the front-top ridge roof is not one clear plane between its stated datums: "
            f"found {len(roof_faces)} coplanar faces, solid valid={half.val().isValid()}, "
            f"funnel keepout intersection {funnel_foul:.6f} mm³")
    print(f"  ridge roof:       {len(roof_faces)} coplanar faces, {lower_x1 - lower_x0:.1f} mm span to "
          f"{hx1 - hx0:.1f} mm funnel opening, keepout clear")


def _report_facet(half, box):
    a = math.radians(display_facet_angle_deg)
    target = cq.Vector(0.0, -math.sin(a), math.cos(a))
    # The lip's +Z bevel ramp shares this normal (excluded by the front-region
    # y filter) and the pod's east shoulder shares it one wall lower (excluded
    # by the on-plane filter) — only the display facet itself is measured.
    outer = box.outer
    _a, _n, origin, dy, _dz = _facet_geom(outer)
    y_hi = outer[2] + dy + 5.0
    boxes = []
    for f in half.val().Faces():
        try:
            n = f.normalAt()
        except Exception:
            continue
        c = f.Center()
        off = (c - cq.Vector(*origin)).dot(target)
        if (n - target).Length < 1e-3 and c.y < y_hi and abs(off) < 1e-3:
            boxes.append(f.BoundingBox())
    if not boxes:
        print("  display facet:    NOT FOUND")
        return
    xspan = max(b.xmax for b in boxes) - min(b.xmin for b in boxes)
    slope = (max(b.ymax for b in boxes) - min(b.ymin for b in boxes)) / math.cos(a)
    want_x = outer[1] - outer[0] - 2.0 * _swept_top.SIDE_RADIUS
    print(f"  display facet:    {xspan:.1f} mm wide (X) × {slope:.1f} mm slope, solid surface "
          f"(want {want_x:g} × {display_facet_slope:g}; the display window is "
          f"{display_facet_x:g} × {display_facet_slope:g}, centred at "
          f"x {display_centre_x(outer):g})")


def _report_split(pieces, core=None):
    for name, p in pieces.items():
        b = p.val().BoundingBox()
        fits = b.xlen <= H2C_X + 1 and b.ylen <= H2C_Y + 1 and b.zlen <= H2C_Z + 1
        print(f"  {name + ':':14s} X {b.xlen:5.0f} × Y {b.ylen:5.0f} × Z {b.zlen:5.0f} mm  "
              f"(Y[{b.ymin:.0f},{b.ymax:.0f}] Z[{b.zmin:.0f},{b.zmax:.0f}])  "
              f"H2C bed: {'fits' if fits else 'OVER'}")
    names = list(pieces)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            v = pieces[a].val().intersect(pieces[b].val()).Volume()
            tag = "CLEAR slip-fit" if v < 5 else "INTERFERENCE"
            print(f"  {a} ∩ {b}: {v:.1f} mm³  ({tag})")
    if core is not None:
        clash = max(core.intersect(p.val()).Volume() for p in pieces.values())
        print(f"  cold core vs pieces: {clash:.1f} mm³ max overlap  "
              f"({'CLEAR' if clash < 1 else 'CLASH'})")


def _report_seams(box):
    """Each Z seam's height, whether it landed in a band its own column left open or
    runs through that column on a clear lip, and the band the bed allowed it."""
    lo, hi = _bed_band(box.inner)
    for col, zj, crosses in zip(("front", "back"), box.splits, box.z_seam_passes):
        how = "runs through its column" if crosses else "in an open band"
        print(f"  Z seam {col + ':':7s} {zj:6.1f} mm  ({how}; the bed allows "
              f"{lo:.1f}..{hi:.1f})")


def _report_levels(box):
    """The Y-seam cross-pin heights each ±X wall ended up with. They are searched
    per wall against what stands against it, so the two can differ — printing
    them keeps a wall that had to give up a level visible instead of silent."""
    bosses = box.y_bosses
    for sx, label in ((+1.0, "−X"), (-1.0, "+X")):
        zs = sorted(z for _xi, _xe, s, z in bosses if s == sx)
        print(f"  Y-seam levels {label} wall: {len(zs)} — "
              + ", ".join(f"{z:.0f}" for z in zs))


def _report_slide(pieces, box):
    """Each column's slide, PROVED on the built pieces: the top swept from entry to home
    against its bottom piece, and lifted off its catch at home.

    THE SWEEP IS THE CLAIM. A slide the length of a column is clear only if every station
    of the travel is, so the top piece is intersected with its bottom at a ladder of
    displacements from full entry down to home, dense where the joint closes — contested
    volume at every rung is the reading and 0 is the only passing figure. LIFTED a
    millimetre off home, the hooks are what has to answer: the contested volume IS the
    catch engaging, and 0 there is a top that lifts straight off. Both go in `BOUNDS`,
    so the scorecard carries the slide the way it carries every other claim."""
    out = {}
    for col, names in (("front", ("front-top", "front-bottom")),
                       ("back", ("back-top", "back-bottom"))):
        if names[0] not in pieces or names[1] not in pieces:
            continue
        plate = box.pack.collet_plate if (box.pump_bay and box.pack.collet_plate) else None
        travel = _z_rail_travel(box.inner, box.y_joint, col, plate, box.pack.vent_chase)
        # AND IT ENTERS FROM THE SIDE THIS COLUMN ENTERS FROM. The two columns are mirrored,
        # so a displacement that is entry on one is a piece driven past home on the other.
        _runs = _z_rail_runs(box.inner, box.y_joint, col, plate, box.pack.vent_chase)
        dy = 1.0 if _runs[0][3] > _runs[0][2] else -1.0
        top, bot = pieces[names[0]].val(), pieces[names[1]].val()
        rungs = [d for d in (0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0) if d < travel]
        d = 24.0
        while d < travel:
            rungs.append(d)
            d += 16.0
        rungs.append(travel)
        worst = (0.0, 0.0)
        for d in rungs:
            v = top.translate(cq.Vector(0.0, -dy * d, 0.0)).intersect(bot).Volume()
            if v > worst[0]:
                worst = (v, d)
        clear = worst[0] <= 1.0
        record_bound(Bound(
            f"z-slide-{col}-clear",
            f"The {col} top slides its whole travel onto its bottom clear", clear,
            f"worst {worst[0]:.1f} mm³ contested, {worst[1]:.2f} mm out of home, "
            f"{len(rungs)} stations over {travel:.1f} mm",
            "0 mm³ at every station",
            ([] if clear else [
                f"the {col} column's slide is blocked {worst[1]:.2f} mm out of home — "
                f"{worst[0]:.1f} mm³ of the two pieces contest the lane. Something grew "
                f"into the channel after the rail was drawn; the channel cut runs last, "
                f"so look for material fused after it or a bottom-piece feature standing "
                f"proud of the mouth outside the lip's own runs"])))
        lift = top.translate(cq.Vector(0.0, 0.0, 1.0)).intersect(bot)
        lifted = lift.Volume()
        # AND IT IS READ ON EACH FLANK, because a column caught on one of them reads as a
        # column caught: the runs are down both ±X sides and one of them answering for the
        # whole seam is the reading a single figure cannot tell from two.
        ox0, ox1, oy0, oy1, oz0, oz1 = box.outer
        flanks = {
            side: lift.intersect(_ybox(fx0, fx1, oy0 - 1.0, oy1 + 1.0,
                                       oz0 - 1.0, oz1 + 1.0)).Volume()
            for side, (fx0, fx1) in (("west", (ox0 - 1.0, 0.0)), ("east", (0.0, ox1 + 1.0)))}
        least = min(flanks.values())
        caught = lifted > 5.0 and least > 5.0
        record_bound(Bound(
            f"z-slide-{col}-catch",
            f"The {col} top's rails catch it against a lift, on both flanks", caught,
            f"{lifted:.1f} mm³ engaged at a 1 mm lift — "
            f"{flanks['west']:.1f} west, {flanks['east']:.1f} east",
            "the hooks bearing down both flanks, so more than 5 mm³ on each",
            ([] if caught else [
                f"lifted 1 mm off home, the {col} top contests {flanks['west']:.1f} mm³ on "
                f"its west flank and {flanks['east']:.1f} mm³ on its east — a flank reading "
                f"nothing has no foot over its head, so that run is a rail the other piece "
                f"never entered. Read the channel cuts that run last on the top piece "
                f"(`_z_rail_channels`) against the runs `_z_rail_runs` "
                f"gives that flank, and `_rail_hook_lap` against both"])))
        foot_depths = [abs(_rail_foot_face(x_in, sx, col) - x_in)
                       for x_in, sx, _y0, _y1, _lane in _runs]
        rail_depths = [abs(_rail_x(x_in, sx, col)[3] - x_in)
                       for x_in, sx, _y0, _y1, _lane in _runs]
        catch_depths = [_rail_hook_lap(col) for _run in _runs]
        channel_skins = [
            wall + abs((_rail_x(x_in, sx, col)[0] - sx * slide_slip) - x_in)
            for x_in, sx, _y0, _y1, _lane in _runs]
        top_flank_t = front_top_flank_t if col == "front" else back_top_flank_t
        bottom_flank_t = front_bottom_flank_t if col == "front" else back_bottom_flank_t
        expected_lap = front_hook_lap if col == "front" else back_hook_lap
        nominal = top_flank_t - wall
        full_feet = (len(foot_depths) == 2
                     and all(abs(depth - nominal) <= stated_bound_tol
                             for depth in foot_depths)
                     and max(rail_depths) <= side_band_inset + stated_bound_tol)
        record_bound(Bound(
            f"z-slide-{col}-foot-section",
            f"Both {col}-top slide feet carry the nominal flank section to the seam",
            full_feet,
            f"{foot_depths[0]:.2f} mm west, {foot_depths[1]:.2f} mm east; "
            f"arm reaches {max(rail_depths):.2f} mm into a {side_band_inset:g} mm band",
            f"{nominal:.2f} mm inward of interior_x on both flanks, rail inside its band",
            ([] if full_feet else [
                f"the {col} feet reach {foot_depths}, but a {top_flank_t:g} mm wall needs "
                f"{nominal:.2f} mm past `interior_x`. Carry the nominal wall section to "
                f"the foot's face and place the hook and arm at its inboard edge"])))
        full_catches = (
            len(catch_depths) == 2
            and all(abs(depth - expected_lap) <= stated_bound_tol
                    for depth in catch_depths)
            and min(channel_skins) >= wall - stated_bound_tol)
        record_bound(Bound(
            f"z-slide-{col}-catch-section",
            f"Both {col}-bottom heads spend the grown flank section on their catches",
            full_catches,
            f"{catch_depths[0]:.2f} mm west, {catch_depths[1]:.2f} mm east; "
            f"least outer skin {min(channel_skins):.2f} mm",
            f"{expected_lap:.2f} mm overlap on both flanks and at least "
            f"{wall:.2f} mm outside the channel",
            ([] if full_catches else [
                f"the {col} catches reach {catch_depths} and leave outer skins "
                f"{channel_skins}. Carry the {bottom_flank_t - 2.0 * wall:.2f} mm grown "
                f"past the lip wall into the hook while keeping one full wall outside "
                f"its channel"])))
        if col == "back":
            # THE CATCH IS A PAIR OF BROAD PLANES, NOT MERELY TWO SOLIDS WHICH COLLIDE
            # WHEN LIFTED. A ridge in a groove passes the engagement-volume reading above while
            # replacing the rail's bearing with two cams. Read the finished B-reps at the two
            # stated bearing planes and require most of the nominal full-width run on each piece.
            def flat_bearing_area(solid, z, normal_z, top_side):
                area = 0.0
                tol = 1e-3
                for face in solid.Faces():
                    if face.geomType() != "PLANE":
                        continue
                    normal = face.normalAt()
                    bounds = face.BoundingBox()
                    if (abs(normal.x) > tol or abs(normal.y) > tol
                            or normal.z * normal_z < 1.0 - tol
                            or abs(bounds.zmin - z) > tol or abs(bounds.zmax - z) > tol):
                        continue
                    centre = face.Center()
                    for x_in, sx, y0, y1, _lane in _runs:
                        sy = 1.0 if y1 > y0 else -1.0
                        stop = y1 - sy * rail_stop_len
                        x_hk, x_f, x_a, _x_h1 = _rail_x(x_in, sx, col)
                        x_other = x_hk - sx * slide_slip if top_side else x_a
                        xa, xb = sorted((x_f if top_side else x_hk, x_other))
                        ya, yb = sorted((y0, stop))
                        if (xa - tol <= centre.x <= xb + tol
                                and ya - tol <= centre.y <= yb + tol):
                            area += face.Area()
                            break
                return area

            z_foot = box.splits[1] + hook_foot
            bottom_flat = flat_bearing_area(
                bot, z_foot + rail_catch_air(col), -1.0, False)
            top_flat = flat_bearing_area(top, z_foot, +1.0, True)
            nominal_flat = sum(
                (abs(y1 - y0) - rail_stop_len) * (_rail_hook_lap(col) + slide_slip)
                for _x_in, _sx, y0, y1, _lane in _runs)
            required_flat = 0.85 * nominal_flat
            if min(bottom_flat, top_flat) < required_flat:
                raise ValueError(
                    "the back Z-slide catch is not two broad horizontal bearing planes: "
                    f"bottom {bottom_flat:.1f} mm², top {top_flat:.1f} mm², "
                    f"each requires at least {required_flat:.1f} mm². Restore the square "
                    "head underside and square foot top; support those functional faces.")
            print(f"    flat bearings:  {bottom_flat:.1f} mm² bottom, "
                  f"{top_flat:.1f} mm² top (minimum {required_flat:.1f} each)")

            # THE CHANNEL ROOF IS FLAT TOO. Checking the source profile is not enough: a
            # later cut or fuse can split away most of the plane while leaving its two end
            # points unchanged. Read the finished back-top B-rep at the stated roof level.
            # The area gate proves that the complete MATERIAL-BACKED span is present, not
            # merely a short land. The cutter continues inboard from `x_f` to `x_d`, but that
            # side is already machine-interior air and cannot be a face without adding a
            # purposeless shelf.
            z_roof = box.splits[1] + z_rise + slide_slip
            roof_flat = 0.0
            tol = 1e-3
            for face in top.Faces():
                if face.geomType() != "PLANE":
                    continue
                normal = face.normalAt()
                bounds = face.BoundingBox()
                if (abs(normal.x) > tol or abs(normal.y) > tol or normal.z > -1.0 + tol
                        or abs(bounds.zmin - z_roof) > tol
                        or abs(bounds.zmax - z_roof) > tol):
                    continue
                centre = face.Center()
                for x_in, sx, y0, y1, _lane in _runs:
                    sy = 1.0 if y1 > y0 else -1.0
                    stop = y1 - sy * rail_stop_len
                    x_open, x_f, _x_d = _rail_channel_span(x_in, sx, col)
                    xa, xb = sorted((x_open, x_f))
                    ya, yb = sorted((y0, stop))
                    if (xa - tol <= centre.x <= xb + tol
                            and ya - tol <= centre.y <= yb + tol):
                        roof_flat += face.Area()
                        break
            nominal_roof = sum(
                (abs(y1 - y0) - rail_stop_len)
                * abs(_rail_channel_span(x_in, sx, col)[1]
                      - _rail_channel_span(x_in, sx, col)[0])
                for x_in, sx, y0, y1, _lane in _runs)
            required_roof = 0.85 * nominal_roof
            if roof_flat < required_roof:
                raise ValueError(
                    "the back Z-slide channel does not have a broad horizontal roof: "
                    f"found {roof_flat:.1f} mm² at z={z_roof:.2f}, requires at least "
                    f"{required_roof:.1f} mm². The channel ceiling is one flat plane "
                    "carried by slicer support.")
            print(f"    flat channel roof: {roof_flat:.1f} mm² "
                  f"(minimum {required_roof:.1f})")
        out[col] = (worst, travel, len(rungs), lifted)
        print(f"  Z slide {col + ':':7s} travel {travel:6.1f} mm, worst contested "
              f"{worst[0]:6.1f} mm³ at {worst[1]:.2f} mm out; catch {lifted:8.1f} mm³ "
              f"at a 1 mm lift")
    return out


def _upper_y_seam_bound(pieces, box):
    """The finished upper corner blocks, their screw bores and their complete entry sweeps."""
    front = pieces["front-top"].val()
    back = pieces["back-top"].val()
    stations = [row for row in box.y_bosses if row[3] > z_seam]
    y0, y1 = _y_corner_back(box.inner[3], box.y_joint)
    yb = _y_boss(box.y_joint)
    readings = []
    for x_in, x_ext, sx, z in stations:
        _seat, x_tip, x_heat, _cap = _boss_x(x_ext, sx)
        xa, xb = sorted((x_ext, x_tip))
        floor = z - plug_dia / 2.0
        crown = z + plug_dia / 2.0
        column = _ybox(xa, xb, y0, y1, crown, box.inner[5] + wall / 2.0)
        column = column.intersect(_rounded_outer(box.outer))
        missing = column.cut(back).Volume()
        sweep = _ybox(xa, xb, y0, y1 + lip_len, floor, box.inner[5] + wall)
        contested = sweep.intersect(front).Volume()
        ramp = _xz_prism(y0, y1, [
            (x_in, floor), (x_tip, floor), (x_in, floor - abs(x_tip - x_in))])
        below = ramp.intersect(back).Volume()
        shank = _xcyl(screw_clear_dia / 2.0, yb, z, x_ext, x_tip)
        insert = _xcyl(heatset_dia / 2.0, yb, z, x_tip, x_heat)
        bore = shank.intersect(back).Volume() + insert.intersect(front).Volume()
        readings.append(("west" if sx > 0 else "east", missing, contested, below, bore))
    ok = len(readings) == 2 and all(
        max(values) <= stated_bound_tol for _side, *values in readings)
    return record_bound(Bound(
        "y-seam-upper",
        "Both upper seam blocks join the ceiling and pass their complete entry lanes",
        ok,
        f"{sum(max(row[1:]) <= stated_bound_tol for row in readings)}/2 corners clear",
        "two complete ceiling columns, flat lower ends, open screw pilots and clear swept slots",
        [f"{side}: missing column {missing:.4f} mm³; entry overlap {contested:.4f} mm³; "
         f"material below the flat end {below:.4f} mm³; blocked bores {bore:.4f} mm³"
         for side, missing, contested, below, bore in readings]))


def _lower_y_seam_bound(pieces, box):
    """Both jambs above the handholds, four screw stations and their entry passages."""
    front = pieces["front-bottom"].val()
    back = pieces["back-bottom"].val()
    y0, y1 = _y_corner_back(box.inner[3], box.y_joint)
    yb = _y_boss(box.y_joint)
    levels = (_seam_lower_z(box.inner), _seam_middle_z())
    _bed, grip_roof, _crown = _handhold_levels(box.inner)
    readings = []
    for x_in, sx in ((box.inner[0], 1.0), (box.inner[1], -1.0)):
        x_ext = x_in - sx * wall
        _seat, x_tip, x_heat, x_cap = _boss_x(x_ext, sx)
        stations = [z for xi, _xe, s, z in box.y_bosses
                    if xi == x_in and s == sx and z < z_seam]
        xa, xb = sorted((x_ext, x_tip))
        crown = levels[-1] + plug_dia / 2.0
        column = _ybox(xa, xb, y0, y1, grip_roof + handhold_edge_r, crown)
        sweep = _ybox(xa, xb, y0, y1 + lip_len, grip_roof + handhold_edge_r, z_seam)
        xa, xb = sorted((x_tip, x_cap))
        socket = _ybox(xa, xb, yb - socket_r, yb + socket_r, grip_roof, z_seam)
        blocked = 0.0
        for z in levels:
            column = column.cut(_screw_cut(x_ext, sx, z, yb))
            heat = _xcyl(heatset_dia / 2.0, yb, z, x_tip, x_heat)
            socket = socket.cut(_supported_cut(heat))
            shank = _xcyl(screw_clear_dia / 2.0, yb, z, x_ext, x_tip)
            blocked += shank.intersect(back).Volume() + heat.intersect(front).Volume()
        missing = column.cut(back).Volume() + socket.cut(front).Volume()
        overlap = sweep.intersect(front).Volume()
        levels_ok = len(stations) == 2 and all(
            abs(actual - wanted) < stated_bound_tol for actual, wanted in zip(stations, levels))
        readings.append(("west" if sx > 0 else "east", levels_ok, missing, overlap, blocked))
    floor_lane = _ybox(box.inner[0], box.inner[1], y0, box.y_joint + lip_len,
                       box.outer[4], box.inner[4])
    floor_register = front.intersect(floor_lane).intersect(
        back.intersect(floor_lane).translate((0, 0, 2.0 * fits.running))).Volume()
    ok = floor_register > stated_bound_tol and all(
             levels_ok and max(missing, overlap, blocked) <= stated_bound_tol
             for _side, levels_ok, missing, overlap, blocked in readings)
    return record_bound(Bound(
        "y-seam-lower",
        "Both lower seam jambs join the handhold roofs and carry complete lower and middle fasteners",
        ok,
        f"four screw axes at Z {levels[0]:g} and {levels[1]:g} mm; middle collars end at Z {z_seam:g}",
        "two jambs above the handholds, four open screw pilots, passages open through the rim, and a registering floor lap",
        [f"{side}: levels {'correct' if levels_ok else 'incorrect'}; missing jamb {missing:.4f} mm³; "
         f"entry overlap {overlap:.4f} mm³; blocked bores {blocked:.4f} mm³"
         for side, levels_ok, missing, overlap, blocked in readings] + [
            f"floor lap blocks a {2.0 * fits.running:g} mm upward shift: {floor_register:.4f} mm³ overlap"]))


def _handhold_bound(pieces, box):
    """Clear upward entry, complete lifting sections and inner walls with only the seam fit."""
    front = pieces["front-bottom"].val()
    back = pieces["back-bottom"].val()
    inner, joint = box.inner, box.y_joint
    bed, roof, crown = _handhold_levels(inner)
    y0, y1 = _handhold_y()
    readings = []

    def missing(shape):
        return shape.cut(front).cut(back)

    for xi, sx in ((inner[0], 1.0), (inner[1], -1.0)):
        xe = xi - sx * wall
        _seat, tip, _heat, cap = _boss_x(xe, sx)
        face = cap - sx * handhold_wall
        tangent = xe + sx * handhold_edge_r
        xa, xb = sorted((face, xe - sx))
        entry = _ybox(xa, xb, y0 + handhold_corner_r, y1 - handhold_corner_r, bed - 1.0, roof)
        blocked = entry.intersect(front).Volume() + entry.intersect(back).Volume()

        xa, xb = sorted((cap, face))
        backing = _ybox(xa, xb, y0, y1, bed, roof)
        seam_air = _handhold_backing_lap(inner, joint, xe, sx, "front").cut(
            _handhold_backing_lap(inner, joint, xe, sx, "back"))
        wall_missing = missing(backing).cut(seam_air).Volume()

        xa, xb = sorted((face, tangent))
        bearing = _ybox(xa, xb, y0 + handhold_corner_r, y1 - handhold_corner_r, roof, crown)
        xa, xb = sorted((tip, cap + sx * fits.running))
        socket_air = _ybox(xa, xb, joint + lip_len, joint + lip_len + fits.running, roof, crown)
        roof_missing = missing(bearing).cut(socket_air).Volume()
        xa, xb = sorted((cap, tangent))
        posts = _ybox(xa, xb, y0 - handhold_wall, y0, bed, crown).fuse(
            _ybox(xa, xb, y1, y1 + handhold_wall, bed, crown))
        post_missing = missing(posts).Volume()
        readings.append(("west" if sx > 0 else "east", blocked, wall_missing,
                         roof_missing, post_missing))
    ok = len(readings) == 2 and all(max(row[1:]) <= stated_bound_tol for row in readings)
    return record_bound(Bound(
        "handholds",
        "Both handholds open through the floor and keep their lifting sections and inner walls",
        ok,
        f"two {handhold_length:g} × {handhold_height:g} mm bottom openings at Y {handhold_y:g}",
        f"clear upward entry, {handhold_wall:g} mm inner walls, {handhold_roof:g} mm roofs and complete end posts",
        [f"{side}: blocked entry {blocked:.4f} mm³; missing inner wall {wall_missing:.4f} mm³; "
         f"missing roof {roof_missing:.4f} mm³; missing end posts {post_missing:.4f} mm³"
         for side, blocked, wall_missing, roof_missing, post_missing in readings]))


def _ceiling_show_cap_bound(back_top, box):
    """Record the complete exterior cap over back-top's whole ceiling field.

    The field is the slab's plan less the funnel's own plan, and what is asked of it is one `wall`
    of stock from the show face down, everywhere. Testing the finished piece catches any later
    cutter that turns a pocket into an opening through the face the piece prints on."""
    solid = back_top.val() if hasattr(back_top, "val") else back_top
    fx0, fx1 = back_top_flank_face()
    show = appliance_height - floor_t
    cap = _ybox(fx0, fx1, back_flank_start(box.y_joint), back_top_wall_face(), show - wall, show)
    if box.pack.funnel:
        cap = cap.cut(_funnel_cut(box.inner, box.outer, box.pack.funnel))
    missing = abs(cap.cut(solid).Volume())
    ok = missing <= stated_bound_tol
    return record_bound(Bound(
        "ceiling-show-cap",
        "The ceiling slab keeps a complete exterior wall over its whole field",
        ok,
        f"{wall:g} mm cap; missing {missing:.4f} mm³",
        "a complete wall over the field, the funnel's own plan excepted",
        ([] if ok else [
            "the finished back-top has lost show-face stock over its ceiling; inspect every "
            "cutter applied after `_back_top_ceiling` and keep every pocket under the lane"])))


def _silhouette_bound(pieces, box):
    """Record that every quadrant wall lies inside the box's own exterior.

    `build_piece` clips each piece to the rounded silhouette before it fuses its furniture, so a
    feature fused after that clip and drawn past a face of the box would stand outside the
    machine. The integral disposal lettering stands `disposal_raise` off the rear
    wall; subtracting only those letters leaves the wall subject to the same bound."""
    ox0, ox1, oy0, oy1, oz0, oz1 = box.outer
    over = []
    for name, piece in pieces.items():
        if name in ("pump-cartridge", "pump-cap"):
            continue
        solid = piece.val()
        if name == "back-bottom":
            solid = solid.cut(disposal_letters(box.outer))
        b = solid.BoundingBox()
        for label, got, limit, sign in (("-X", b.xmin, ox0, -1.0), ("+X", b.xmax, ox1, 1.0),
                                        ("-Y", b.ymin, oy0, -1.0), ("+Y", b.ymax, oy1, 1.0),
                                        ("-Z", b.zmin, oz0, -1.0), ("+Z", b.zmax, oz1, 1.0)):
            excess = sign * (got - limit)
            if excess > stated_bound_tol:
                over.append(f"{name} {label} by {excess:.3f} mm")
    ok = not over
    return record_bound(Bound(
        "pieces-in-silhouette",
        "Every quadrant wall lies inside the machine's exterior; only the disposal letters stand proud",
        ok,
        f"walls inside `outer`; disposal letters raised {disposal_raise:g} mm" if ok else "; ".join(over),
        "only the disposal letters extend past the box's exterior",
        ([] if ok else [
            "a feature fused after the silhouette clip stands outside the box; bound it to the "
            "interior lane or the wall it roots on"])))


def build_pieces(box):
    """The printable pieces of one box — the four quadrants and, when the pack stands
    pumps, the pump cartridge that slides out of the front pair — and the assembly of them in
    place with the seams intact.

    DRAWING A PIECE TAKES NO READING. Every bound the box states is in the ledger before this
    runs — `_dims` states its own as it sizes the shells, `with_funnel` states the throat's as
    it seats the centre — so the four pieces are a pure function of the Box and a piece handed
    back unbuilt is a piece nothing on the card was waiting for. That is what lets `_realized`
    keep them: a build that moves a body inside the walls moves neither the box, which is its
    stated size, nor the code that cuts it, and a station moves only when the body carrying it
    does."""
    _last_box[0] = box
    cache = {}

    def _product(n):
        if n == "pump-cartridge":
            return build_pump_cartridge(box, halves_cache=cache)
        if n == "pump-cap":
            return build_pump_cap(box, halves_cache=cache)
        return build_piece(box, *n.split("-"), halves_cache=cache)

    names = [n for n in PIECE_COLORS
             if n not in ("pump-cartridge", "pump-cap")
             or (box.pump_bay and box.pack.collet_plate)]
    pieces = {name: _realized.realized(
                  _realized.key(__name__, box, name),
                  lambda n=name: _product(n))
              for name in names}
    disconnected = [f"{name}: {len(piece.val().Solids())} solids"
                    for name, piece in pieces.items()
                    if len(piece.val().Solids()) != 1 or not piece.val().isValid()]
    record_bound(Bound(
        "connected-pieces", "Each printed enclosure piece is one valid connected solid",
        not disconnected, "; ".join(disconnected) if disconnected else f"{len(pieces)} connected pieces",
        "one valid solid per printed piece", disconnected))
    if "back-top" in pieces:
        _ceiling_show_cap_bound(pieces["back-top"], box)
    if "front-top" in pieces and "back-top" in pieces:
        _upper_y_seam_bound(pieces, box)
    if "front-bottom" in pieces and "back-bottom" in pieces:
        _lower_y_seam_bound(pieces, box)
        _handhold_bound(pieces, box)
    _silhouette_bound(pieces, box)
    assy = cq.Assembly(name="enclosure")
    for name, piece in pieces.items():
        assy.add(piece, name=f"enclosure-{name}".replace("-", "_"),
                 color=PIECE_COLORS[name])
    return pieces, assy


# HOW FINELY A PIECE IS TESSELLATED FOR THE BED. The show surface is fluted now, so the mesh a
# slicer reads has to hold a curve the nozzle can draw: the deviation allowed is a fraction of
# the 0.42 mm bead, and the angle is tight enough that a groove's own arc does not come back as
# a few flats. It costs file size and nothing else — a slicer reads the triangles once.
piece_mesh_tol = 0.005
piece_mesh_angle = 0.05


# The box the pieces were last drawn from, so `_export_pieces` can strike the flute field on the
# same rails they were clipped to without being handed it through three call sites.
_last_box = [None]


def _piece_mesh(solid):
    """Absolute-tolerance print mesh, without any cached triangulation."""
    from _world_sdf import mesh_shape
    points, triangles = mesh_shape(solid.copy(mesh=False), piece_mesh_tol, piece_mesh_angle)
    mesh = trimesh.Trimesh(vertices=points, faces=triangles, process=True)
    mesh.merge_vertices()
    return mesh


def _collet_plate_body(plate):
    """The collet plate's unperforated envelope for the flute shadow mask.

    The plate is printed into front-top. Its envelope marks the tee wall behind it as
    a bearing face, keeping that band out of the show-surface flutes."""
    return _xz_prism(plate["fore_y"], plate["aft_y"], plate_outline(plate))


def _export_pieces(pieces, assy):
    refused = []
    box = _last_box[0]
    outer = box.outer
    # Every assembly piece is meshed once. The plate's envelope also contributes a
    # shadow mask over the bearing band behind the integral release face.
    bodies = {name: _piece_mesh(piece.val()) for name, piece in pieces.items()}
    steel = ([_piece_mesh(_collet_plate_body(box.pack.collet_plate))]
             if box.pack.collet_plate else [])
    for name, piece in pieces.items():
        export_assembly(one_body(piece, f"enclosure-{name}", PIECE_COLORS[name]),
                        str(_here.parent / f"enclosure-{name}.step"))
        print(f"-> enclosure-{name}.step")
        # AND THE SHOW SURFACES ARE FLUTED HERE, in the mesh, on the way to the bed. See
        # `flute_skin.py` for why they are not in the solid.
        berthed = [m for other, m in bodies.items() if other != name] + steel
        rails = flute_rails(box, berthed)
        # The top clamp is an interior mechanical part and carries no show field. The
        # full-width cradle owns the flush front face and both outer flanks: its front rail
        # carries the face and front corners, while the enclosure-phase side rail starts at
        # their tangencies. No rail is struck on the fixed front plane inside it.
        if name == "pump-cap":
            rails = []
        elif name == "pump-cartridge":
            rails = [_pump_cartridge_side_flute_rail(outer),
                     _pump_cartridge_front_flute_rail(outer)]
        mesh = _flute_skin.flute(bodies[name], rails,
                                 flute_pitch(outer), flute_depth, flute_rise)
        if name == "back-bottom":
            # The flute cutter closes outside the wall even where its depth is zero.
            # Carry the raised outlines onto the finished smooth field after that cut.
            letters = _piece_mesh(disposal_letters(outer))
            mesh = trimesh.boolean.union(
                [_flute_skin.as_written(mesh), _flute_skin.as_written(letters)],
                engine="manifold", check_volume=False)
            mesh = trimesh.boolean.union(
                [_flute_skin.as_written(mesh)], engine="manifold", check_volume=False)
        # WHAT IS CHECKED IS WHAT COMES OUT. A piece tessellates with a handful of edges
        # carrying four faces rather than two — the solid touching itself along a line, which is
        # a fact about the solid — and refusing the cut for it would refuse every piece. The
        # engine takes that and repairs it; a mesh that is still not closed after it is one no
        # slicer should be handed.
        # WHAT IS CHECKED IS WHAT A SLICER REFUSES. `is_watertight` is the easier question and
        # a mesh can pass it while Bambu Studio rejects the file outright: winding can close
        # over an edge that four faces share. This asks the harder one, because these meshes go
        # in the release bundle and out to a bed.
        stl = _here.parent / f"enclosure-{name}.stl"
        mesh.export(str(stl))
        # AND THE READING IS TAKEN OFF THE FILE, re-read the way a slicer reads it. Everything
        # before this is in memory and in double precision; what goes to the bed is neither.
        written = trimesh.load_mesh(str(stl))
        loose = _flute_skin.non_manifold_edges(written)
        if loose or not written.is_watertight:
            # EVERY PIECE IS STILL WRITTEN, and the build still fails. A piece that comes back
            # refusable says nothing about the five beside it, and raising on the first one
            # withholds five good files over a sixth — including, on the day this was written,
            # the one piece somebody was waiting to print.
            refused.append(
                f"enclosure-{name}.stl: {loose} non-manifold edge(s), watertight="
                f"{written.is_watertight}, over {len(written.faces)} facets")
        print(f"-> enclosure-{name}.stl  ({len(mesh.faces)} facets, "
              f"{'watertight' if mesh.is_watertight else 'NOT WATERTIGHT'})")
    export_assembly(assy, str(_here.parent / "enclosure.step"))
    print("-> enclosure.step (assembled pieces)")
    if refused:
        raise ValueError(
            "meshes a slicer refuses, read back off the file and merged by position the way a "
            "slicer reads one:\n    " + "\n    ".join(refused))


def stated_box(pack):
    """The box at `appliance_width` × `rear_plane_y` × `appliance_height`, with `pack` measured
    against it — the description `build_pieces` turns into the four printable pieces.

    THE PACK DOES NOT SIZE IT. Where the bodies stand decides what `_dims` puts in `BOUNDS`,
    and a pack that reaches past a wall gets that wall drawn through it, a red row saying by
    how much, and a clash in `pack-closes` at the body that overran. Moving a body moves the
    reading, never the wall."""
    return _dims(pack)


def machine_of():
    """The cold core, when directly derived, and the box around the placed machine.

    A build action receives the exact output of `enclosure_box.py`, which derives the pack once
    for the enclosure producer. It needs no core: the standalone overlap report is diagnostic
    output, not part of a wall's geometry. A direct design run derives the live pack and reports
    against its placed core; it never accepts a potentially old description from the source tree.

    Imported here rather than at module scope so that enclosure_assembly, which builds its
    own assembly around these walls, is not importing a module that is importing it back."""
    import _box_spec

    if _box_spec.in_action():
        box, bounds = _box_spec.read(Box, Bound, (Pack, PortField, Nameplate))
        BOUNDS[:] = bounds
        return None, box
    sys.path.insert(0, str(_repo / "hardware" / "manifold-layout"))
    import enclosure_assembly
    _assy, pack, box = enclosure_assembly.machine()
    return pack.placed["foam-assembly"][0], box


def _report_columns(box):
    """Each standing corner's column, and what it gave up to the pack standing in it.

    A relief is a decision the pack made for the box, so it is printed rather than assumed:
    a column quietly hollowed over most of its height is one to look at."""
    for sx, sy in column_corners:
        label = f"{'X-' if sx < 0 else 'X+'}/{'Y-' if sy < 0 else 'Y+'}"
        gave = [(n, r) for csx, csy, n, r in box.column_reliefs if (csx, csy) == (sx, sy)]
        if not gave:
            print(f"  column {label}:   whole")
            continue
        print(f"  column {label}:   relieved for " +
              ", ".join(f"{n} (z {r[4]:.1f}..{r[5]:.1f})" for n, r in gave))


def _report_bounds():
    """Every bound in the ledger that is open, and nothing when they all hold.

    The card `enclosure_assembly` writes is the committed account of these; this is the same
    reading for whoever ran this module on its own, where there is no card."""
    open_ = [b for b in BOUNDS if not b.ok]
    if not open_:
        return
    print(f"\n{len(open_)} of {len(BOUNDS)} bounds open — the box is drawn at its stated size "
          f"anyway, so the overrun is in the pieces:")
    for b in open_:
        print(f"  {b.id}: {b.value}   (wants {b.target})")
        for line in b.detail:
            print(f"    {line}")
    print()


def main():
    core, box = machine_of()
    pieces, assy = build_pieces(box)
    print("enclosure:")
    _report_bay_sill(pieces["front-top"], box)
    _report_ridge_roof(pieces["front-top"], box)
    _report_slide(pieces, box)     # the slides swept and the catches lifted, into BOUNDS
    _report_bounds()          # the machine's, with its pieces cut and its slides swept

    _export_pieces(pieces, assy)

    _report_columns(box)
    _report_facet(pieces["front-top"], box)
    _report_seams(box)
    _report_levels(box)
    _report_split(pieces, core)

    bo = box.outer
    # The loops this box's ribs close, read off the seats the pack actually bored. Every rib
    # holding a RUN is bored for the one stock; the ribs holding a BODY are bored for whatever
    # section that body offers, so the radii are as many as the pack has kinds of seat. The
    # smallest is the runs' own and the largest is the widest body's, and a zip tie cut to the
    # largest closes on every one of them — which is what the table quotes.
    seats = sorted({round(s[3], 6) for s in (box.pack.tube_anchors or ())})
    if not seats:
        raise ValueError(
            "the box bores no tube anchor at all, and the zip tie table quotes a loop for them. "
            "Either the pack stands a rib again or the table stops reading one.")
    # And the meter's, off the one station its two anchors are struck from. A flow-meter anchor
    # reaches `flow_meter_anchor_wall` off the arm's axis where a rib reaches `wall`, and both are
    # the box's own three millimetres, so the hull is the same figure of the seat and one function
    # reads both families.
    meter = box.pack.flow_meter_anchors
    if not meter:
        raise ValueError(
            "the box hangs no flow-meter anchor, and the zip tie table quotes the loop one closes. "
            "Either the pack stands them again or the table stops reading one.")
    # The vents as the piece came out, for the page — the same reading `flank-vent-mullions` is
    # graded on, asked of the same solid after it was drawn.
    vent_read = vent_readings(pieces, box)
    plate = box.pack.collet_plate if (box.pump_bay and box.pack.collet_plate) else None
    front_runs = _z_rail_runs(box.inner, box.y_joint, "front", plate, box.pack.vent_chase)
    back_runs = _z_rail_runs(box.inner, box.y_joint, "back", plate, box.pack.vent_chase)
    front_rail_foot = abs(_rail_foot_face(front_runs[0][0], front_runs[0][1], "front")
                          - front_runs[0][0])
    front_rail_inboard = max(abs(_rail_x(x_in, sx, "front")[3] - x_in)
                              for x_in, sx, _y0, _y1, _lane in front_runs)
    back_rail_foot = abs(_rail_foot_face(back_runs[0][0], back_runs[0][1], "back")
                         - back_runs[0][0])
    back_rail_inboard = max(abs(_rail_x(x_in, sx, "back")[3] - x_in)
                             for x_in, sx, _y0, _y1, _lane in back_runs)
    # WHAT A FLANK ACTUALLY BEARS ON, which is its run less anything crossing it: the PRV
    # passage takes `vent_channel_w` of the flank it stands on (`_vent_chase`), so the two
    # back flanks do not read the same figure and the card should not say they do.
    def _borne(run):
        _x, sx, y0, y1, _lane = run
        lo, hi = min(y0, y1), max(y0, y1)
        cut = sum(vent_channel_w for cx, cy, _cz in (box.pack.vent_chase or ())
                  if (cx < 0.0) == (sx > 0.0) and lo <= cy <= hi)
        return abs(y1 - y0) - rail_stop_len - cut
    back_len = sorted(_borne(r) for r in back_runs)
    if box.pack.vent_chase:
        _vent_x, _vent_y, _vent_z = box.pack.vent_chase[0]
        vent_rib_base = _vent_x - back_top_flank_face()[0]
        vent_rib_land = ((_vent_z - vent_channel_w / 2.0)
                         - (z_seam + z_rise + vent_rib_base))
    else:
        vent_rib_base = vent_rib_land = None
    variables = {
        "SLIDE_SLIP": f"{slide_slip:g} mm",
        "PUMP_CARTRIDGE_Z_CLEARANCE": f"{pump_cartridge_z_clearance:g} mm",
        "HOOK_LAP": f"{hook_lap:g} mm",
        "FRONT_HOOK_LAP": f"{front_hook_lap:g} mm",
        "BACK_HOOK_LAP": f"{back_hook_lap:g} mm",
        "HOOK_FOOT": f"{hook_foot:g} mm",
        "Z_RISE": f"{z_rise:g} mm",
        "HOOK_NECK": f"{hook_foot + rail_catch_air('front'):g} mm",
        "BACK_HOOK_NECK": f"{hook_foot + rail_catch_air('back'):g} mm",
        "HOOK_HEAD": f"{z_rise - hook_foot - rail_catch_air('front'):g} mm",
        "BACK_HOOK_HEAD": f"{z_rise - hook_foot - rail_catch_air('back'):g} mm",
        "RAIL_REACH": f"{rail_reach_in:.1f} mm",
        "FRONT_RAIL_FOOT": f"{front_rail_foot:.4g} mm",
        "FRONT_RAIL_INBOARD": f"{front_rail_inboard:.4g} mm",
        "BACK_RAIL_FOOT": f"{back_rail_foot:.4g} mm",
        "BACK_RAIL_INBOARD": f"{back_rail_inboard:.4g} mm",
        "VENT_CHANNEL_W": f"{vent_channel_w:g} mm",
        "VENT_GROOVE_ROOF": f"{box.inner[0] - box.outer[0]:.4g} mm",
        "VENT_RIB_BASE": (f"{vent_rib_base:.4g} mm" if vent_rib_base is not None
                          else "no station"),
        "VENT_RIB_LAND": (f"{vent_rib_land:.4g} mm" if vent_rib_land is not None
                          else "no station"),
        "RAIL_RUN_FRONT": f"{_borne(front_runs[0]):.0f} mm",
        "RAIL_RUN_BACK": f"{back_len[-1]:.0f} mm",
        "RAIL_RUN_BACK_W": f"{back_len[0]:.0f} mm",
        "LOOP_CARB_1": f"{tube_anchor_tie_loop(seats[0]):.3g} mm",
        "LOOP_WR1110": f"{tube_anchor_tie_loop(seats[-1]):.3g} mm",
        "LOOP_DIGITEN": f"{tube_anchor_tie_loop(meter[2]):.3g} mm",
        "ANCHOR_SEATS": ", ".join(f"{2 * r:.4g}" for r in seats),
        "DISPLAY_FACET_X": f"{display_facet_x:.4g} mm",
        "DISPLAY_FACET_SLOPE": f"{display_facet_slope:.4g} mm",
        "DISPLAY_INSET_X": f"{display_inset_x:.4g} mm",
        "DISPLAY_INSET_SLOPE": f"{display_inset_slope:.4g} mm",
        "MQ6_CARD_T": f"{mq6_card_x:.4g} mm",
        "MQ6_SLOT_OPEN": f"{mq6_card_x + 2 * mq6_slot_press:.4g} mm",
        "COND_SLOT_OPEN": f"{box.pack.cond_cradle[0][4] - box.pack.cond_cradle[0][3] + 2 * cond_slot_press:.4g} mm",
        "COND_SLOT_GRIP": f"{cond_slot_grip:.4g} mm",
        "CORE_STOP_BORE": (f"{2.0 * (box.pack.core_stops[0][2] + core_stop_slip / 2.0):.4g} mm"
                           if box.pack.core_stops else "no station"),
        "CORE_STOP_WEB": f"{core_stop_web:.4g} mm",
        "CORE_STOP_RISE": f"{core_stop_rise:.4g} mm",
        # The block runs the wall inboard to one round past the tangent, and both are mirrored.
        "CORE_STOP_WIDE": (
            f"{interior_x()[1] - (abs(box.pack.core_stops[0][0]) - box.pack.core_stops[0][2]):.4g} mm"
            if box.pack.core_stops else "no station"),
        "CORE_HOLD_LAND": f"{core_hold_land:.4g} mm",
        "CORE_HOLD_REACH": f"{core_hold_reach:.4g} mm",
        "CORE_HOLD_RISE": f"{core_hold_rise:.4g} mm",
        "CORE_HOLD_WIDE": (f"{box.pack.core_holds[0][1] - box.pack.core_holds[0][0]:.4g} mm"
                           if box.pack.core_holds else "no station"),
        "COLUMN_ARC": f"{column_round:.3g} mm",
        # What a hand gets on a flank: the return's own section and the lane the box keeps
        # open behind it, off the exterior side face.
        "COLUMN_ALONG": f"{_column_along():.3g} mm",
        "COLUMN_DEPTH": f"{_column_depth():.3g} mm",
        "APPLIANCE_HEIGHT": f"{appliance_height:.4g} mm",
        "FUNNEL_COLLAR_AIR": f"{funnel_collar_air:.4g} mm",
        # The sections on this box that are not `wall`, and the piece each belongs to. Every
        # WALL grows INWARD off the plane the box states, so the silhouette and `interior_x`
        # both stand still and only the piece carrying the section knows about it. The FLOOR
        # is the one that does not: `appliance_height` is struck to its underside, so its
        # section stands in the silhouette and the cavity keeps its floor plane at z = 0.
        "WALL_T": f"{wall:.4g} mm",
        "FLOOR_T": f"{floor_t:.4g} mm",
        "FLUTE_COUNT": f"{flute_count:d}",
        "FLUTE_PERIM": f"{plan_perimeter(bo):.5g} mm",
        "FLUTE_PITCH": f"{flute_pitch(bo):.5g} mm",
        "COUPON_PITCH": f"{reeding.flute_pitch:.4g} mm",
        "FLUTE_WIDTH": f"{reeding.flute_width:.4g} mm",
        "FLUTE_DEPTH": f"{flute_depth:.4g} mm",
        "FLUTE_BACKING": f"{flute_backing:.4g} mm",
        "FLUTE_LEFT": f"{flute_backing - flute_depth:.4g} mm",
        "FLUTE_RISE": f"{flute_rise:.4g} mm",
        "FLUTE_STEPS": f"{flute_fade_steps:d}",
        "FLUTE_RAMP": f"{math.degrees(math.atan(1.5 * flute_depth / flute_rise)):.3g}°",
        # The bay storey's complete phase path, including its two uncut air spans.
        "STOREY_RUN": (
            f"{sum(l for _k, l, _d in _bay_storey_segments(box.inner, bo, box.pump_bay, box.pack.collet_plate)):.5g} mm"
            if box.pump_bay and box.pack.collet_plate else "no bay on this pack"),
        "STOREY_BAND": (f"{bay_storey_z(box.pump_bay)[0]:.4g}..{bay_storey_z(box.pump_bay)[1]:.4g} mm"
                        if box.pump_bay else "no bay on this pack"),
        # The condenser's own two vents, pierced down the flutes those flanks already carry.
        # Every one of these is READ OFF THE BUILT PIECE (`vent_readings`) or off the field
        # the slot was struck on, so the page and `flank-vent-mullions` quote one derivation.
        "VENT_SLOT": f"{reeding.pierce_width:.4g} mm",
        "VENT_MULLION": f"{reeding.mullion(flute_pitch(bo), reeding.pierce_width, 1):.4f} mm",
        "VENT_CEILING": f"{reeding.pierce_max(reeding.pierce_shell, flute_pitch(bo)):.4f} mm",
        "VENT_SHELL": f"{reeding.pierce_shell:.4g} mm",
        "VENT_SPARE": (
            f"{reeding.mullion(flute_pitch(bo), reeding.pierce_width, 1) - reeding.pierce_shell:.4f} mm"),
        "VENT_JAMB": (
            f"{2.0 * wall - flute_depth * float(reeding.groove(reeding.pierce_width / 2.0)):.4f} mm"),
        "VENT_OPEN_PCT": f"{100.0 * reeding.open_fraction(flute_pitch(bo), reeding.pierce_width, 1):.1f} %",
        "VENT_CLEAR": f"{cond_vent_clear:.4g} mm",
        "VENT_FLANK_T": f"{2.0 * wall:.4g} mm",
        "VENT_WINDOW": (f"{box.pack.cond_airway[0]:.4g}..{box.pack.cond_airway[1]:.4g} mm"
                        if box.pack.cond_airway else "no block"),
        "VENT_BAND": (f"{vent_band(box.pack.cond_airway)[0]:.4g}..{vent_band(box.pack.cond_airway)[1]:.4g} mm"
                      if box.pack.cond_airway else "no block"),
        "VENT_BAND_H": (f"{vent_band(box.pack.cond_airway)[1] - vent_band(box.pack.cond_airway)[0]:.4g} mm"
                        if box.pack.cond_airway else "no block"),
        "VENT_FAN_RISE": f"{cond_fan_rise:.4g} mm",
        "VENT_FAN_DROP": f"{cond_fan_drop:.4g} mm",
        "VENT_TRANSOMS": f"{cond_vent_transoms:d}",
        "VENT_TRANSOM_H": f"{cond_vent_transom_h:.4g} mm",
        "VENT_TRANSOM_Z": (", ".join(f"{(a + b) / 2.0:.4g}" for a, b in
                                     vent_transoms(box.pack.cond_airway)) + " mm"
                           if box.pack.cond_airway else "no block"),
        "VENT_SEGMENTS": f"{cond_vent_transoms + 1:d}",
        "VENT_SEGMENT": (f"{vent_segment(box.pack.cond_airway):.4g} mm"
                         if box.pack.cond_airway else "no block"),
        "VENT_GROOVES": (f"{sum(1 for sx, _y in vent_grooves(bo, box.pack.cond_airway) if sx > 0):g}"
                         if box.pack.cond_airway else "0"),
        "VENT_SLOTS_IN": (f"{len(vent_read[-1.0]['slots']):g}" if -1.0 in vent_read else "0"),
        "VENT_SLOTS_OUT": (f"{len(vent_read[1.0]['slots']):g}" if 1.0 in vent_read else "0"),
        "VENT_RUNS_IN": (f"{len(vent_read[-1.0]['runs']):g}" if -1.0 in vent_read else "0"),
        "VENT_RUNS_OUT": (f"{len(vent_read[1.0]['runs']):g}" if 1.0 in vent_read else "0"),
        "VENT_TOWER": (f"{max(r['tallest'] for r in vent_read.values()):.4g} mm"
                       if vent_read else "no vent"),
        "VENT_TOWER_IN": (f"{vent_read[-1.0]['tallest']:.4g} mm" if -1.0 in vent_read else "no vent"),
        "VENT_TOWER_OUT": (f"{vent_read[1.0]['tallest']:.4g} mm" if 1.0 in vent_read else "no vent"),
        # And what the flank's own obstruction took out of that layout, read the same way: a run
        # the sweep left SHORT of a full segment is a run something rooted on this wall stopped.
        "VENT_SHORT": ((lambda seg: f"{sum(1 for r in vent_read.values() for v in r['runs'] if v < seg - stated_bound_tol):g}")(
            vent_segment(box.pack.cond_airway)) if vent_read and box.pack.cond_airway else "0"),
        "VENT_SHORTEST": ((lambda v: f"{v:.4g} mm")(
            min(min(r["runs"]) for r in vent_read.values())) if vent_read else "no vent"),
        "VENT_ASPECT": ((lambda tall, thin: f"{tall / thin:.3g}:1")(
            max(r["tallest"] for r in vent_read.values()),
            min(min(r["mullions"]) for r in vent_read.values()))
            if vent_read else "no vent"),
        "VENT_ASPECT_BARE": ((lambda tall, thin: f"{tall / thin:.3g}:1")(
            vent_band(box.pack.cond_airway)[1] - vent_band(box.pack.cond_airway)[0],
            min(min(r["mullions"]) for r in vent_read.values()))
            if vent_read and box.pack.cond_airway else "no vent"),
        "VENT_MEAS_MULLION": (
            f"{min(min(r['mullions']) for r in vent_read.values()):.4f} mm"
            if vent_read else "no vent"),
        "VENT_OPEN_IN": (f"{vent_read[-1.0]['open_mm2'] / 100.0:.1f} cm²"
                         if -1.0 in vent_read else "no vent"),
        "VENT_OPEN_OUT": (f"{vent_read[1.0]['open_mm2'] / 100.0:.1f} cm²"
                          if 1.0 in vent_read else "no vent"),
        "FLUTE_SEAM_MISS": (
            lambda arc, pitch: f"{min(arc % pitch, pitch - arc % pitch):.2g} mm")(
                _plan_segments(bo)[0][1] + _plan_segments(bo)[1][1]
                + (y_seam - (bo[2] + corner_round)), flute_pitch(bo)),
        "FRONT_TOP_FLANK": f"{front_top_flank_t:.4g} mm",
        "BACK_TOP_FLANK": f"{back_top_flank_t:.4g} mm",
        "BACK_TOP_WALL": f"{back_top_wall_t:.4g} mm",
        # And back-top's own ceiling: the slab's section, what it adds inward of the lane, the
        # plane it presents, and the lane every station under it is struck on.
        "BACK_TOP_CEILING_T": f"{back_top_ceiling_t:.4g} mm",
        "BACK_TOP_CEILING_GROWTH": f"{back_top_ceiling_growth:.4g} mm",
        "BACK_TOP_CEILING_FACE": f"{back_top_ceiling_face():.4g}",
        "CEILING_LANE": f"{appliance_height - floor_t - wall:.4g}",
        "SEAM_SCREW_END_INSET": f"{seam_screw_end_inset:.4g} mm",
        "SEAM_SCREW_LOWER_Z": f"{_seam_lower_z(box.inner):g} mm",
        "HANDHOLD_Y": f"{handhold_y:g} mm",
        "HANDHOLD_LENGTH": f"{handhold_length:g} mm",
        "HANDHOLD_HEIGHT": f"{handhold_height + fits.supported_surface:g} mm",
        "HANDHOLD_ROOF": f"{handhold_roof:g} mm",
        "HANDHOLD_WALL": f"{handhold_wall:g} mm",
        "HANDHOLD_CORNER_R": f"{handhold_corner_r:g} mm",
        "HANDHOLD_EDGE_R": f"{handhold_edge_r:g} mm",
        "SEAM_SCREW_MIDDLE_Z": f"{_seam_middle_z():.4g} mm",
        # How much stock each grown flank stands INBOARD of the box's own interior — the room a
        # rib rooted on that piece loses, and the room its relief gives back.
        "BACK_TOP_FLANK_GROWN": f"{back_top_flank_t - wall:.4g} mm",
        "FRONT_TOP_FLANK_GROWN": f"{front_top_flank_t - wall:.4g} mm",
        "PIECE_H": f"{appliance_height - floor_t - z_seam:.4g} mm",
        # And the section a bottom piece's three lipped sides carry for free — the lip's own
        # skin carried to the slab (`_lip_underwall`), which is what the two flanks above are
        # brought level with.
        "LIP_UNDERWALL": f"{2.0 * wall:.4g} mm",
        # The Y-seam ladder as the walls came out — per wall, and one figure when they agree.
        "Y_LEVELS": "/".join(str(c) for c in sorted({
            sum(1 for _xi, _xe, s, _z in box.y_bosses
                if s == sx) for sx in (+1.0, -1.0)})),
        "BACK_SEAM_FLANK_T": f"{back_seam_flank_t():.4g} mm",
        "SEAM_PIN_SHANK": f"{seam_pin_shank_len:.4g} mm",
        "SEAM_HEATSET_DEPTH": f"{seam_heatset_depth:.4g} mm",
        "SEAM_HEATSET_RELIEF": f"{seam_heatset_relief:.4g} mm",
        "PLUG_DIA": f"{plug_dia:.4g} mm",
        "RIDGE_WALL_T": f"{ridge_wall_t:.4g} mm",
        "RIDGE_LEN": f"{display_pcb_x:.4g} mm",
        "CABLE_BORE": f"{cable_bore_dia:.4g} mm",
        "CABLE_SLEEVE_NOM": f"{cable_sleeve_nom:.4g} mm",
        "DISPLAY_LOOM_X": f"{display_loom_x_offset:+.4g} mm",
        "PUMP_JACK_Z": (f"{_ridge_stations(bo, plate, box.pump_bay)[0][2]:.5g} mm"
                        if plate else "no bay on this pack"),
        "PUMP_JACK_APERTURE": f"{_keystone.FACE_W + 2 * fits.slip:.4g} × {_keystone.FACE_H + 2 * fits.slip:.4g} mm",
        "PUMP_JACK_BOSS_REACH": f"{_keystone.DEPTH - ridge_wall_t:.4g} mm",
        "PUMP_JACK_BODY": f"{_keystone.BODY_DEPTH:.4g} mm",
        "PUMP_JACK_CLIP_LAND": f"{pump_jack_clip_edge_land:.4g} mm",
        "FLANK_CLIPS": f"{len(flank_clip_stations)}",
        "FLANK_CLIP_Y": ", ".join(
            f"{y0:.4g}–{y0 + run:.4g}" for y0, run in flank_clip_stations) + " mm",
        "FLANK_CLIP_Z": (f"{_seam_web_at(box, front_top_flank_face()[1]):.5g} mm"
                         if box.y_bosses else "this pack stands no seam socket"),
        "CABLE_CLIP_DEPTH": f"{_cable_clip.DEPTH:.4g} mm",
        "CABLE_CLIP_HEIGHT": f"{_cable_clip.HEIGHT:.4g} mm",
        "CABLE_CLIP_SEAT": f"{_cable_clip.seat_height():.4g} mm",
        "CABLE_CLIP_RUN": f"{_cable_clip.RUN:.4g} mm",
        "CABLE_CLIP_RAMP": f"{_cable_clip.RAMP:.4g} mm",
        "CABLE_CLIP_BACKING": f"{_cable_clip.BACKING:.4g} mm",
        "PAN_CLIP_WALL": f"{back_top_flank_t:.4g} mm",
        "PAN_CLIP_EMBED": f"{pan_cable_clip_embed:.4g} mm",
        "PAN_CLIP_PROUD": f"{_cable_clip.projection(pan_cable_clip_embed):.4g} mm",
        "TEARDROP_ROOF": f"{teardrop_roof_angle:.4g}°",
        "SOCKET_BORE": f"{socket_bore_dia:.4g} mm",
        "SOCKET_OD": f"{2.0 * socket_r:.4g} mm",
        "BOX_SIZE": (f"{bo[1] - bo[0]:.6g} × {bo[3] - bo[2]:.6g} × "
                     f"{bo[5] - bo[4]:.6g} mm"),
        "FRONT_WALL": f"{front_wall:.4g} mm",
        **disposal_figures(bo),
        **pump_cartridge_figures(box),
    }
    substitute_py_comments(
        Path(__file__),
        variables=variables,
    )
    substitute_md(
        _here.parent / "README.md",
        variables=variables,
    )
    print("-> README.md")


if __name__ == "__main__":
    # THIS FILE, UNDER THE NAME EVERYTHING ELSE IMPORTS IT BY. A direct run imports
    # `enclosure_assembly` inside `machine_of`; that module imports `enclosure` back and must
    # receive this same copy so the Box and the bounds ledger it fills come back to `main`.
    # The ceiling joint makes the same round trip. One name, one module, one box.
    sys.modules.setdefault(__name__ if __name__ != "__main__" else "enclosure", sys.modules[__name__])
    main()
