"""Read-only attribution of three exact, existing rear-shell collisions."""
from pathlib import Path
import hashlib,importlib.util,json,sys,time,types
import cadquery as cq
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'hardware/printed-parts/petgf.3mf').is_file())
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'hardware/scripts'),str(ROOT/'hardware/printed-parts/cadlib'),str(ROOT/'hardware/printed-parts/enclosure/enclosure')]
# The independent inlet scan has changed its live API since this wall export.
# Load the retained dependency only for this frozen-wall diagnosis; no alias or
# production source change is made and no inlet geometry is constructed.
frozen_c14=HERE/'frozen-inputs/hardware/reference/iec-c14-inlet/iec_c14_inlet.py'
spec=importlib.util.spec_from_file_location('iec_c14_inlet',frozen_c14)
c14=importlib.util.module_from_spec(spec);sys.modules['iec_c14_inlet']=c14;spec.loader.exec_module(c14)
frozen_enc=HERE/'frozen-inputs/hardware/printed-parts/enclosure/enclosure/enclosure.py'
enc=types.ModuleType('enclosure')
enc.__file__=str(ROOT/'hardware/printed-parts/enclosure/enclosure/enclosure.py')
sys.modules['enclosure']=enc
exec(compile(frozen_enc.read_bytes(),str(frozen_enc),'exec'),enc.__dict__)
import _box_spec

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bb(s):
    b=s.BoundingBox();return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def info(s):
    v=abs(s.Volume());return {'volume_mm3':v,'bounds_mm':bb(s) if v>1e-8 else None,'solid_count':len(s.Solids())}
def save(j): (HERE/'native-triage.json').write_text(json.dumps(j,indent=2)+'\n')
def seed():return cq.Solid.makeBox(1,1,1,cq.Vector(-1000,-1000,-1000))
start=time.monotonic()
wallpath=ROOT/'hardware/printed-parts/enclosure/enclosure/enclosure-back-top.step'
factspath=ROOT/'hardware/manifold-layout/enclosure-assembly.facts.json'
inputs=[wallpath,factspath,ROOT/'hardware/manifold-layout/enclosure-box.json',frozen_enc,ROOT/'hardware/reference/wago-221/wago-221-415.step',ROOT/'hardware/reference/wago-221/wago-221-420.step',ROOT/'hardware/reference/jg-bulkhead-union/jg-bulkhead-union.step',frozen_c14]
hashes={str(p.relative_to(ROOT)):sha(p) for p in inputs}
facts=json.loads(factspath.read_text())
box,_=_box_spec.read(enc.Box,enc.Bound,(enc.Pack,enc.PortField,enc.Nameplate))
print('Importing frozen native rear wall',flush=True)
wall=cq.importers.importStep(str(wallpath)).val();assert wall.isValid()
components={}
for name,size in (('wago-reeds-a','415'),('wago-reeds-b','420')):
    s=cq.importers.importStep(str(ROOT/f'hardware/reference/wago-221/wago-221-{size}.step')).val()
    s=s.rotate((0,0,0),(1,0,0),90).rotate((0,0,0),(0,1,0),90)
    b=s.BoundingBox();want=facts['bodies'][name]
    s=s.translate((want[0]-b.xmin,want[1]-b.ymin,want[2]-b.zmin))
    assert max(abs(x-y) for x,y in zip(bb(s),want))<1e-6
    components[name]=s
name='bulkhead-flavor-b'
s=cq.importers.importStep(str(ROOT/'hardware/reference/jg-bulkhead-union/jg-bulkhead-union.step')).val()
b=s.BoundingBox();want=facts['bodies'][name];s=s.translate((want[0]-b.xmin,want[1]-b.ymin,want[2]-b.zmin))
assert max(abs(x-y) for x,y in zip(bb(s),want))<1e-6
components[name]=s
clashes={}
for name,s in components.items():
    clash=wall.intersect(s);clashes[name]=clash
    print(name,info(clash),flush=True)
report={'scope':'Existing back-top, measured in the frozen canonical assembly pose; no proposed production correction yet.','input_sha256':hashes,'script_sha256':sha(Path(__file__)),'collisions':{k:info(v) for k,v in clashes.items()},'attribution':{},'stale_inlet_dependency':'The retained pre-scan IEC module supplies import constants for this frozen-wall diagnosis; no native IEC body or production alias is created.'}
save(report)
roots=enc.piece_root_faces(box.inner,'back','top')
bands=enc._piece_bands(box,'back-top');y0,y1,z0,z1=bands
features={}
for i,station in enumerate(box.pack.tube_anchors):
    p=station[0]
    if (abs(p[0]+78.07)<1e-4 and abs(p[2]-270.5740001)<1e-4):
        print('Building isolated flavor tube anchor',i,station,flush=True)
        features['fluid-28-anchor']=enc._tube_anchors(seed(),roots,box.inner,(station,),y0,y1,z0,z1,up=-1)
        report['tube_anchor_station']=station
features['core-holds']=enc._core_holds(seed(),box.inner,box.pack.core_holds,y0,y1,z0,z1,face=enc.back_top_wall_face())
features['side-wells']=enc._side_wells(seed(),box.inner,box.pack.side_wells,y0,y1,z0,z1,up=-1)
features['nameplate']=enc._nameplate(seed(),box.pack.nameplate,box.outer,box.outer[3],z0,z1,up=-1)
features['pan-sleeve']=enc._pan_sleeve(seed(),box.pack.pan_sleeve,z0,z1,up=-1)
for name,clash in clashes.items():
    rows={k:info(clash.intersect(feature)) for k,feature in features.items()}
    report['attribution'][name]=rows
    print('attribution',name,rows,flush=True)
    report['collisions'][name]['solid_components']=[info(s) for s in clash.Solids()]
    report['collisions'][name]['faces']=[{'area_mm2':f.Area(),'center_mm':f.Center().toTuple(),'type':f.geomType(),'bounds_mm':bb(f)} for f in clash.Faces()]
save(report)
rear_wells=[s for s in box.pack.side_wells if s[0]<0 and s[1]>box.y_joint and abs(s[2]-270)<1e-6]
tower_fore=min(s[1]-enc.wago_half(s[3])[0] for s in rear_wells)
candidate_y=tower_fore-1.0-enc.tube_anchor_len/2
anchor=features['fluid-28-anchor'].cut(seed())
candidate=anchor.translate((0,candidate_y-report['tube_anchor_station'][0][1],0))
tower=enc._side_wells(seed(),box.inner,rear_wells,y0,y1,z0,z1,up=-1).cut(seed())
cb=bb(candidate)
rows=[]
for name,b in facts['bodies'].items():
    if name.startswith('enclosure-') or name=='tube-fluid-28':continue
    if all(min(cb[k+3],b[k+3])-max(cb[k],b[k])>1e-8 for k in range(3)):
        block=cq.Solid.makeBox(b[3]-b[0],b[4]-b[1],b[5]-b[2],cq.Vector(*b[:3]))
        rows.append({'name':name,'body_bounds_mm':b,'anchor_intersection_with_conservative_body_box_mm3':abs(candidate.intersect(block).Volume())})
report['anchor_candidate']={'mid_y_mm':candidate_y,'full_anchor':info(candidate),'full_wago_tower_fore_y_mm':tower_fore,'full_tower_clearance_mm':candidate.distance(tower),'full_tower_overlap_mm3':abs(candidate.intersect(tower).Volume()),'placed_neighbor_box_checks':rows,'complete_stock_checked':'Complete native anchor, including both end corbels and supported-face stock; not only its tube axis.'}
print('anchor candidate',report['anchor_candidate'],flush=True)
worked_fore=min(s[1]-enc.wago_swing(s[3])/2 for s in rear_wells)
worked_y=min(tower_fore,worked_fore)-1.0-enc.tube_anchor_len/2
worked=anchor.translate((0,worked_y-report['tube_anchor_station'][0][1],0))
report['worked_lever_anchor_candidate']={'mid_y_mm':worked_y,'full_anchor':info(worked),'worked_lever_fore_y_mm':worked_fore,'full_tower_gap_mm':worked.distance(tower),'lever_envelope_y_gap_mm':worked_fore-bb(worked)[4]}
report['flavor_b_down_candidates']=[]
for dx in (0.,-.51,-1.36):
    fitting=components['bulkhead-flavor-b'].translate((dx,0,-1.55))
    row={'axis_delta_mm':[dx,0,-1.55],'bounds_mm':bb(fitting),'sleeve_overlap_mm3':abs(fitting.intersect(features['pan-sleeve']).Volume()),'sleeve_air_mm':fitting.distance(features['pan-sleeve']),'core_hold_overlap_mm3':abs(fitting.intersect(features['core-holds']).Volume()),'core_hold_air_mm':fitting.distance(features['core-holds'])}
    report['flavor_b_down_candidates'].append(row)
    print('flavor candidate',row,flush=True)
save(report)
report['input_drift']=[p for p,h in hashes.items() if sha(ROOT/p)!=h]
report['elapsed_seconds']=time.monotonic()-start
save(report)
assert not report['input_drift'],report['input_drift']
print('Done in',report['elapsed_seconds'],'s',flush=True)
