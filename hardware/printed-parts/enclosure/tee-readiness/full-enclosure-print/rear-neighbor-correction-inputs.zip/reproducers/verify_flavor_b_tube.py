"""Regenerate only the installed Flavor-B tube after the local panel offset."""
from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,inspect,json,math,sys,time
import cadquery as cq
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'hardware/printed-parts/petgf.3mf').is_file())
HERE=Path(__file__).resolve().parent
PACK=Path('/tmp/scanner-review/integration-correction/route-pack')
EXTRAS=Path('/tmp/scanner-review/integration-correction/route-neighbors')
sys.path[:0]=[str(ROOT/'hardware/manifold-layout'),str(ROOT/'hardware/scripts')]
import _lines as L, _routing as R, _boxes
start=time.monotonic();inputs={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):p=Path(p);inputs[str(p)]=sha(p);return p
def bb(s):
 b=_boxes.boxed(s);return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def vb(d):return [d[k] for k in ('xmin','ymin','zmin','xmax','ymax','zmax')]
def gap(a,b):return math.sqrt(sum(max(0,a[k]-b[k+3],b[k]-a[k+3])**2 for k in range(3)))
records=json.loads(bind(PACK/'frames.json').read_text());extras=json.loads(bind(EXTRAS/'neighbors.json').read_text());routes=json.loads(bind(PACK/'routes.json').read_text())
bind(Path(L.__file__));bind(Path(R.__file__))
F={}
for name,rec in records.items():
 if 'ports' not in rec:continue
 ports=rec['ports']
 if name=='bulkhead-flavor-b':
  ports={n:([p[0],p[1],p[2]-1.55],normal,diam) for n,(p,normal,diam) in ports.items()}
 F[name]=R.Frame(name,ports,SimpleNamespace(**rec['bbox']))
R._frames.update(F)
r=L._fluid_28(F,{})
t=R.tube(r)
report={'scope':'One production-authored installed tube on fresh port frames; lowered Flavor-B endpoint only. Endpoint hardware own engagement is excluded from neighbor collision readings.','source_sha256':inputs,'pts':r.pts,'radii':r.radii,'min_radius_mm':r.tightest,'blocked':R.BLOCKED.get(r.id),'tube_valid':t.isValid(),'tube_volume_mm3':abs(t.Volume()),'bounds_mm':bb(t),'endpoint_offset_mm':[0,0,-1.55],'native_neighbors':[],'box_clear_neighbors':[]}
print('route',r.pts,r.radii,'blocked',report['blocked'],flush=True)
report['excluded_placeholder']={'name':'stub-fluid-28','source':'enclosure_assembly.py::build_pack omits stub-* for every _lines.authored() run; manifold stub is replaced by this tube'}
rows={n:(PACK/rec['brep'],vb(rec['bbox'])) for n,rec in records.items() if n not in ('valve-v-j','bulkhead-flavor-b','stub-fluid-28')}
rows.update({n:(EXTRAS/rec['brep'],vb(rec['bbox'])) for n,rec in extras['placed'].items()})
for name,rec in routes.items():
 if name=='fluid-28':continue
 p=bind(PACK/rec['brep']);s=cq.Shape.importBrep(str(p));rows['tube-'+name]=(p,bb(s))
ab=bb(t)
for name,(p,b) in rows.items():
 lower=gap(ab,b)
 if lower>1.0:
  report['box_clear_neighbors'].append({'name':name,'box_air_lower_bound_mm':lower});continue
 s=cq.Shape.importBrep(str(bind(p)));v=abs(t.intersect(s).Volume());air=0. if v>1e-7 else t.distance(s)
 row={'name':name,'overlap_mm3':v,'air_mm':air};report['native_neighbors'].append(row);print(row,flush=True)
report['pass']=report['tube_valid'] and report['blocked'] is None and report['min_radius_mm']>=14-1e-6 and all(v['overlap_mm3']<1e-6 for v in report['native_neighbors'])
report['source_sha256']=inputs
report['route_author_ast_sha256']=hashlib.sha256(ast.dump(ast.parse(inspect.getsource(L._fluid_28)),include_attributes=False).encode()).hexdigest()
report['script_sha256']=sha(Path(__file__))
report['input_drift']=[p for p,h in inputs.items() if sha(p)!=h]
report['pass']=report['pass'] and not report['input_drift'];report['elapsed_seconds']=time.monotonic()-start
(HERE/'flavor-b-tube-check.json').write_text(json.dumps(report,indent=2)+'\n')
t.exportBrep(str(HERE/'flavor-b-lowered-tube.brep'))
print('PASS',report['pass'],'elapsed',report['elapsed_seconds'],flush=True)
