"""Bounded native rear corrections against frozen and refreshed measured solids."""
from pathlib import Path
import ast, hashlib, json, math, sys, time, types
from collections import namedtuple
import cadquery as cq
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'hardware/printed-parts/petgf.3mf').is_file())
HERE=Path(__file__).resolve().parent
PACK=Path('/tmp/scanner-review/integration-correction/route-pack')
EXTRAS=Path('/tmp/scanner-review/integration-correction/route-neighbors')
sys.path[:0]=[str(ROOT/'hardware/scripts'),str(ROOT/'hardware/printed-parts/cadlib'),str(ROOT/'hardware/printed-parts/enclosure/enclosure')]
import enclosure as enc
import _box_spec, _routing
start=time.monotonic()
inputs={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):
 p=Path(p);inputs[str(p)]=sha(p);return p

def bb(s):
 b=s.BoundingBox();return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def vb(d):return [d[k] for k in ('xmin','ymin','zmin','xmax','ymax','zmax')]
def gap(a,b):return math.sqrt(sum(max(0,a[k]-b[k+3],b[k]-a[k+3])**2 for k in range(3)))
def volume(s):return abs(s.Volume())
def info(s):return {'bounds_mm':bb(s),'volume_mm3':volume(s),'valid':s.isValid(),'solids':len(s.Solids())}
def seed():return cq.Solid.makeBox(1,1,1,cq.Vector(-1000,-1000,-1000))
def features(build,*args,**kwargs):return build(seed(),*args,**kwargs).cut(seed())
def boxshape(b):return cq.Solid.makeBox(b[3]-b[0],b[4]-b[1],b[5]-b[2],cq.Vector(*b[:3]))
def save():
 report['elapsed_seconds']=time.monotonic()-start
 (HERE/'candidate-check.json').write_text(json.dumps(report,indent=2)+'\n')

# Execute exactly the small production declaration/function region under test.
easource=bind(ROOT/'hardware/manifold-layout/enclosure_assembly.py')
tree=ast.parse(easource.read_text()); names={'CLUSTER_WAGOS','FLAVOR_B_ANCHOR_WELL_CLEAR','tube_anchor_midpoint','CORE_HOLD_LANE','PANEL_FLAVOR_B_DROP','PANEL_ON_GATE_LANE','panel_z'}
nodes=[n for n in tree.body if isinstance(n,(ast.Assign,ast.AnnAssign)) and any(isinstance(t,ast.Name) and t.id in names for t in getattr(n,'targets',[getattr(n,'target',None)])) or isinstance(n,ast.FunctionDef) and n.name in names]
ns={'_enc':enc,'math':math};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(easource),'exec'),ns)
region_hash=hashlib.sha256(ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False).encode()).hexdigest()
bind(Path(enc.__file__))
oldpath=bind(HERE/'frozen-inputs/hardware/manifold-layout/enclosure-box.json')
oldpack_fields=json.loads(oldpath.read_text())["box"]["pack"]["fields"]
OldPack=namedtuple("Pack",oldpack_fields)
old,_=_box_spec.read(enc.Box,enc.Bound,(OldPack,enc.PortField,enc.Nameplate),path=oldpath)
frames=json.loads(bind(PACK/'frames.json').read_text());routes=json.loads(bind(PACK/'routes.json').read_text());extras=json.loads(bind(EXTRAS/'neighbors.json').read_text())
inner=tuple(extras['funnel_inner']);outer=tuple(extras['funnel_outer'])
y0,y1,z0,z1=old.y_joint,inner[3],enc.z_seam,inner[5]
roots=enc.piece_root_faces(inner,'back','top')
r=routes['fluid-28']
run=_routing.Run('fluid-28','fluid',r['from'],r['to'],r['pts'],r['diam'],14.0,bends=_routing._bends(r['pts'],'fluid-28'),radii={int(k):v for k,v in r['radii'].items()})
mid=ns['tube_anchor_midpoint'](run,2)
oldstation=next(s for s in old.pack.tube_anchors if abs(s[0][0]+78.07)<1e-6 and abs(s[0][2]-270.5740001)<1e-6)
seat_r=oldstation[3]
station=(mid,(0.,1.,0.),(-1.,0.,0.),seat_r,(None,None))
anchor=features(enc._tube_anchors,roots,inner,(station,),y0,y1,z0,z1,up=-1)
rearwells=[s for s in old.pack.side_wells if s[0]<0 and s[1]>old.y_joint and abs(s[2]-270)<1e-6]
assert {tuple(s[:4]) for s in rearwells}=={(side,y,z,size) for side,y,z,size in ns['CLUSTER_WAGOS'].values() if side<0 and enc.back_top_owns((0,y,z))}
tower=features(enc._side_wells,inner,rearwells,y0,y1,z0,z1,up=-1)
lever_fore=min(y-enc.wago_swing(size)/2 for _,y,_,size,*_rest in rearwells)
well_fore=min(y-enc.wago_half(size)[0] for _,y,_,size,*_rest in rearwells)
report={'scope':'Bounded native candidate checks only; no whole-shell release or production exports. Cached foam cap features remain the prior producer at the refreshed core pose.','source_region_sha256':region_hash,'input_sha256':inputs,'anchor':{'station':station,'native':info(anchor),'tower_overlap_mm3':volume(anchor.intersect(tower)),'tower_air_mm':anchor.distance(tower),'worked_lever_y_air_mm':lever_fore-bb(anchor)[4],'full_tower_fore_y_mm':well_fore,'worked_lever_fore_y_mm':lever_fore},'flavor_b':{},'checks':[]}
save()

# Every candidate is checked against all cached bodies by conservative box first;
# only a possible contact needs an expensive native operation.
rows={}
for name,row in frames.items():rows[name]=(PACK/row['brep'],vb(row['bbox']))
for name,row in extras['placed'].items():rows[name]=(EXTRAS/row['brep'],vb(row['bbox']))
for name,row in routes.items():
 path=PACK/row['brep']
 if not path.is_file():continue
 s=cq.Shape.importBrep(str(bind(path)));rows['tube-'+name]=(path,bb(s))
cache={}
def load(name):
 if name not in cache:cache[name]=cq.Shape.importBrep(str(bind(rows[name][0])))
 return cache[name]
def read(a,b):
 ab=bb(a);total=0.;nearest=float('inf');tested=0
 # Per-solid native queries keep distant scan-envelope faces outside the solver.
 ordered=sorted(((gap(ab,bb(s)),s) for s in b.Solids()),key=lambda row:row[0])
 for lower,s in ordered:
  if lower>nearest:continue
  tested+=1; v=volume(a.intersect(s));total+=v
  nearest=min(nearest,0. if v>1e-8 else a.distance(s))
 return {'overlap_mm3':total,'air_mm':None if nearest==float('inf') else nearest,'tested_solids':tested}
def neighbors(a,exclude=()):
 ab=bb(a);results=[]
 for name,(_p,b) in rows.items():
  if name in exclude:continue
  lower=gap(ab,b)
  if lower>2.0:continue
  reading=read(a,load(name));reading.update(name=name,conservative_box_lower_bound_mm=lower);results.append(reading)
  print('neighbor',name,reading,flush=True)
 return results
report['anchor']['neighbor_native_checks']=neighbors(anchor,('tube-fluid-28',))
report['anchor']['own_tube']=read(anchor,load('tube-fluid-28'))
# The helper rejects a station outside the rounded straight.
short=types.SimpleNamespace(id='fluid-28',pts=[*run.pts[:3],(run.pts[3][0],280.,run.pts[3][2])],radii=run.radii,bends=run.bends)
try:ns['tube_anchor_midpoint'](short,2)
except ValueError:report['checks'].append({'name':'anchor rejects insufficient straight','pass':True})
else:report['checks'].append({'name':'anchor rejects insufficient straight','pass':False})
report['checks'].append({'name':'non-flavor anchor midpoint invariant','pass':ns['tube_anchor_midpoint'](types.SimpleNamespace(id='carb-1',pts=[(1,2,3),(5,8,11)]),0)==(3,5,7)})
save()

# Current pan owner confirms exact rigid +4.3Y translation with Z unchanged.
sleeve=features(enc._pan_sleeve,old.pack.pan_sleeve,z0,z1,up=-1).translate((0,4.3,0))
bulkhead=load('bulkhead-flavor-b');drop=ns['PANEL_FLAVOR_B_DROP'];flavor=bulkhead.translate((0,0,-drop))
assert abs(ns['panel_z']('bulkhead-flavor-b',330,270.5740001)-(270.5740001-drop))<1e-8
assert ns['panel_z']('bulkhead-flavor-a',330,270.5740001)==270.5740001
assert ns['panel_z']('bulkhead-carb',330,270.5740001)==330
aft=frames['foam-assembly']['bbox']['ymax'];crown=old.pack.core_holds[0][3]
oldstations=tuple((a,b,aft,crown) for a,b,_,_ in old.pack.core_holds)
lo,hi=ns['CORE_HOLD_LANE']
newstations=tuple((min(sign*lo,sign*hi),max(sign*lo,sign*hi),aft,crown) for sign in (-1.,1.))
holds=features(enc._core_holds,inner,newstations,y0,y1,z0,z1,face=enc.back_top_wall_face())
oldholds=features(enc._core_holds,inner,oldstations,y0,y1,z0,z1,face=enc.back_top_wall_face())
report['flavor_b']={'axis_delta_mm':[0,0,-1.55],'native':info(flavor),'sleeve_native':info(sleeve),'sleeve_translation_mm':[0,4.3,0],'sleeve_overlap_mm3':volume(flavor.intersect(sleeve)),'sleeve_air_mm':flavor.distance(sleeve),'hold_stations':newstations,'hold_native':info(holds),'hold_overlap_mm3':volume(flavor.intersect(holds)),'hold_air_mm':flavor.distance(holds),'hold_stock_volume_invariant':abs(volume(holds)-volume(oldholds))<1e-7,'hold_widths_mm':[b-a for a,b,_,_ in newstations],'wall_stack_before_mm':enc.back_wall_t_at(-78.07,270.5740001),'wall_stack_after_mm':enc.back_wall_t_at(-78.07,270.5740001-1.55)}
lowered_tube=cq.Shape.importBrep(str(bind(HERE/'flavor-b-lowered-tube.brep')))
report['flavor_b']['updated_tube_clearance']={n:{'overlap_mm3':volume(lowered_tube.intersect(s)),'air_mm':lowered_tube.distance(s)} for n,s in [('anchor',anchor),('pan_sleeve',sleeve),('core_holds',holds)]}
report['flavor_b']['neighbor_native_checks']=neighbors(flavor,('bulkhead-flavor-b','tube-fluid-28'))
report['flavor_b']['hold_neighbor_native_checks']=neighbors(holds,('bulkhead-flavor-b',))
# Explicit bearing-pad native stock immediately under both horizontal faces.
foam=load('foam-assembly');pads=[]
for x0,x1,aft,crown in newstations:
 p=boxshape((x0,aft-enc.core_hold_reach+1,crown-.1,x1,aft-.1,crown))
 overlap=sum(volume(p.intersect(s)) for s in foam.Solids() if gap(bb(p),bb(s))<1e-6)
 pads.append({'bounds_mm':bb(p),'probe_volume_mm3':volume(p),'native_foam_overlap_mm3':overlap,'coverage_fraction':overlap/volume(p)})
report['flavor_b']['bearing_face_native_stock']=pads
for name,condition in [('anchor tower clear',report['anchor']['tower_overlap_mm3']<1e-7),('anchor lever air at least1',report['anchor']['worked_lever_y_air_mm']>=1-1e-6),('anchor neighbors clear',all(r['overlap_mm3']<1e-6 for r in report['anchor']['neighbor_native_checks'])),('flavor sleeve air at least1',report['flavor_b']['sleeve_air_mm']>=1),('flavor hold air at least1',report['flavor_b']['hold_air_mm']>=1),('holds full9mm width',all(abs(x-9)<1e-8 for x in report['flavor_b']['hold_widths_mm'])),('hold volume invariant',report['flavor_b']['hold_stock_volume_invariant']),('hold bearings fully supported',all(p['coverage_fraction']>.9999 for p in pads)),('flavor neighbors clear',all(r['overlap_mm3']<1e-6 for r in report['flavor_b']['neighbor_native_checks'])),('hold neighbors clear',all(r['overlap_mm3']<1e-6 for r in report['flavor_b']['hold_neighbor_native_checks']))]:report['checks'].append({'name':name,'pass':condition})
report['production_region_checks']={'panel_flavor_b_drop_mm':drop,'core_hold_lane_mm':[lo,hi],'other_panel_storeys_unchanged':True}
report['checks'].append({'name':'updated tube clear of anchor sleeve and holds','pass':all(r['overlap_mm3']<1e-6 for r in report['flavor_b']['updated_tube_clearance'].values())})
native_dir=HERE/'qualified-native';native_dir.mkdir(exist_ok=True)
for name,shape in [('anchor',anchor),('wago-tower',tower),('flavor-b',flavor),('pan-sleeve',sleeve),('core-holds',holds),('flavor-b-tube',lowered_tube)]:
 path=native_dir/(name+'.brep');shape.exportBrep(str(path))
report['qualified_native']={p.name:sha(p) for p in sorted(native_dir.glob('*.brep'))}
c14=vb(extras['placed']['c14-inlet']['bbox'])
report['flavor_b']['c14_box_separation']={'c14_bounds_mm':c14,'fitting_bounds_mm':bb(flavor),'minimum_distance_lower_bound_mm':gap(c14,bb(flavor)),'no_native_query_needed':True}
report['script_sha256']=sha(Path(__file__))
report['input_drift']=[p for p,h in inputs.items() if sha(p)!=h]
report['pass']=all(r['pass'] for r in report['checks']) and not report['input_drift']
save();print(json.dumps({'pass':report['pass'],'checks':report['checks'],'flavor_b':{k:v for k,v in report['flavor_b'].items() if k not in ['neighbor_native_checks','hold_neighbor_native_checks']},'elapsed_seconds':report['elapsed_seconds']},indent=2),flush=True)
