"""Bounded native interpretation of aggregate carrier envelope findings."""
import hashlib,json,os,sys,time
from pathlib import Path
ROOT=Path('/Users/derekbredensteiner/Developer/homesodamachine')
OUT=Path('/tmp/scanner-review/front-top-triage')
os.environ['HSM_NO_BUILD_LOCK']='1'
sys.path[:0]=[str(ROOT/'hardware/scripts'),str(ROOT/'hardware/manifold-layout'),str(ROOT/'hardware/printed-parts/enclosure/tee-carrier')]
import cadquery as cq
import tee_carrier as tc
from _carrier_motion import swept_overlap
spec=tc.DEFAULT_SPEC
facts=json.loads((ROOT/'hardware/manifold-layout/enclosure-assembly.facts.json').read_text())
pack=facts['box'];interface=pack['tee_carrier'];plate=pack['collet_plate']
wall=cq.importers.importStep(str(ROOT/'hardware/printed-parts/enclosure/enclosure/enclosure-front-top.step')).val()
halves=[cq.importers.importStep(str(ROOT/f'hardware/printed-parts/enclosure/tee-carrier/enclosure-tee-carrier-{side}.step')).val() for side in ('left','right')]
carrier=cq.Compound.makeCompound(halves).translate((0,spec.release_offset_y,0))
report={'scope':'Exact current native carrier/coil/wall probes; no geometry edits','rows':[],'spec':{k:getattr(spec,k) for k in ('side_web_z0','side_web_added_y','web_aft_y','release_offset_y')}}
def bounds(s):
    if not s.Solids():return None
    b=s.BoundingBox();return {n:getattr(b,n) for n in ('xmin','ymin','zmin','xmax','ymax','zmax')}
def save(): (OUT/'carrier-envelope-triage.json').write_text(json.dumps(report,indent=2)+'\n')
def read(name,hit):
    r={'name':name,'volume_mm3':hit.Volume(),'bounds':bounds(hit)}
    report['rows'].append(r);save();print(json.dumps(r),flush=True)
    if r['volume_mm3']>1e-5:hit.exportBrep(str(OUT/(name.replace(' ','_')+'.brep')))
    return hit
def ycyl(r,x,z,y0,y1):
    return cq.Solid.makeCylinder(r,y1-y0,cq.Vector(x,y0,z),cq.Vector(0,1,0))
root=interface['fixed_seat_wall_y']-.1
cups=cq.Compound.makeCompound([ycyl(interface['fixed_seat_outer_d']/2,s['x'],s['z'],root,s['seat_mouth_y']).cut(ycyl(interface['spring_bore_d']/2,s['x'],s['z'],root-.1,s['seat_mouth_y']+.1)) for s in interface['spring_stations']])
for i,spans in enumerate(interface['tee_wells'],1):
    well=tc._box(*[x for pair in spans for x in pair]).val()
    hit=read(f'well {i} vs wall',well.intersect(wall))
    if hit.Volume()>1e-5:
        read(f'well {i} hit beyond fixed cups',hit.cut(cups))
        read(f'well {i} hit shared fixed cups',hit.intersect(cups))
report['valve_tray']={'planes':pack['valve_trays']}
report['coil_entry_y_mm']=interface['aft_valve_entry_y'];save()
cache=Path('/tmp/scanner-review/full-enclosure-current/route-pack')
for letter in 'cd':
    coil=cq.Shape.importBrep(str(OUT/f'coil-v-{letter}.brep'))
    valve=cq.Shape.importBrep(str(cache/f'valve-v-{letter}.brep'))
    dz=plate['z0']-max(coil.BoundingBox().zmax,valve.BoundingBox().zmax)-spec.slide_air
    entry_dy=interface['aft_valve_entry_y']
    actual=coil.translate((0,entry_dy,0))
    for i,comp in enumerate(coil.Solids(),1):
        b=comp.translate((0,entry_dy,0)).BoundingBox()
        swept=tc._box(b.xmin,b.xmax,b.ymin,b.ymax,b.zmin+dz,b.zmax).val()
        hit=read(f'coil {letter} component {i} bbox entry vs carrier',swept.intersect(carrier))
        if hit.Volume()>1e-5:
            hb=hit.BoundingBox()
            projection=actual.intersect(tc._box(hb.xmin-1e-5,hb.xmax+1e-5,hb.ymin-1e-5,hb.ymax+1e-5,b.zmin-1,b.zmax+1).val())
            pb=bounds(projection)
            r={'name':f'coil {letter} actual native projection in collision XY','projection_bounds':pb,'carrier_collision_floor_z':hb.zmin,'entire_upward_rise_ends_below_backing_by_mm':hb.zmin-pb['zmax'] if pb else None,'rise_z':[-abs(dz),0],'native_volume_mm3':projection.Volume()}
            report['rows'].append(r);save();print(json.dumps(r),flush=True)
    print('Native complete '+letter+' coil rise',flush=True)
    sweep=swept_overlap(coil,(0,entry_dy,dz),(0,entry_dy,0),carrier)
    report['rows'].append({'name':f'coil {letter} complete native rise vs carrier',**sweep});save();print(json.dumps(report['rows'][-1]),flush=True)
report['status']='complete';save()
