"""Read-only bounded triage of the failed full-enclosure native scorecard."""
import hashlib,json,os,sys,time
from pathlib import Path
ROOT=Path('/Users/derekbredensteiner/Developer/homesodamachine')
OUT=Path('/tmp/scanner-review/front-top-triage')
OUT.mkdir(exist_ok=True)
os.environ['HSM_NO_BUILD_LOCK']='1'
sys.path[:0]=[str(ROOT/'hardware/scripts'),str(ROOT/'hardware/manifold-layout')]
import cadquery as cq
from _cadq_export import import_assembly
COORDS=('xmin','ymin','zmin','xmax','ymax','zmax')
def bounds(s):
    b=s.BoundingBox();return {n:getattr(b,n) for n in COORDS}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'status':'running','scope':'Current frozen exported native assembly versus current canonical front-top; read-only geometry probes','inputs':{},'rows':[]}
def save(): (OUT/'native-triage.json').write_text(json.dumps(report,indent=2)+'\n')
def row(name,a,b):
    start=time.monotonic();inter=a.intersect(b);v=inter.Volume()
    r={'name':name,'intersection_mm3':v,'bounds':bounds(inter) if v>1e-8 else None,'seconds':time.monotonic()-start}
    report['rows'].append(r);save();print(json.dumps(r),flush=True)
    if v>1e-5:inter.exportBrep(str(OUT/(name.replace('/','-').replace(' ','_')+'.brep')))
    return inter
wallpath=ROOT/'hardware/printed-parts/enclosure/enclosure/enclosure-front-top.step'
wall=cq.importers.importStep(str(wallpath)).val()
report['inputs'][str(wallpath.relative_to(ROOT))]=sha(wallpath)
cache=Path('/tmp/scanner-review/full-enclosure-current/route-pack')
foam=cq.Shape.importBrep(str(cache/'foam-assembly.brep'))
report['inputs'][str(cache/'foam-assembly.brep')]=sha(cache/'foam-assembly.brep')
row('retained foam envelope vs canonical front-top',foam,wall)
for name in ('coil-v-f','coil-v-i'):
    p=cache/(name+'.brep');report['inputs'][str(p)]=sha(p)
    s=cq.Shape.importBrep(str(p));row('retained '+name+' vs canonical front-top',s,wall)
path=ROOT/'hardware/manifold-layout/enclosure-assembly.step'
report['inputs'][str(path.relative_to(ROOT))]=sha(path)
print('Loading exact named assembly STEP',flush=True)
placed=import_assembly(path)
report['named_bodies']=sorted(placed);save()
print('Named bodies: '+str(sorted(placed)),flush=True)
actualwall=placed['enclosure-front-top'][0]
row('aggregate wall extra vs canonical',actualwall,wall) # intersection agreement alongside volume; exact differences below
report['wall_native_difference_mm3']={'aggregate_extra':actualwall.cut(wall).Volume(),'canonical_extra':wall.cut(actualwall).Volume()};save()
for name in ('coil-v-f','coil-v-i','coil-v-c','coil-v-d','tube-fluid-18'):
    s=placed[name][0];s.exportBrep(str(OUT/(name+'.brep')))
    report.setdefault('current_body_bounds',{})[name]=bounds(s)
    if name in ('coil-v-f','coil-v-i','tube-fluid-18'):row('current '+name+' vs canonical front-top',s,wall)
    if (cache/(name+'.brep')).exists():
        old=cq.Shape.importBrep(str(cache/(name+'.brep')))
        report.setdefault('cache_native_differences_mm3',{})[name]={'current_extra':s.cut(old).Volume(),'cache_extra':old.cut(s).Volume()};save()
for name,(s,c) in placed.items():
    if 'foam' in name:
        report.setdefault('current_foam_bounds',{})[name]=bounds(s)
        s.exportBrep(str(OUT/(name.replace('/','-')+'.brep')))
        row('current '+name+' vs canonical front-top',s,wall)
report['status']='bounded_native_intersections_complete';save()
