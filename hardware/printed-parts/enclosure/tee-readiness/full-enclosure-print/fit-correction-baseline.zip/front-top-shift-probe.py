"""Read-only comparison of the proposed aft-row translation against retained parts."""
import json,os,sys
from pathlib import Path
ROOT=Path('/Users/derekbredensteiner/Developer/homesodamachine')
OUT=Path('/tmp/scanner-review/front-top-triage')
os.environ['HSM_NO_BUILD_LOCK']='1'
sys.path[:0]=[str(ROOT/'hardware/scripts'),str(ROOT/'hardware/printed-parts/enclosure/tee-carrier')]
import cadquery as cq
import tee_carrier as tc
from _carrier_motion import swept_overlap
facts=json.loads((ROOT/'hardware/manifold-layout/enclosure-assembly.facts.json').read_text())
I=facts['box']['tee_carrier'];spec=tc.DEFAULT_SPEC
halves={side:cq.importers.importStep(str(ROOT/f'hardware/printed-parts/enclosure/tee-carrier/enclosure-tee-carrier-{name}.step')).val() for side,name in ((-1,'left'),(1,'right'))}
carrier=cq.Compound.makeCompound(list(halves.values()))
cache=Path('/tmp/scanner-review/full-enclosure-current/route-pack')
coils={s:cq.Shape.importBrep(str(cache/f'coil-v-{s}.brep')) for s in 'cdgj'}
valves={s:cq.Shape.importBrep(str(cache/f'valve-v-{s}.brep')) for s in 'cdgj'}
rows=[]
def row(name,a,b):
    h=a.intersect(b);v=h.Volume();bb=h.BoundingBox() if v>1e-6 else None
    r={'name':name,'overlap_mm3':v,'bounds':{k:getattr(bb,k) for k in ('xmin','ymin','zmin','xmax','ymax','zmax')} if bb else None};rows.append(r)
    (OUT/'aft-row-shift-probe.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(r),flush=True)
for shift in (-4.3,-.3):
    for l in 'cdgj':
        row(f'coil {l} shift {shift} final vs released carrier',coils[l].translate((0,shift,0)),carrier)
        row(f'coil {l} shift {shift} insertion top vs released carrier',coils[l].translate((0,shift+I['aft_valve_entry_y'],0)),carrier)
    for side,half in halves.items():
        pose=(-side*spec.entry_shift_x,spec.entry_staging_y,0)
        for l in 'cdgj':
            row(f'half {side} current lowering end with coil {l} preinstalled shift {shift}',half.translate(pose),coils[l].translate((0,shift,0)))
            row(f'half {side} current lowering end with valve {l} preinstalled shift {shift}',half.translate(pose),valves[l].translate((0,shift,0)))
