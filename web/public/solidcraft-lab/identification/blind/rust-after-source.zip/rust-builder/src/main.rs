//! Builds and exports the complete packet-defined identification-chip set with hsm.
mod contours;
mod export;
mod model;

use anyhow::{Context, Result, ensure};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, path::Path};

pub fn digest_file(path: &Path) -> Result<String> {
    Ok(format!("{:x}", Sha256::digest(std::fs::read(path)?)))
}

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    ensure!(args.len() == 3, "usage: blind-identification <inputs directory> <output directory>");
    let input_dir = Path::new(&args[1]);
    let out = Path::new(&args[2]);
    let exports = out.join("exports");
    std::fs::create_dir_all(&exports)?;
    let inputs: model::Inputs = serde_json::from_slice(&std::fs::read(input_dir.join("inputs.json"))?)?;
    let artwork = inputs.sketches.iter().map(|sketch| {
        let artwork = contours::Artwork::read(&input_dir.join(&sketch.contours))?;
        ensure!(artwork.id == sketch.id, "artwork identity differs from its packet entry");
        Ok((sketch.id.clone(), artwork))
    }).collect::<Result<BTreeMap<_,_>>>()?;
    let mut parts: Vec<Value> = Vec::new();
    for part in &inputs.parts {
        let artwork = artwork.get(&part.sketch_id).context("part artwork is present")?;
        let chip = model::construct(&inputs.common, part, artwork).with_context(|| format!("Constructing {}",part.id))?;
        let record = export::write(&exports, part, &chip)?;
        println!("{}",json!({"part":part.id,"event":"complete_exports","display":record["display"],"3mf":record["print_multicolor"],"stl":record["print_exterior"]}));
        parts.push(record);
    }
    let mut source_files = vec!["Cargo.toml".to_owned(),"Cargo.lock".to_owned(),"build.sh".to_owned(),"src/main.rs".to_owned(),"src/model.rs".to_owned(),"src/contours.rs".to_owned(),"src/export.rs".to_owned(),"inputs/inputs.json".to_owned(),"inputs/released-request.json".to_owned()];
    source_files.extend(inputs.sketches.iter().map(|s| format!("inputs/{}",s.contours)));
    let sources = source_files.into_iter().map(|name| Ok(json!({"path":name,"sha256":digest_file(&out.join(&name))?}))).collect::<Result<Vec<Value>>>()?;
    let manifest = json!({
        "purpose":"This manifest identifies the editable Rust identification-chip set and its complete per-part exports.",
        "engine":"hsm-kernel","packet_manifest_sha256":"bb6ea41ff9619186b32f6dcc28146bc5213bbccce81eee81649f9c4e97486812",
        "released_request":serde_json::from_slice::<Value>(&std::fs::read(input_dir.join("released-request.json"))?)?,
        "kernel_linear_mm":hsm_kernel::LINEAR,"units":"mm",
        "coordinate_frame":{"x":"horizontal in card plane","y":"positive toward raised face","z":"vertical in card plane","back_face_y_mm":0.0},
        "export_transform":"identity; no display arrangement is applied",
        "build_command":"bash .cache/runs/solidcraft-blind-20261109/rust-builder/build.sh",
        "sources":sources,"parts":parts,
        "construction":"Original line and Bezier contours, extrema-centered and mapped into each card's local frame, extrude into the word solid. The bored card excludes this full word solid; the printable exterior unites the bored blank with the word.",
        "print_qualification":"No physical fit or physical print qualification is claimed."
    });
    std::fs::write(out.join("output-manifest.json"),serde_json::to_vec_pretty(&manifest)?)?;
    Ok(())
}
