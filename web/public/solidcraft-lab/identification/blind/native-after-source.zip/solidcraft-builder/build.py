#!/usr/bin/env python3
"""build.py authors and exports the neutral identification chips with native SolidCraft features."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
CLI = '/opt/homebrew/bin/solidcraft-cli'
PACKET = HERE.parent / 'packet'
INPUTS = HERE / 'inputs'
EXPORTS = HERE / 'exports'
SOURCES = HERE / 'sources'
LOGS = HERE / 'logs'


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def record(phase, detail, commands=None, source_paths=None, output_paths=None, **extra):
    path = HERE / 'observations.json'
    data = json.loads(path.read_text())
    data['milestones'].append(dict(utc=utc(), phase=phase, detail=detail,
        commands=commands or [], source_paths=source_paths or [],
        output_paths=output_paths or [], **extra))
    path.write_text(json.dumps(data, indent=2) + '\n')


def digest(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(HERE)), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def step(command, **params):
    return dict(command=command, params=params)


def srgb(values):
    def convert(v):
        s = 12.92 * v if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055
        return min(255, max(0, round(s * 255)))
    return [convert(v) for v in values]


def author_part(inputs, part):
    common = inputs['common']
    pid = part['id']
    sketch = next(s for s in inputs['sketches'] if s['id'] == part['sketch_id'])
    artwork = json.loads((INPUTS / sketch['contours']).read_text())
    word_bodies = ['Word' if i == 0 else f'Word ({i + 1})' for i in range(len(artwork['profiles']))]
    part_dir = EXPORTS / pid
    part_dir.mkdir(exist_ok=True)
    values = {
        'card_center_x': common['card_center_x_mm'],
        'card_width': common['card_width_mm'],
        'card_thickness': common['card_thickness_mm'],
        'card_z_min': part['z_min_mm'],
        'card_z_max': part['z_max_mm'],
        'bore_x': part['bore_center_xz_mm'][0],
        'bore_z': part['bore_center_xz_mm'][1],
        'bore_diameter': part['bore_diameter_mm'],
        'bore_overrun': common['bore_tool_overrun_mm'],
        'inlay_depth': common['lettering_inlay_depth_mm'],
        'letter_raise': common['lettering_raise_mm'],
    }
    params = [dict(name=k, expression=str(v), unit='mm') for k, v in values.items()]
    script = [
        step('file.new', name=f"{pid} {part['word']}"),
        step('component.create', name=pid),
        step('parameters.import', text=json.dumps(params)),
        step('solid.box', corner=['card_center_x - card_width / 2', 0, 'card_z_min'],
             length='card_width', width='card_thickness', height='card_z_max - card_z_min',
             operation='new', name='Card stock', body_name='Card'),
        step('solid.cylinder', base=['bore_x', '-bore_overrun', 'bore_z'], axis='Y',
             diameter='bore_diameter', height='card_thickness + 2 * bore_overrun',
             operation='cut', targets=['Card'], name='Fitting bore'),
        step('sketch.create', name='Word artwork',
             plane=dict(origin=[0, 0, part['word_center_z_mm']], x_dir=[-1, 0, 0], y_dir=[0, 0, 1])),
        step('sketch.insert_svg', path=str(INPUTS / sketch['svg']), align='center',
             scale=common['lettering_em_mm'] / artwork['em_mm']),
        step('sketch.finish'),
        step('solid.extrude', sketch='Word artwork', operation='new',
             start_offset='card_thickness - inlay_depth', distance='inlay_depth + letter_raise',
             name='Word inlay and relief', body_name='Word'),
        step('solid.combine', target='Card', tools=word_bodies, operation='cut', keep_tools=True),
        step('appearance.assign', bodies=['Card'], color=srgb(part['card_linear_rgb'])),
        step('appearance.assign', bodies=word_bodies, color=srgb(part['word_linear_rgb'])),
        step('document.inspect', measure=True, sketch_counts=True),
        step('file.save', path=str(SOURCES / f'{pid}.sc'), cache=True, preview=True),
        step('file.export', path=str(part_dir / f'{pid}.3mf'), format='3mf', quality='finest', objects='component'),
        step('file.export_obj', path=str(part_dir / f'{pid}.obj'), quality='finest'),
        step('solid.combine', target='Card', tools=word_bodies, operation='join', keep_tools=False),
        step('body.rename', body='Card', name='Exterior'),
        step('inspect.measure'),
        step('file.export_stl', path=str(part_dir / f'{pid}.stl'), quality='finest'),
    ]
    path = SOURCES / f'{pid}.json'
    path.write_text(json.dumps(dict(commands=script), indent=2) + '\n')
    return dict(id=pid, word=part['word'], sketch_id=part['sketch_id'],
        native_document=str((SOURCES / f'{pid}.sc').relative_to(HERE)),
        authoring_script=str(path.relative_to(HERE)),
        display_geometry=str((part_dir / f'{pid}.3mf').relative_to(HERE)),
        display_obj=str((part_dir / f'{pid}.obj').relative_to(HERE)),
        display_materials=str((part_dir / f'{pid}.mtl').relative_to(HERE)),
        multicolor_print_3mf=str((part_dir / f'{pid}.3mf').relative_to(HERE)),
        fused_print_stl=str((part_dir / f'{pid}.stl').relative_to(HERE)),
        material_bodies=dict(card=['Card'], word=word_bodies),
        color_srgb8=dict(card=srgb(part['card_linear_rgb']), word=srgb(part['word_linear_rgb'])),
        export_transform=[1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0],
        artwork_placement=dict(sketch_origin=[0, 0, part['word_center_z_mm']],
            x_dir=[-1, 0, 0], y_dir=[0, 0, 1], svg_alignment='center',
            scale=common['lettering_em_mm'] / artwork['em_mm']))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--author-only', action='store_true')
    parser.add_argument('--part', choices=[f'p{i:02}' for i in range(1, 7)])
    args = parser.parse_args()
    for directory in (INPUTS / 'sketches', EXPORTS, SOURCES, LOGS):
        directory.mkdir(parents=True, exist_ok=True)
    if not (INPUTS / 'inputs.json').exists():
        for rel in ['inputs.json', 'brief.md', 'manifest.json']:
            shutil.copyfile(PACKET / rel, INPUTS / rel)
        for sketch_path in (PACKET / 'sketches').iterdir():
            shutil.copyfile(sketch_path, INPUTS / 'sketches' / sketch_path.name)
    inputs = json.loads((INPUTS / 'inputs.json').read_text())
    manifest = dict(purpose='This manifest names the editable SolidCraft sources and local-frame display and print exports.',
        engine='SolidCraft', engine_version='0.40.0-rc.3',
        packet_manifest_sha256=hashlib.sha256((INPUTS / 'manifest.json').read_bytes()).hexdigest(),
        coordinate_frame=inputs['coordinate_frame'], export_units='mm',
        export_quality='finest', native_documents='container with evaluated model cache and preview',
        reproduction_command=f'python3 tools/run.py -- python3 {HERE.relative_to(Path.cwd())}/build.py',
        parts=[])
    selected = [p for p in inputs['parts'] if args.part is None or p['id'] == args.part]
    for part in selected:
        manifest['parts'].append(author_part(inputs, part))
    record('initial_source_authoring', 'Authored the complete selected part source as native boxes, cylinder bore cuts, exact editable SVG sketches, lettering extrusions and material-separating booleans.',
        source_paths=['build.py', 'inputs/inputs.json'] + [p['authoring_script'] for p in manifest['parts']])
    if args.author_only:
        print(json.dumps(manifest, indent=2))
        return
    for part in manifest['parts']:
        cmd = [CLI, 'run', str(HERE / part['authoring_script']), '--json-out', str(LOGS / f"{part['id']}-results.json"), '--results', '--timings']
        started = time.monotonic()
        record('geometry_start', f"Generate and export {part['id']}.", commands=[cmd], source_paths=[part['authoring_script']])
        with (LOGS / f"{part['id']}.log").open('w') as log:
            result = subprocess.run(cmd, cwd=Path.cwd(), stdout=log, stderr=subprocess.STDOUT)
        elapsed = time.monotonic() - started
        if result.returncode:
            record('failure', f"SolidCraft exited while generating {part['id']}.", commands=[cmd], returncode=result.returncode, elapsed_s=elapsed, output_paths=[f"logs/{part['id']}.log"])
            raise SystemExit(f"SolidCraft failed for {part['id']}; inspect logs/{part['id']}.log")
        paths = list(dict.fromkeys(part[k] for k in ('native_document', 'authoring_script', 'display_geometry', 'display_obj', 'display_materials', 'multicolor_print_3mf', 'fused_print_stl')))
        part['files'] = [digest(HERE / p) for p in paths]
        part['build_elapsed_s'] = elapsed
        record('part_exports_complete', f"Native material bodies, colored meshes and fused exterior exported for {part['id']}.", elapsed_s=elapsed, source_paths=[part['native_document'], part['authoring_script']], output_paths=paths)
        print(f"{part['id']}: complete in {elapsed:.3f}s", flush=True)
    manifest['completed_utc'] = utc()
    manifest['reproduction_inputs'] = [digest(p) for p in sorted(INPUTS.rglob('*')) if p.is_file()]
    manifest['authoring_program'] = digest(HERE / 'build.py')
    target = HERE / ('output-manifest.json' if args.part is None else f"{args.part}-output-manifest.json")
    target.write_text(json.dumps(manifest, indent=2) + '\n')
    record('baseline_exports_complete', 'All selected editable native documents and required exports exist; awaiting review.', output_paths=[target.name])
    print(target, flush=True)


if __name__ == '__main__':
    main()
