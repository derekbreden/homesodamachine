#!/bin/bash
# Rebuilds the packet-defined Rust baseline through the shared host scheduler.
set -euo pipefail
task_dir="$(cd "$(dirname "$0")" && pwd)"
repo_dir="$(cd "$task_dir/../../../.." && pwd)"
cd "$repo_dir"
export CARGO_TARGET_DIR="$repo_dir/tools/hsm/target"
exec python3 tools/run.py -- cargo run --release --offline --locked -j2 \
  --manifest-path "$task_dir/Cargo.toml" -- "$task_dir/inputs" "$task_dir"
