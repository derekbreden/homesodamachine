//! Exports preserve the colored material solids and fuse their printable exterior separately.
use anyhow::Result;
use hsm_kernel::{Body, Solid};
use serde_json::{Value, json};
use std::fmt::Write;
use std::path::Path;
use crate::{model::{Chip, Part}, digest_file};

fn xml(text: &str) -> String {
    text.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn display_color(linear: [f64; 3]) -> String {
    let mut color = String::from("#");
    for c in linear {
        let c = if c <= 0.0031308 { 12.92 * c } else { 1.055 * c.powf(1.0 / 2.4) - 0.055 };
        write!(color, "{:02X}", (c.clamp(0.0, 1.0) * 255.0).round() as u8).unwrap();
    }
    color.push_str("FF");
    color
}

fn material_3mf(bodies: &[Body], name: &str) -> Result<Vec<u8>> {
    let mut resources = String::from(r#"<basematerials id="1">"#);
    for body in bodies {
        write!(resources, r#"<base name="{}" displaycolor="{}"/>"#, xml(body.name), display_color(body.color.unwrap()))?;
    }
    resources.push_str("</basematerials>");
    let mut components = String::new();
    for (i, body) in bodies.iter().enumerate() {
        let id = i + 2;
        let solid = body.solid.simplified()?;
        write!(resources, r#"<object id="{id}" type="model" name="{}" pid="1" pindex="{i}"><mesh><vertices>"#, xml(body.name))?;
        for p in solid.verts() { write!(resources, r#"<vertex x="{:.9}" y="{:.9}" z="{:.9}"/>"#, p.x, p.y, p.z)?; }
        resources.push_str("</vertices><triangles>");
        for t in solid.tris() { write!(resources, r#"<triangle v1="{}" v2="{}" v3="{}"/>"#, t[0], t[1], t[2])?; }
        resources.push_str("</triangles></mesh></object>");
        write!(components, r#"<component objectid="{id}"/>"#)?;
    }
    let assembly = bodies.len() + 2;
    write!(resources, r#"<object id="{assembly}" type="model" name="{}"><components>{components}</components></object>"#, xml(name))?;
    let model = format!(r#"<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><resources>{resources}</resources><build><item objectid="{assembly}"/></build></model>"#);
    let types = r#"<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>"#;
    let rels = r#"<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>"#;
    Ok(hsm_kernel::write::zip(&[("[Content_Types].xml", types.as_bytes()), ("_rels/.rels", rels.as_bytes()), ("3D/3dmodel.model", model.as_bytes())]))
}

fn solid_report(solid: &Solid) -> Value {
    let bounds = solid.bounds();
    json!({"min_mm":bounds.min.to_array(),"max_mm":bounds.max.to_array(),"volume_mm3":solid.volume(),"triangles":solid.tris().len(),"components":solid.components().len()})
}

pub fn write(dir: &Path, part: &Part, chip: &Chip) -> Result<Value> {
    let bodies = [
        Body { name: "card", color: Some(part.card_linear_rgb), solid: &chip.card },
        Body { name: "word", color: Some(part.word_linear_rgb), solid: &chip.word },
    ];
    let shown = hsm_kernel::part::write_shown(dir, &part.id, &bodies)?;
    let threemf = format!("{}.3mf", part.id);
    let stl = format!("{}.stl", part.id);
    std::fs::write(dir.join(&threemf), material_3mf(&bodies, &part.id)?)?;
    hsm_kernel::write_stl(dir.join(&stl), &[&chip.exterior])?;
    let mut files = shown["files"].as_array().unwrap().iter().map(|v| v.as_str().unwrap().to_owned()).collect::<Vec<_>>();
    files.extend([threemf.clone(),stl.clone()]);
    let outputs = files.into_iter().map(|name| {
        let path = dir.join(&name);
        Ok(json!({"path":format!("exports/{name}"),"bytes":std::fs::metadata(&path)?.len(),"sha256":digest_file(&path)?}))
    }).collect::<Result<Vec<Value>>>()?;
    Ok(json!({
        "id":part.id,"word":part.word,"sketch_id":part.sketch_id,
        "source_files":["src/main.rs","src/model.rs","src/contours.rs","src/export.rs","inputs/inputs.json",format!("inputs/sketches/{}.json",part.sketch_id)],
        "display":format!("exports/{}.step.mesh",part.id),"print_multicolor":format!("exports/{threemf}"),"print_exterior":format!("exports/{stl}"),
        "outputs":outputs,"local_to_export_transform":[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],
        "materials":[{"name":"card","linear_rgb":part.card_linear_rgb},{"name":"word","linear_rgb":part.word_linear_rgb}],
        "geometry":{"card":solid_report(&chip.card),"word":solid_report(&chip.word),"exterior":solid_report(&chip.exterior),"source_artwork_exact_bounds":chip.artwork_bounds,"source_counter_count":chip.counters}
    }))
}
