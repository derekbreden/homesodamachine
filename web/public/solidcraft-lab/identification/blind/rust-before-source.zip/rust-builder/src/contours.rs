//! Original artwork contours provide editable exact curves and their extrema-centered mapping.
use anyhow::{Context, Result};
use hsm_kernel::{Loop, Profile, Seg, V2, v2};
use serde::Deserialize;
use std::path::Path;

#[derive(Clone, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Curve {
    Line([[f64; 2]; 2]),
    Quad([[f64; 2]; 3]),
    Cubic([[f64; 2]; 4]),
}

#[derive(Deserialize)]
pub struct Outline {
    outer: Vec<Curve>,
    holes: Vec<Vec<Curve>>,
}

#[derive(Deserialize)]
pub struct Artwork {
    pub id: String,
    pub em_mm: f64,
    profiles: Vec<Outline>,
}

fn evaluate(points: &[[f64; 2]], t: f64, axis: usize) -> f64 {
    let mut held: Vec<f64> = points.iter().map(|p| p[axis]).collect();
    for count in (1..held.len()).rev() {
        for i in 0..count {
            held[i] = held[i] * (1.0 - t) + held[i + 1] * t;
        }
    }
    held[0]
}

impl Curve {
    fn points(&self) -> &[[f64; 2]] {
        match self {
            Self::Line(p) => p,
            Self::Quad(p) => p,
            Self::Cubic(p) => p,
        }
    }

    fn extrema(&self, axis: usize) -> Vec<f64> {
        let p = self.points();
        let mut roots = Vec::new();
        match self {
            Self::Line(_) => {}
            Self::Quad(_) => {
                let d = p[0][axis] - 2.0 * p[1][axis] + p[2][axis];
                if d.abs() > f64::EPSILON {
                    roots.push((p[0][axis] - p[1][axis]) / d);
                }
            }
            Self::Cubic(_) => {
                let a = -p[0][axis] + 3.0 * p[1][axis] - 3.0 * p[2][axis] + p[3][axis];
                let b = 2.0 * (p[0][axis] - 2.0 * p[1][axis] + p[2][axis]);
                let c = p[1][axis] - p[0][axis];
                if a.abs() <= f64::EPSILON {
                    if b.abs() > f64::EPSILON { roots.push(-c / b); }
                } else {
                    let discriminant = b * b - 4.0 * a * c;
                    if discriminant >= 0.0 {
                        let d = discriminant.sqrt();
                        roots.extend([(-b - d) / (2.0 * a), (-b + d) / (2.0 * a)]);
                    }
                }
            }
        }
        let mut values = vec![p[0][axis], p[p.len() - 1][axis]];
        values.extend(roots.into_iter().filter(|t| *t > 0.0 && *t < 1.0).map(|t| evaluate(p, t, axis)));
        values
    }

    fn mapped(&self, map: impl Fn([f64; 2]) -> V2) -> Seg {
        match *self {
            Self::Line([a, b]) => Seg::Line { a: map(a), b: map(b) },
            Self::Quad([a, c, b]) => Seg::Quad { a: map(a), c: map(c), b: map(b) },
            Self::Cubic([a, c1, c2, b]) => Seg::Cubic { a: map(a), c1: map(c1), c2: map(c2), b: map(b) },
        }
    }
}

impl Artwork {
    pub fn read(path: &Path) -> Result<Self> {
        serde_json::from_slice(&std::fs::read(path)?).with_context(|| format!("Reading artwork {}", path.display()))
    }

    pub fn bounds(&self) -> [[f64; 2]; 2] {
        let mut bounds = [[f64::INFINITY; 2], [f64::NEG_INFINITY; 2]];
        for outline in &self.profiles {
            for curve in outline.outer.iter().chain(outline.holes.iter().flatten()) {
                for axis in 0..2 {
                    for value in curve.extrema(axis) {
                        bounds[0][axis] = bounds[0][axis].min(value);
                        bounds[1][axis] = bounds[1][axis].max(value);
                    }
                }
            }
        }
        bounds
    }

    pub fn profiles(&self, em: f64, center_z: f64) -> Result<Vec<Profile>> {
        let bounds = self.bounds();
        let center = [(bounds[0][0] + bounds[1][0]) / 2.0, (bounds[0][1] + bounds[1][1]) / 2.0];
        let scale = em / self.em_mm;
        let map = |p: [f64; 2]| v2(-(p[0] - center[0]) * scale, (p[1] - center[1]) * scale + center_z);
        let mapped_loop = |curves: &[Curve]| Loop::new(curves.iter().map(|c| c.mapped(map)).collect());
        self.profiles.iter().map(|outline| {
            let mut profile = Profile::new(mapped_loop(&outline.outer)?);
            for hole in &outline.holes { profile = profile.with_hole(mapped_loop(hole)?); }
            Ok(profile)
        }).collect()
    }

    pub fn counter_count(&self) -> usize {
        self.profiles.iter().map(|p| p.holes.len()).sum()
    }
}
