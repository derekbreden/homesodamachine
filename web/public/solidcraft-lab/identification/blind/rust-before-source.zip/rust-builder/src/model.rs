//! Packet parameters construct the bored card and the full-depth contrasting word in their local frame.
use anyhow::Result;
use hsm_kernel::{Plane, Profile, Solid, v2, v3};
use serde::Deserialize;
use crate::contours::Artwork;

#[derive(Deserialize)]
pub struct Common {
    pub card_center_x_mm: f64,
    pub card_width_mm: f64,
    pub card_thickness_mm: f64,
    pub bore_tool_overrun_mm: f64,
    pub lettering_em_mm: f64,
    pub lettering_inlay_depth_mm: f64,
    pub lettering_raise_mm: f64,
}

#[derive(Deserialize)]
pub struct Part {
    pub id: String,
    pub word: String,
    pub sketch_id: String,
    pub z_min_mm: f64,
    pub z_max_mm: f64,
    pub bore_center_xz_mm: [f64; 2],
    pub bore_diameter_mm: f64,
    pub word_center_z_mm: f64,
    pub card_linear_rgb: [f64; 3],
    pub word_linear_rgb: [f64; 3],
}

#[derive(Deserialize)]
pub struct Sketch {
    pub id: String,
    pub contours: String,
}

#[derive(Deserialize)]
pub struct Inputs {
    pub common: Common,
    pub parts: Vec<Part>,
    pub sketches: Vec<Sketch>,
}

pub struct Chip {
    pub card: Solid,
    pub word: Solid,
    pub exterior: Solid,
    pub artwork_bounds: [[f64; 2]; 2],
    pub counters: usize,
}

pub fn construct(common: &Common, part: &Part, artwork: &Artwork) -> Result<Chip> {
    let card_section = Profile::rect(
        v2(common.card_center_x_mm, (part.z_min_mm + part.z_max_mm) / 2.0),
        common.card_width_mm, part.z_max_mm - part.z_min_mm,
    );
    let blank = Plane::XZ.extrude(&card_section, -common.card_thickness_mm)?;
    let overrun = common.bore_tool_overrun_mm;
    let bore = Solid::cylinder(
        v3(part.bore_center_xz_mm[0], -overrun, part.bore_center_xz_mm[1]),
        v3(0.0, 1.0, 0.0), part.bore_diameter_mm / 2.0,
        common.card_thickness_mm + 2.0 * overrun,
    )?;
    let blank = blank.cut(&bore)?;
    let inlay_back = common.card_thickness_mm - common.lettering_inlay_depth_mm;
    let word_depth = common.lettering_inlay_depth_mm + common.lettering_raise_mm;
    let word_plane = Plane::XZ.at(v3(0.0, inlay_back, 0.0));
    let profiles = artwork.profiles(common.lettering_em_mm, part.word_center_z_mm)?;
    let letters = profiles.iter().map(|p| word_plane.extrude(p, -word_depth)).collect::<Result<Vec<_>>>()?;
    let word = Solid::union_all(&letters)?;
    let card = blank.cut(&word)?;
    let exterior = blank.union(&word)?;
    Ok(Chip { card, word, exterior, artwork_bounds: artwork.bounds(), counters: artwork.counter_count() })
}
