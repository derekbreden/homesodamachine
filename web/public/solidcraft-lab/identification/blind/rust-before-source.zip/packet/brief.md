# Identification chips

Create editable source geometry for the complete standalone part set in `inputs.json`.
All dimensions and colors are defined there. The enclosure is outside this task.

Each part has a rectangular card with square corners, a through bore on its fitting
axis, and a contrasting raised word. Keep every part in its own stated local frame.
The card's X bounds are symmetric about `common.card_center_x_mm`.
Parts with the same word still have their own card bounds, bore and word placement.

Model the full material separation: the card excludes the word throughout the
specified inlay depth; the word fills that recess and stands above the card face.
The union is the printable exterior. Export each part's complete colored model and
its fused printable exterior. Retain editable design source for the part set.

The supplied SVG sketches and original contour JSON describe identical lettering.
The JSON uses original upward sketch coordinates; the SVG uses centered physical
millimeter coordinates and normal downward SVG Y. `inputs.json` gives the mapping
into the part frame. Use the original contours, including their counters and curve
control points, without substituting a local font. The typeface metadata documents
the artwork. The contours define its exact shape.

The neutral reference files, when listed in `references/index.json`, are comparison
evidence only. Do not use imported reference meshes or solids as modeled source
geometry. Their tessellation is a finite approximation; the scalar inputs and
vector contours define the requirements.

Use only this packet as part-design input. General modeling tools and their API
documentation may be read. Do not inspect project history, production part source,
existing studies or other experiment outputs. Choose the construction you consider
appropriate for the stated parts and preserve its editable source.
