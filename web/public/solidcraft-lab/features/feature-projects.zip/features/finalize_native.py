"""finalize_native.py preserves native readback and replayable command histories for these fixtures."""
from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent
out=[]
for name in ['boss-base','boss-axis-shift']:
 cmd=['solidcraft-cli','eval',str(p/'boss-axis-native-query.json'),'--in',str(p/(name+'.sc')),'--json-out',str(p/(name+'-native-axis-results.json'))]
 r=subprocess.run(cmd,capture_output=True,text=True)
 out.append({'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 print(name,'native axis',r.returncode,r.stderr,flush=True)
for name in ['boss-base','boss-axis-shift','boss-attached','boss-height-edit','boss-position-edit','rim-shell','rim-shell-edit','snap','snap-edit']:
 cmd=['solidcraft-cli','script',str(p/(name+'.sc')),'--out',str(p/(name+'-history.json'))]
 r=subprocess.run(cmd,capture_output=True,text=True)
 out.append({'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 print(name,'history',r.returncode,r.stderr,flush=True)
(p/'finalize-outcomes.json').write_text(json.dumps(out,indent=2)+'\n')
