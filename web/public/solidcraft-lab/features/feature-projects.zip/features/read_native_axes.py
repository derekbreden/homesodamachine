"""read_native_axes.py preserves native readback and replayable command histories for these fixtures."""
from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent
out=[]
for name in ['boss-base','boss-axis-shift']:
 cmd=['solidcraft-cli','run',str(p/'boss-axis-native-query.json'),'--results','--in',str(p/(name+'.sc')),'--json-out',str(p/(name+'-native-axis-results.json'))]
 r=subprocess.run(cmd,capture_output=True,text=True)
 out.append({'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 print(name,'native axis',r.returncode,r.stderr,flush=True)
(p/'native-axis-outcomes.json').write_text(json.dumps(out,indent=2)+'\n')
