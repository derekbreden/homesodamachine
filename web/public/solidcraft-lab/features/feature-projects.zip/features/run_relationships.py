"""run_relationships.py writes the selected native enclosure feature fixtures and their readback."""
from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent
outcomes=[]
for name, prior in [('boss-attached',None),('boss-height-edit','boss-attached'),('boss-wall-edit','boss-attached'),('boss-position-edit','boss-attached')]:
 cmd=['solidcraft-cli','run',str(p/(name+'.json'))]
 if prior:cmd+=['--in',str(p/(prior+'.sc'))]
 cmd+=['--save',str(p/(name+'.sc')),'--out',str(p/(name+'.3mf')),'--out',str(p/(name+'.stl')),'--results','--json-out',str(p/(name+'-results.json'))]
 r=subprocess.run(cmd,capture_output=True,text=True)
 outcomes.append({'probe':name,'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 (p/'relationship-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 print(name,r.returncode,r.stderr,flush=True)
