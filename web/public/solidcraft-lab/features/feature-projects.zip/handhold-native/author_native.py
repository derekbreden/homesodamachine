"""author_native.py writes the editable native handhold corbel from the frozen interfaces."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKET = ROOT.parent / "packet" / "inputs.json"
INPUTS = json.loads(PACKET.read_text())
HANDHOLD = INPUTS["handhold"]
STOCK = INPUTS["stock"]


def command(command_id, **params):
    return {"command": command_id, "params": params}


def add_parameter(commands, name, expression, unit="mm", favorite=False, comment=""):
    commands.append(command("parameters.add", name=name, expression=expression, unit=unit, favorite=favorite, comment=comment))


def base_commands():
    commands = [command("file.new", name="Handhold native circular sections")]
    values = {
        "stock_depth": STOCK["max"][0] - STOCK["min"][0],
        "stock_width": STOCK["max"][1] - STOCK["min"][1],
        "stock_height": STOCK["max"][2] - STOCK["min"][2],
        "opening_width": HANDHOLD["y"][1] - HANDHOLD["y"][0],
        "roof": HANDHOLD["roof"],
        "mouth_radius": HANDHOLD["radius"],
        "corner_radius": HANDHOLD["corner"],
        "cutter_depth": HANDHOLD["cutter_depth"],
        "cutter_floor": -10.0,
    }
    for name, value in values.items():
        add_parameter(commands, name, value, favorite=True)
    add_parameter(commands, "roof_slope", HANDHOLD["slope"], unit="", favorite=True)
    commands.append(command("solid.box", length="stock_depth", width="stock_width", height="stock_height", corner=[0, "-stock_width / 2", 0], operation="new", name="Supporting stock", body_name="Stock"))
    return commands


def section(commands, name, depth, expansion):
    add_parameter(commands, name + "_depth", depth)
    add_parameter(commands, name + "_expansion", expansion)
    add_parameter(commands, name + "_top", "roof + mouth_radius - " + name + "_depth / roof_slope")
    add_parameter(commands, name + "_radius", "corner_radius + " + name + "_expansion")
    commands.append(command("sketch.create", plane="YZ", offset=name + "_depth", name=name))
    commands.append(command("sketch.rectangle.two_point", p0=["-opening_width / 2 - " + name + "_expansion", "cutter_floor"], p1=["opening_width / 2 + " + name + "_expansion", name + "_top"]))
    commands.append(command("sketch.fillet", points=[{"a": "l2", "b": "l3"}, {"a": "l3", "b": "l4"}], radius=name + "_radius"))
    commands.append(command("sketch.finish"))
    return {"sketch": name}


def author():
    commands = base_commands()
    commands[0]["params"]["name"] = "Handhold native corbel"
    mouth = section(commands, "MouthSection", "0 mm", "mouth_radius")
    inner = section(commands, "InnerSection", "mouth_radius", "0 mm")
    commands.append(command("solid.loft", sections=[mouth, inner], operation="new", name="Ruled mouth transition", body_name="MouthAir"))
    rear = section(commands, "RearSection", "cutter_depth", "0 mm")
    commands.append(command("solid.loft", sections=[inner, rear], operation="join", targets=["MouthAir"], name="Constant-radius sloping roof"))
    commands.append(command("solid.combine", target="Stock", tools=["MouthAir"], operation="cut"))
    commands.append(command("appearance.assign", bodies=["Stock"], color="#7ba9c7"))
    commands.append(command("browser.visibility", folder="sketches", visible=False))
    commands.append(command("view.save", name="Mouth oblique", camera={"target": [7, 0, 23.625], "yaw": 1.1, "pitch": 0.35, "distance": 170, "fov": 0}))
    commands.append(command("document.inspect", measure=True, sketch_counts=True))
    return {"commands": commands}


if __name__ == "__main__":
    (ROOT / "native-ruled.json").write_text(json.dumps(author(), indent=2) + "\n")
