This study evaluates native editable mechanical features for the handhold corbel.

The retained candidate is `native-ruled.sc`. Its source command history is `native-ruled.json`, authored by `author_native.py` from the frozen interface packet. The display mesh, fused exterior and retained views use the same basename. `results.json` holds measured dimensions, timings, hashes and the bounded trial results.

The construction uses supporting stock and constrained mouth, inner and rear profiles. Each profile is a native rectangle with tangent equal-radius sketch fillets at its upper corners. Native lofts form a chamfered mouth with conical end transitions and an inward-sloping rear roof. A native cut opens the stock. The profile planes, dimensions, radii and stock remain editable parameters and features. No imported reference mesh, sampled contour or custom depth-variation function defines the candidate.

The mouth is intentionally formed by planar chamfers and conical end transitions. Its corners are rounded in the opening plane; its side walls have a deliberate chamfer across depth. The roof supports normal-layer printing geometrically, and the stock envelope and inner wall are retained. The native validation, export topology, slope measurement and a bounded dimension edit succeed. Physical fit, print behavior and strength remain untested.

The direct draft-and-rolling-fillet trial retains its last successful state in `direct-roof-only.sc`. Its optional mouth round is refused where the selected vertical edge continues tangentially into an unselected roof-round edge. Its exact command and error are retained. The recommended construction avoids that operation.

The native container is the edit path. `native-edit-parameters.json` records authoritative parameter names, units, defaults and edited values read directly from the retained containers. The edited container has its own display mesh, fused exterior and oblique view.

This is a bounded rectangular feature fixture. It does not replace a quadrant or include the enclosure's adjacent seams, fluting or assembly attachments. The production reference supplies context rather than an equality target.
