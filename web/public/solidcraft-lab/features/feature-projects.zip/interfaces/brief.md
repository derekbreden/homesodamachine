# Native handhold construction

This packet defines the active handhold opening and a bounded wall fixture around it. Build a functional native SolidCraft version using the construction that best serves fit, appearance, editing and performance. Preserve editable dimensions, curves and feature history.

The local frame and source interfaces are in `inputs.json`. The roof slopes inward; its supporting stock and finger room matter. The recorded legacy section law and Rust shape provide context. They are not an equality oracle: an intentional native transition may differ where it looks right and works right.

Retain the envelope and attachment interfaces, useful hand space, an inward printable corbel and sound roof/end/inner-wall stock. Choose native features that capture those requirements. Record meaningful changes and real editing behavior, without forcing the old sampled geometry into the native design.

Retain an evaluated native container, editable source, colored mesh export and printable exterior. This study changes no production geometry and submits no print.
